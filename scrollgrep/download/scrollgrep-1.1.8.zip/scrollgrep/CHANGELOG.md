# Changelog

All notable changes to Scrollgrep: Terminal Filter.

## 1.1.8 (2026-11-20)

The first release. The builds before it (1.0.0 to 1.1.7) were never published.

Free:
- Live filter for the Terminal tab you are in: plain text or `grep -E` patterns, Match case, Words, Regex (grep -E) and
  Invert, a match count, and results that keep arriving while the command runs.
- Matching lines stay in the panel after the Terminal trims its own history (up to 32 MB and 200,000 lines per tab by
  default; Settings | Tools | Scrollgrep). A panel opened after a long run says how many lines the Terminal had already
  dropped, and to open the panel before the run to keep what the Terminal drops later.
- A plain-text pattern such as `a|b` that finds nothing offers to turn Regex on.
- A line whose match would sit past the panel's right edge is shown from the start of the word just before the match;
  hover over any line wider than the panel for the whole line.
- On IDE 2026.3, output the Terminal skipped (its Ghostty emulator) is marked in the results, with one click to switch new
  tabs to the JediTerm emulator.
- In a narrow panel the controls scroll in whole rows (the window ends between two rows, and the wheel moves from one row to
  the next) and the results keep at least six rows. Messages and hints share one line under the match count, so the results
  do not move when one appears. The lines under the filter start at one left edge.
- A one-time balloon after the first start says where Scrollgrep is and which keys to press.
- Preview: the licensed features on sample output in a Terminal tab of their own, before buying: a Gradle test run, and
  with `./sync-orders` a Python sync log and with `./dev-server` a Node.js dev server log. A second press of Preview
  selects that tab instead of opening another.
- The locked line says what **Try or buy** opens: the IDE's license dialog, where **Start trial** is. The rule about
  several patterns shows with the first extra row.

With a license ($12 once, 30-day trial):
- Links to files and stack frames (JVM, Python, Node.js, Go) in the results.
- Filter one command's output, with its exit code, plus context lines.
- Up to eight include and exclude patterns, each with its own color and boxes, saved as presets per project.
- Watch alerts from the Terminal tabs Scrollgrep can filter, even a hidden one.

The zip holds the plugin, this file, the README, the license and the source code.
