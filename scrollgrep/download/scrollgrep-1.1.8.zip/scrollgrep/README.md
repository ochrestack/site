# Scrollgrep: Terminal Filter

Only the lines you want, from a Terminal tab, while the output is still scrolling.

Scrollgrep opens a panel next to the Terminal tool window of a JetBrains IDE: type text or a regular expression and it
lists the matching lines the tab still holds, then appends new matches as they arrive. The terminal itself is left
exactly as it was, and you can change the pattern after the run without running the command again.

- **Free, with no time limit:** the live filter (Match case, Words, Regex, Invert, a match count) for the Terminal tab
  you are in. Matching lines the Terminal receives stay after it trims its own history; on IDE 2026.3 the panel says
  where the Terminal skipped output and offers the JediTerm emulator, which keeps every line.
- **With a license ($12 once, the same for personal and commercial use, 30-day trial, nothing renews):** clickable
  paths and stack traces in the results, one command's output with context lines, up to eight color-coded include and
  exclude patterns saved as presets per project, and watch alerts.
- **Try the licensed features before buying:** **Preview** in the panel opens a Terminal tab of its own with a sample
  Gradle test run, a Python sync job and a Node.js dev server log, where the licensed features work on that sample
  output.

Made for the IntelliJ-based IDEs from version 2025.3 with the Reworked terminal engine (the default since 2025.2).
Pictures, the demo film, the loop and how it was tested: https://ochrestack.com/scrollgrep/ and
https://ochrestack.com/scrollgrep/how-we-tested.html. Tested on Linux: IntelliJ IDEA and PyCharm 2025.3 and 2026.3,
and WebStorm 2025.3 (its test run, no window). Not tested: WebStorm's window and the filter in WebStorm 2026.3,
GoLand and the other JetBrains IDEs, Windows, macOS, PowerShell, Remote Development, and a real Marketplace trial or
purchase (Scrollgrep is not on the Marketplace yet).

## Install

1. In the IDE open **Settings | Plugins | ⚙ | Install Plugin from Disk**, choose `scrollgrep-1.1.8.zip` (keep it
   zipped; it is the file you downloaded from https://ochrestack.com/scrollgrep/), click **OK**, and **Accept** the
   third-party plugin notice. Once Scrollgrep is on the JetBrains Marketplace (it is not yet) you can install it from the
   Plugins search field instead.
2. Restart the IDE: it loads plugins with paid features only after a restart. Click **Restart IDE** on the plugin's row, or
   answer the IDE's restart prompt; if Settings offers neither, use **File | Exit** and start the IDE again.
3. After the restart a balloon says "Scrollgrep is installed" and which keys to press; the Scrollgrep icon on the right
   edge opens the panel too. The IDE may also show "Cannot update plugin": it cannot look for updates of a plugin
   installed from a file. That is the IDE's message, not an error of the plugin, and it can come back at later starts.
4. Check that **Settings | Tools | Terminal | Engine** is **Reworked** (the default). Scrollgrep does not see Classic
   terminal tabs.

## Usage

Open the panel from a Terminal tab: press **Ctrl+Shift+G** while the terminal has focus, right-click the tab's title (or
inside the output) and choose **Filter with Scrollgrep**, or use Find Action (Ctrl+Shift+A): "Filter Terminal Output". Type
in the filter field; **Escape** goes back to the terminal and the panel keeps filtering.

- **Match case** (Alt+C), **Words** (Alt+W), **Regex (grep -E)** (Alt+X; off means plain text) and **Invert** (Alt+I) mean
  what `grep` means by `-i` (off), `-w`, `-E` and `-v`. As in grep, `\d` is the letter "d"; the panel says so and suggests
  `[0-9]`. With Regex off, `skipped|ERROR` means those 13 characters: when such a pattern finds nothing, the panel says
  "Regex is off" and **Turn on Regex** ticks the box.
- A line whose first match would sit past the panel's right edge is shown from the start of the word just before the match,
  after "…". Hover over a line wider than the panel for the line itself (its first 1,000 characters).
- Matches stay after the Terminal trims its own history **if the panel was showing the tab, or the tab was left with a
  filter, while the output arrived**. A panel opened after a long run sees what the Terminal still holds and says how many
  lines it had dropped. The panel keeps its own copy of a tab within 32 MB and 200,000 lines (Settings | Tools |
  Scrollgrep).
- On IDE 2026.3 the Terminal's Ghostty emulator skips output that prints faster than it shows it. Scrollgrep marks where
  and offers **use JediTerm for new tabs**, which keeps every line.

### Preview: try the licensed features first

Without a license the panel shows "Try them on sample output first: **Preview**". Preview opens a Terminal tab named
**Scrollgrep preview** with a sample project and a sample Gradle test run; a second press selects that tab. In that tab
only, links, Scope, Context, extra patterns and Watch work: click the frame `MoneyTest.java:16`, pick the sample command
under Scope, add a pattern with **Watch** ticked and run `./sync-orders` (Python) or `./dev-server` (Node.js). The preview
ends at the first command of your own in that tab. Preview is offered on Linux and macOS (the samples are shell scripts);
it was run on Linux.

### With a license

- **Links:** paths and stack frames (JVM, Python, Node.js, Go) in the results open the file at the line.
- **Scope and Context:** one command's output with its exit code (needs the IDE's shell integration; tested with Bash and
  Zsh), and that many lines before and after each match, like `grep -C`.
- **Patterns and presets:** up to eight Include and Exclude patterns, each with its own color, saved as presets per
  project. **Add pattern** adds a row; a line shows if it matches any Include pattern and no Exclude pattern.
- **Watch:** a pattern with **Watch** on raises one IDE notification when it matches in a Terminal tab Scrollgrep can
  filter, even with the Terminal hidden.

## Pictures

The product page, https://ochrestack.com/scrollgrep/, shows captures of Scrollgrep 1.1.8 in IntelliJ IDEA 2025.3 and 2026.3 and PyCharm 2026.3:

- the panel filtering jsoup's Maven run with `FAILURE|Failures: [1-9]` ("4 matching lines"), and the "Regex is off" hint with **Turn on Regex**;
- five Gradle runs kept (70 lines, the Terminal's own search 42), and the "some lines missing" notice on the Ghostty emulator;
- Preview: a clicked stack frame, the Scope list, context lines, a pattern row with Watch, a Python frame in PyCharm; and a 35-second film, captions only.

## License and trial

The live filter is free and never locks, with or without a license or a trial. Everything else (Preview aside) needs a
JetBrains Marketplace license for Scrollgrep: a perpetual license, $12 once, the same for personal and commercial use, with every
update included and nothing that renews. **Try or buy** in the panel opens the IDE's own license dialog (tabs **Paid
license** and **Start trial**); it asks you to log in to a JetBrains Account and says "Subscription" even though
Scrollgrep's license is perpetual. The license and the trial become available when the Marketplace listing is live;
until then **Try or buy** cannot start a trial, and Preview shows the licensed features on sample output. Without a
license the panel shows one line with the price instead of the licensed controls; there is no pop-up or banner, at
project open or when a trial ends.

## Limits

- Results are shown in Scrollgrep's own panel; lines are not hidden inside the terminal view. Results are plain text,
  without the terminal's colors.
- Needs the Reworked terminal engine on IDE 2025.3 or later. SSH sessions (they run on the Classic engine), the Classic
  engine itself, and full-screen programs on the alternate screen (vim, less, htop) are not filtered.
- One-command scope needs the IDE's shell integration (tested with Bash and Zsh; PowerShell not tested). With Bash the
  IDE reports the first part of a compound command line (`for i in 1 2 3` for `for i in 1 2 3; do …; done`).
- The Terminal turns tabs into spaces and composes accents inside its emulator, before any plugin can read the line.
  Matching allows for both (`\t` and a typed tab match the spaces; patterns are composed too); tabs are shown as spaces.
- When a wide character (CJK, many emoji) does not fit in the last column of a row, the Terminal leaves that cell blank;
  Scrollgrep drops that blank from the line it shows.
- Paths that contain spaces are not linked. Clearing the terminal (`clear`, Clear Buffer) clears that tab's results too.
- The line the cursor is on is shown once it ends (Enter, a newline), so a prompt that waits for input is not listed
  until it is answered.
- IDE 2026.3 with the Ghostty emulator (the default there): output that prints faster than the Terminal shows it is
  partly skipped by the Terminal before any plugin can read it; Scrollgrep marks where and offers the JediTerm
  emulator, which keeps every line. How many lines were skipped is not known, only where.
- The Run, Debug, Build and Services consoles, Run configurations that use a terminal console, and Remote Development or
  Code With Me clients are not covered. English only.
- The Terminal API the plugin relies on is marked experimental by JetBrains; a new IDE version can need a compatibility
  update.

## Privacy

Scrollgrep reads the output of the Terminal tabs in the open project. It keeps a copy of that output in memory, not
only the matching lines, within the limits above (32 MB and 200,000 lines per tab by default), for the tab its panel
shows and tabs you left with a filter; the copy is gone when the tab or the IDE closes. Watch alerts read the Terminal tabs
Scrollgrep can filter, without keeping a copy. Your patterns and presets are stored in the project's workspace settings. The
one-time "Scrollgrep is installed" balloon is remembered in the plugin's settings file. Preview writes its sample
project to a temporary folder. Scrollgrep writes no output to disk, makes no network calls, and collects and sends
nothing.

## License and source

Scrollgrep is distributed under its End User License Agreement (`LICENSE`, also at
https://ochrestack.com/scrollgrep/eula). The plugin zip includes the source code as
`scrollgrep/src/scrollgrep-<version>-sources.zip`; the EULA (section 5) says what you may do with it.

## Support

Email **support@ochrestack.com**. We answer every message, usually within one business day.

