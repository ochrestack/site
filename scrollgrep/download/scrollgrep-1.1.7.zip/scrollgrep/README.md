# Scrollgrep: Terminal Filter

Only the lines you want, from a Terminal tab, while the output is still scrolling.

Scrollgrep opens a panel next to the Terminal tool window of a JetBrains IDE: type text or a regular expression and it
lists the matching lines the tab still holds, then appends new matches as they arrive. The terminal itself is left
exactly as it was, and you can change the pattern after the run without running the command again.

- **Free, with no time limit:** the live filter (Match case, Words, Regex, Invert, a match count) for the Terminal tab
  you are in. Matching lines the Terminal receives stay after it trims its own history; on IDE 2026.3 the panel says
  where the Terminal skipped output and offers the JediTerm emulator, which keeps every line.
- **With a license ($12 once, the same for personal and commercial use, 30-day trial, nothing renews):** clickable
  paths and stack traces in the results, one command's output with context lines, up to eight color-coded include and
  exclude patterns saved as presets per project, and watch alerts.
- **Try the licensed features before buying:** **Preview** in the panel opens a Terminal tab of its own with a sample
  Gradle test run, a Python sync job and a Node.js dev server log, where the licensed features work on that sample
  output.

Made for the IntelliJ-based IDEs from version 2025.3 with the Reworked terminal engine (the default since 2025.2).
Pictures, the 42-second demo film, the loop and how it was tested: https://ochrestack.com/scrollgrep/ and
https://ochrestack.com/scrollgrep/how-we-tested.html. Tested on Linux: IntelliJ IDEA and PyCharm 2025.3 and 2026.3,
and WebStorm 2025.3 (its test run, no window). Not tested: WebStorm's window and the filter in WebStorm 2026.3,
GoLand and the other JetBrains IDEs, Windows, macOS, PowerShell, Remote Development, and a real Marketplace trial or
purchase (Scrollgrep is not on the Marketplace yet).

## Install

1. In the IDE open **Settings | Plugins | ⚙ | Install Plugin from Disk**, choose `scrollgrep-1.1.7.zip` (keep it
   zipped; it is the file you downloaded from https://ochrestack.com/scrollgrep/), click **OK**, and **Accept** the
   third-party plugin notice. Once Scrollgrep is on the JetBrains Marketplace (it is not yet) you can install it from the
   Plugins search field instead.
2. Restart the IDE: it loads plugins with paid features only after a restart. Click **Restart IDE** on the plugin's row, or
   answer the IDE's restart prompt; if Settings offers neither, use **File | Exit** and start the IDE again.
3. After the restart a balloon says "Scrollgrep is installed" and which keys to press; the Scrollgrep icon on the right
   edge opens the panel too. The IDE may also show "Cannot update plugin": it cannot look for updates of a plugin
   installed from a file. That is the IDE's message, not an error of the plugin, and it can come back at later starts.
4. Check that **Settings | Tools | Terminal | Engine** is **Reworked** (the default). Scrollgrep does not see Classic
   terminal tabs.

## Usage

### Live filter (free)

Open the panel from a Terminal tab in any of three ways: press **Ctrl+Shift+G** while the terminal has focus;
right-click the tab's title, or inside the output, and choose **Filter with Scrollgrep**; or use **Find Action**
(Ctrl+Shift+A): "Filter Terminal Output". The filter field has focus. Press **Escape** to go back to the terminal;
the panel keeps filtering.

Toggles (each has a mnemonic, and none takes focus from the field): **Match case** (Alt+C), **Words** (Alt+W, whole
words), **Regex (grep -E)** (Alt+X; off means plain text), **Invert** (Alt+I, show the lines that do not match). They
mean what `grep` means by `-i` (off), `-w`, `-E` and `-v`. Regex uses `grep -E` syntax: `FAIL|Exception`,
`[[:digit:]]+`, `\<word\>`, `x{,2}`, `^$` select the same lines as `grep -E`. As in grep, a backslash before an ordinary
letter means that letter (`\d` is "d"; the panel says so and suggests `[0-9]`); one addition: `\t` matches a tab, or
the spaces the Terminal printed for it. With Regex off, `skipped|ERROR` means those 13 characters: when such a pattern
finds nothing, the panel says "Regex is off: “|” is matched as typed. Turn on Regex", and the link ticks Regex.

- A line redrawn in place, such as a progress bar or a spinner, appears once with its final text.
- A line whose first match would sit past the panel's right edge is shown from just before the match, after "…". Hover
  over any line wider than the panel for the whole line.
- Matches stay in the panel after the Terminal trims its own history (it keeps about 1 MB of output by default) **if the
  panel was showing the tab, or the tab was left with a filter, while the output arrived**. A panel opened after a run
  sees what the Terminal still holds, and says how much it had dropped (after `seq 1 300000` on IntelliJ IDEA 2025.3:
  "The Terminal had dropped the first 241,748 lines of this tab before the panel opened. Open the panel before a run to
  keep every line."). The notice goes when the tab is cleared.
- The panel keeps its own copy of a tab's output within two limits (Settings | Tools | Scrollgrep): **32 MB per tab**
  and **200,000 lines per tab**. Past the memory limit the text of the oldest lines that do not match the current
  filter is let go first, so matching lines stay longest. A tab you leave with an empty filter is not kept. The status
  line says how many matches were dropped.
- Changing the filter on a long session does not freeze the IDE: up to 0.1 s of the work runs at once, the rest in the
  background ("Filtering N lines…"), and the next keystroke cancels it.
- Switching Terminal tabs switches the panel to that tab. An invalid regular expression is outlined in red, the reason
  is shown, and the results stay as they were. Messages and hints appear in one line under the match count; when there
  is none, that line says "Esc goes back to the Terminal."
- In a narrow panel the controls above the results scroll, and the results keep at least six rows while the window is
  tall enough.

#### Skipped output (IDE 2026.3)

The 2026.3 IDEs run new Terminal tabs on the Ghostty emulator (IDE Registry key `terminal.use.ghostty.emulator`, on by
default). When more than 1,000 lines arrive between two screen updates, the Terminal shows only its screen until the
output pauses, then its own history: lines that scrolled past in between never reach the Terminal's text, so no plugin
can read them. Scrollgrep keeps every line that does arrive, in order and once; marks each place where lines are
missing with a row "⋯ the Terminal skipped lines here ⋯", adds "some lines missing" to the status line, and shows
"The Terminal skipped output that printed too fast. Keep every line: use JediTerm for new tabs". That link sets the
Registry key to off, so the next Terminal tab runs on JediTerm (no restart; open a new tab and run the command
again). JediTerm passes every line on, as in 2025.3. To go back: Help | Find Action, "Registry…",
`terminal.use.ghostty.emulator`.

### Preview (try the licensed features first)

Without a license the panel shows "Try them on sample output first: **Preview**". Preview writes a small sample
project to a temporary folder (a Java ledger with two failing tests, `sync_orders.py`, a Node.js shop API in
`src/orders.js` and `src/server.js`, and three scripts that print sample output; nothing is run but those scripts) and
opens a Terminal tab named **Scrollgrep preview** there, with the panel on it. The tab runs `./gradlew test`: a script
that prints a sample Gradle test run (about 200 lines, 2 failures with JVM stack frames, a compiler warning with a path,
exit code 1; no Gradle runs). The filter starts as `com.example`, which matches the three stack frames.

In that tab only, links, Scope, Context, extra patterns, presets and Watch work without a license: click the frame
`MoneyTest.java:16` (the sample's test opens at line 16); pick the sample command under Scope and set Context to 3; or
add a pattern `sync finished` with **Watch** ticked, hide the Terminal and run `./sync-orders` in the tab, and a
notification arrives. For Node.js, run `./dev-server` in the tab: a log of about 80 lines that ends in a crash (a
`TypeError`, exit code 1), and filter `orders.js` to click its frames: `orders.js:12:62` opens `src/orders.js` at line 12,
column 62. The preview ends for that tab, for good, at the first command of your own in it (anything but
`./gradlew test`, `./sync-orders` and `./dev-server`) or past 1,000 lines of output; the panel then says "Preview ended". Every other
tab stays locked: the Marketplace license check is unchanged. Preview is offered on Linux and macOS (the samples are
shell scripts); it was run on Linux. The folder is deleted when the project closes.

### Links in the results (licensed)

Paths and stack-trace lines in the results become links that open the file at the line, and at the column when one is
printed: absolute paths; paths relative to the directory the command ran in, then to the project, then the one project
file whose path ends with the printed path (when that is unique); `path:line` and `path:line:column`; JVM stack frames
(matched by package), Python tracebacks, Node.js frames and Go panics. A path that matches several files opens a
chooser; one that matches nothing, or contains spaces, stays plain text. Without a license, a click on such a line says
what a license does.

### One command, with context (licensed)

With the IDE's shell integration (tested with Bash and Zsh), **Scope** limits the filter to all output, the last
command, or a command picked from a list that shows each command line, its directory and its exit code. **Context**
shows that many lines before and after each match, like `grep -C`, with `--` between groups. In a shell without
integration, such as sh, the panel says why Scope is unavailable and filters all output.

### Several patterns and presets (licensed)

**Add pattern** adds a row with its own **Include** or **Exclude** choice, **Match case**, **Words**, **Regex** and
**Watch** boxes, and a highlight color (the colored square). A line shows if it matches any Include pattern (the filter
field is the first) and no Exclude pattern. Up to eight patterns work at once; a ninth is refused with a message.
**Save…** keeps the set as a named preset in this project.

### Watch alerts (licensed)

A pattern with **Watch** on raises one IDE notification with the matching line when it appears in a Terminal tab
Scrollgrep can filter, even with the Terminal hidden. Matches within 2 seconds (Settings, 1 to 60) are grouped into one
notification with a count. **Show in Scrollgrep** opens the panel on that tab with the line selected.

### Settings

**Settings | Tools | Scrollgrep**: lines kept per tab (1,000 to 1,000,000; default 200,000), memory per Terminal tab
(4 to 1,024 MB; default 32), the watch grouping interval (1 to 60 seconds; default 2), the license status with a link
to the IDE's license dialog.

## License and trial

The live filter is free and never locks, with or without a license or a trial. Everything else (Preview aside) needs a
JetBrains Marketplace license for Scrollgrep: a perpetual license, $12 once, the same for personal and commercial use, with every
update included and nothing that renews. **Try or buy** in the panel opens the IDE's own license dialog (tabs **Paid
license** and **Start trial**); it asks you to log in to a JetBrains Account and says "Subscription" even though
Scrollgrep's license is perpetual. The license and the trial become available when the Marketplace listing is live;
until then **Try or buy** cannot start a trial, and Preview shows the licensed features on sample output. Without a
license the panel shows one line with the price instead of the licensed controls; there is no pop-up or banner, at
project open or when a trial ends.

## Limits

- Results are shown in Scrollgrep's own panel; lines are not hidden inside the terminal view. Results are plain text,
  without the terminal's colors.
- Needs the Reworked terminal engine on IDE 2025.3 or later. SSH sessions (they run on the Classic engine), the Classic
  engine itself, and full-screen programs on the alternate screen (vim, less, htop) are not filtered.
- One-command scope needs the IDE's shell integration (tested with Bash and Zsh; PowerShell not tested). With Bash the
  IDE reports the first part of a compound command line (`for i in 1 2 3` for `for i in 1 2 3; do …; done`).
- The Terminal turns tabs into spaces and composes accents inside its emulator, before any plugin can read the line.
  Matching allows for both (`\t` and a typed tab match the spaces; patterns are composed too); tabs are shown as spaces.
- When a wide character (CJK, many emoji) does not fit in the last column of a row, the Terminal leaves that cell blank;
  Scrollgrep drops that blank from the line it shows.
- Paths that contain spaces are not linked. Clearing the terminal (`clear`, Clear Buffer) clears that tab's results too.
- The line the cursor is on is shown once it ends (Enter, a newline), so a prompt that waits for input is not listed
  until it is answered.
- IDE 2026.3 with the Ghostty emulator (the default there): output that prints faster than the Terminal shows it is
  partly skipped by the Terminal before any plugin can read it; Scrollgrep marks where and offers the JediTerm
  emulator, which keeps every line. How many lines were skipped is not known, only where.
- The Run, Debug, Build and Services consoles, Run configurations that use a terminal console, and Remote Development or
  Code With Me clients are not covered. English only.
- The Terminal API the plugin relies on is marked experimental by JetBrains; a new IDE version can need a compatibility
  update.

## Privacy

Scrollgrep reads the output of the Terminal tabs in the open project. It keeps a copy of that output in memory, not
only the matching lines, within the limits above (32 MB and 200,000 lines per tab by default), for the tab its panel
shows and tabs you left with a filter; the copy is gone when the tab or the IDE closes. Watch alerts read the Terminal tabs
Scrollgrep can filter, without keeping a copy. Your patterns and presets are stored in the project's workspace settings. The
one-time "Scrollgrep is installed" balloon is remembered in the plugin's settings file. Preview writes its sample
project to a temporary folder. Scrollgrep writes no output to disk, makes no network calls, and collects and sends
nothing.

## License and source

Scrollgrep is distributed under its End User License Agreement (`LICENSE`, also at
https://ochrestack.com/scrollgrep/eula). The plugin zip includes the source code as
`scrollgrep/src/scrollgrep-<version>-sources.zip`; the EULA (section 5) says what you may do with it.

## Support

Email **support@ochrestack.com**. We answer every message, usually within one business day.

## Building and testing

Requirements: JDK 21, `bash`, `zsh` and `sh` on the PATH (the tests start real shells), `python3`, and GNU `grep`
(the tests compare results with it).

```
./gradlew test                       # every test, headless (real bash, zsh and sh terminals inside the test JVM)
./gradlew buildPlugin verifyPlugin   # build/distributions/scrollgrep-1.1.7.zip, Plugin Verifier on IntelliJ IDEA 2025.3 and 2026.3 and WebStorm 2026.3
./gradlew benchmark                  # 200,000 lines in a real terminal tab; build/benchmark/results.json
./gradlew -I tests/redteam/redteam.init.gradle test --tests 'com.ochrestack.scrollgrep.redteam.*'   # the red team's tests
```

The same suite on WebStorm's own platform, headless (WebStorm's distribution has no test framework jar, so IntelliJ
IDEA's is borrowed; `build/platform-under-test.txt` records which platform ran):

```
./gradlew -PlocalIde=/path/to/WebStorm-2025.3 -PtestFrameworkJar=/path/to/idea-2025.3/lib/testFramework.jar test
```

Every number, version, file name and condition on the buyer-facing surfaces is written once in `docs/facts.md`;
`python3 tests/check_facts.py [--site ../site] [--control <listing draft>]` checks the surfaces against it (the same
checks without the site run inside `./gradlew test` as `FactsTest`).

The red team's tests on 1.1.7: see docs/evidence/critique-round-1-1.1.7.md.

With unpacked IDEs instead of downloads (for example on a machine without access to the JetBrains download
services): put `localIde=/path/to/idea-2025.3` and `localIdeNewest=/path/to/idea-2026.3` (optionally
`localIdeWebStorm=/path/to/webstorm-2026.3`, for the verifier only) in `~/.gradle/gradle.properties`
or pass them with `-P`. `./gradlew test` also runs `presetRestartPhase1` first: the first half of the IDE-restart test
for presets, in its own JVM.
The window sessions and captures: `screenshots/prepare-sample.sh` (the jsoup clone), `tests/gui/run_gui_session.sh` (an IDE with the zip installed, under Xvfb), `tests/gui/capture_1_1_7.sh` and `tests/gui/make_hero_gif.sh` (the pictures on the product page).
