# Changelog

All notable changes to Scrollgrep: Terminal Filter.

## 1.1.7 (2026-11-19)

The first release. The builds before it (1.0.0 to 1.1.6) were never published.

Free:
- Live filter for the Terminal tab you are in: plain text or `grep -E` patterns, Match case, Words, Regex (grep -E) and
  Invert, a match count, and results that keep arriving while the command runs.
- Matching lines stay in the panel after the Terminal trims its own history (up to 32 MB and 200,000 lines per tab by
  default; Settings | Tools | Scrollgrep).
- A plain-text pattern such as `a|b` that finds nothing offers to turn Regex on.
- A line whose match would sit past the panel's right edge is shown from just before the match; hover over any line wider
  than the panel for the whole line.
- On IDE 2026.3, output the Terminal skipped (its Ghostty emulator) is marked in the results, with one click to switch new
  tabs to the JediTerm emulator.
- In a narrow panel the controls scroll and the results keep at least six rows. Messages and hints share one line under
  the match count, so the results do not move when one appears.
- A one-time balloon after the first start says where Scrollgrep is and which keys to press.
- Preview: the licensed features on sample output in a Terminal tab of their own, before buying.

With a license ($12 once, 30-day trial):
- Links to files and stack frames (JVM, Python, Node.js, Go) in the results.
- Filter one command's output, with its exit code, plus context lines.
- Up to eight include and exclude patterns, each with its own color and boxes, saved as presets per project.
- Watch alerts from the Terminal tabs Scrollgrep can filter, even a hidden one.

Fixed since the last internal build, 1.1.6, after five testers went through it on IntelliJ IDEA 2025.3 at 1366x768 and 1024x600:
- The results disappeared after Preview or Add pattern; Invert was cut off at 330 px and the locked line ended in "Try o".
- Result rows moved as hints came and went; an empty filter said "No matching lines" above "N lines held".
- A click on a stack frame did nothing without a license; the pattern rows had no labels; the install gave no sign; the
  license link did not say what the IDE's dialog would show; Preview kept the filter of another tab.
- The panel, settings and documents use the IDE's own spelling (license, color); hint text is readable (4.5:1); the tab menu
  item shows its shortcut; a double click on a pattern's remove button removes one row.
- The README, license and change log are at the top of the zip. The 50-second demo film showed an older panel and was
  replaced by a 42-second film recorded on this version, with Preview in it and a 4 MB copy for phones.

The zip holds the plugin, this file, the README, the license and the source code.
