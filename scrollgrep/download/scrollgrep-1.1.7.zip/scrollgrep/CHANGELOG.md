# Changelog

All notable changes to Scrollgrep: Terminal Filter.

## 1.1.7 (2026-11-19)

The first release. The builds before it (1.0.0 to 1.1.6) were never published.

Free:
- Live filter for the Terminal tab you are in: plain text or `grep -E` patterns, Match case, Words, Regex (grep -E) and
  Invert, a match count, and results that keep arriving while the command runs.
- Matching lines stay in the panel after the Terminal trims its own history (up to 32 MB and 200,000 lines per tab by
  default; Settings | Tools | Scrollgrep). A panel opened after a long run says how many lines the Terminal had already
  dropped, and to open the panel before the run to keep every line.
- A plain-text pattern such as `a|b` that finds nothing offers to turn Regex on.
- A line whose match would sit past the panel's right edge is shown from just before the match; hover over any line wider
  than the panel for the whole line.
- On IDE 2026.3, output the Terminal skipped (its Ghostty emulator) is marked in the results, with one click to switch new
  tabs to the JediTerm emulator.
- In a narrow panel the controls scroll and the results keep at least six rows. Messages and hints share one line under
  the match count, so the results do not move when one appears.
- A one-time balloon after the first start says where Scrollgrep is and which keys to press.
- Preview: the licensed features on sample output in a Terminal tab of their own, before buying: a Gradle test run, and
  with `./sync-orders` a Python sync log and with `./dev-server` a Node.js dev server log.

With a license ($12 once, 30-day trial):
- Links to files and stack frames (JVM, Python, Node.js, Go) in the results.
- Filter one command's output, with its exit code, plus context lines.
- Up to eight include and exclude patterns, each with its own color and boxes, saved as presets per project.
- Watch alerts from the Terminal tabs Scrollgrep can filter, even a hidden one.

### Critique round 1: fixed since build 1.1.6

Five testers went through build 1.1.6 on IntelliJ IDEA 2025.3 at 1366x768 and 1024x600 and listed 24 issues (critique round 1,
T1 to T24). All 24 are fixed in 1.1.7.

Broken:
- T1: the results disappeared after Preview or Add pattern. The panel is now four parts (filter, scrolling controls, count,
  results) and the results keep at least six rows when the window is tall enough.
- T2: Invert was cut off at 330 px and the locked line ended in "Try o". The toggles and the locked line wrap.

Clunky:
- T3: a click on a path or stack frame did nothing without a license. It now says that links open with a license or in Preview.
- T4, T24 (ugly): the pattern rows had no labels. They have labels, boxes with words and one line saying how the rows combine.
- T5: the install gave no sign. A one-time balloon says "Scrollgrep is installed" and which keys to press.
- T6: the license link did not say what the IDE's dialog would show. Its tooltip and the page name the dialog.
- T7, T10: the page and the quick start were long and carried the build history. They are shorter and say what the picture is.
- T8: three different taglines. There is one.
- T9, T21 (ugly): page and listing pictures were too small to read on a phone. They are re-captured on 1.1.7 and cropped.
- T11, T12, T13, T14: the demo film showed an older panel, opened on a title card, claimed things the screen did not show, and
  was a 14 MB file for phones with small captions. The film is re-made on 1.1.7: 42 seconds, a 2.8 MB file and a 0.9 MB file for
  phones, captions about 13 px at a 360 px player.
- T15: the listing description was 1,594 words. It is 462.
- T16: the Regex box now reads "Regex (grep -E)".
- T17: result rows moved as hints came and went, and an empty filter said "No matching lines" above "N lines held". One notice
  line holds the messages and hints, and the empty filter reads "N lines in this tab".
- T18: Preview kept the filter of another tab. It starts from its own filter, `com.example`.
- T19: the README, license and change log were buried in the zip. They are at the top.

Ugly:
- T20: the panel and the documents spelled license and color the British way, against the IDE's own spelling. One spelling now.
- T22: the tab menu item showed no shortcut. It shows Ctrl+Shift+G.
- T23: hint text was 3.7:1 grey. It is 4.5:1 or better on the light and dark panels.

Also fixed: a double click on a pattern's remove button removes one row; the Preview note no longer scrolls the controls to
its last line; the count of an empty filter reads "1 line", not "1 lines".

The zip holds the plugin, this file, the README, the license and the source code.
