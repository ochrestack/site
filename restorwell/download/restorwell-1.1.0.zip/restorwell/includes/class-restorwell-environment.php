<?php
/**
 * Facts about this server that decide whether a backup can be restored here.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Server facts.
 */
final class Restorwell_Environment {

	/**
	 * Collects the facts the Check report compares against.
	 *
	 * @return array
	 */
	public static function snapshot() {
		global $wp_version, $wpdb;

		$free = null;
		if ( function_exists( 'disk_free_space' ) ) {
			$dir   = is_dir( Restorwell_Files::folder() ) ? Restorwell_Files::folder() : WP_CONTENT_DIR;
			$value = @disk_free_space( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Hosts may disable it; null means unknown.
			$free  = false === $value ? null : (float) $value;
		}
		/**
		 * Filters the free disk space Restorwell compares against, in bytes.
		 * Return null when it cannot be known.
		 *
		 * @param float|null $free Free bytes in wp-content, or null.
		 */
		$free = apply_filters( 'restorwell_free_disk_space', $free );

		$packet = null;
		if ( isset( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli ) {
			$value  = $wpdb->get_var( 'SELECT @@global.max_allowed_packet' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$packet = is_numeric( $value ) ? (int) $value : null;
		}

		return array(
			'wp_version'  => (string) $wp_version,
			'max_packet'  => $packet,
			'php_version' => PHP_VERSION,
			'free_bytes'  => null === $free ? null : (float) $free,
			'multisite'   => is_multisite(),
			'mysql'       => isset( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli,
			'bz2'         => function_exists( 'bzdecompress' ),
			'openssl'     => function_exists( 'openssl_decrypt' ),
			'int_size'    => PHP_INT_SIZE,
		);
	}
}
