<?php
/**
 * Tools > Restorwell: the screen and its AJAX endpoints. Every endpoint
 * checks a nonce and the manage_options capability.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin screen.
 */
final class Restorwell_Admin {

	const PAGE   = 'restorwell';
	const NONCE  = 'restorwell';
	const PRO    = 'https://ochrestack.com/restorwell#pro';
	const REVIEW = 'https://wordpress.org/support/plugin/restorwell/reviews/#new-post';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		$actions = array( 'list', 'upload_status', 'upload_chunk', 'delete_partial', 'check', 'restore_start', 'restore_step', 'restore_cancel', 'cleanup', 'delete_backup', 'dismiss' );
		foreach ( $actions as $action ) {
			add_action( 'wp_ajax_restorwell_' . $action, array( __CLASS__, 'ajax_' . $action ) );
		}
		add_filter( 'plugin_action_links_' . plugin_basename( RESTORWELL_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Adds the Tools menu entry.
	 */
	public static function menu() {
		add_management_page( __( 'Restorwell', 'restorwell' ), __( 'Restorwell', 'restorwell' ), 'manage_options', self::PAGE, array( __CLASS__, 'render' ) );
	}

	/**
	 * Adds an "Open" link on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'tools.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Restore a backup', 'restorwell' ) . '</a>' );
		return $links;
	}

	/**
	 * Loads the screen's script and styles.
	 *
	 * @param string $hook Screen hook.
	 */
	public static function assets( $hook ) {
		if ( 'tools_page_' . self::PAGE !== $hook ) {
			return;
		}
		$url = plugin_dir_url( RESTORWELL_FILE );
		wp_enqueue_style( 'restorwell-admin', $url . 'assets/admin.css', array(), RESTORWELL_VERSION );
		wp_enqueue_script( 'restorwell-admin', $url . 'assets/admin.js', array( 'wp-i18n' ), RESTORWELL_VERSION, true );
		wp_set_script_translations( 'restorwell-admin', 'restorwell' );
		$state = Restorwell_Restore::read_state();
		$job   = Restorwell_Restore::current();
		wp_localize_script(
			'restorwell-admin',
			'restorwellData',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( self::NONCE ),
				'chunkSize'   => Restorwell_Files::chunk_size(),
				'uploadLimit' => (int) wp_max_upload_size(),
				'loginUrl'    => wp_login_url( admin_url( 'tools.php?page=' . self::PAGE ) ),
				'homeUrl'     => home_url( '/' ),
				'reviewUrl'   => self::REVIEW,
				'job'         => $job ? self::job_payload( $job ) : null,
				'last'        => self::last_payload( $state ),
				'review'      => empty( $state['review_dismissed'] ),
			)
		);
	}

	/**
	 * Renders the screen. The script fills in the dynamic parts.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to restore backups on this site.', 'restorwell' ) );
		}
		$limit = (int) wp_max_upload_size();
		$chunk = Restorwell_Files::chunk_size();
		include __DIR__ . '/view-admin.php';
	}

	/**
	 * Rows of the Check report, shared by the screen and WP-CLI.
	 *
	 * @param array $r Report.
	 * @return array[] Each: label, value.
	 */
	public static function report_rows( array $r ) {
		$yes     = __( 'Yes', 'restorwell' );
		$no      = __( 'No', 'restorwell' );
		$unknown = $r['error'] ? __( 'not known: the backup could not be read', 'restorwell' ) : __( 'known once the password is accepted', 'restorwell' );
		$plugins = array();
		foreach ( $r['plugins'] as $p ) {
			$plugins[] = $p['name'] . ( '' !== $p['version'] ? ' ' . $p['version'] : '' );
		}
		$theme = __( 'none recorded', 'restorwell' );
		if ( $r['theme'] ) {
			$theme = $r['theme']['name'];
			if ( isset( $r['theme']['parent'] ) ) {
				/* translators: %s: parent theme name. */
				$theme .= ' ' . sprintf( __( '(child theme of %s)', 'restorwell' ), $r['theme']['parent'] );
			}
		}
		$compression = __( 'No', 'restorwell' );
		if ( '' !== $r['compression'] ) {
			/* translators: %s: gzip or bzip2. */
			$compression = sprintf( __( 'Yes (%s)', 'restorwell' ), $r['compression'] );
		}
		$password = $no;
		if ( $r['encrypted'] ) {
			$labels   = array(
				'needed'     => __( 'Yes: password needed', 'restorwell' ),
				'wrong'      => __( 'Yes: the password typed is wrong', 'restorwell' ),
				'ok'         => __( 'Yes: password accepted', 'restorwell' ),
				'unverified' => __( 'Yes: password not yet confirmed', 'restorwell' ),
			);
			$password = isset( $labels[ $r['password'] ] ) ? $labels[ $r['password'] ] : $yes;
		}
		$database = null !== $r['database_bytes']
			/* translators: 1: size, 2: number of tables. */
			? sprintf( _n( '%1$s in %2$s table', '%1$s in %2$s tables', (int) $r['tables'], 'restorwell' ), Restorwell_Files::size_label( $r['database_bytes'] ), number_format_i18n( (int) $r['tables'] ) )
			/* translators: %s: size. */
			: sprintf( __( '%s as stored in the backup', 'restorwell' ), Restorwell_Files::size_label( $r['database_stored'] ) );
		$files = __( 'not counted yet', 'restorwell' );
		if ( null !== $r['files'] ) {
			$files = number_format_i18n( $r['files'] );
			if ( null !== $r['files_bytes'] ) {
				/* translators: %s: size. */
				$files .= ' ' . sprintf( __( '(%s unpacked)', 'restorwell' ), Restorwell_Files::size_label( $r['files_bytes'] ) );
			}
		}
		$rows = array(
			array( __( 'Backup file', 'restorwell' ), $r['file'] ),
			array( __( 'Source site address', 'restorwell' ), '' !== $r['home_url'] ? $r['home_url'] : __( 'not recorded', 'restorwell' ) ),
			array( __( 'WordPress version', 'restorwell' ), '' !== $r['wp_version'] ? $r['wp_version'] : __( 'not recorded', 'restorwell' ) ),
			array( __( 'PHP version', 'restorwell' ), '' !== $r['php_version'] ? $r['php_version'] : __( 'not recorded', 'restorwell' ) ),
			array( __( 'Backup size', 'restorwell' ), Restorwell_Files::size_label( $r['size'] ) ),
			array( __( 'Files', 'restorwell' ), $files ),
			array( __( 'Database', 'restorwell' ), $database ),
			array( __( 'Active plugins', 'restorwell' ), $plugins ? implode( ', ', $plugins ) : __( 'none', 'restorwell' ) ),
			array( __( 'Active theme', 'restorwell' ), $theme ),
			array( __( 'Compressed', 'restorwell' ), $compression ),
			array( __( 'Password-protected', 'restorwell' ), $password ),
			array( __( 'Multisite network', 'restorwell' ), null === $r['multisite'] ? $unknown : ( $r['multisite'] ? $yes : $no ) ),
		);
		if ( $r['made_on'] ) {
			$rows[] = array( __( 'Backup made on', 'restorwell' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $r['made_on'] ) );
		}
		if ( '' !== $r['made_with'] ) {
			/* translators: %s: version number. */
			$rows[] = array( __( 'Made with', 'restorwell' ), sprintf( __( 'All-in-One WP Migration %s', 'restorwell' ), $r['made_with'] ) );
		}
		return $rows;
	}

	/**
	 * Seconds one request may work before answering.
	 *
	 * @return float
	 */
	public static function step_seconds() {
		$max     = (int) ini_get( 'max_execution_time' );
		$seconds = $max > 0 ? max( 2, min( 20, $max * 0.4 ) ) : 20;
		/**
		 * Filters how long one Check or Restore request works before answering.
		 *
		 * @param float $seconds Seconds.
		 */
		return (float) apply_filters( 'restorwell_step_seconds', $seconds );
	}

	/**
	 * Refuses the request unless the nonce and capability are right.
	 */
	private static function guard() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Your session expired. Reload the page and try again.', 'restorwell' ) ), 403 );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Only administrators can restore backups.', 'restorwell' ) ), 403 );
		}
		if ( is_multisite() ) {
			wp_send_json_error( array( 'message' => __( 'Restorwell restores into single sites only.', 'restorwell' ) ), 400 );
		}
	}

	/**
	 * Reads a POST string, unslashed (callers sanitise for their use).
	 *
	 * @param string $key Key.
	 * @return string
	 */
	private static function post( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard() checks the nonce before any call.
		return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	/**
	 * Reads the backup password from the request. It is used as typed (no
	 * sanitising, which could change it) and only ever kept in memory.
	 *
	 * @return string
	 */
	private static function password() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- guard() checks the nonce; the password is opaque, never output or stored.
		return isset( $_POST['password'] ) && is_string( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
	}

	/**
	 * Lists backups and unfinished uploads.
	 */
	public static function ajax_list() {
		self::guard();
		Restorwell_Files::ensure_folder();
		wp_send_json_success(
			array(
				'files'    => self::files_payload(),
				'partials' => Restorwell_Files::list_partials(),
			)
		);
	}

	/**
	 * Formats the file list.
	 *
	 * @return array[]
	 */
	private static function files_payload() {
		$out = array();
		foreach ( Restorwell_Files::list_backups() as $b ) {
			$b['sizeLabel'] = Restorwell_Files::size_label( $b['size'] );
			$b['date']      = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $b['modified'] );
			$out[]          = $b;
		}
		return $out;
	}

	/**
	 * Reads and validates the upload fields.
	 *
	 * @return array{0:string,1:int,2:int}
	 */
	private static function upload_fields() {
		$name     = Restorwell_Files::clean_upload_name( self::post( 'name' ) );
		$size     = (int) self::post( 'size' );
		$modified = (int) self::post( 'modified' );
		if ( false === $name ) {
			wp_send_json_error( array( 'message' => __( 'Choose a .wpress file. Other files cannot be restored.', 'restorwell' ) ), 400 );
		}
		if ( $size <= Restorwell_Archive::HEADER_SIZE ) {
			wp_send_json_error( array( 'message' => __( 'This file is too small to be a .wpress backup.', 'restorwell' ) ), 400 );
		}
		return array( $name, $size, $modified );
	}

	/**
	 * Tells the uploader how much of a file already arrived.
	 */
	public static function ajax_upload_status() {
		self::guard();
		list( $name, $size, $modified ) = self::upload_fields();
		wp_send_json_success(
			array(
				'received'  => Restorwell_Files::received( $name, $size, $modified ),
				'chunkSize' => Restorwell_Files::chunk_size(),
			)
		);
	}

	/**
	 * Receives one piece of an upload.
	 */
	public static function ajax_upload_chunk() {
		self::guard();
		list( $name, $size, $modified ) = self::upload_fields();
		$offset                         = (int) self::post( 'offset' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- guard() checks the nonce; only tmp_name and error are used, and tmp_name is verified with is_uploaded_file().
		$file = isset( $_FILES['chunk'] ) && is_array( $_FILES['chunk'] ) ? $_FILES['chunk'] : null;
		if ( ! $file || ! isset( $file['error'], $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
			wp_send_json_error(
				array(
					'message'  => __( 'A piece of the upload did not arrive. It will be sent again.', 'restorwell' ),
					'received' => Restorwell_Files::received( $name, $size, $modified ),
				),
				400
			);
		}
		try {
			wp_send_json_success( Restorwell_Files::append_chunk( $name, $size, $modified, $offset, $file['tmp_name'] ) );
		} catch ( Restorwell_Exception $e ) {
			wp_send_json_error(
				array(
					'message'  => $e->text(),
					'received' => Restorwell_Files::received( $name, $size, $modified ),
				),
				400
			);
		}
	}

	/**
	 * Removes an unfinished upload.
	 */
	public static function ajax_delete_partial() {
		self::guard();
		if ( ! Restorwell_Files::delete_partial( self::post( 'id' ) ) ) {
			wp_send_json_error( array( 'message' => __( 'That unfinished upload could not be removed.', 'restorwell' ) ), 400 );
		}
		wp_send_json_success( array( 'partials' => Restorwell_Files::list_partials() ) );
	}

	/**
	 * Runs the Check in steps. The first call names a file; later calls
	 * send back the signed token.
	 */
	public static function ajax_check() {
		self::guard();
		$password = self::password();
		$token    = self::post( 'token' );
		if ( '' !== $token ) {
			$state = Restorwell_Check::verify( $token );
			if ( null === $state ) {
				wp_send_json_error( array( 'message' => __( 'The check could not continue. Choose the backup again.', 'restorwell' ) ), 400 );
			}
		} else {
			$path = Restorwell_Files::resolve( self::post( 'ref' ) );
			if ( false === $path ) {
				wp_send_json_error( array( 'message' => __( 'That file cannot be used. Only .wpress files directly inside wp-content/restorwell-backups or wp-content/ai1wm-backups can be checked.', 'restorwell' ) ), 400 );
			}
			$state = Restorwell_Check::start( $path );
		}
		$state = Restorwell_Check::step( $state, $password, microtime( true ) + self::step_seconds() );
		$out   = Restorwell_Check::report( $state );
		wp_send_json_success(
			array(
				'token'  => Restorwell_Check::sign( $state ),
				'done'   => 'done' === $state['phase'],
				'report' => $out,
				'rows'   => self::report_rows( $out ),
			)
		);
	}

	/**
	 * Starts the restore after the confirmation tick.
	 */
	public static function ajax_restore_start() {
		self::guard();
		if ( '1' !== self::post( 'confirm' ) ) {
			wp_send_json_error( array( 'message' => __( 'Tick the confirmation box first.', 'restorwell' ) ), 400 );
		}
		$state = Restorwell_Check::verify( self::post( 'token' ) );
		if ( null === $state || 'done' !== $state['phase'] ) {
			wp_send_json_error( array( 'message' => __( 'Check the backup first.', 'restorwell' ) ), 400 );
		}
		try {
			$job = Restorwell_Restore::start( $state, self::password() );
		} catch ( Restorwell_Exception $e ) {
			wp_send_json_error( array( 'message' => $e->text() ), 400 );
		}
		wp_send_json_success( self::job_payload( $job ) );
	}

	/**
	 * Runs one restore step.
	 */
	public static function ajax_restore_step() {
		self::guard();
		$job = Restorwell_Restore::current();
		if ( ! $job ) {
			wp_send_json_error( array( 'message' => __( 'There is no restore in progress.', 'restorwell' ) ), 400 );
		}
		if ( $job['package']['encrypted'] && ! in_array( Restorwell_Check::password_status( $job['package'], self::password() ), array( 'ok', 'unverified' ), true ) ) {
			wp_send_json_error(
				array(
					'message'  => __( 'Type the backup password to continue the restore.', 'restorwell' ),
					'password' => true,
				),
				400
			);
		}
		try {
			$job = Restorwell_Restore::step( $job, self::password(), microtime( true ) + self::step_seconds() );
		} catch ( Restorwell_Exception $e ) {
			wp_send_json_error(
				array(
					'message' => $e->text(),
					'stopped' => true,
				),
				500
			);
		}
		wp_send_json_success( self::job_payload( $job ) );
	}

	/**
	 * Cancels a restore that has not reached the switch.
	 */
	public static function ajax_restore_cancel() {
		self::guard();
		$job    = Restorwell_Restore::current();
		$result = $job ? Restorwell_Restore::abort( $job ) : 'cancelled';
		switch ( $result ) {
			case 'rolled_back':
				wp_send_json_success( array( 'message' => __( 'The restore was cancelled. The folders it had already switched in were put back, so your site is as it was, and the temporary files and tables were removed.', 'restorwell' ) ) );
				break;
			case 'switched':
				$job = Restorwell_Restore::current();
				wp_send_json_success(
					array(
						'message'  => __( 'Too late to cancel: the restored database was already switched in. The restore is being finished now.', 'restorwell' ),
						'switched' => true,
						'job'      => $job ? self::job_payload( $job ) : null,
					)
				);
				break;
			case 'busy':
				wp_send_json_error( array( 'message' => __( 'A restore step is still running. Wait a few seconds, then click Cancel again.', 'restorwell' ) ), 409 );
				break;
			case 'stuck':
				wp_send_json_error(
					array(
						/* translators: %s: folder path. */
						'message' => sprintf( __( 'The restore could not be cancelled: Restorwell could not move every one of your site\'s own folders back. They are kept, untouched, in %s. Nothing was deleted. Write to support@ochrestack.com before you change anything.', 'restorwell' ), Restorwell_Restore::job_dir( $job['id'] ) . '/old' ),
					),
					500
				);
				break;
		}
		wp_send_json_success( array( 'message' => __( 'The restore was cancelled. Nothing on your site changed, and the temporary files and tables were removed.', 'restorwell' ) ) );
	}

	/**
	 * Continues removing the files a finished restore replaced.
	 */
	public static function ajax_cleanup() {
		self::guard();
		$job = Restorwell_Restore::current();
		if ( $job && ! empty( $job['switched'] ) ) {
			$job = Restorwell_Restore::cleanup( $job, microtime( true ) + self::step_seconds() );
		}
		wp_send_json_success( array( 'done' => ! $job || 'done' === $job['stage'] ) );
	}

	/**
	 * Deletes the backup file after a restore.
	 */
	public static function ajax_delete_backup() {
		self::guard();
		$ref = self::post( 'ref' );
		if ( ! Restorwell_Files::delete_backup( $ref ) ) {
			wp_send_json_error( array( 'message' => __( 'The backup file could not be deleted. Delete it with FTP or your host\'s File Manager.', 'restorwell' ) ), 400 );
		}
		$state = Restorwell_Restore::read_state();
		if ( isset( $state['last_restore']['ref'] ) && $state['last_restore']['ref'] === $ref ) {
			$state['last_restore']['deleted'] = true;
			Restorwell_Restore::write_state( array( 'last_restore' => $state['last_restore'] ) );
		}
		wp_send_json_success( array( 'message' => __( 'The backup file was deleted.', 'restorwell' ) ) );
	}

	/**
	 * Dismisses the review line or the finished panel.
	 */
	public static function ajax_dismiss() {
		self::guard();
		$what  = self::post( 'what' );
		$state = Restorwell_Restore::read_state();
		if ( 'review' === $what ) {
			Restorwell_Restore::write_state( array( 'review_dismissed' => true ) );
		} elseif ( 'finished' === $what && isset( $state['last_restore'] ) ) {
			$state['last_restore']['seen'] = true;
			Restorwell_Restore::write_state(
				array(
					'last_restore'     => $state['last_restore'],
					// The review line is shown once, on the first finished screen.
					'review_dismissed' => true,
				)
			);
		}
		wp_send_json_success();
	}

	/**
	 * What the screen needs to know about a job.
	 *
	 * @param array $job Job.
	 * @return array
	 */
	public static function job_payload( array $job ) {
		$progress = Restorwell_Restore::progress( $job );
		return array(
			'stage'     => $job['stage'],
			'percent'   => $progress['percent'],
			'label'     => $progress['label'],
			'name'      => $job['name'],
			'encrypted' => (bool) $job['package']['encrypted'],
			'switched'  => ! empty( $job['switched'] ),
			'source'    => $job['package']['home_url'],
			'files'     => $job['files'],
			'tables'    => count( $job['tables'] ),
			'warnings'  => isset( $job['warnings'] ) ? $job['warnings'] : array(),
			'busy'      => ! empty( $job['busy'] ),
			// Stopped inside the switch, with some restored folders already moved in.
			'moved'     => 'switch' === $job['stage'] && ! empty( $job['moves'] ),
		);
	}

	/**
	 * The finished panel's data, until it is closed.
	 *
	 * @param array $state Restorwell state file.
	 * @return array|null
	 */
	private static function last_payload( array $state ) {
		if ( empty( $state['last_restore'] ) || ! empty( $state['last_restore']['seen'] ) ) {
			return null;
		}
		$last = $state['last_restore'];
		$path = ! empty( $last['ref'] ) && empty( $last['deleted'] ) ? Restorwell_Files::resolve( $last['ref'] ) : false;
		return array(
			'name'      => $last['name'],
			'source'    => $last['source'],
			'files'     => (int) $last['files'],
			'tables'    => (int) $last['tables'],
			'date'      => wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $last['time'] ),
			'ref'       => false !== $path ? $last['ref'] : '',
			'sizeLabel' => false !== $path ? Restorwell_Files::size_label( (int) filesize( $path ) ) : '',
		);
	}
}
