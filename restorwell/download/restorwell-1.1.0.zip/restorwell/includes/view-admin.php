<?php
/**
 * Tools > Restorwell screen markup. The script in assets/admin.js fills in
 * the file list, the Check report and the progress.
 *
 * @package Restorwell
 *
 * @var int $limit Host upload limit in bytes.
 * @var int $chunk Upload piece size in bytes.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap restorwell" id="restorwell">
	<h1><?php esc_html_e( 'Restorwell', 'restorwell' ); ?></h1>
	<p class="rw-lead">
		<?php esc_html_e( 'Restore a .wpress backup made with All-in-One WP Migration, at any size, with or without a password. Nothing on this site changes until you have read the Check report, ticked the confirmation and clicked Restore.', 'restorwell' ); ?>
	</p>

	<?php if ( is_multisite() ) : ?>
		<div class="notice notice-error inline"><p><?php esc_html_e( 'This WordPress is a multisite network. Restorwell restores into single sites only.', 'restorwell' ); ?></p></div>
	<?php else : ?>

	<div id="rw-notice" class="rw-notice" role="status" aria-live="polite" hidden></div>

	<div id="rw-finished" class="rw-card rw-finished" hidden></div>
	<div id="rw-resume" class="rw-card rw-resume" hidden></div>

	<ol class="rw-steps" aria-label="<?php esc_attr_e( 'Steps', 'restorwell' ); ?>">
		<li class="rw-step is-current" data-step="choose"><span class="rw-step-n">1</span> <?php esc_html_e( 'Choose a backup', 'restorwell' ); ?></li>
		<li class="rw-step" data-step="check"><span class="rw-step-n">2</span> <?php esc_html_e( 'Check', 'restorwell' ); ?></li>
		<li class="rw-step" data-step="restore"><span class="rw-step-n">3</span> <?php esc_html_e( 'Restore', 'restorwell' ); ?></li>
	</ol>

	<section id="rw-choose" class="rw-section">
		<div class="rw-grid">
			<div class="rw-card rw-card-upload">
				<h2><?php esc_html_e( 'Upload a backup', 'restorwell' ); ?></h2>
				<p>
					<?php
					printf(
						/* translators: 1: piece size, 2: the host's upload limit. */
						esc_html__( 'The file is sent in pieces of %1$s, below this server\'s upload limit of %2$s, so the size of the backup does not matter. If the web server refuses a piece as too large, the pieces get smaller by themselves. If the connection drops or you reload the page, choose the same file again and the upload continues where it stopped.', 'restorwell' ),
						'<strong>' . esc_html( size_format( $chunk ) ) . '</strong>',
						'<strong>' . esc_html( size_format( $limit ) ) . '</strong>'
					);
					?>
				</p>
				<p class="rw-upload-row">
					<label class="screen-reader-text" for="rw-file"><?php esc_html_e( 'Backup file (.wpress)', 'restorwell' ); ?></label>
					<input type="file" id="rw-file" accept=".wpress" />
					<button type="button" class="button button-primary" id="rw-upload" disabled><?php esc_html_e( 'Upload', 'restorwell' ); ?></button>
				</p>
				<div id="rw-upload-progress" class="rw-progress" hidden>
					<div class="rw-bar"><span style="width:0"></span></div>
					<p class="rw-progress-label" aria-live="polite"></p>
				</div>
				<div id="rw-partials" hidden></div>
			</div>

			<div class="rw-card rw-card-files">
				<h2><?php esc_html_e( 'Backups already on this server', 'restorwell' ); ?></h2>
				<p>
					<?php
					printf(
						/* translators: 1: Restorwell folder, 2: All-in-One WP Migration folder. */
						esc_html__( 'Backups in %1$s and %2$s are listed here. To skip the upload, put a .wpress file in %1$s with FTP or your host\'s File Manager, then refresh the list.', 'restorwell' ),
						'<code>wp-content/' . esc_html( Restorwell_Files::FOLDER ) . '</code>',
						'<code>wp-content/ai1wm-backups</code>'
					);
					?>
				</p>
				<div id="rw-files" class="rw-files"><p class="rw-muted"><?php esc_html_e( 'Loading…', 'restorwell' ); ?></p></div>
				<p><button type="button" class="button" id="rw-refresh"><?php esc_html_e( 'Refresh list', 'restorwell' ); ?></button></p>
			</div>

			<?php
			/**
			 * Fires after the backup sources on the Restorwell screen, so an add-on can add one.
			 */
			do_action( 'restorwell_sources' );
			?>
		</div>
	</section>

	<section id="rw-check" class="rw-section" hidden>
		<div class="rw-card">
			<h2 id="rw-check-title"><?php esc_html_e( 'Check', 'restorwell' ); ?></h2>
			<div id="rw-check-progress" class="rw-progress" hidden>
				<div class="rw-bar"><span style="width:0"></span></div>
				<p class="rw-progress-label" aria-live="polite"></p>
			</div>
			<table class="widefat striped rw-report" id="rw-report" hidden><tbody></tbody></table>
			<h3 id="rw-limits-title" hidden><?php esc_html_e( 'Limits on this server', 'restorwell' ); ?></h3>
			<ul id="rw-limits" class="rw-limits" hidden></ul>

			<div id="rw-password" class="rw-password" hidden>
				<label for="rw-password-input"><strong><?php esc_html_e( 'Backup password', 'restorwell' ); ?></strong></label>
				<p class="description"><?php esc_html_e( 'Used only while checking and restoring. It is never saved.', 'restorwell' ); ?></p>
				<input type="password" id="rw-password-input" class="regular-text" autocomplete="off" spellcheck="false" />
				<button type="button" class="button" id="rw-password-check"><?php esc_html_e( 'Check password', 'restorwell' ); ?></button>
			</div>

			<div id="rw-confirm" class="rw-confirm" hidden>
				<p>
					<label>
						<input type="checkbox" id="rw-confirm-input" />
						<?php esc_html_e( 'I understand that this replaces this site\'s database, media, plugins and themes with the backup\'s, and that afterwards I log in with a username and password from the backup.', 'restorwell' ); ?>
					</label>
				</p>
				<p>
					<button type="button" class="button button-primary button-hero" id="rw-restore" disabled><?php esc_html_e( 'Restore', 'restorwell' ); ?></button>
					<button type="button" class="button button-link" id="rw-back"><?php esc_html_e( 'Choose another backup', 'restorwell' ); ?></button>
				</p>
			</div>
			<p id="rw-blocked" class="rw-blocked" hidden></p>
		</div>
	</section>

	<section id="rw-restore-section" class="rw-section" hidden>
		<div class="rw-card">
			<h2><?php esc_html_e( 'Restoring', 'restorwell' ); ?></h2>
			<div class="rw-progress">
				<div class="rw-bar"><span style="width:0"></span></div>
				<p class="rw-progress-label" id="rw-restore-label" aria-live="polite"></p>
			</div>
			<p class="rw-muted"><?php esc_html_e( 'Your live site keeps running until the final switch. Keep this page open; if it closes, come back to Tools > Restorwell to continue or cancel.', 'restorwell' ); ?></p>
			<p><button type="button" class="button" id="rw-cancel"><?php esc_html_e( 'Cancel restore', 'restorwell' ); ?></button></p>
		</div>
	</section>

		<?php if ( ! defined( 'RESTORWELL_PRO_VERSION' ) ) : ?>
		<p class="rw-footnote">
			<?php
			printf(
				/* translators: %s: link to the Restorwell Pro page. */
				esc_html__( 'Restoring never needs a paid add-on. If you would rather have the server download a backup from a link than upload it yourself, see %s.', 'restorwell' ),
				'<a href="' . esc_url( Restorwell_Admin::PRO ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Restorwell Pro', 'restorwell' ) . '</a>'
			);
			?>
		</p>
	<?php endif; ?>
	<?php endif; ?>
</div>
