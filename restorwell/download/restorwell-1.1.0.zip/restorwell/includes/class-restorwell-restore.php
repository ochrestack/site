<?php
/**
 * The restore itself. Files are unpacked into a job folder and the
 * database into temporary tables, beside the live site, in short steps.
 * Only the final switch touches the live site: it moves the prepared
 * folders in and renames the tables in one statement. If anything fails
 * before that, the live site is untouched and the temporary data is removed.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resumable restore job.
 */
final class Restorwell_Restore {

	const STATE_FILE = '.restorwell-state.json';

	/**
	 * Root-level files in wp-content that belong to the server, not the site.
	 *
	 * @var string[]
	 */
	private static $host_mu_plugins = array( 'endurance-page-cache.php', 'endurance-php-edge.php', 'endurance-browser-cache.php', 'gd-system-plugin.php', 'wp-stack-cache.php', 'wpcomsh-loader.php', 'wpcomsh', 'mu-plugin.php', 'wpe-wp-sign-on-plugin.php', 'wpengine-security-auditor.php', 'aaa-wp-cerber.php', 'sqlite-database-integration', '0-sqlite.php', 'eos-deactivate-plugins.php' );

	/**
	 * Folder of a job.
	 *
	 * @param string $id Job id.
	 * @return string
	 */
	public static function job_dir( $id ) {
		return Restorwell_Files::folder() . '/job-' . $id;
	}

	/**
	 * Finds an unfinished job.
	 *
	 * @return array|null
	 */
	public static function current() {
		$dir = Restorwell_Files::folder();
		if ( ! is_dir( $dir ) ) {
			return null;
		}
		foreach ( (array) glob( $dir . '/job-*/job.json' ) as $file ) {
			$job = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( is_array( $job ) && isset( $job['id'] ) && self::job_dir( $job['id'] ) . '/job.json' === $file ) {
				return $job;
			}
		}
		return null;
	}

	/**
	 * Reads a job's saved state.
	 *
	 * @param string $id Job id.
	 * @return array|null Null when the job no longer exists (finished or cancelled).
	 */
	private static function load( $id ) {
		$file = self::job_dir( $id ) . '/job.json';
		clearstatcache( true, $file );
		if ( ! is_file( $file ) ) {
			return null;
		}
		$job = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return is_array( $job ) && isset( $job['id'] ) && $job['id'] === $id ? $job : null;
	}

	/**
	 * Saves a job's state (never the password). Never recreates the folder of
	 * a job that was cancelled meanwhile.
	 *
	 * @param array $job Job.
	 * @throws Restorwell_Exception When the job's folder is gone.
	 */
	private static function save( array $job ) {
		$dir = self::job_dir( $job['id'] );
		if ( ! is_dir( $dir ) ) {
			$exception = self::cancelled();
			throw $exception;
		}
		$file = $dir . '/job.json';
		file_put_contents( $file . '.tmp', wp_json_encode( $job ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		rename( $file . '.tmp', $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
	}

	/**
	 * The exception for a step that finds its restore cancelled.
	 *
	 * @return Restorwell_Exception
	 */
	private static function cancelled() {
		return new Restorwell_Exception( 'cancelled', esc_html__( 'The restore was cancelled.', 'restorwell' ) );
	}

	/**
	 * Takes a job's lock, waiting up to $wait seconds for a running step.
	 *
	 * @param string $id   Job id.
	 * @param float  $wait Seconds to wait; 0 to try once.
	 * @return resource|false|null The lock handle; false when another request holds it; null when the job folder is gone.
	 */
	private static function lock( $id, $wait ) {
		$dir = self::job_dir( $id );
		if ( ! is_dir( $dir ) ) {
			return null;
		}
		$lock = fopen( $dir . '/lock', 'c' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( false === $lock ) {
			return is_dir( $dir ) ? false : null;
		}
		$until = microtime( true ) + $wait;
		while ( ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			if ( microtime( true ) >= $until ) {
				fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
				return false;
			}
			usleep( 100000 );
		}
		return $lock;
	}

	/**
	 * Releases a lock taken with lock().
	 *
	 * @param resource $lock Handle.
	 */
	private static function unlock( $lock ) {
		flock( $lock, LOCK_UN );
		fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	}

	/**
	 * Calls the step hook. Tests use it to inject faults.
	 *
	 * @param string $stage Stage name.
	 * @param array  $job   Job.
	 */
	private static function hook( $stage, array $job ) {
		/**
		 * Fires before each restore step runs.
		 *
		 * @param string $stage prepare, extract, database or switch.
		 * @param array  $job   Job state.
		 */
		do_action( 'restorwell_before_step', $stage, $job );
	}

	/**
	 * Starts a restore from a finished check.
	 *
	 * @param array  $check    Check state (from Restorwell_Check).
	 * @param string $password Password, or ''.
	 * @return array Job.
	 * @throws Restorwell_Exception When the backup may not be restored.
	 */
	public static function start( array $check, $password ) {
		global $wpdb;

		if ( null !== self::current() ) {
			throw new Restorwell_Exception( 'busy', esc_html__( 'Another restore is already in progress. Continue it or cancel it first.', 'restorwell' ) );
		}
		clearstatcache( true, $check['path'] );
		if ( ! is_file( $check['path'] ) || (int) filesize( $check['path'] ) !== $check['size'] || (int) filemtime( $check['path'] ) !== $check['mtime'] ) {
			throw new Restorwell_Exception( 'changed', esc_html__( 'The backup file changed after it was checked. Check it again.', 'restorwell' ) );
		}
		$report = Restorwell_Check::report( $check );
		if ( ! $report['can_restore'] ) {
			throw new Restorwell_Exception( 'not_ready', esc_html__( 'This backup cannot be restored on this server yet. See the limits listed in the Check report.', 'restorwell' ) );
		}
		$pkg = $check['package'];
		if ( $pkg['encrypted'] && ! in_array( Restorwell_Check::password_status( $pkg, $password ), array( 'ok', 'unverified' ), true ) ) {
			throw new Restorwell_Exception( 'password_wrong', '' === $password ? esc_html__( 'This backup is password-protected. Type its password.', 'restorwell' ) : esc_html__( 'The password is wrong.', 'restorwell' ) );
		}
		if ( ! Restorwell_Files::ensure_folder() ) {
			throw new Restorwell_Exception( 'not_writable', esc_html__( 'Restorwell cannot create its folder in wp-content. Ask your host to make wp-content writable by the web server.', 'restorwell' ) );
		}

		$id      = strtolower( wp_generate_password( 10, false ) );
		$uploads = wp_upload_dir( null, false );
		$keep    = array( plugin_basename( RESTORWELL_FILE ) );
		$dirs    = array( dirname( plugin_basename( RESTORWELL_FILE ) ) );

		$job = array(
			'id'           => $id,
			'path'         => $check['path'],
			'name'         => wp_basename( $check['path'] ),
			'size'         => $check['size'],
			'mtime'        => $check['mtime'],
			'eof'          => (int) $check['eof'][0],
			'package'      => $pkg,
			'stage'        => 'extract',
			'offset'       => 0,
			'entry'        => null,
			'cursor'       => array(),
			'files'        => 0,
			'files_total'  => (int) $report['files'],
			'sql_offset'   => 0,
			'sql_size'     => 0,
			'statements'   => 0,
			'skipped_sql'  => 0,
			'tmp_prefix'   => 'rwt' . substr( md5( $id ), 0, 5 ) . '_',
			'old_prefix'   => 'rwo' . substr( md5( $id ), 5, 5 ) . '_',
			'tables'       => array(),
			'moves'        => array(),
			'started'      => time(),
			'target'       => array(
				'prefix'      => $wpdb->prefix,
				'site_url'    => (string) get_option( 'siteurl' ),
				'home_url'    => (string) get_option( 'home' ),
				'uploads_url' => untrailingslashit( $uploads['baseurl'] ),
				'uploads_dir' => untrailingslashit( $uploads['basedir'] ),
				'content_dir' => untrailingslashit( WP_CONTENT_DIR ),
				'abspath'     => untrailingslashit( ABSPATH ),
				'template'    => (string) get_option( 'template' ),
				'stylesheet'  => (string) get_option( 'stylesheet' ),
			),
			/**
			 * Filters the plugins that stay active after a restore (Restorwell itself always does).
			 *
			 * @param string[] $basenames Plugin basenames.
			 */
			'keep_active'  => array_values( array_unique( (array) apply_filters( 'restorwell_keep_active_plugins', $keep ) ) ),
			/**
			 * Filters the plugin folders a backup may never overwrite (Restorwell's own always).
			 *
			 * @param string[] $dirs Folder names inside the plugins folder.
			 */
			'protect_dirs' => array_values( array_unique( (array) apply_filters( 'restorwell_protected_plugin_dirs', $dirs ) ) ),
		);

		if ( ! wp_mkdir_p( self::job_dir( $id ) . '/content' ) ) {
			throw new Restorwell_Exception( 'not_writable', esc_html__( 'Restorwell could not create its working folder. Check that wp-content is writable and has free space.', 'restorwell' ) );
		}
		self::save( $job );
		try {
			self::hook( 'prepare', $job );
		} catch ( Throwable $e ) {
			self::abort( $job );
			$stopped = self::stopped( $e );
			throw $stopped;
		}
		return $job;
	}

	/**
	 * Runs the job until the deadline passes or the stage changes.
	 *
	 * @param array  $job      Job.
	 * @param string $password Password, or ''.
	 * @param float  $deadline microtime(true) limit.
	 * @return array Updated job.
	 * @throws Restorwell_Exception When the restore was cancelled, or stops before the switch (the site is unchanged).
	 * @throws Throwable Any error after the switch.
	 */
	public static function step( array $job, $password, $deadline ) {
		$lock = self::lock( $job['id'], 0 );
		if ( null === $lock ) {
			$exception = self::cancelled();
			throw $exception;
		}
		if ( false === $lock ) {
			$job['busy'] = true;
			return $job;
		}
		// Work from the saved state: another request may have moved the job on,
		// or cancelled it while this request waited.
		$fresh = self::load( $job['id'] );
		if ( null === $fresh ) {
			self::unlock( $lock );
			self::remove_empty_job_dir( $job['id'] );
			$exception = self::cancelled();
			throw $exception;
		}
		$job   = $fresh;
		$stage = $job['stage'];
		try {
			switch ( $stage ) {
				case 'extract':
					$job = self::extract( $job, $password, $deadline );
					break;
				case 'database':
					$job = self::database( $job, $deadline );
					break;
				case 'switch':
					$job = self::switch_in( $job, $deadline );
					break;
				case 'cleanup':
					$job = self::cleanup( $job, $deadline );
					break;
			}
		} catch ( Throwable $e ) {
			self::unlock( $lock );
			if ( $e instanceof Restorwell_Exception && 'cancelled' === $e->get_reason() ) {
				throw $e;
			}
			if ( in_array( $stage, array( 'extract', 'database', 'switch' ), true ) ) {
				$result = self::abort( $job );
				if ( 'stuck' === $result ) {
					throw new Restorwell_Exception(
						'not_writable',
						/* translators: 1: the reason the restore stopped, 2: folder path. */
						sprintf( esc_html__( 'The restore stopped during the switch: %1$s Restorwell could not move every one of your site\'s own folders back. They are kept, untouched, in %2$s. Nothing was deleted. Write to support@ochrestack.com before you change anything.', 'restorwell' ), esc_html( rtrim( $e instanceof Restorwell_Exception ? $e->text() : $e->getMessage(), '.' ) . '.' ), esc_html( self::job_dir( $job['id'] ) . '/old' ) )
					);
				}
				$stopped = self::stopped( $e );
				throw $stopped;
			}
			throw $e;
		}
		self::unlock( $lock );
		return $job;
	}

	/**
	 * Removes what a step left of a cancelled job's folder (its lock file), if nothing else is in it.
	 *
	 * @param string $id Job id.
	 */
	private static function remove_empty_job_dir( $id ) {
		$dir = self::job_dir( $id );
		if ( is_dir( $dir ) && array( 'lock' ) === self::children( $dir ) ) {
			wp_delete_file( $dir . '/lock' );
			rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		}
	}

	/**
	 * The exception shown when a restore stops before the switch.
	 *
	 * @param Throwable $e Cause.
	 * @return Restorwell_Exception
	 */
	private static function stopped( Throwable $e ) {
		$reason = $e instanceof Restorwell_Exception ? $e->get_reason() : 'failed';
		$text   = $e instanceof Restorwell_Exception ? $e->text() : $e->getMessage();
		return new Restorwell_Exception(
			$reason,
			/* translators: %s: the reason the restore stopped. */
			sprintf( esc_html__( 'The restore stopped before anything on your site changed: %s Your site is as it was, and the temporary files and tables were removed.', 'restorwell' ), esc_html( rtrim( $text, '.' ) . '.' ) )
		);
	}

	/**
	 * Where an entry is unpacked to, or null to leave it out.
	 *
	 * @param string $rel Entry path.
	 * @param array  $job Job.
	 * @return string|null
	 */
	public static function destination( $rel, array $job ) {
		$dir = self::job_dir( $job['id'] );
		if ( 'database.sql' === $rel ) {
			return $dir . '/database.sql';
		}
		return self::is_excluded( $rel, $job ) ? null : $dir . '/content/' . $rel;
	}

	/**
	 * Whether an entry is left out of the restore.
	 *
	 * @param string $rel Entry path.
	 * @param array  $job Job.
	 * @return bool
	 */
	public static function is_excluded( $rel, array $job ) {
		$parts = explode( '/', $rel );
		$top   = $parts[0];
		if ( Restorwell_Archive::is_config_file( $rel ) ) {
			return true;
		}
		if ( 1 === count( $parts ) && array_key_exists( $rel, _get_dropins() ) ) {
			return true;
		}
		if ( in_array( $top, array( Restorwell_Files::FOLDER, 'ai1wm-backups' ), true ) ) {
			return true;
		}
		if ( 'plugins' === $top && isset( $parts[1] ) && in_array( $parts[1], $job['protect_dirs'], true ) ) {
			return true;
		}
		if ( 'mu-plugins' === $top && isset( $parts[1] ) && in_array( $parts[1], self::$host_mu_plugins, true ) ) {
			return true;
		}
		if ( 'themes/functions.php' === $rel || 0 === strpos( $rel, 'uploads/elementor/css/' ) || 'database/db-path.php' === $rel ) {
			return true;
		}
		return 1 === preg_match( '/(\.less\.cache|\.sqlite|\.sqlite-wal|\.sqlite-shm|\.sqlite-journal)$/i', $rel );
	}

	/**
	 * Stage 1: unpacks files and database.sql into the job folder.
	 *
	 * @param array  $job      Job.
	 * @param string $password Password.
	 * @param float  $deadline Deadline.
	 * @return array
	 * @throws Restorwell_Exception When a file cannot be written.
	 */
	private static function extract( array $job, $password, $deadline ) {
		self::hook( 'extract', $job );
		$archive = new Restorwell_Archive( $job['path'] );
		$pw      = $job['package']['encrypted'] ? $password : '';
		try {
			while ( microtime( true ) < $deadline ) {
				if ( null === $job['entry'] ) {
					if ( $job['offset'] >= $job['eof'] ) {
						$job['stage']    = 'database';
						$job['sql_size'] = is_file( self::job_dir( $job['id'] ) . '/database.sql' ) ? (int) filesize( self::job_dir( $job['id'] ) . '/database.sql' ) : 0;
						break;
					}
					$header = $archive->header_at( $job['offset'] );
					if ( 'file' !== $header['type'] || ! $header['safe'] ) {
						$exception = Restorwell_Archive::not_wpress();
						throw $exception;
					}
					$header['dest'] = self::destination( $header['relative'], $job );
					$job['entry']   = $header;
					$job['cursor']  = array();
				}
				$entry = $job['entry'];
				if ( null === $entry['dest'] ) {
					$job['offset'] = $entry['data_offset'] + $entry['size'];
					$job['entry']  = null;
					continue;
				}
				$dest = $entry['dest'];
				if ( ! is_dir( dirname( $dest ) ) && ! wp_mkdir_p( dirname( $dest ) ) ) {
					throw new Restorwell_Exception( 'not_writable', esc_html__( 'A folder could not be created while unpacking. Check the free disk space and that wp-content is writable.', 'restorwell' ) );
				}
				$cursor  = $job['cursor'];
				$written = isset( $cursor['written'] ) ? (int) $cursor['written'] : 0;
				// phpcs:disable WordPress.WP.AlternativeFunctions -- Streaming large files in pieces.
				$out = fopen( $dest, 0 === $written ? 'wb' : 'r+b' );
				if ( false === $out ) {
					throw new Restorwell_Exception( 'not_writable', esc_html__( 'A file could not be written while unpacking. Check the free disk space and that wp-content is writable.', 'restorwell' ) );
				}
				if ( $written > 0 ) {
					ftruncate( $out, $written );
					fseek( $out, $written );
				}
				$done = $archive->decode(
					$entry,
					$cursor,
					Restorwell_Archive::is_stored_plain( $entry['relative'], $job['package']['made_with'] ) ? '' : $pw,
					$job['package']['compression'],
					function ( $data ) use ( $out, $dest ) {
						if ( fwrite( $out, $data ) !== strlen( $data ) ) {
							throw new Restorwell_Exception( 'disk_full', esc_html__( 'The server ran out of disk space while unpacking the backup.', 'restorwell' ) );
						}
					},
					$deadline
				);
				fclose( $out );
				// phpcs:enable
				$job['cursor'] = $cursor;
				if ( ! $done ) {
					break;
				}
				if ( $entry['mtime'] > 0 ) {
					touch( $dest, $entry['mtime'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_touch -- Keeps the backup's modification time, as the original file had.
				}
				if ( 'database.sql' !== $entry['relative'] ) {
					++$job['files'];
				}
				$job['offset'] = $entry['data_offset'] + $entry['size'];
				$job['entry']  = null;
			}
		} finally {
			$archive->close();
		}
		self::save( $job );
		return $job;
	}

	/**
	 * Collation replacements for collations this database server lacks.
	 *
	 * @return array<string,string>
	 */
	private static function collation_map() {
		global $wpdb;
		$have = array();
		foreach ( (array) $wpdb->get_col( 'SHOW COLLATION' ) as $name ) {
			$have[ $name ] = true;
		}
		$fallback = isset( $have['utf8mb4_unicode_520_ci'] ) ? 'utf8mb4_unicode_520_ci' : 'utf8mb4_unicode_ci';
		$map      = array();
		foreach ( array( 'utf8mb4_0900_ai_ci', 'utf8mb4_0900_as_ci', 'utf8mb4_0900_as_cs', 'utf8mb4_uca1400_ai_ci', 'utf8mb4_uca1400_as_cs' ) as $c ) {
			if ( ! isset( $have[ $c ] ) ) {
				$map[ $c ] = $fallback;
			}
		}
		return $map;
	}

	/**
	 * Lists the job's temporary tables as they exist in the database.
	 *
	 * @param string $prefix Temporary prefix.
	 * @return string[]
	 */
	private static function prefixed_tables( $prefix ) {
		global $wpdb;
		return array_values( (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $prefix ) . '%' ) ) );
	}

	/**
	 * Runs one statement built by Restorwell_Sql (from the backup).
	 *
	 * @param string $sql Statement.
	 * @return bool
	 */
	private static function run_sql( $sql ) {
		global $wpdb;
		$wpdb->check_current_query = false;
		// The statement comes from the backup's database.sql and was rewritten by
		// Restorwell_Sql so it can only touch this job's temporary tables.
		$result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES ) {
			$wpdb->queries = array();
		}
		return false !== $result;
	}

	/**
	 * Stage 2: loads database.sql into temporary tables.
	 *
	 * @param array $job      Job.
	 * @param float $deadline Deadline.
	 * @return array
	 * @throws Restorwell_Exception On a database error.
	 */
	private static function database( array $job, $deadline ) {
		global $wpdb;
		self::hook( 'database', $job );
		$file = self::job_dir( $job['id'] ) . '/database.sql';
		if ( ! is_file( $file ) ) {
			throw new Restorwell_Exception( 'no_database', esc_html__( 'This backup has no database, so there is nothing Restorwell can restore it into.', 'restorwell' ) );
		}
		$suppress = $wpdb->suppress_errors( true );
		if ( 0 === $job['sql_offset'] ) {
			foreach ( self::prefixed_tables( $job['tmp_prefix'] ) as $table ) {
				self::run_sql( 'DROP TABLE IF EXISTS `' . $table . '`' );
			}
		}
		$wpdb->query( "SET SESSION sql_mode = ''" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( 'SET SESSION foreign_key_checks = 0' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rewriter = new Restorwell_Sql(
			$job['tmp_prefix'],
			$job['target']['prefix'],
			new Restorwell_Replace( Restorwell_Replace::build_pairs( $job['package'], $job['target'] ) ),
			self::collation_map()
		);

		$fh = fopen( $file, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fseek( $fh, $job['sql_offset'] );
		$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$query = '';
		try {
			while ( true ) {
				$line = fgets( $fh );
				if ( false === $line ) {
					if ( '' !== trim( $query ) ) {
						self::execute( $rewriter, $query, $job );
					}
					$job['sql_offset'] = $job['sql_size'];
					$job['stage']      = 'switch';
					break;
				}
				$query .= $line;
				if ( 1 !== preg_match( '/;\s*$/', $line ) ) {
					continue;
				}
				self::execute( $rewriter, $query, $job );
				$query             = '';
				$job['sql_offset'] = (int) ftell( $fh );
				if ( microtime( true ) > $deadline ) {
					break;
				}
			}
			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		} finally {
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			$wpdb->suppress_errors( $suppress );
		}
		self::save( $job );
		return $job;
	}

	/**
	 * Rewrites and runs one statement.
	 *
	 * @param Restorwell_Sql $rewriter Rewriter.
	 * @param string         $query    Statement.
	 * @param array          $job      Job, updated in place.
	 * @throws Restorwell_Exception On a database error.
	 */
	private static function execute( Restorwell_Sql $rewriter, $query, array &$job ) {
		global $wpdb;
		$r = $rewriter->rewrite( $query );
		if ( 'skip' === $r['type'] ) {
			if ( '' !== trim( preg_replace( '/^\s*(--|#).*$/m', '', $query ) ) && 1 !== preg_match( '/^\s*(START\s+TRANSACTION|COMMIT)\s*;?\s*$/i', $query ) ) {
				++$job['skipped_sql'];
			}
			return;
		}
		if ( strlen( $r['table'] ) > 64 ) {
			throw new Restorwell_Exception(
				'database',
				/* translators: %s: table name. */
				sprintf( esc_html__( 'The table name %s is too long for this database server once Restorwell adds its temporary prefix.', 'restorwell' ), esc_html( $r['table'] ) )
			);
		}
		if ( ! self::run_sql( $r['sql'] ) ) {
			throw new Restorwell_Exception(
				'database',
				/* translators: 1: table name, 2: database error. */
				sprintf( esc_html__( 'The database could not be restored: table %1$s, database error "%2$s".', 'restorwell' ), esc_html( $r['table'] ), esc_html( $wpdb->last_error ) )
			);
		}
		if ( 'create' === $r['type'] && ! in_array( $r['table'], $job['tables'], true ) ) {
			$job['tables'][] = $r['table'];
		}
		++$job['statements'];
	}

	/**
	 * Stage 3: the switch. Moves the prepared folders in and swaps the tables.
	 *
	 * @param array $job      Job.
	 * @param float $deadline Deadline for the old-file cleanup that follows.
	 * @return array
	 * @throws Restorwell_Exception When the switch cannot be made (the site is left as it was).
	 * @throws Throwable Any other error during the switch, after the moves are rolled back.
	 */
	private static function switch_in( array $job, $deadline ) {
		global $wpdb;
		self::hook( 'switch', $job );

		if ( self::renamed_already( $job ) ) {
			// A previous request stopped hard right after the tables were swapped:
			// the restored database is live, so finish the switch.
			return self::after_switch( $job, count( $job['tables'] ), self::prefixed_tables( $job['old_prefix'] ), $deadline );
		}
		if ( ! empty( $job['moves'] ) ) {
			// A previous request stopped hard in the middle of the moves: put
			// everything back first, then make the switch again from the start.
			if ( ! self::rollback_moves( $job ) ) {
				throw new Restorwell_Exception( 'not_writable', esc_html__( 'The folders moved by the interrupted switch could not be put back.', 'restorwell' ) );
			}
			$job['moves'] = array();
			self::save( $job );
		}

		$tmp_tables = self::prefixed_tables( $job['tmp_prefix'] );
		foreach ( array( 'options', 'users', 'usermeta' ) as $core ) {
			if ( ! in_array( $job['tmp_prefix'] . $core, $tmp_tables, true ) ) {
				throw new Restorwell_Exception( 'no_database', esc_html__( 'The backup\'s database has no options or users table, so it cannot run a site.', 'restorwell' ) );
			}
		}

		// Files: move each prepared item in, keeping what it replaces.
		$dir     = self::job_dir( $job['id'] );
		$content = $dir . '/content';
		$bases   = array(
			'plugins'    => WP_PLUGIN_DIR,
			'themes'     => get_theme_root(),
			'mu-plugins' => WPMU_PLUGIN_DIR,
		);
		$moves   = array();
		foreach ( self::children( $content ) as $top ) {
			if ( isset( $bases[ $top ] ) && is_dir( $content . '/' . $top ) ) {
				foreach ( self::children( $content . '/' . $top ) as $child ) {
					$moves[] = array( $content . '/' . $top . '/' . $child, $bases[ $top ] . '/' . $child, $top . '/' . $child );
				}
			} else {
				$moves[] = array( $content . '/' . $top, WP_CONTENT_DIR . '/' . $top, $top );
			}
		}
		$never = array( realpath( Restorwell_Files::folder() ), realpath( dirname( RESTORWELL_FILE ) ) );

		try {
			foreach ( $moves as $move ) {
				list( $src, $dest, $key ) = $move;
				$real                     = realpath( $dest );
				if ( false !== $real && in_array( $real, $never, true ) ) {
					continue;
				}
				foreach ( $bases as $base ) {
					if ( ! is_dir( $base ) ) {
						wp_mkdir_p( $base );
					}
				}
				$old = file_exists( $dest ) || is_link( $dest ) ? $dir . '/old/' . $key : null;
				// Record the move before making it, so a request that is killed
				// half-way can always be put back (see rollback_moves()).
				$job['moves'][] = array( $src, $dest, $old );
				self::save( $job );
				if ( null !== $old ) {
					wp_mkdir_p( dirname( $old ) );
					if ( ! rename( $dest, $old ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
						throw new Restorwell_Exception( 'not_writable', esc_html__( 'An existing folder could not be moved aside.', 'restorwell' ) );
					}
				}
				self::hook( 'move', $job );
				if ( ! rename( $src, $dest ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
					throw new Restorwell_Exception( 'not_writable', esc_html__( 'A restored folder could not be moved into place.', 'restorwell' ) );
				}
			}

			// Database: one RENAME TABLE swaps every table at once.
			$names = array();
			$olds  = array();
			$live  = array_flip( (array) $wpdb->get_col( 'SHOW TABLES' ) );
			foreach ( $tmp_tables as $tmp ) {
				$suffix = substr( $tmp, strlen( $job['tmp_prefix'] ) );
				$target = $job['target']['prefix'] . $suffix;
				if ( isset( $live[ $target ] ) ) {
					$old     = $job['old_prefix'] . $suffix;
					$names[] = $target;
					$names[] = $old;
					$olds[]  = $old;
				}
				$names[] = $tmp;
				$names[] = $target;
			}
			// The restored options already carry this server's address, plugins and
			// theme, so the site is consistent the moment the tables are swapped,
			// even if this request is killed right after.
			self::finish_options( $job, $job['tmp_prefix'] . 'options' );
			self::hook( 'rename', $job );
			$sql = 'RENAME TABLE ' . implode( ', ', array_fill( 0, count( $names ) / 2, '%i TO %i' ) );
			if ( false === $wpdb->query( $wpdb->prepare( $sql, $names ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery -- $sql holds only %i placeholders, filled by prepare().
				throw new Restorwell_Exception(
					'database',
					/* translators: %s: database error. */
					sprintf( esc_html__( 'The tables could not be switched: %s', 'restorwell' ), $wpdb->last_error )
				);
			}
		} catch ( Throwable $e ) {
			self::rollback_moves( $job );
			throw $e;
		}
		self::hook( 'renamed', $job );
		return self::after_switch( $job, count( $tmp_tables ), $olds, $deadline );
	}

	/**
	 * Whether the tables of a job in the switch stage were already swapped:
	 * its temporary tables are gone and the live site's tables were renamed
	 * to its old-table prefix, which only RENAME TABLE does.
	 *
	 * @param array $job Job.
	 * @return bool
	 */
	private static function renamed_already( array $job ) {
		return 'switch' === $job['stage']
			&& ! empty( $job['tables'] )
			&& array() === self::prefixed_tables( $job['tmp_prefix'] )
			&& array() !== self::prefixed_tables( $job['old_prefix'] );
	}

	/**
	 * Puts back the folders a switch moved, newest first: each restored folder
	 * goes back into the job folder and the live one it replaced returns to
	 * its place. Safe to repeat, and safe after a request was killed between
	 * two renames, because every move is recorded before it is made.
	 *
	 * @param array $job Job.
	 * @return bool True when every live folder is back in place.
	 */
	private static function rollback_moves( array $job ) {
		$ok = true;
		foreach ( array_reverse( isset( $job['moves'] ) ? (array) $job['moves'] : array() ) as $move ) {
			list( $src, $dest, $old ) = $move;
			$dest_there               = file_exists( $dest ) || is_link( $dest );
			$old_there                = null !== $old && ( file_exists( $old ) || is_link( $old ) );
			// What sits at $dest is the restored copy when the live one is aside, or when there was none.
			if ( $dest_there && ! file_exists( $src ) && ( null === $old || $old_there ) ) {
				wp_mkdir_p( dirname( $src ) );
				$dest_there = ! rename( $dest, $src ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			}
			if ( $old_there && ! $dest_there ) {
				$old_there = ! rename( $old, $dest ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			}
			if ( $old_there ) {
				$ok = false;
			}
		}
		return $ok;
	}

	/**
	 * Everything after the tables were swapped: options for this server, old
	 * tables dropped, temporary files removed.
	 *
	 * @param array    $job      Job.
	 * @param int      $tables   Number of tables restored.
	 * @param string[] $olds     The live site's previous tables, renamed aside.
	 * @param float    $deadline Deadline for the old-file cleanup.
	 * @return array
	 */
	private static function after_switch( array $job, $tables, array $olds, $deadline ) {
		global $wpdb;
		$dir = self::job_dir( $job['id'] );

		// The restored site is live. Anything that goes wrong from here on is
		// reported as a warning: the switch itself has been made.
		$job['stage']    = 'cleanup';
		$job['switched'] = time();
		$job['warnings'] = array();
		try {
			self::save( $job );
			// Written into the temporary table before the switch too; again here
			// in case a cache or a plugin changed them since.
			self::finish_options( $job, $job['target']['prefix'] . 'options' );
			foreach ( $olds as $old ) {
				$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $old ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			}
			wp_cache_flush();
			Restorwell_Files::remove_tree( $dir . '/content' );
			wp_delete_file( $dir . '/database.sql' );
			self::write_state(
				array(
					'last_restore' => array(
						'time'   => time(),
						'name'   => $job['name'],
						'ref'    => self::ref_for( $job['path'] ),
						'source' => $job['package']['home_url'],
						'files'  => $job['files'],
						'tables' => $tables,
						'seen'   => false,
					),
				)
			);
			self::save( $job );
		} catch ( Throwable $e ) {
			$job['warnings'][] = $e instanceof Restorwell_Exception ? $e->text() : $e->getMessage();
		}
		return self::cleanup( $job, $deadline );
	}

	/**
	 * The reference of a file when it sits in one of the listed folders.
	 *
	 * @param string $path Absolute path.
	 * @return string '' when the file is elsewhere.
	 */
	private static function ref_for( $path ) {
		foreach ( Restorwell_Files::sources() as $source => $dir ) {
			if ( realpath( $dir ) === dirname( $path ) ) {
				return Restorwell_Files::ref( $source, wp_basename( $path ) );
			}
		}
		return '';
	}

	/**
	 * Sets the options a restored site needs on this server.
	 *
	 * @param array  $job   Job.
	 * @param string $table Options table to write: the temporary one before the switch.
	 */
	private static function finish_options( array $job, $table ) {
		$plugins = array();
		foreach ( $job['package']['plugins'] as $basename ) {
			if ( 0 === validate_file( $basename ) && is_file( WP_PLUGIN_DIR . '/' . $basename ) ) {
				$plugins[] = $basename;
			}
		}
		foreach ( $job['keep_active'] as $basename ) {
			if ( is_file( WP_PLUGIN_DIR . '/' . $basename ) ) {
				$plugins[] = $basename;
			}
		}
		$plugins = array_values( array_unique( $plugins ) );

		$template   = $job['package']['template'];
		$stylesheet = $job['package']['stylesheet'];
		$root       = get_theme_root();
		if ( '' === $stylesheet || '' === $template || 0 !== validate_file( $stylesheet ) || 0 !== validate_file( $template ) || ! is_file( $root . '/' . $stylesheet . '/style.css' ) || ! is_dir( $root . '/' . $template ) ) {
			$template   = $job['target']['template'];
			$stylesheet = $job['target']['stylesheet'];
		}

		$values = array(
			'siteurl'        => $job['target']['site_url'],
			'home'           => $job['target']['home_url'],
			'active_plugins' => serialize( $plugins ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- Written straight to the options table, as WordPress stores it.
			'template'       => $template,
			'stylesheet'     => $stylesheet,
			// An empty value makes WordPress rebuild the permalink rules on the next request.
			'rewrite_rules'  => '',
		);
		foreach ( $values as $name => $value ) {
			self::set_option( $table, $name, $value );
		}
	}

	/**
	 * Writes an option row in a given options table.
	 *
	 * @param string $table Options table (built from the validated prefix).
	 * @param string $name  Option name.
	 * @param string $value Raw value.
	 */
	private static function set_option( $table, $name, $value ) {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE option_name = %s', $table, $name ) );
		if ( $exists ) {
			$wpdb->update( $table, array( 'option_value' => $value ), array( 'option_name' => $name ) );
		} else {
			$wpdb->insert(
				$table,
				array(
					'option_name'  => $name,
					'option_value' => $value,
					'autoload'     => 'yes',
				)
			);
		}
		// phpcs:enable
	}

	/**
	 * Stage 4: removes the replaced files, then the job folder.
	 *
	 * @param array $job      Job.
	 * @param float $deadline Deadline.
	 * @return array
	 */
	public static function cleanup( array $job, $deadline ) {
		$dir = self::job_dir( $job['id'] );
		if ( Restorwell_Files::remove_tree( $dir . '/old', $deadline ) ) {
			$job['stage'] = 'done';
			Restorwell_Files::remove_tree( $dir );
			return $job;
		}
		self::save( $job );
		return $job;
	}

	/**
	 * Cancels a job that did not reach the switch. Waits for a step that is
	 * still running, puts back any folder the switch had already moved, then
	 * removes the temporary tables and the job folder.
	 *
	 * @param array $job  Job.
	 * @param float $wait Seconds to wait for a running step.
	 * @return string cancelled | rolled_back (folders were put back) | switched (too late: the restored site is live) | busy (a step is still running) | stuck (a folder could not be put back; nothing was deleted).
	 */
	public static function abort( array $job, $wait = 45.0 ) {
		global $wpdb;
		if ( ! empty( $job['switched'] ) ) {
			return 'switched';
		}
		$moved = false;
		$lock  = self::lock( $job['id'], $wait );
		if ( false === $lock ) {
			return 'busy';
		}
		if ( null !== $lock ) {
			$fresh = self::load( $job['id'] );
			$job   = null !== $fresh ? $fresh : $job;
			if ( ! empty( $job['switched'] ) || self::renamed_already( $job ) ) {
				self::unlock( $lock );
				return 'switched';
			}
			$moved = ! empty( $job['moves'] );
			if ( ! self::rollback_moves( $job ) ) {
				self::unlock( $lock );
				return 'stuck';
			}
			// Without job.json the job is gone for every other request, even
			// one that takes the lock before the folder is removed.
			wp_delete_file( self::job_dir( $job['id'] ) . '/job.json' );
			self::unlock( $lock );
		}
		if ( ! empty( $job['tmp_prefix'] ) && 1 === preg_match( '/^rwt[0-9a-f]{5}_$/', $job['tmp_prefix'] ) ) {
			foreach ( self::prefixed_tables( $job['tmp_prefix'] ) as $table ) {
				$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			}
		}
		if ( ! Restorwell_Files::remove_tree( self::job_dir( $job['id'] ) ) ) {
			Restorwell_Files::remove_tree( self::job_dir( $job['id'] ) );
		}
		return $moved ? 'rolled_back' : 'cancelled';
	}

	/**
	 * Removes every job, for uninstall. A job whose tables were already
	 * swapped, or whose moved folders cannot be put back, is kept untouched
	 * so the site's own files are never deleted.
	 *
	 * @return string[] Temporary and old table prefixes that must be kept.
	 */
	public static function discard_all() {
		$keep = array();
		foreach ( (array) glob( Restorwell_Files::folder() . '/job-*', GLOB_ONLYDIR ) as $dir ) {
			$id  = substr( wp_basename( $dir ), 4 );
			$job = self::load( $id );
			if ( null === $job ) {
				if ( ! file_exists( $dir . '/old' ) ) {
					Restorwell_Files::remove_tree( $dir );
				}
				continue;
			}
			if ( ! empty( $job['switched'] ) ) {
				Restorwell_Files::remove_tree( $dir );
				continue;
			}
			if ( ! in_array( self::abort( $job, 5.0 ), array( 'cancelled', 'rolled_back' ), true ) ) {
				$keep[] = $job['tmp_prefix'];
				$keep[] = $job['old_prefix'];
			}
		}
		return $keep;
	}

	/**
	 * Names in a folder, without dot entries.
	 *
	 * @param string $dir Folder.
	 * @return string[]
	 */
	private static function children( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return array();
		}
		return array_values( array_diff( (array) scandir( $dir ), array( '.', '..' ) ) );
	}

	/**
	 * Progress for the screen and WP-CLI.
	 *
	 * @param array $job Job.
	 * @return array{stage:string,percent:int,label:string}
	 */
	public static function progress( array $job ) {
		switch ( $job['stage'] ) {
			case 'extract':
				$done = null === $job['entry'] ? $job['offset'] : $job['entry']['data_offset'] + ( isset( $job['cursor']['consumed'] ) ? $job['cursor']['consumed'] : 0 );
				$frac = $job['eof'] > 0 ? min( 1, $done / $job['eof'] ) : 0;
				return array(
					'stage'   => 'extract',
					'percent' => (int) floor( $frac * 80 ),
					'label'   => sprintf(
						/* translators: 1: files unpacked, 2: total files, 3: percent. */
						__( 'Unpacking files beside the live site: %1$s of %2$s files (%3$d%%)', 'restorwell' ),
						number_format_i18n( $job['files'] ),
						number_format_i18n( $job['files_total'] ),
						(int) floor( $frac * 100 )
					),
				);
			case 'database':
				$frac = $job['sql_size'] > 0 ? min( 1, $job['sql_offset'] / $job['sql_size'] ) : 0;
				return array(
					'stage'   => 'database',
					'percent' => 80 + (int) floor( $frac * 17 ),
					'label'   => sprintf(
						/* translators: 1: percent, 2: tables so far. */
						__( 'Restoring the database into temporary tables: %1$d%% (%2$s tables)', 'restorwell' ),
						(int) floor( $frac * 100 ),
						number_format_i18n( count( $job['tables'] ) )
					),
				);
			case 'switch':
				return array(
					'stage'   => 'switch',
					'percent' => 97,
					'label'   => __( 'Switching the restored site in', 'restorwell' ),
				);
			case 'cleanup':
				return array(
					'stage'   => 'cleanup',
					'percent' => 99,
					'label'   => __( 'Removing the replaced files', 'restorwell' ),
				);
		}
		return array(
			'stage'   => 'done',
			'percent' => 100,
			'label'   => __( 'Restore finished', 'restorwell' ),
		);
	}

	/**
	 * Reads Restorwell's small state file (last restore, review line).
	 *
	 * @return array
	 */
	public static function read_state() {
		$file = Restorwell_Files::folder() . '/' . self::STATE_FILE;
		if ( ! is_file( $file ) ) {
			return array();
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Merges values into the state file. It lives in Restorwell's folder, not
	 * the database, so a later restore cannot overwrite it.
	 *
	 * @param array $values Values.
	 */
	public static function write_state( array $values ) {
		Restorwell_Files::ensure_folder();
		$state = array_merge( self::read_state(), $values );
		file_put_contents( Restorwell_Files::folder() . '/' . self::STATE_FILE, wp_json_encode( $state ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}
}
