=== Restorwell – Restore .wpress Backups of Any Size ===
Contributors: ochrestack
Tags: restore, backup, migration, import, upload limit
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Restores a .wpress backup past your host's upload limit, with or without a password, after checking the whole file and your server's limits. Free.

== Description ==

Asked to pay to restore your own backup? Restorwell restores your .wpress file free, at any size your server has disk space for, past your host's upload limit and with or without a password. It reads and checksums the whole backup and checks your server's limits before anything changes, and if a restore fails or is cancelled before the final switch, your site is left exactly as it was.

Tested on a host capped at 8 MB uploads, 30-second requests and 128 MB of memory: a 4.3 GB password-protected, compressed backup restored byte for byte.

Restorwell reads the .wpress files that All-in-One WP Migration makes. Restorwell is an independent plugin by Ochrestack and is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= 1. Get the backup onto the server =

* **Upload in pieces.** Tools > Restorwell sends the file in pieces smaller than your host's upload limit, so the size of the backup does not matter. If the web server refuses a piece as too large (HTTP 413), the pieces get smaller by themselves.
* **Resume.** If the connection drops or you reload the page, choose the same file again and the upload continues where it stopped.
* **Or skip the upload.** Copy the file to `wp-content/restorwell-backups` with FTP or your host's File Manager. Files there and in `wp-content/ai1wm-backups` are listed, "site (1).wpress" included.

= 2. Check, before anything changes =

The Check reads every byte of the backup and verifies its checksums. It shows the source site address, WordPress and PHP versions, backup size, number of files, database size, plugins, active theme, and whether the backup is compressed or password-protected.

Then it names, in plain words, the limits it checks on this server: free disk space needed against available, the largest database statement against max_allowed_packet, a newer WordPress or PHP in the backup, a multisite backup (not supported), a password that is needed or wrong, a damaged or incomplete file. Restore stays off until nothing blocks it, and nothing on the site changes until you tick the confirmation and click Restore.

= 3. Restore, at any size, password or not =

* Database, media, plugins and themes are restored. Compressed (gzip, bzip2) and password-protected backups are included. The password is typed on the Check screen and never saved.
* The work runs in short steps with a named progress line, so PHP time limits do not stop it.
* The old site address and file paths become the new ones, including inside serialized data and page-builder data. Addresses that only start with the old one (old-site.com.au) are left alone. A different table prefix is handled.
* Files and tables are prepared beside the live site and switched in at the end. If any step before the switch fails, or you click Cancel, your site is left as it was and the temporary data is removed.
* Afterwards permalinks are refreshed, you log in with an account from the backup, and Restorwell offers to delete the backup file.

= 4. Command line =

`wp restorwell list`, `wp restorwell check <file>` and `wp restorwell restore <file> [--password=<password> | --password-stdin] [--yes]`, where `<file>` is a listed name or a path. All free.

= What it does not do =

* It does not make backups. For new backups, use a backup plugin whose restore is free.
* No multisite networks, and no backup formats other than .wpress.
* No staging, no restoring single files or tables, no scheduled or cloud backups.
* It needs a working WordPress to restore into, on MySQL or MariaDB.

= Restorwell Pro (optional, $19 one-time) =

Restoring never needs Pro. Pro adds one thing: Restore from a link. Paste the direct download address of a .wpress file; the server downloads it, resuming where the remote server allows, then runs the same Check and Restore. $19 once, unlimited sites, no renewal, no licence checks. Sold at ochrestack.com/restorwell.

= External services =

None. Restorwell contacts no outside server: no analytics, telemetry, licence or update calls, remote fonts or scripts. Your backup and its password never leave your server.

== Installation ==

1. In WordPress, go to Plugins > Add New, search for "Restorwell", click Install Now, then Activate. Or upload restorwell.zip with Plugins > Add New > Upload Plugin.
2. Go to Tools > Restorwell.
3. Upload the .wpress file, or pick one already on the server, and click Check.
4. Read the report, type the password if the backup has one, tick the confirmation and click Restore.

== Frequently Asked Questions ==

= My backup is bigger than the upload limit. Can I still restore it? =

Yes. Restorwell sends the file in pieces, each smaller than your host's upload limit, so the limit no longer matters. Only free disk space does, and the Check tells you how much is needed and how much is available. You can also copy the file to `wp-content/restorwell-backups` by FTP and skip the upload.

= The upload stops with "413 Request Entity Too Large". =

That is the web server's own limit, which can be lower than the one WordPress shows. Restorwell halves the piece size and carries on, down to 64 KB, and tells you. If even that is refused, copy the file by FTP.

= Do I need Restorwell if my backup is small? =

If your backup is smaller than the upload limit your host shows, All-in-One WP Migration's own Import screen restores it for free. If you can raise the limit (.htaccess, .user.ini, or a request to your host), the same applies. Restorwell is for the rest: a backup over the limit, a password, the command line, or a full check first. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= I raised the limit and it still asks me to pay. =

Restorwell has no size limit of its own and nothing to pay for restoring. You do not need to raise any limit at all.

= It says "Corrupted File". What is wrong with my backup? =

Run the Check. It names the problem: an incomplete file (copy it again), a checksum that does not match (copy it again from where it was made), or a password that is needed.

= My backup has a password. =

Type it on the Check screen. Restorwell checks it before restoring and uses it only while checking and restoring; it is never written to the database, a file or a log.

= Can I restore from the command line? =

Yes: `wp restorwell restore site.wpress --password-stdin --yes` (`--password-stdin` keeps the password out of the process list). Exit codes: 2 password, 3 damaged backup, 4 disk space, 5 another limit.

= Is restoring really free at any size? =

Yes. No size limit, no locked buttons, no account. Pro only changes how the file reaches the server.

= What happens if the restore stops halfway? =

Until the final switch your live site is not touched. If a step fails, or you click Cancel, the temporary files and tables are removed and the site is as it was; Cancel waits for the step that is running. If the page is closed, Tools > Restorwell offers to continue or cancel. If the server killed the restore in the middle of the switch, the screen says so: Continue finishes the restore, and Cancel puts your site's own folders back first. Once the restored database is switched in, it is too late to cancel, and the screen finishes the restore.

= Why am I logged out after the restore? =

The users come from the backup: log in with an account from it.

= Is anything left out of the restore? =

Restorwell never overwrites itself, and leaves out server-specific files: drop-ins such as `object-cache.php` and `db.php`, known hosting-company must-use plugins, and cache files. Your `wp-config.php` is not changed.

= Are my backups safe in wp-content? =

Restorwell's folder blocks web access with `.htaccess`, `web.config` and an index file. On nginx, ask your host to deny access to `wp-content/restorwell-backups`, or delete the backup after restoring.

= Which backups has it been tested with? =

All-in-One WP Migration 7.113: plain, gzip, bzip2, password-protected, password-protected plus compressed. 7.101 password-protected (the older format, before February 2026). 7.0, 7.40, 7.62, 7.80 and 7.100 plain. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= The Check says a statement is larger than max_allowed_packet. =

Ask your host to raise the database server's max_allowed_packet to the size the Check gives, then check again.

= What happens when I uninstall Restorwell? =

Temporary data is removed. Your .wpress files are kept. A restore stopped mid-switch has your site's folders put back first.

== Screenshots ==

1. The Check report, then each limit checked on this server, marked OK.
2. "Password needed", and Restore off until the password is accepted.
3. Uploading a 2.29 GB backup in 6 MB pieces on a host whose upload limit is 8 MB.
4. A blocking limit: not enough free disk space, with both numbers.
5. Restoring, with a named progress line; the live site keeps running until the final switch.
6. Restore finished: the summary and the offer to delete the backup file.

== Changelog ==

= 1.1.0 =
* Fix: Cancel restore stops the restore, after the step that is running.
* Fix: password-protected backups in the older format (made before February 2026).
* Fix: after a restore was killed mid-switch, Cancel and uninstall put your site's folders back.
* Fix: smaller upload pieces when the web server answers HTTP 413.
* Check names the database's largest statement against max_allowed_packet.
* FTP files listed whatever their name; WP-CLI takes listed names and --password-stdin.
* Addresses that only start with the old address are left alone.

= 1.0.0 =
* First release: piecewise upload with resume, the full Check, restore of plain, compressed and password-protected .wpress backups, and WP-CLI commands.
