<?php
/**
 * Plugin Name:       Restorwell – Restore .wpress Backups of Any Size
 * Plugin URI:        https://ochrestack.com/restorwell
 * Description:       Restores a .wpress backup at any size, with or without a password. Checks the whole backup and this server's limits before anything changes. Tools > Restorwell, or wp restorwell.
 * Version:           1.1.1
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       restorwell
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

define( 'RESTORWELL_VERSION', '1.1.1' );
define( 'RESTORWELL_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-restorwell-exception.php';
require_once __DIR__ . '/includes/class-restorwell-crc.php';
require_once __DIR__ . '/includes/class-restorwell-archive.php';
require_once __DIR__ . '/includes/class-restorwell-files.php';
require_once __DIR__ . '/includes/class-restorwell-environment.php';
require_once __DIR__ . '/includes/class-restorwell-check.php';
require_once __DIR__ . '/includes/class-restorwell-replace.php';
require_once __DIR__ . '/includes/class-restorwell-sql.php';
require_once __DIR__ . '/includes/class-restorwell-restore.php';
require_once __DIR__ . '/includes/class-restorwell-admin.php';

register_activation_hook( __FILE__, array( 'Restorwell_Files', 'ensure_folder' ) );

Restorwell_Admin::init();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once __DIR__ . '/includes/class-restorwell-cli.php';
	WP_CLI::add_command( 'restorwell', 'Restorwell_CLI' );
}
