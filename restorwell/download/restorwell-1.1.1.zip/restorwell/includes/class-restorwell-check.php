<?php
/**
 * The Check step: reads the whole backup, confirms its structure and
 * checksums, gathers what the report shows, and lists each limit it
 * checks on this server. Check never writes anything: its progress is
 * carried between requests in a signed token instead of being stored.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resumable backup check.
 */
final class Restorwell_Check {

	const STATE_VERSION = 1;

	/**
	 * Table names that only exist in a multisite network.
	 *
	 * @var string[]
	 */
	private static $multisite_tables = array( 'blogs', 'site', 'sitemeta' );

	/**
	 * Starts a check of a file.
	 *
	 * @param string $path Absolute path.
	 * @return array State.
	 */
	public static function start( $path ) {
		clearstatcache( true, $path );
		return array(
			'v'        => self::STATE_VERSION,
			'path'     => $path,
			'size'     => (int) filesize( $path ),
			'mtime'    => (int) filemtime( $path ),
			'phase'    => 'walk',
			'offset'   => 0,
			'entries'  => 0,
			'unsafe'   => array(),
			'special'  => array(),
			'eof'      => null,
			'error'    => null,
			'package'  => null,
			'password' => 'none',
			'decode'   => false,
			'entry'    => null,
			'cursor'   => array(),
			'acrc'     => '',
			'acrc_len' => 0,
			'files'    => 0,
			'f_bytes'  => 0,
			'stored'   => 0,
			'db_bytes' => 0,
			'tables'   => array(),
			'sql_tail' => '',
			'sql_line' => 0,
			'sql_end'  => '',
			'sql_stmt' => 0,
			'sql_max'  => 0,
			'capture'  => '',
			'plugins'  => array(),
			'themes'   => array(),
		);
	}

	/**
	 * Runs the check until it finishes or the deadline passes.
	 *
	 * @param array  $state    State from start() or a previous step().
	 * @param string $password Password typed on the Check screen ('' for none).
	 * @param float  $deadline microtime(true) limit.
	 * @return array Updated state; 'phase' is 'done' when finished.
	 */
	public static function step( array $state, $password, $deadline ) {
		if ( 'done' === $state['phase'] ) {
			return $state;
		}
		clearstatcache( true, $state['path'] );
		if ( ! is_file( $state['path'] ) || (int) filesize( $state['path'] ) !== $state['size'] || (int) filemtime( $state['path'] ) !== $state['mtime'] ) {
			$state['error'] = array( 'changed', __( 'The backup file changed or disappeared while it was being checked. Choose it again.', 'restorwell' ) );
			$state['phase'] = 'done';
			return $state;
		}

		try {
			$archive = new Restorwell_Archive( $state['path'] );
		} catch ( Restorwell_Exception $e ) {
			$state['error'] = array( $e->get_reason(), $e->text() );
			$state['phase'] = 'done';
			return $state;
		}

		try {
			if ( 'walk' === $state['phase'] ) {
				$state = self::walk( $archive, $state, $password, $deadline );
			}
			if ( 'scan' === $state['phase'] && microtime( true ) < $deadline ) {
				$state = self::scan( $archive, $state, $password, $deadline );
			}
		} catch ( Restorwell_Exception $e ) {
			$reason = $e->get_reason();
			if ( 'password_wrong' === $reason ) {
				$state['password'] = 'wrong';
			}
			$state['error'] = array( $reason, $e->text() );
			$state['phase'] = 'done';
		}
		$archive->close();
		return $state;
	}

	/**
	 * Phase 1: walks every header without reading file contents, to find
	 * damage, unsafe paths and the parts the report needs.
	 *
	 * @param Restorwell_Archive $archive  Archive.
	 * @param array              $state    State.
	 * @param string             $password Password.
	 * @param float              $deadline Deadline.
	 * @return array
	 * @throws Restorwell_Exception On damage.
	 */
	private static function walk( Restorwell_Archive $archive, array $state, $password, $deadline ) {
		$size = $state['size'];
		if ( $size < Restorwell_Archive::HEADER_SIZE ) {
			$exception = Restorwell_Archive::not_wpress();
			throw $exception;
		}
		$n = 0;
		while ( true ) {
			$header = $archive->header_at( $state['offset'] );
			if ( 'eof' === $header['type'] ) {
				if ( $state['offset'] + Restorwell_Archive::HEADER_SIZE !== $size ) {
					$exception = Restorwell_Archive::checksum_failed();
					throw $exception;
				}
				if ( null !== $header['eof_len'] && $header['eof_len'] !== $state['offset'] ) {
					$exception = Restorwell_Archive::checksum_failed();
					throw $exception;
				}
				$state['eof'] = array( $state['offset'], $header['eof_crc'] );
				break;
			}
			++$state['entries'];
			if ( ! $header['safe'] ) {
				if ( count( $state['unsafe'] ) < 5 ) {
					$state['unsafe'][] = $header['folder'] . '/' . $header['name'];
				}
			} elseif ( in_array( $header['relative'], array( 'package.json', 'multisite.json', 'database.sql' ), true ) ) {
				$state['special'][ $header['relative'] ] = array( $header['offset'], $header['size'], $header['mtime'] );
			}
			$next = $header['data_offset'] + $header['size'];
			if ( $next + Restorwell_Archive::HEADER_SIZE > $size ) {
				$exception = Restorwell_Archive::truncated();
				throw $exception;
			}
			$state['offset'] = $next;
			++$n;
			if ( 0 === $n % 250 && microtime( true ) > $deadline ) {
				return $state;
			}
		}

		if ( ! empty( $state['unsafe'] ) ) {
			throw new Restorwell_Exception(
				'unsafe',
				/* translators: %s: a path stored in the backup. */
				sprintf( esc_html__( 'The backup contains a file path that points outside wp-content (%s). Restorwell will not restore it.', 'restorwell' ), esc_html( $state['unsafe'][0] ) )
			);
		}
		if ( ! isset( $state['special']['package.json'] ) ) {
			throw new Restorwell_Exception( 'not_wpress', esc_html__( 'This file has no package.json inside, so it was not made by All-in-One WP Migration or it is damaged.', 'restorwell' ) );
		}

		$pkg_header = $archive->header_at( $state['special']['package.json'][0] );
		$package    = json_decode( $archive->read_raw_entry( $pkg_header ), true );
		if ( ! is_array( $package ) ) {
			throw new Restorwell_Exception( 'not_wpress', esc_html__( 'The package.json inside the backup cannot be read, so the backup is damaged.', 'restorwell' ) );
		}
		$state['package'] = self::package_summary( $package );

		$compression = $state['package']['compression'];
		if ( '' !== $compression && ! in_array( $compression, array( 'gzip', 'bzip2' ), true ) ) {
			throw new Restorwell_Exception( 'compression', esc_html__( 'This backup uses a compression type Restorwell does not know.', 'restorwell' ) );
		}

		$state['password'] = self::password_status( $state['package'], $password );
		$state['decode']   = in_array( $state['password'], array( 'none', 'ok', 'unverified' ), true )
			&& ( 'bzip2' !== $compression || function_exists( 'bzdecompress' ) )
			&& ( ! $state['package']['encrypted'] || function_exists( 'openssl_decrypt' ) );

		if ( 'wrong' === $state['password'] ) {
			$state['phase'] = 'done';
			return $state;
		}
		$state['offset'] = 0;
		$state['phase']  = 'scan';
		return $state;
	}

	/**
	 * Keeps what Restorwell needs from package.json.
	 *
	 * @param array $p Decoded package.json.
	 * @return array
	 */
	public static function package_summary( array $p ) {
		$wp  = isset( $p['WordPress'] ) && is_array( $p['WordPress'] ) ? $p['WordPress'] : array();
		$str = function ( $v ) {
			return is_scalar( $v ) ? (string) $v : '';
		};
		return array(
			'site_url'          => $str( isset( $p['SiteURL'] ) ? $p['SiteURL'] : '' ),
			'home_url'          => $str( isset( $p['HomeURL'] ) ? $p['HomeURL'] : '' ),
			'internal_site_url' => $str( isset( $p['InternalSiteURL'] ) ? $p['InternalSiteURL'] : '' ),
			'internal_home_url' => $str( isset( $p['InternalHomeURL'] ) ? $p['InternalHomeURL'] : '' ),
			'wp_version'        => $str( isset( $wp['Version'] ) ? $wp['Version'] : '' ),
			'abspath'           => $str( isset( $wp['Absolute'] ) ? $wp['Absolute'] : '' ),
			'content_dir'       => $str( isset( $wp['Content'] ) ? $wp['Content'] : '' ),
			'uploads_dir'       => $str( isset( $wp['Uploads'] ) ? $wp['Uploads'] : '' ),
			'uploads_url'       => $str( isset( $wp['UploadsURL'] ) ? $wp['UploadsURL'] : '' ),
			'php_version'       => $str( isset( $p['PHP']['Version'] ) ? $p['PHP']['Version'] : '' ),
			'prefix'            => $str( isset( $p['Database']['Prefix'] ) ? $p['Database']['Prefix'] : '' ),
			'made_with'         => $str( isset( $p['Plugin']['Version'] ) ? $p['Plugin']['Version'] : '' ),
			'plugins'           => isset( $p['Plugins'] ) && is_array( $p['Plugins'] ) ? array_values( array_filter( $p['Plugins'], 'is_string' ) ) : array(),
			'template'          => $str( isset( $p['Template'] ) ? $p['Template'] : '' ),
			'stylesheet'        => $str( isset( $p['Stylesheet'] ) ? $p['Stylesheet'] : '' ),
			'encrypted'         => ! empty( $p['Encrypted'] ),
			'signature'         => $str( isset( $p['EncryptedSignature'] ) ? $p['EncryptedSignature'] : '' ),
			'compression'       => ! empty( $p['Compression']['Enabled'] ) && isset( $p['Compression']['Type'] ) ? $str( $p['Compression']['Type'] ) : '',
		);
	}

	/**
	 * Works out the password status from package.json.
	 *
	 * @param array  $package  Package summary.
	 * @param string $password Password typed.
	 * @return string none | needed | ok | wrong | unverified
	 */
	public static function password_status( array $package, $password ) {
		if ( ! $package['encrypted'] ) {
			return 'none';
		}
		if ( '' === $password ) {
			return 'needed';
		}
		if ( '' === $package['signature'] || ! function_exists( 'openssl_decrypt' ) ) {
			return 'unverified';
		}
		return Restorwell_Archive::password_matches_signature( $package['signature'], $password ) ? 'ok' : 'wrong';
	}

	/**
	 * Phase 2: reads every byte in order. Checksums the whole archive and,
	 * when the contents can be decoded, every file inside it.
	 *
	 * @param Restorwell_Archive $archive  Archive.
	 * @param array              $state    State.
	 * @param string             $password Password.
	 * @param float              $deadline Deadline.
	 * @return array
	 * @throws Restorwell_Exception On damage or a wrong password.
	 */
	private static function scan( Restorwell_Archive $archive, array $state, $password, $deadline ) {
		$eof_offset = $state['eof'][0];
		$pw         = $state['decode'] && $state['package']['encrypted'] ? $password : '';
		$archive->start_raw_hash();
		try {
			while ( microtime( true ) < $deadline ) {
				if ( null === $state['entry'] ) {
					if ( $state['offset'] >= $eof_offset ) {
						break;
					}
					$header           = $archive->header_at( $state['offset'] );
					$state['entry']   = $header;
					$state['cursor']  = array();
					$state['capture'] = '';
				}
				$entry = $state['entry'];
				$rel   = $entry['relative'];
				if ( $state['decode'] || Restorwell_Archive::is_config_file( $rel ) ) {
					$cursor          = $state['cursor'];
					$done            = $archive->decode(
						$entry,
						$cursor,
						Restorwell_Archive::is_stored_plain( $rel, $state['package']['made_with'] ) ? '' : $pw,
						$state['package']['compression'],
						function ( $data ) use ( &$state, $rel ) {
							self::sink( $state, $rel, $data );
						},
						$deadline
					);
					$state['cursor'] = $cursor;
				} else {
					$cursor = $state['cursor'] + array( 'consumed' => 0 );
					while ( $cursor['consumed'] < $entry['size'] ) {
						$n = (int) min( 4194304, $entry['size'] - $cursor['consumed'] );
						$archive->raw_bytes( $entry['data_offset'] + $cursor['consumed'], $n );
						$cursor['consumed'] += $n;
						if ( microtime( true ) > $deadline ) {
							break;
						}
					}
					$state['cursor'] = $cursor;
					$done            = $cursor['consumed'] >= $entry['size'];
				}
				if ( ! $done ) {
					break;
				}
				self::finish_entry( $state );
				$state['offset'] = $entry['data_offset'] + $entry['size'];
				$state['entry']  = null;
			}
		} finally {
			list( $crc, $len )  = $archive->end_raw_hash();
			$state['acrc']      = Restorwell_Crc::combine( $state['acrc'], $crc, $len );
			$state['acrc_len'] += $len;
		}

		if ( null === $state['entry'] && $state['offset'] >= $eof_offset ) {
			if ( null !== $state['eof'][1] && ( $state['acrc_len'] !== $eof_offset || $state['acrc'] !== $state['eof'][1] ) ) {
				$exception = Restorwell_Archive::checksum_failed();
				throw $exception;
			}
			if ( 'unverified' === $state['password'] && $state['decode'] ) {
				$state['password'] = 'ok';
			}
			$state['phase'] = 'done';
		}
		return $state;
	}

	/**
	 * Looks at decoded bytes: database statistics and plugin or theme headers.
	 *
	 * @param array  $state State, updated in place.
	 * @param string $rel   Entry path.
	 * @param string $data  Decoded bytes.
	 */
	private static function sink( array &$state, $rel, $data ) {
		if ( 'database.sql' === $rel ) {
			$state['db_bytes'] += strlen( $data );
			self::measure_statements( $state, $data );
			$lines             = explode( "\n", $state['sql_tail'] . $data );
			$tail              = array_pop( $lines );
			$state['sql_tail'] = substr( $tail, 0, 300 );
			foreach ( $lines as $line ) {
				if ( 0 === strncmp( $line, 'CREATE TABLE `SERVMASK_PREFIX_', 30 ) ) {
					$end = strpos( $line, '`', 30 );
					if ( false !== $end && count( $state['tables'] ) < 2000 ) {
						$state['tables'][] = substr( $line, 30, $end - 30 );
					}
				}
			}
			return;
		}
		if ( strlen( $state['capture'] ) < 8192 && self::is_header_file( $state, $rel ) ) {
			$state['capture'] .= substr( $data, 0, 8192 - strlen( $state['capture'] ) );
		}
	}

	/**
	 * Measures the longest SQL statement, split the way the restore splits
	 * database.sql: a statement ends with a line whose last non-blank
	 * character is a semicolon. The database server must accept a statement
	 * of that size (max_allowed_packet).
	 *
	 * @param array  $state State, updated in place.
	 * @param string $data  Decoded bytes of database.sql, or '' at its end.
	 */
	private static function measure_statements( array &$state, $data ) {
		$pieces = explode( "\n", $data );
		$last   = count( $pieces ) - 1;
		foreach ( $pieces as $i => $piece ) {
			$state['sql_line'] += strlen( $piece );
			$trimmed            = rtrim( $piece );
			if ( '' !== $trimmed ) {
				$state['sql_end'] = substr( $trimmed, -1 );
			}
			if ( $i === $last && '' !== $data ) {
				break;
			}
			// A whole line ends here (or the file does).
			$state['sql_stmt'] += $state['sql_line'] + 1;
			if ( ';' === $state['sql_end'] || '' === $data ) {
				$state['sql_max']  = max( $state['sql_max'], $state['sql_stmt'] );
				$state['sql_stmt'] = 0;
			}
			$state['sql_line'] = 0;
			$state['sql_end']  = '';
		}
	}

	/**
	 * Whether an entry is the main file of an active plugin or a theme's style.css.
	 *
	 * @param array  $state State.
	 * @param string $rel   Entry path.
	 * @return bool
	 */
	private static function is_header_file( array $state, $rel ) {
		if ( 0 === strpos( $rel, 'plugins/' ) && in_array( substr( $rel, 8 ), $state['package']['plugins'], true ) ) {
			return true;
		}
		foreach ( array( $state['package']['stylesheet'], $state['package']['template'] ) as $theme ) {
			if ( '' !== $theme && 'themes/' . $theme . '/style.css' === $rel ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Updates counters when an entry has been read completely.
	 *
	 * @param array $state State, updated in place.
	 */
	private static function finish_entry( array &$state ) {
		$entry = $state['entry'];
		$rel   = $entry['relative'];
		if ( Restorwell_Archive::is_config_file( $rel ) ) {
			return;
		}
		if ( 'database.sql' === $rel ) {
			self::measure_statements( $state, '' );
			if ( '' !== $state['sql_tail'] && 0 === strncmp( $state['sql_tail'], 'CREATE TABLE `SERVMASK_PREFIX_', 30 ) ) {
				$state['sql_tail'] .= "\n";
				self::sink( $state, $rel, '' );
			}
			return;
		}
		++$state['files'];
		$state['stored']  += $entry['size'];
		$state['f_bytes'] += $state['decode'] ? (int) $state['cursor']['written'] : $entry['size'];
		if ( '' !== $state['capture'] ) {
			$headers = self::parse_headers( $state['capture'] );
			if ( 0 === strpos( $rel, 'plugins/' ) ) {
				$state['plugins'][ substr( $rel, 8 ) ] = array(
					'name'    => $headers['Plugin Name'],
					'version' => $headers['Version'],
				);
			} else {
				$parts                        = explode( '/', $rel );
				$state['themes'][ $parts[1] ] = array(
					'name'    => $headers['Theme Name'],
					'version' => $headers['Version'],
				);
			}
			$state['capture'] = '';
		}
	}

	/**
	 * Reads WordPress file headers from the start of a file.
	 *
	 * @param string $text First 8 KB.
	 * @return array<string,string>
	 */
	private static function parse_headers( $text ) {
		$out = array();
		foreach ( array( 'Plugin Name', 'Theme Name', 'Version' ) as $field ) {
			$out[ $field ] = '';
			if ( preg_match( '/^(?:[ \t]*<\?php)?[ \t\/*#@]*' . preg_quote( $field, '/' ) . ':(.*)$/mi', $text, $m ) ) {
				$out[ $field ] = trim( preg_replace( '/\s*(?:\*\/|\?>).*/', '', $m[1] ) );
			}
		}
		return $out;
	}

	/**
	 * Builds the report and the list of limits.
	 *
	 * @param array      $state State after the check.
	 * @param array|null $env   Server facts; defaults to this server.
	 * @return array
	 */
	public static function report( array $state, $env = null ) {
		$env      = null === $env ? Restorwell_Environment::snapshot() : $env;
		$pkg      = is_array( $state['package'] ) ? $state['package'] : null;
		$done     = 'done' === $state['phase'];
		$decoded  = $done && null === $state['error'] && $state['decode'];
		$tables   = $state['tables'];
		$ms_found = (bool) array_intersect( self::$multisite_tables, $tables ) || isset( $state['special']['multisite.json'] );

		$plugins = array();
		if ( $pkg ) {
			foreach ( $pkg['plugins'] as $basename ) {
				$info      = isset( $state['plugins'][ $basename ] ) ? $state['plugins'][ $basename ] : null;
				$plugins[] = array(
					'basename' => $basename,
					'name'     => $info && '' !== $info['name'] ? $info['name'] : $basename,
					'version'  => $info ? $info['version'] : '',
				);
			}
		}
		$theme = null;
		if ( $pkg && '' !== $pkg['stylesheet'] ) {
			$theme = array(
				'stylesheet' => $pkg['stylesheet'],
				'name'       => isset( $state['themes'][ $pkg['stylesheet'] ] ) && '' !== $state['themes'][ $pkg['stylesheet'] ]['name'] ? $state['themes'][ $pkg['stylesheet'] ]['name'] : $pkg['stylesheet'],
				'template'   => $pkg['template'],
			);
			if ( $pkg['template'] && $pkg['template'] !== $pkg['stylesheet'] ) {
				$theme['parent'] = isset( $state['themes'][ $pkg['template'] ] ) && '' !== $state['themes'][ $pkg['template'] ]['name'] ? $state['themes'][ $pkg['template'] ]['name'] : $pkg['template'];
			}
		}

		$db_stored = isset( $state['special']['database.sql'] ) ? $state['special']['database.sql'][1] : 0;
		$report    = array(
			'file'            => wp_basename( $state['path'] ),
			'size'            => $state['size'],
			'complete'        => $done,
			'progress'        => $state['size'] > 0 ? min( 100, (int) floor( ( 'walk' === $state['phase'] ? 0 : $state['acrc_len'] ) * 100 / $state['size'] ) ) : 0,
			'site_url'        => $pkg ? $pkg['site_url'] : '',
			'home_url'        => $pkg ? $pkg['home_url'] : '',
			'wp_version'      => $pkg ? $pkg['wp_version'] : '',
			'php_version'     => $pkg ? $pkg['php_version'] : '',
			'prefix'          => $pkg ? $pkg['prefix'] : '',
			'made_with'       => $pkg ? $pkg['made_with'] : '',
			'made_on'         => isset( $state['special']['package.json'] ) ? (int) $state['special']['package.json'][2] : 0,
			'files'           => $done && null === $state['error'] ? $state['files'] : null,
			'files_bytes'     => $decoded ? $state['f_bytes'] : null,
			'database_bytes'  => $decoded ? $state['db_bytes'] : null,
			'database_stored' => $db_stored,
			'tables'          => $decoded ? count( $tables ) : null,
			'longest_sql'     => $decoded && isset( $state['sql_max'] ) ? (int) $state['sql_max'] : null,
			'plugins'         => $plugins,
			'theme'           => $theme,
			'compression'     => $pkg ? $pkg['compression'] : '',
			'encrypted'       => $pkg ? $pkg['encrypted'] : false,
			'password'        => $state['password'],
			'multisite'       => $decoded ? $ms_found : ( isset( $state['special']['multisite.json'] ) ? true : null ),
			'error'           => $state['error'] ? array(
				'reason'  => $state['error'][0],
				'message' => $state['error'][1],
			) : null,
		);

		$report['disk_needed'] = self::disk_needed( $report, $state );
		$report['limits']      = self::limits( $report, $env, $state );
		$blocked               = false;
		foreach ( $report['limits'] as $limit ) {
			if ( 'block' === $limit['level'] ) {
				$blocked = true;
			}
		}
		$report['can_restore'] = $done && ! $blocked && null === $state['error'];
		return $report;
	}

	/**
	 * Estimates the free disk space a restore needs: the unpacked files and
	 * the database file beside the live site, plus a safety margin.
	 *
	 * @param array $report Report so far.
	 * @param array $state  State.
	 * @return array{bytes:float,exact:bool}
	 */
	private static function disk_needed( array $report, array $state ) {
		if ( null !== $report['files_bytes'] ) {
			$bytes = $report['files_bytes'] + 2 * $report['database_bytes'];
			$exact = true;
		} else {
			$bytes = $state['stored'] > 0 ? $state['stored'] + 2 * $report['database_stored'] : $state['size'];
			$exact = '' === $report['compression'] && ! $report['encrypted'];
		}
		return array(
			'bytes' => (float) ( $bytes + 50 * MB_IN_BYTES + $bytes * 0.02 ),
			'exact' => $exact,
		);
	}

	/**
	 * Lists each limit it checks, in plain words.
	 *
	 * @param array $r     Report.
	 * @param array $env   Server facts.
	 * @param array $state State.
	 * @return array[] Each: code, level (ok|warn|block), message.
	 */
	private static function limits( array $r, array $env, array $state ) {
		$limits = array();
		$add    = function ( $code, $level, $message ) use ( &$limits ) {
			$limits[] = array(
				'code'    => $code,
				'level'   => $level,
				'message' => $message,
			);
		};

		if ( $env['multisite'] ) {
			$add( 'target_multisite', 'block', __( 'This WordPress is a multisite network. Restorwell restores into single sites only.', 'restorwell' ) );
		}
		if ( ! $env['mysql'] ) {
			$add( 'target_database', 'block', __( 'This site does not use a MySQL or MariaDB database (for example it runs on SQLite). Restorwell restores into MySQL and MariaDB only.', 'restorwell' ) );
		}

		if ( $r['error'] ) {
			$code = 'password_wrong' === $r['error']['reason'] ? 'password' : 'structure';
			$add( $code, 'block', $r['error']['message'] );
		} elseif ( $r['complete'] ) {
			if ( null !== $state['eof'] && null !== $state['eof'][1] ) {
				$msg = $state['decode']
					? __( 'Structure and checksums: every part of the backup was read, and the checksum of the whole file and of every file inside it matches.', 'restorwell' )
					: __( 'Structure and checksum: every part of the backup was read and the checksum of the whole file matches. The files inside are checked once the password is accepted.', 'restorwell' );
			} else {
				$msg = $state['decode']
					? __( 'Structure and checksums: every part of the backup was read and every file inside it matches its checksum. (This backup is from an older version without a checksum for the whole file.)', 'restorwell' )
					: __( 'Structure: every part of the backup was read. This older backup has no checksum for the whole file.', 'restorwell' );
			}
			$add( 'structure', 'ok', $msg );
		}

		if ( 'needed' === $r['password'] ) {
			$add( 'password', 'block', __( 'Password needed: this backup is password-protected. Type its password and check again. The password is used only while checking and restoring, and is never saved.', 'restorwell' ) );
		} elseif ( 'wrong' === $r['password'] && ( ! $r['error'] || 'password_wrong' !== $r['error']['reason'] ) ) {
			$add( 'password', 'block', __( 'Wrong password: the password typed does not open this backup. Passwords are case-sensitive; type it again and check again.', 'restorwell' ) );
		} elseif ( 'ok' === $r['password'] ) {
			$add( 'password', 'ok', __( 'Password accepted. It is used only while restoring and is never saved.', 'restorwell' ) );
		}

		if ( ! empty( $env['other_disk'] ) ) {
			$add(
				'other_disk',
				'block',
				sprintf(
					/* translators: 1: Restorwell's backup folder, 2: list of folders. */
					__( 'Restorwell\'s backup folder (%1$s) is on a different disk from %2$s, so the restored folders could not be switched into place. Make %1$s an ordinary folder inside wp-content (not a link to another disk), move the backup into it, then check again.', 'restorwell' ),
					'wp-content/' . Restorwell_Files::FOLDER,
					implode( ', ', $env['other_disk'] )
				)
			);
		}

		if ( 'bzip2' === $r['compression'] && ! $env['bz2'] ) {
			$add( 'bzip2', 'block', __( 'This backup is compressed with bzip2, and PHP on this server does not have the bz2 extension. Ask your host to enable the PHP bz2 extension, then check again.', 'restorwell' ) );
		}
		if ( $r['encrypted'] && ! $env['openssl'] ) {
			$add( 'openssl', 'block', __( 'This backup is password-protected, and PHP on this server does not have the OpenSSL extension needed to decrypt it. Ask your host to enable it.', 'restorwell' ) );
		}
		if ( 4 === (int) $env['int_size'] && $r['size'] > 2147483647 ) {
			$add( 'php32', 'block', __( 'This server runs 32-bit PHP, which cannot read files larger than 2 GB. Ask your host for 64-bit PHP.', 'restorwell' ) );
		}

		if ( true === $r['multisite'] ) {
			$add( 'multisite', 'block', __( 'This backup is of a WordPress multisite network. Restorwell restores single sites only, so it cannot restore this backup.', 'restorwell' ) );
		} elseif ( false === $r['multisite'] ) {
			$add( 'multisite', 'ok', __( 'Single site: this backup is not of a multisite network.', 'restorwell' ) );
		}

		$need = $r['disk_needed']['bytes'];
		if ( $r['error'] && 'password_wrong' !== $r['error']['reason'] ) {
			return $limits;
		}
		if ( null === $env['free_bytes'] ) {
			$add(
				'disk',
				'warn',
				/* translators: %s: size such as "2.3 GB". */
				sprintf( __( 'Free disk space could not be measured on this server (the host has turned that off). Make sure at least %s is free before restoring.', 'restorwell' ), Restorwell_Files::size_label( $need ) )
			);
		} else {
			$enough = $env['free_bytes'] >= $need;
			$add(
				'disk',
				$enough ? 'ok' : 'block',
				sprintf(
					/* translators: 1: needed size, 2: available size. */
					$enough ? __( 'Free disk space: %1$s needed, %2$s available.', 'restorwell' ) : __( 'Not enough free disk space: %1$s is needed and only %2$s is available. Free some space (for example delete old backups) or ask your host for more, then check again.', 'restorwell' ),
					sprintf(
						/* translators: %s: size. */
						$r['disk_needed']['exact'] ? __( 'about %s', 'restorwell' ) : __( 'at least %s', 'restorwell' ),
						Restorwell_Files::size_label( $need )
					),
					Restorwell_Files::size_label( $env['free_bytes'] )
				)
			);
		}

		if ( null !== $r['longest_sql'] && ! empty( $env['max_packet'] ) && $r['longest_sql'] > 0 ) {
			// Room for the temporary table prefix and longer addresses after replacement.
			$packet_needed = (int) ceil( $r['longest_sql'] * 1.02 ) + 4096;
			$fits          = $packet_needed <= (int) $env['max_packet'];
			$add(
				'packet',
				$fits ? 'ok' : 'block',
				sprintf(
					/* translators: 1: size of the largest statement, 2: the server's max_allowed_packet, 3: size to ask for. */
					$fits ? __( 'Database statement size: the largest in the backup is %1$s; this database server accepts up to %2$s in one statement.', 'restorwell' ) : __( 'The backup\'s database holds a statement of %1$s (one very large row, or many rows written together), and this database server accepts at most %2$s in one statement (its max_allowed_packet setting). Ask your host to raise max_allowed_packet to at least %3$s, then check again.', 'restorwell' ),
					Restorwell_Files::size_label( $r['longest_sql'] ),
					Restorwell_Files::size_label( (int) $env['max_packet'] ),
					Restorwell_Files::size_label( (int) ( ceil( $packet_needed / MB_IN_BYTES ) * MB_IN_BYTES ) )
				)
			);
		}

		if ( '' !== $r['wp_version'] ) {
			$newer = version_compare( self::clean_version( $r['wp_version'] ), self::clean_version( $env['wp_version'] ), '>' );
			$add(
				'wp_version',
				$newer ? 'warn' : 'ok',
				sprintf(
					/* translators: 1: version in the backup, 2: version on this site. */
					$newer ? __( 'Newer WordPress in the backup: it was made with WordPress %1$s and this site runs %2$s. Update WordPress here first (Dashboard > Updates) for the safest result; you may restore anyway.', 'restorwell' ) : __( 'WordPress: the backup was made with %1$s; this site runs %2$s.', 'restorwell' ),
					$r['wp_version'],
					$env['wp_version']
				)
			);
		}
		if ( '' !== $r['php_version'] ) {
			$newer = version_compare( self::clean_version( $r['php_version'], 2 ), self::clean_version( $env['php_version'], 2 ), '>' );
			$add(
				'php_version',
				$newer ? 'warn' : 'ok',
				sprintf(
					/* translators: 1: version in the backup, 2: version on this server. */
					$newer ? __( 'Newer PHP in the backup: the site ran on PHP %1$s and this server has PHP %2$s. Some plugins or themes may need the newer PHP; ask your host to switch PHP versions if the restored site shows errors. You may restore anyway.', 'restorwell' ) : __( 'PHP: the site ran on PHP %1$s; this server has PHP %2$s.', 'restorwell' ),
					$r['php_version'],
					$env['php_version']
				)
			);
		}
		return $limits;
	}

	/**
	 * Normalises a version for comparison, keeping the first parts.
	 *
	 * @param string $version Version.
	 * @param int    $parts   Parts to keep.
	 * @return string
	 */
	private static function clean_version( $version, $parts = 3 ) {
		preg_match( '/^\d+(?:\.\d+)*/', (string) $version, $m );
		$v = isset( $m[0] ) ? explode( '.', $m[0] ) : array( '0' );
		return implode( '.', array_slice( $v, 0, $parts ) );
	}

	/**
	 * Packs a state into a signed token so it can travel through the browser.
	 *
	 * @param array $state State.
	 * @return string
	 */
	public static function sign( array $state ) {
		$json = wp_json_encode( $state );
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Transport encoding for the signed state.
		$body = base64_encode( (string) gzcompress( (string) $json, 6 ) );
		return $body . '.' . hash_hmac( 'sha256', $body, wp_salt( 'auth' ) . 'restorwell-check' );
	}

	/**
	 * Unpacks a token made by sign(), refusing anything altered.
	 *
	 * @param string $token Token.
	 * @return array|null
	 */
	public static function verify( $token ) {
		if ( ! is_string( $token ) || false === strpos( $token, '.' ) ) {
			return null;
		}
		list( $body, $mac ) = explode( '.', $token, 2 );
		if ( ! hash_equals( hash_hmac( 'sha256', $body, wp_salt( 'auth' ) . 'restorwell-check' ), $mac ) ) {
			return null;
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Transport encoding for the signed state.
		$raw  = base64_decode( $body, true );
		$json = false === $raw ? false : @gzuncompress( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$data = false === $json ? null : json_decode( $json, true );
		return is_array( $data ) && isset( $data['v'] ) && self::STATE_VERSION === $data['v'] ? $data : null;
	}

	/**
	 * Runs a whole check in one go (WP-CLI and the restore's own re-check).
	 *
	 * @param string $path     File.
	 * @param string $password Password.
	 * @return array State.
	 */
	public static function run( $path, $password ) {
		$state = self::start( $path );
		while ( 'done' !== $state['phase'] ) {
			$state = self::step( $state, $password, microtime( true ) + 30 );
		}
		return $state;
	}
}
