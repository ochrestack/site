<?php
/**
 * The folders Restorwell reads backups from, the piecewise uploader's
 * storage, and validation of every file name that comes from a request.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Backup folders, file references and uploads.
 */
final class Restorwell_Files {

	const FOLDER = 'restorwell-backups';

	/**
	 * Restorwell's own folder, where uploads land and where a file copied by
	 * FTP or the host's File Manager is picked up.
	 *
	 * @return string Absolute path without trailing slash.
	 */
	public static function folder() {
		return WP_CONTENT_DIR . '/' . self::FOLDER;
	}

	/**
	 * All-in-One WP Migration's backups folder.
	 *
	 * @return string Absolute path without trailing slash.
	 */
	public static function ai1wm_folder() {
		if ( defined( 'AI1WM_BACKUPS_PATH' ) && is_string( AI1WM_BACKUPS_PATH ) ) {
			return untrailingslashit( AI1WM_BACKUPS_PATH );
		}
		return WP_CONTENT_DIR . '/ai1wm-backups';
	}

	/**
	 * Folders that are listed, keyed by the source name used in references.
	 *
	 * @return array<string,string>
	 */
	public static function sources() {
		return array(
			'restorwell' => self::folder(),
			'ai1wm'      => self::ai1wm_folder(),
		);
	}

	/**
	 * Creates Restorwell's folder and the files that stop a web server from
	 * listing or serving its contents.
	 *
	 * @return bool
	 */
	public static function ensure_folder() {
		$dir = self::folder();
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		$guards = array(
			'index.php'  => "<?php\n// Silence is golden.\n",
			'.htaccess'  => "# Backups are private.\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\nOptions -Indexes\n",
			'web.config' => "<configuration>\n<system.webServer>\n<authorization>\n<deny users=\"*\" />\n</authorization>\n</system.webServer>\n</configuration>\n",
		);
		foreach ( $guards as $name => $content ) {
			if ( ! file_exists( $dir . '/' . $name ) ) {
				file_put_contents( $dir . '/' . $name, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Small guard files in the plugin's own folder.
			}
		}
		return true;
	}

	/**
	 * Whether a bare file name is acceptable for a backup.
	 *
	 * @param string $name File name.
	 * @return bool
	 */
	public static function is_valid_name( $name ) {
		if ( ! is_string( $name ) || '' === $name || strlen( $name ) > 255 ) {
			return false;
		}
		// Names a browser or a person gives a copy ("site (1).wpress", "My Site Backup.wpress",
		// "site.old.wpress") are fine. Only path separators, control characters and
		// hidden names (which include Restorwell's unfinished uploads) are refused.
		if ( '.' === $name[0] || false !== strpbrk( $name, '/\\' ) || 1 === preg_match( '/[\x00-\x1f\x7f]/', $name ) ) {
			return false;
		}
		return 1 === preg_match( '/\.wpress$/i', $name );
	}

	/**
	 * Turns an uploaded file name into a safe one, keeping the .wpress ending.
	 *
	 * @param string $name Name from the browser.
	 * @return string|false
	 */
	public static function clean_upload_name( $name ) {
		$name = (string) $name;
		if ( '' === $name || '.' === $name[0] || false !== strpbrk( $name, "/\\\0" ) ) {
			return false;
		}
		$name = sanitize_file_name( $name );
		return self::is_valid_name( $name ) ? $name : false;
	}

	/**
	 * Resolves a reference "source:name" to an absolute path, refusing
	 * anything that is not a regular .wpress file inside its folder.
	 *
	 * @param string $ref Reference from a request.
	 * @return string|false Absolute path, or false when refused.
	 */
	public static function resolve( $ref ) {
		if ( ! is_string( $ref ) || false === strpos( $ref, ':' ) ) {
			return false;
		}
		list( $source, $name ) = explode( ':', $ref, 2 );
		$sources               = self::sources();
		if ( ! isset( $sources[ $source ] ) || ! self::is_valid_name( $name ) ) {
			return false;
		}
		$dir_real = realpath( $sources[ $source ] );
		if ( false === $dir_real ) {
			return false;
		}
		$path      = $dir_real . DIRECTORY_SEPARATOR . $name;
		$path_real = realpath( $path );
		if ( false === $path_real || ! is_file( $path_real ) ) {
			return false;
		}
		// The file, or the target of a link, must sit directly in the folder.
		if ( dirname( $path_real ) !== $dir_real ) {
			return false;
		}
		return $path_real;
	}

	/**
	 * Builds the reference for a file in one of the folders.
	 *
	 * @param string $source Source key.
	 * @param string $name   File name.
	 * @return string
	 */
	public static function ref( $source, $name ) {
		return $source . ':' . $name;
	}

	/**
	 * Lists the .wpress files in both folders.
	 *
	 * @return array[] Each: ref, name, folder (label), path, size, modified.
	 */
	public static function list_backups() {
		$out = array();
		foreach ( self::sources() as $source => $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			}
			$names = scandir( $dir );
			foreach ( (array) $names as $name ) {
				if ( ! self::is_valid_name( $name ) ) {
					continue;
				}
				$ref  = self::ref( $source, $name );
				$path = self::resolve( $ref );
				if ( false === $path ) {
					continue;
				}
				$out[] = array(
					'ref'      => $ref,
					'name'     => $name,
					'folder'   => 'restorwell' === $source ? 'wp-content/' . self::FOLDER : 'wp-content/' . wp_basename( $dir ),
					'size'     => (int) filesize( $path ),
					'modified' => (int) filemtime( $path ),
				);
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['modified'] - $a['modified'];
			}
		);
		return $out;
	}

	/**
	 * Size of each upload piece: comfortably below the host's upload limit.
	 *
	 * @return int Bytes.
	 */
	public static function chunk_size() {
		$limit = (int) wp_max_upload_size();
		$post  = (int) wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) );
		if ( $post > 0 ) {
			$limit = $limit > 0 ? min( $limit, $post ) : $post;
		}
		if ( $limit <= 0 ) {
			$limit = 2 * MB_IN_BYTES;
		}
		$size = (int) floor( $limit * 0.75 / 65536 ) * 65536;
		$size = max( 65536, min( 16 * MB_IN_BYTES, $size ) );
		return (int) apply_filters( 'restorwell_chunk_size', $size, $limit );
	}

	/**
	 * Path of the partial file for an upload.
	 *
	 * @param string $name     Clean file name.
	 * @param int    $size     Total size.
	 * @param int    $modified Last-modified time reported by the browser, in ms.
	 * @return string
	 */
	public static function part_path( $name, $size, $modified ) {
		return self::folder() . '/.' . $name . '.' . (int) $size . '.' . (int) $modified . '.part';
	}

	/**
	 * How many bytes of an upload have arrived.
	 *
	 * @param string $name     Clean file name.
	 * @param int    $size     Total size.
	 * @param int    $modified Last-modified time in ms.
	 * @return int
	 */
	public static function received( $name, $size, $modified ) {
		$part = self::part_path( $name, $size, $modified );
		clearstatcache( true, $part );
		return is_file( $part ) ? (int) filesize( $part ) : 0;
	}

	/**
	 * Appends one piece to an upload.
	 *
	 * @param string $name     Clean file name.
	 * @param int    $size     Total size.
	 * @param int    $modified Last-modified time in ms.
	 * @param int    $offset   Where the piece starts.
	 * @param string $tmp      Uploaded temporary file holding the piece.
	 * @return array{received:int,complete:bool,ref?:string,name?:string}
	 * @throws Restorwell_Exception On a write failure or a piece that does not fit.
	 */
	public static function append_chunk( $name, $size, $modified, $offset, $tmp ) {
		if ( ! self::ensure_folder() ) {
			throw new Restorwell_Exception( 'not_writable', esc_html__( 'Restorwell cannot create its folder in wp-content. Ask your host to make wp-content writable by the web server.', 'restorwell' ) );
		}
		$part     = self::part_path( $name, $size, $modified );
		$received = self::received( $name, $size, $modified );
		if ( $offset !== $received ) {
			return array(
				'received' => $received,
				'complete' => false,
			);
		}
		$length = (int) filesize( $tmp );
		if ( $length <= 0 || $offset + $length > $size ) {
			throw new Restorwell_Exception( 'bad_piece', esc_html__( 'A piece of the upload did not match the file. Choose the file again to continue.', 'restorwell' ) );
		}
		// phpcs:disable WordPress.WP.AlternativeFunctions -- Appending pieces of a multi-gigabyte file; WP_Filesystem cannot append.
		$in  = fopen( $tmp, 'rb' );
		$out = fopen( $part, 'ab' );
		if ( false === $in || false === $out ) {
			throw new Restorwell_Exception( 'not_writable', esc_html__( 'Restorwell could not write the upload to disk. Check the free disk space and that wp-content is writable.', 'restorwell' ) );
		}
		$copied = stream_copy_to_stream( $in, $out );
		fclose( $in );
		fclose( $out );
		// phpcs:enable
		if ( $copied !== $length ) {
			// Drop the half-written piece so the next attempt starts at a clean edge.
			$handle = fopen( $part, 'r+b' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			if ( $handle ) {
				ftruncate( $handle, $offset );
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			}
			throw new Restorwell_Exception( 'disk_full', esc_html__( 'The server ran out of disk space while receiving the upload. Free some space, then choose the same file to continue.', 'restorwell' ) );
		}
		$received = $offset + $length;
		if ( $received < $size ) {
			return array(
				'received' => $received,
				'complete' => false,
			);
		}
		$final = self::unique_name( $name );
		if ( ! rename( $part, self::folder() . '/' . $final ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			throw new Restorwell_Exception( 'not_writable', esc_html__( 'The upload arrived but could not be renamed. Check that wp-content is writable.', 'restorwell' ) );
		}
		return array(
			'received' => $received,
			'complete' => true,
			'ref'      => self::ref( 'restorwell', $final ),
			'name'     => $final,
		);
	}

	/**
	 * Picks a name not yet used in Restorwell's folder.
	 *
	 * @param string $name Wanted name.
	 * @return string
	 */
	public static function unique_name( $name ) {
		$dir = self::folder();
		if ( ! file_exists( $dir . '/' . $name ) ) {
			return $name;
		}
		$base = substr( $name, 0, -7 );
		for ( $i = 2; $i < 1000; $i++ ) {
			$try = $base . '-' . $i . '.wpress';
			if ( ! file_exists( $dir . '/' . $try ) ) {
				return $try;
			}
		}
		return $base . '-' . wp_generate_password( 6, false ) . '.wpress';
	}

	/**
	 * Unfinished uploads in Restorwell's folder.
	 *
	 * @return array[] Each: id, name, size, received.
	 */
	public static function list_partials() {
		$out = array();
		$dir = self::folder();
		if ( ! is_dir( $dir ) ) {
			return $out;
		}
		foreach ( (array) scandir( $dir ) as $file ) {
			if ( 1 === preg_match( '/^\.(.+\.wpress)\.(\d+)\.(\d+)\.part$/i', $file, $m ) && ! is_link( $dir . '/' . $file ) ) {
				$out[] = array(
					'id'       => $file,
					'name'     => $m[1],
					'size'     => (int) $m[2],
					'received' => (int) filesize( $dir . '/' . $file ),
				);
			}
		}
		return $out;
	}

	/**
	 * Deletes an unfinished upload.
	 *
	 * @param string $id Partial file name as listed.
	 * @return bool
	 */
	public static function delete_partial( $id ) {
		foreach ( self::list_partials() as $partial ) {
			if ( $partial['id'] === $id ) {
				return wp_delete_file_from_directory( self::folder() . '/' . $id, self::folder() ) || ! file_exists( self::folder() . '/' . $id );
			}
		}
		return false;
	}

	/**
	 * Deletes a listed backup file.
	 *
	 * @param string $ref Reference.
	 * @return bool
	 */
	public static function delete_backup( $ref ) {
		$path = self::resolve( $ref );
		if ( false === $path || is_link( $path ) ) {
			return false;
		}
		wp_delete_file( $path );
		return ! file_exists( $path );
	}

	/**
	 * Formats a byte count.
	 *
	 * @param int|float $bytes Bytes.
	 * @return string
	 */
	public static function size_label( $bytes ) {
		return size_format( (float) $bytes, $bytes >= GB_IN_BYTES ? 2 : 1 );
	}

	/**
	 * Formats a size in whole units when it is one ("8 MB"), with one decimal
	 * otherwise ("1.5 MB"), so two different sizes never read the same.
	 *
	 * @param int|float $bytes Bytes.
	 * @return string
	 */
	public static function short_size_label( $bytes ) {
		$bytes = (float) $bytes;
		foreach ( array( GB_IN_BYTES, MB_IN_BYTES, KB_IN_BYTES ) as $unit ) {
			if ( $bytes >= $unit ) {
				$value = $bytes / $unit;
				return size_format( $bytes, round( $value, 1 ) === round( $value ) ? 0 : 1 );
			}
		}
		return size_format( $bytes, 0 );
	}

	/**
	 * Deletes a folder and everything in it, stopping at the deadline.
	 *
	 * @param string $dir      Folder.
	 * @param float  $deadline microtime(true) limit, or 0 for none.
	 * @return bool True when the folder is gone.
	 */
	public static function remove_tree( $dir, $deadline = 0.0 ) {
		if ( ! file_exists( $dir ) && ! is_link( $dir ) ) {
			return true;
		}
		if ( is_link( $dir ) || is_file( $dir ) ) {
			return unlink( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
		}
		$it = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);
		$n  = 0;
		foreach ( $it as $item ) {
			$path = $item->getPathname();
			if ( $item->isDir() && ! $item->isLink() ) {
				rmdir( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
			} else {
				unlink( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			}
			++$n;
			if ( $deadline > 0 && 0 === $n % 200 && microtime( true ) > $deadline ) {
				return false;
			}
		}
		return rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
	}
}
