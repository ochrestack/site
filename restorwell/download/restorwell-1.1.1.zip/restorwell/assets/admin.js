/**
 * Restorwell screen: piecewise upload with resume, file list, Check report,
 * restore progress and the finished screen. No libraries beyond wp.i18n.
 */
( function () {
	'use strict';

	var data = window.restorwellData;
	if ( data ) {
		// wp_localize_script() turns top-level numbers into strings.
		data.chunkSize = parseInt( data.chunkSize, 10 );
		data.uploadLimit = parseInt( data.uploadLimit, 10 );
		data.review = !! data.review && '0' !== data.review && '' !== data.review;
	}
	var i18n = window.wp && window.wp.i18n;
	var __ = i18n.__;
	var sprintf = i18n.sprintf;
	var root = document.getElementById( 'restorwell' );
	if ( ! root || ! data ) {
		return;
	}

	var state = { ref: null, name: '', token: null, report: null, busy: false, restoring: false, cancelRequested: false };

	function $( id ) {
		return document.getElementById( id );
	}

	function el( tag, attrs, children ) {
		var node = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( key ) {
			if ( 'text' === key ) {
				node.textContent = attrs[ key ];
			} else if ( 'className' === key ) {
				node.className = attrs[ key ];
			} else if ( 'on' === key ) {
				Object.keys( attrs.on ).forEach( function ( ev ) {
					node.addEventListener( ev, attrs.on[ ev ] );
				} );
			} else {
				node.setAttribute( key, attrs[ key ] );
			}
		} );
		( children || [] ).forEach( function ( child ) {
			node.appendChild( 'string' === typeof child ? document.createTextNode( child ) : child );
		} );
		return node;
	}

	function sizeLabel( bytes ) {
		var units = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
		var i = 0;
		while ( bytes >= 1024 && i < units.length - 1 ) {
			bytes /= 1024;
			i++;
		}
		return ( i === 0 ? bytes : bytes.toFixed( i >= 3 ? 2 : 1 ) ) + ' ' + units[ i ];
	}

	function notice( message, type ) {
		var box = $( 'rw-notice' );
		box.hidden = ! message;
		box.className = 'rw-notice notice inline notice-' + ( type || 'info' );
		box.textContent = '';
		if ( message ) {
			box.appendChild( el( 'p', { text: message } ) );
		}
	}

	function setStep( step ) {
		root.querySelectorAll( '.rw-step' ).forEach( function ( li ) {
			li.classList.toggle( 'is-current', li.getAttribute( 'data-step' ) === step );
		} );
		$( 'rw-choose' ).hidden = 'choose' !== step;
		$( 'rw-check' ).hidden = 'check' !== step;
		$( 'rw-restore-section' ).hidden = 'restore' !== step;
	}

	function setProgress( container, percent, label ) {
		container.hidden = false;
		container.querySelector( '.rw-bar span' ).style.width = Math.max( 0, Math.min( 100, percent ) ) + '%';
		container.querySelector( '.rw-progress-label' ).textContent = label;
	}

	function sleep( ms ) {
		return new Promise( function ( resolve ) {
			setTimeout( resolve, ms );
		} );
	}

	/**
	 * Posts to admin-ajax. Resolves with `data`, rejects with an Error whose
	 * `info` holds the error payload.
	 */
	function api( action, fields, blob ) {
		var body = new FormData();
		body.append( 'action', 'restorwell_' + action );
		body.append( 'nonce', data.nonce );
		Object.keys( fields || {} ).forEach( function ( key ) {
			body.append( key, fields[ key ] );
		} );
		if ( blob ) {
			body.append( 'chunk', blob, 'chunk.bin' );
		}
		return fetch( data.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( response ) {
			return response.text().then( function ( text ) {
				var json = null;
				try {
					json = JSON.parse( text );
				} catch ( e ) {
					json = null;
				}
				if ( json && json.success ) {
					return json.data;
				}
				var info = json && json.data ? json.data : {};
				var err = new Error( info.message || ( '-1' === text || '0' === text ? __( 'Your session expired. Reload the page and log in again.', 'restorwell' ) : sprintf( __( 'The server answered with an error (HTTP %d).', 'restorwell' ), response.status ) ) );
				err.info = info;
				err.status = response.status;
				throw err;
			} );
		} );
	}

	/** Retries network failures (not refusals) a few times. */
	function apiRetry( action, fields, blob, tries ) {
		tries = tries || 5;
		return api( action, fields, blob ).catch( function ( err ) {
			var retryable = ! err.status || err.status >= 502;
			if ( retryable && tries > 1 ) {
				return sleep( 1500 * ( 6 - tries ) ).then( function () {
					return apiRetry( action, fields, blob, tries - 1 );
				} );
			}
			throw err;
		} );
	}

	window.addEventListener( 'beforeunload', function ( e ) {
		if ( state.busy ) {
			e.preventDefault();
			e.returnValue = '';
		}
	} );

	/* ---------- File list ---------- */

	function renderFiles( files, partials ) {
		var box = $( 'rw-files' );
		box.textContent = '';
		if ( ! files.length ) {
			box.appendChild( el( 'p', { className: 'rw-muted', text: __( 'No .wpress files found yet.', 'restorwell' ) } ) );
		} else {
			var tbody = el( 'tbody' );
			files.forEach( function ( f ) {
				tbody.appendChild(
					el( 'tr', {}, [
						el( 'td', {}, [ el( 'strong', { text: f.name } ), el( 'br' ), el( 'span', { className: 'rw-muted', text: f.folder } ) ] ),
						el( 'td', { text: f.sizeLabel } ),
						el( 'td', { text: f.date } ),
						el( 'td', {}, [
							el( 'button', {
								type: 'button',
								className: 'button',
								text: __( 'Check', 'restorwell' ),
								'aria-label': sprintf( __( 'Check %s', 'restorwell' ), f.name ),
								on: {
									click: function () {
										startCheck( f.ref, f.name );
									},
								},
							} ),
						] ),
					] )
				);
			} );
			box.appendChild(
				el( 'table', { className: 'widefat striped rw-file-table' }, [
					el( 'thead', {}, [ el( 'tr', {}, [ el( 'th', { text: __( 'File', 'restorwell' ) } ), el( 'th', { text: __( 'Size', 'restorwell' ) } ), el( 'th', { text: __( 'Date', 'restorwell' ) } ), el( 'th', { text: '' } ) ] ) ] ),
					tbody,
				] )
			);
		}
		renderPartials( partials || [] );
	}

	function renderPartials( partials ) {
		var box = $( 'rw-partials' );
		box.textContent = '';
		box.hidden = ! partials.length;
		partials.forEach( function ( p ) {
			box.appendChild(
				el( 'p', { className: 'rw-partial' }, [
					sprintf( __( 'Unfinished upload: %1$s, %2$s of %3$s. Choose the same file and click Upload to continue.', 'restorwell' ), p.name, sizeLabel( p.received ), sizeLabel( p.size ) ),
					' ',
					el( 'button', {
						type: 'button',
						className: 'button-link rw-remove',
						text: __( 'Remove', 'restorwell' ),
						on: {
							click: function () {
								api( 'delete_partial', { id: p.id } ).then( function ( res ) {
									renderPartials( res.partials );
								} );
							},
						},
					} ),
				] )
			);
		} );
	}

	function refreshList() {
		return api( 'list', {} )
			.then( function ( res ) {
				renderFiles( res.files, res.partials );
				return res;
			} )
			.catch( function ( err ) {
				notice( err.message, 'error' );
			} );
	}

	/* ---------- Upload ---------- */

	var fileInput = $( 'rw-file' );
	var uploadBtn = $( 'rw-upload' );

	fileInput.addEventListener( 'change', function () {
		var file = fileInput.files[ 0 ];
		notice( '' );
		if ( file && ! /\.wpress$/i.test( file.name ) ) {
			notice( __( 'Choose a .wpress file. Other files cannot be restored.', 'restorwell' ), 'error' );
			uploadBtn.disabled = true;
			return;
		}
		uploadBtn.disabled = ! file;
	} );

	uploadBtn.addEventListener( 'click', function () {
		var file = fileInput.files[ 0 ];
		if ( file ) {
			upload( file );
		}
	} );

	var MIN_CHUNK = 65536;

	function upload( file ) {
		var meta = { name: file.name, size: file.size, modified: file.lastModified || 0 };
		var box = $( 'rw-upload-progress' );
		var started = Date.now();
		var startOffset = 0;
		var firstChunk = 0;
		state.busy = true;
		uploadBtn.disabled = true;
		fileInput.disabled = true;
		notice( '' );
		closeLast();

		function label( received, resumed ) {
			var pct = Math.floor( ( received / file.size ) * 100 );
			var text = sprintf( __( 'Uploading %1$s: %2$s of %3$s (%4$d%%)', 'restorwell' ), file.name, sizeLabel( received ), sizeLabel( file.size ), pct );
			if ( resumed ) {
				text += ' ' + sprintf( __( '– continued from %s', 'restorwell' ), sizeLabel( resumed ) );
			}
			setProgress( box, pct, text );
		}

		function finish() {
			state.busy = false;
			uploadBtn.disabled = false;
			fileInput.disabled = false;
		}

		return apiRetry( 'upload_status', meta )
			.then( function ( status ) {
				// A smaller size learned from a 413 earlier on this page is kept.
				var chunk = Math.min( parseInt( status.chunkSize, 10 ) || data.chunkSize, data.chunkSize );
				firstChunk = chunk;
				var offset = parseInt( status.received, 10 ) || 0;
				startOffset = offset;
				label( offset, offset > 0 ? offset : 0 );

				function next() {
					if ( offset >= file.size ) {
						return Promise.resolve( null );
					}
					var end = Math.min( offset + chunk, file.size );
					var fields = Object.assign( { offset: offset }, meta );
					return apiRetry( 'upload_chunk', fields, file.slice( offset, end ), 6 ).then(
						function ( res ) {
							offset = res.received;
							label( offset, startOffset );
							if ( res.complete ) {
								return res;
							}
							return next();
						},
						function ( err ) {
							// 413: the web server in front of PHP takes less than PHP does. Send smaller pieces.
							if ( 413 === err.status && chunk > MIN_CHUNK ) {
								var smaller = Math.max( MIN_CHUNK, Math.floor( chunk / 2 / MIN_CHUNK ) * MIN_CHUNK );
								notice( sprintf( __( 'The web server refused a piece of %1$s (HTTP 413, its own size limit is lower than PHP\'s). Sending pieces of %2$s instead.', 'restorwell' ), sizeLabel( chunk ), sizeLabel( smaller ) ), 'warning' );
								chunk = smaller;
								data.chunkSize = smaller;
								return next();
							}
							if ( err.info && 'number' === typeof err.info.received && err.status === 400 && ! /space|writ/i.test( err.message ) ) {
								offset = err.info.received;
								return next();
							}
							throw err;
						}
					);
				}
				return next();
			} )
			.then( function ( res ) {
				finish();
				var seconds = Math.max( 1, Math.round( ( Date.now() - started ) / 1000 ) );
				var done = startOffset > 0
					? sprintf( __( 'Upload complete: %1$s (%2$s). The last %3$s arrived in %4$d s after it continued. Checking it now.', 'restorwell' ), res.name, sizeLabel( file.size ), sizeLabel( file.size - startOffset ), seconds )
					: sprintf( __( 'Upload complete: %1$s (%2$s) in %3$d s. Checking it now.', 'restorwell' ), res.name, sizeLabel( file.size ), seconds );
				if ( data.chunkSize < firstChunk ) {
					done += ' ' + sprintf( __( 'The web server only accepted pieces of %s, so smaller pieces were sent.', 'restorwell' ), sizeLabel( data.chunkSize ) );
				}
				notice( done, 'success' );
				fileInput.value = '';
				refreshList();
				startCheck( res.ref, res.name );
			} )
			.catch( function ( err ) {
				finish();
				if ( 413 === err.status ) {
					notice( __( 'The web server refuses even the smallest pieces (64 KB, HTTP 413). Ask your host to raise the web server\'s request size limit (for nginx: client_max_body_size), or copy the backup into wp-content/restorwell-backups with FTP or your host\'s File Manager and click Refresh list.', 'restorwell' ), 'error' );
					refreshList();
					return;
				}
				notice( err.message + ' ' + __( 'What arrived is kept: choose the same file and click Upload to continue.', 'restorwell' ), 'error' );
				refreshList();
			} );
	}

	/* ---------- Check ---------- */

	function password() {
		return $( 'rw-password-input' ).value;
	}

	/** The previous "Restore finished" card goes once a new backup is uploaded or checked. */
	function closeLast() {
		var box = $( 'rw-finished' );
		if ( data.last && ! box.hidden ) {
			box.hidden = true;
			data.last = null;
			api( 'dismiss', { what: 'finished' } ).catch( function () {} );
		}
	}

	function startCheck( ref, name ) {
		closeLast();
		state.ref = ref;
		state.name = name;
		state.token = null;
		state.report = null;
		$( 'rw-confirm-input' ).checked = false;
		setStep( 'check' );
		$( 'rw-check-title' ).textContent = sprintf( __( 'Check: %s', 'restorwell' ), name );
		[ 'rw-report', 'rw-limits', 'rw-limits-title', 'rw-confirm', 'rw-blocked' ].forEach( function ( id ) {
			$( id ).hidden = true;
		} );
		runCheck();
	}

	function runCheck( token ) {
		var box = $( 'rw-check-progress' );
		var fields = { password: password() };
		if ( token ) {
			fields.token = token;
		} else {
			fields.ref = state.ref;
			setProgress( box, 0, __( 'Reading the whole backup…', 'restorwell' ) );
		}
		state.busy = true;
		return apiRetry( 'check', fields )
			.then( function ( res ) {
				state.token = res.token;
				if ( ! res.done ) {
					setProgress( box, res.report.progress, sprintf( __( 'Reading the whole backup and checking its checksums: %d%%. Nothing on the site changes during the check.', 'restorwell' ), res.report.progress ) );
					return runCheck( res.token );
				}
				state.busy = false;
				box.hidden = true;
				showReport( res.report, res.rows );
			} )
			.catch( function ( err ) {
				state.busy = false;
				box.hidden = true;
				notice( err.message, 'error' );
			} );
	}

	var icons = { ok: '✓', warn: '!', block: '✕' };
	var levelText = { ok: __( 'OK', 'restorwell' ), warn: __( 'Warning', 'restorwell' ), block: __( 'Blocks restore', 'restorwell' ) };

	function showReport( report, rows ) {
		state.report = report;
		var tbody = $( 'rw-report' ).querySelector( 'tbody' );
		tbody.textContent = '';
		rows.forEach( function ( row ) {
			tbody.appendChild( el( 'tr', {}, [ el( 'th', { scope: 'row', text: row[ 0 ] } ), el( 'td', { text: row[ 1 ] } ) ] ) );
		} );
		$( 'rw-report' ).hidden = false;

		var list = $( 'rw-limits' );
		list.textContent = '';
		report.limits.forEach( function ( limit ) {
			list.appendChild(
				el( 'li', { className: 'rw-limit rw-' + limit.level, 'data-code': limit.code }, [
					el( 'span', { className: 'rw-icon', 'aria-hidden': 'true', text: icons[ limit.level ] } ),
					el( 'span', { className: 'screen-reader-text', text: levelText[ limit.level ] + ': ' } ),
					el( 'span', { className: 'rw-limit-text', text: limit.message } ),
				] )
			);
		} );
		list.hidden = false;
		$( 'rw-limits-title' ).hidden = false;

		var pw = $( 'rw-password' );
		pw.hidden = ! report.encrypted || 'ok' === report.password;
		if ( ! pw.hidden ) {
			$( 'rw-password-input' ).focus();
		}

		$( 'rw-confirm' ).hidden = ! report.can_restore;
		$( 'rw-blocked' ).hidden = report.can_restore;
		$( 'rw-blocked' ).textContent = report.can_restore ? '' : __( 'Restore stays off until every limit marked ✕ is solved. Nothing on your site has changed.', 'restorwell' );
		updateRestoreButton();
	}

	function updateRestoreButton() {
		$( 'rw-restore' ).disabled = ! ( state.report && state.report.can_restore && $( 'rw-confirm-input' ).checked );
	}

	$( 'rw-confirm-input' ).addEventListener( 'change', updateRestoreButton );
	$( 'rw-password-check' ).addEventListener( 'click', function () {
		notice( '' );
		[ 'rw-report', 'rw-limits', 'rw-limits-title', 'rw-confirm', 'rw-blocked' ].forEach( function ( id ) {
			$( id ).hidden = true;
		} );
		runCheck();
	} );
	$( 'rw-password-input' ).addEventListener( 'keydown', function ( e ) {
		if ( 'Enter' === e.key ) {
			e.preventDefault();
			$( 'rw-password-check' ).click();
		}
	} );
	$( 'rw-back' ).addEventListener( 'click', function () {
		notice( '' );
		setStep( 'choose' );
	} );
	$( 'rw-refresh' ).addEventListener( 'click', refreshList );

	/* ---------- Restore ---------- */

	$( 'rw-restore' ).addEventListener( 'click', function () {
		notice( '' );
		setStep( 'restore' );
		setRestoreProgress( { percent: 0, label: __( 'Starting…', 'restorwell' ) } );
		beginRestore();
		api( 'restore_start', { token: state.token, password: password(), confirm: '1' } )
			.then( runRestore )
			.catch( restoreFailed );
	} );

	function beginRestore() {
		state.busy = true;
		state.restoring = true;
		state.cancelRequested = false;
		$( 'rw-cancel' ).disabled = false;
	}

	function endRestore() {
		state.busy = false;
		state.restoring = false;
		state.cancelRequested = false;
		$( 'rw-cancel' ).disabled = false;
	}

	function setRestoreProgress( job ) {
		setProgress( $( 'rw-restore-section' ).querySelector( '.rw-progress' ), job.percent, job.label );
	}

	function runRestore( job ) {
		setRestoreProgress( job );
		if ( job.switched || 'done' === job.stage ) {
			endRestore();
			finishedNow( job );
			return null;
		}
		// Cancel waits for the step that was running, then stops the loop here.
		if ( state.cancelRequested ) {
			return cancelRestore();
		}
		var wait = job.busy ? sleep( 2000 ) : Promise.resolve();
		return wait
			.then( function () {
				return apiRetry( 'restore_step', { password: password() } );
			} )
			.then( runRestore );
	}

	function restoreFailed( err ) {
		endRestore();
		if ( err.info && err.info.password ) {
			setStep( 'check' );
		} else {
			setStep( err.info && err.info.stopped ? 'choose' : 'check' );
		}
		notice( err.message, 'error' );
		refreshList();
	}

	$( 'rw-cancel' ).addEventListener( 'click', function () {
		if ( state.cancelRequested ) {
			return;
		}
		state.cancelRequested = true;
		$( 'rw-cancel' ).disabled = true;
		$( 'rw-restore-label' ).textContent = __( 'Cancelling: waiting for the current step to finish…', 'restorwell' );
		if ( ! state.restoring ) {
			cancelRestore().catch( restoreFailed );
		}
	} );

	/** Asks the server to cancel. It waits for a running step and puts back anything already moved. */
	function cancelRestore() {
		$( 'rw-restore-label' ).textContent = __( 'Cancelling and removing the temporary data…', 'restorwell' );
		return apiRetry( 'restore_cancel', {} ).then( function ( res ) {
			if ( res.switched && res.job ) {
				// Too late: the switch was made. Finish it instead.
				state.cancelRequested = false;
				notice( res.message, 'warning' );
				return runRestore( res.job );
			}
			endRestore();
			setStep( 'choose' );
			notice( res.message, 'info' );
			refreshList();
			return null;
		} );
	}

	/** Shown in the same page right after the switch: the session is gone now. */
	function finishedNow( job ) {
		root.querySelectorAll( '.rw-section, .rw-steps, .rw-footnote' ).forEach( function ( node ) {
			node.hidden = true;
		} );
		var box = $( 'rw-finished' );
		box.textContent = '';
		box.hidden = false;
		box.appendChild( el( 'h2', { text: __( 'Restore finished', 'restorwell' ) } ) );
		box.appendChild( el( 'p', { text: sprintf( __( 'The site from %1$s is now live at %2$s: %3$d files and %4$d database tables restored. Permalinks are refreshed on the next page load.', 'restorwell' ), job.source, data.homeUrl, job.files, job.tables ) } ) );
		box.appendChild( el( 'p', { text: __( 'The accounts on this site are now the ones in the backup, so you have been signed out. Log in with a username and password from the backup.', 'restorwell' ) } ) );
		( job.warnings || [] ).forEach( function ( w ) {
			box.appendChild( el( 'p', { className: 'rw-warn-text', text: w } ) );
		} );
		box.appendChild(
			el( 'p', {}, [
				el( 'a', { className: 'button button-primary button-hero', href: data.loginUrl, text: __( 'Log in with an account from the backup', 'restorwell' ) } ),
				' ',
				el( 'a', { className: 'button button-hero', href: data.homeUrl, target: '_blank', rel: 'noopener', text: __( 'View the site', 'restorwell' ) } ),
			] )
		);
		box.focus();
	}

	/* ---------- After login: finished panel, resume panel ---------- */

	function showLast( last ) {
		var box = $( 'rw-finished' );
		box.textContent = '';
		box.hidden = false;
		box.appendChild( el( 'h2', { text: __( 'Restore finished', 'restorwell' ) } ) );
		box.appendChild( el( 'p', { text: sprintf( __( '%1$s, restored on %2$s from %3$s: %4$d files and %5$d database tables. Permalinks were refreshed.', 'restorwell' ), last.name, last.date, last.source, last.files, last.tables ) } ) );

		if ( last.ref ) {
			var del = el( 'p', { className: 'rw-delete' }, [
				sprintf( __( 'The backup file (%s) is still on the server. Delete it now to free the space?', 'restorwell' ), last.sizeLabel ),
				' ',
			] );
			del.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button',
					id: 'rw-delete-backup',
					text: __( 'Delete backup file', 'restorwell' ),
					on: {
						click: function () {
							api( 'delete_backup', { ref: last.ref } )
								.then( function ( res ) {
									del.textContent = res.message;
									refreshList();
								} )
								.catch( function ( err ) {
									notice( err.message, 'error' );
								} );
						},
					},
				} )
			);
			del.appendChild( document.createTextNode( ' ' ) );
			del.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button-link',
					text: __( 'Keep it', 'restorwell' ),
					on: {
						click: function () {
							del.remove();
						},
					},
				} )
			);
			box.appendChild( del );
		}

		if ( data.review ) {
			var line = el( 'p', { className: 'rw-review', id: 'rw-review' }, [
				__( 'Did Restorwell get your site back? A short review on WordPress.org helps other people find it.', 'restorwell' ),
				' ',
				el( 'a', { href: data.reviewUrl, target: '_blank', rel: 'noopener noreferrer', text: __( 'Leave a review', 'restorwell' ) } ),
				' ',
			] );
			line.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button-link rw-dismiss',
					text: __( 'Dismiss', 'restorwell' ),
					'aria-label': __( 'Dismiss the review request', 'restorwell' ),
					on: {
						click: function () {
							api( 'dismiss', { what: 'review' } );
							line.remove();
						},
					},
				} )
			);
			box.appendChild( line );
		}

		box.appendChild(
			el( 'p', {}, [
				el( 'button', {
					type: 'button',
					className: 'button',
					id: 'rw-close-finished',
					text: __( 'Close', 'restorwell' ),
					on: {
						click: function () {
							api( 'dismiss', { what: 'finished' } );
							box.hidden = true;
						},
					},
				} ),
			] )
		);
	}

	function showChooser( visible ) {
		root.querySelector( '.rw-steps' ).hidden = ! visible;
		$( 'rw-choose' ).hidden = ! visible;
	}

	function showResume( job ) {
		var box = $( 'rw-resume' );
		box.textContent = '';
		box.hidden = false;
		// One restore at a time: the backup chooser comes back once this one is continued or cancelled.
		showChooser( false );
		box.appendChild( el( 'h2', { text: __( 'A restore was interrupted', 'restorwell' ) } ) );
		box.appendChild(
			el( 'p', {
				text: job.moved
					? sprintf( __( 'Restoring %1$s stopped in the middle of the switch: some restored folders were already moved in, and your site\'s own folders are kept aside. Continue finishes the restore. Cancel puts your site\'s own folders back and then removes the temporary data.', 'restorwell' ), job.name )
					: sprintf( __( 'Restoring %1$s stopped at: %2$s. Your live site has not changed yet.', 'restorwell' ), job.name, job.label ),
			} )
		);
		var row = el( 'p', {} );
		if ( job.encrypted ) {
			box.appendChild( el( 'label', { for: 'rw-resume-password', text: __( 'Backup password', 'restorwell' ) } ) );
			box.appendChild( el( 'br' ) );
			box.appendChild( el( 'input', { type: 'password', id: 'rw-resume-password', className: 'regular-text', autocomplete: 'off' } ) );
		}
		row.appendChild(
			el( 'button', {
				type: 'button',
				className: 'button button-primary',
				text: __( 'Continue restore', 'restorwell' ),
				on: {
					click: function () {
						if ( job.encrypted ) {
							$( 'rw-password-input' ).value = $( 'rw-resume-password' ).value;
						}
						box.hidden = true;
						root.querySelector( '.rw-steps' ).hidden = false;
						setStep( 'restore' );
						beginRestore();
						runRestore( job ).catch( restoreFailed );
					},
				},
			} )
		);
		row.appendChild( document.createTextNode( ' ' ) );
		row.appendChild(
			el( 'button', {
				type: 'button',
				className: 'button',
				text: __( 'Cancel and remove temporary data', 'restorwell' ),
				on: {
					click: function () {
						api( 'restore_cancel', {} )
							.then( function ( res ) {
								box.hidden = true;
								showChooser( true );
								if ( res.switched && res.job ) {
									notice( res.message, 'warning' );
									setStep( 'restore' );
									beginRestore();
									return runRestore( res.job ).catch( restoreFailed );
								}
								setStep( 'choose' );
								notice( res.message, 'info' );
								refreshList();
								return null;
							} )
							.catch( function ( err ) {
								notice( err.message, 'error' );
							} );
					},
				},
			} )
		);
		box.appendChild( row );
	}

	function cleanupLoop() {
		return api( 'cleanup', {} ).then( function ( res ) {
			if ( ! res.done ) {
				return cleanupLoop();
			}
			return null;
		} );
	}

	// A small interface for add-ons such as Restorwell Pro.
	window.restorwell = {
		api: api,
		notice: notice,
		sizeLabel: sizeLabel,
		setProgress: setProgress,
		refreshList: refreshList,
		startCheck: startCheck,
		setBusy: function ( busy ) {
			state.busy = !! busy;
		},
	};

	if ( data.job ) {
		if ( data.job.switched ) {
			cleanupLoop().catch( function () {} );
		} else {
			showResume( data.job );
		}
	}
	if ( data.last ) {
		showLast( data.last );
	}
	refreshList();
} )();
