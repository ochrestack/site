<?php
/**
 * Uninstall: removes Restorwell's temporary data (unfinished restores,
 * unfinished uploads, its small state file). Your .wpress backups are kept.
 * An unfinished restore that had already moved folders in is cancelled the
 * same way as from the screen, which puts the site's own folders back first;
 * a restore whose folders cannot be put back is left untouched.
 *
 * @package Restorwell
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

require_once __DIR__ . '/restorwell.php';

$restorwell_keep = array();
if ( is_dir( Restorwell_Files::folder() ) ) {
	$restorwell_keep  = Restorwell_Restore::discard_all();
	$restorwell_items = array_merge(
		(array) glob( Restorwell_Files::folder() . '/.*.part' ),
		(array) glob( Restorwell_Files::folder() . '/' . Restorwell_Restore::STATE_FILE )
	);
	foreach ( $restorwell_items as $restorwell_item ) {
		wp_delete_file( $restorwell_item );
	}
}

// Temporary tables of an unfinished restore that has no folder any more.
global $wpdb;
foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( 'rw' ) . '%' ) ) as $restorwell_table ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( 1 === preg_match( '/^(rw[to][0-9a-f]{5}_)/', $restorwell_table, $restorwell_m ) && ! in_array( $restorwell_m[1], $restorwell_keep, true ) ) {
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $restorwell_table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
	}
}
