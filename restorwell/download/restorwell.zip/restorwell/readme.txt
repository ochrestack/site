=== Restorwell – Restore .wpress Backups of Any Size ===
Contributors: ochrestack
Tags: restore, backup, migration, upload limit
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Restores a .wpress backup free, past your host's upload limit, password-protected or not. Checks the whole file before anything on your site changes.

== Description ==

Asked to pay to restore your own backup? Restorwell restores your .wpress file for free, at any size your server has disk space for, past your host's upload limit, with or without a password. Before anything changes, it reads the whole backup, verifies its checksums and checks your server's limits. If a restore fails or you cancel it before the final switch, your site is left exactly as it was.

**Restoring is free in every case:** no size cap, no locked button, no account. An optional add-on, Restorwell Pro, costs $19 once and does one thing: your server downloads the backup from a link. You never need it to restore.

**Tested on a strict host.** On a server capped at 8 MB uploads, 30-second requests and 128 MB of memory, version 1.1.0 restored a 2.29 GB password-protected, compressed backup. All 820 files and all 450 database rows matched the source site. The longest single request took 4 seconds. The largest backup restored in testing so far was 4.3 GB, on version 1.0.0.

Restorwell reads the .wpress files that All-in-One WP Migration makes. Restorwell is an independent plugin by Ochrestack and is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= How it works =

1. **Choose the backup.** Tools > Restorwell uploads the file in pieces smaller than your host's limit. If the connection drops or you reload the page, choose the same file and it carries on. Or copy the file to `wp-content/restorwell-backups` by FTP or your host's File Manager: it is listed, even as "site (1).wpress".
2. **Check.** Restorwell reads every byte and shows what is inside: the source address, WordPress and PHP versions, size, files, database, plugins, theme, compression and password. Then it names each limit on this server: free disk space needed and available, the largest database statement against max_allowed_packet, newer WordPress or PHP, multisite, a missing or wrong password, a damaged or incomplete file. Restore stays off while anything blocks it.
3. **Restore.** Tick the confirmation and click Restore. Files and tables are prepared beside your live site in short steps, then switched in at the end. Old addresses and paths become the new ones, inside serialized and page-builder data too. Then you log in with an account from the backup, and Restorwell offers to delete the backup file.

= Command line, also free =

`wp restorwell list`, `wp restorwell check <file>` and `wp restorwell restore <file> --password-stdin --yes`. Exit codes tell a script why it stopped: 2 password, 3 damaged backup, 4 disk space, 5 another limit.

= When you do not need Restorwell =

If your backup is smaller than the upload limit your host shows, All-in-One WP Migration's own Import screen restores it for free. If you can raise the limit (.htaccess, .user.ini, or a request to your host), the same applies. Restorwell is for the rest: a backup over the limit, a password, the command line, or a full check before anything is touched. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

Two other free plugins also read .wpress files: Shiftbox restores large ones, but not password-protected ones, and Poly Bright Quick Restore restores them up to 512 MB.

= What it does not do =

* It does not make backups. For new backups, use a backup plugin whose restore is free.
* No multisite networks, and no backup formats other than .wpress.
* It needs a working WordPress on MySQL or MariaDB to restore into.

= Restorwell Pro (optional, $19 once) =

For a backup that already sits on another server, such as the old host or a storage bucket: paste its direct download address, and your server downloads it itself, resuming where the remote server allows, then runs the same Check and Restore. The file never passes through your own connection. $19 once, unlimited sites, no renewal, no licence checks. At ochrestack.com/restorwell.

= External services =

None. Restorwell contacts no outside server: no analytics, telemetry, licence or update calls, no remote fonts or scripts. Your backup and its password stay on your server.

== Installation ==

1. Plugins > Add New, search for "Restorwell", Install Now, Activate.
2. Go to Tools > Restorwell.
3. Upload the .wpress file, or pick one already on the server, and click Check.
4. Read the report, type the password if asked, tick the confirmation and click Restore.

== Frequently Asked Questions ==

= Is restoring really free? =

Yes, at any size, with or without a password, from the screen or from WP-CLI. There is no size cap, locked button or account. Pro only changes how the file reaches your server.

= My backup is bigger than my host's upload limit. =

Restorwell sends it in pieces smaller than the limit, so the limit no longer matters; free disk space does, and the Check shows both numbers. If the web server refuses a piece ("413 Request Entity Too Large"), the pieces get smaller by themselves, down to 64 KB. You can also skip the upload: copy the file by FTP to `wp-content/restorwell-backups`. Files already in `wp-content/ai1wm-backups` are listed too.

= I raised the limit and it still asks me to pay. =

Restorwell has no limit of its own and nothing to pay for restoring. You do not need to raise any limit.

= My import keeps stopping halfway, or at 100%. =

Restorwell works in short steps, each well inside PHP's time limit (the longest took 4 seconds on a 30-second host), with a named progress line. If the page is closed, Tools > Restorwell offers to continue or cancel.

= It says "Corrupted File". Is my backup broken? =

Run the Check. It says whether the file is incomplete (usually a download that stopped early: copy it again), damaged (it names the damaged file inside), or simply needs a password.

= My backup has a password. =

Type it on the Check screen. It is checked before anything changes, used only while checking and restoring, and never written to the database, a file or a log. The older password format (backups made before February 2026) is read correctly; it was tested with password-protected backups from 7.62, 7.80, 7.98, 7.100 and 7.101.

= What if the restore stops halfway? =

Your live site is not touched until the final switch. If a step fails or you click Cancel, the temporary files and tables are removed and your site is as it was. If the server killed the restore during the switch, the screen says so: Continue finishes it, and Cancel puts your site's own folders back first (once the restored database is in place, it finishes instead).

= Why am I logged out afterwards? =

The users come from the backup. Log in with an account from it.

= The Check says a statement is larger than max_allowed_packet. =

Ask your host to raise the database setting max_allowed_packet to the size the Check gives, then check again. Nothing has changed on your site.

= Which backups has it been tested with? =

All-in-One WP Migration 7.113: plain, gzip, bzip2, password-protected and password-protected plus compressed. 7.62, 7.80, 7.98, 7.100 and 7.101 password-protected. 7.0, 7.40, 7.62, 7.80 and 7.100 plain. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= Are my backups safe in wp-content? =

Restorwell's folder blocks web access with .htaccess, web.config and an index file. On nginx, ask your host to deny `wp-content/restorwell-backups`, or delete the backup after restoring (Restorwell offers to).

== Screenshots ==

1. The Check report for a 2.29 GB password-protected backup: what is inside, then each limit on this server marked OK, before anything changes.
2. Uploading the 2.29 GB backup in 6 MB pieces on a host whose upload limit is 8 MB.
3. A password-protected backup: "Password needed", and Restore stays off until the password is accepted.
4. Not enough free disk space: both numbers, and Restore off. Nothing on the site has changed.
5. A backup that stopped downloading early is named as incomplete, before anything changes.
6. Restoring: files are unpacked beside the live site, which keeps running until the final switch.
7. Restore finished: 820 files and 12 tables restored, and the offer to delete the backup file.

== Changelog ==

= 1.1.3 =
* Fix: before the password is typed, the Check names plugins from their folders, not file paths.
* Fix: an interrupted restore says where Continue picks up, without the last "Restore finished" card above it.

= 1.1.2 =
* Fix: a backup cut off before its end reads "not known" for password, plugins, theme and compression, instead of "No" and "none".
* Fix: the database progress line no longer starts at "0% (0 tables)".
* The review request after a restore waits until Restorwell is listed on WordPress.org.

= 1.1.1 =
* Fix: the upload box states the real piece size.
* Fix: the previous "Restore finished" card closes when a new backup is uploaded or checked.
* New: the Check blocks a restore, before anything changes, when Restorwell's backup folder is on a different disk from the folders it switches in.
* Fix: Check rows read "not known" for an incomplete file or a wrong password.
* Fix: no raw PHP warnings when a folder cannot be moved.
* Tested: password-protected backups made with versions 7.62, 7.80, 7.98 and 7.100.

= 1.1.0 =
* Fix: Cancel restore stops after the running step; after a kill mid-switch, Cancel and uninstall put your site's folders back.
* Fix: password-protected backups made before February 2026.
* Fix: smaller upload pieces when the web server answers HTTP 413.
* New: the Check names the largest database statement against max_allowed_packet.
* New: FTP files listed whatever their name; WP-CLI takes listed names and --password-stdin.
* Fix: addresses that only start with the old address are left alone.
