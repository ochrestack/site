=== Restorwell – Restore .wpress Backups of Any Size ===
Contributors: ochrestack
Tags: restore, backup, migration, upload limit
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Restores a .wpress backup free, past your host's upload limit, password-protected or not. Checks the whole file before anything on your site changes.

== Description ==

Asked to pay to restore your own backup? Restorwell restores your .wpress file for free, at any size your server has disk space for, past your host's upload limit, with or without a password. Before anything changes, it reads the whole backup, verifies its checksums and checks your server's limits. If a restore fails or you cancel it before the final switch, your site is left exactly as it was.

**Restoring is free in every case:** no size cap, no locked button, no account. An optional add-on, Restorwell Pro, costs $19 once and does one thing: your server downloads the backup from a link. You never need it to restore.

**Tested on a strict host.** On a server capped at 8 MB uploads, 30-second requests and 128 MB of memory, version 1.2.1 restored a 2.29 GB password-protected, compressed backup: all 820 files and all 450 database rows matched the source site, and the longest request took 5 seconds. The largest backup restored in testing so far was 4.3 GB, on version 1.0.0.

Restorwell reads the .wpress files that All-in-One WP Migration makes. Restorwell is an independent plugin by Ochrestack and is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= How it works =

1. **Choose the backup.** Tools > Restorwell uploads the file in pieces smaller than your host's limit. If the connection drops or you reload the page, choose the same file and it carries on. Or copy the file to `wp-content/restorwell-backups` by FTP or your host's File Manager: it is listed, even as "site (1).wpress". Each listed backup has Check and Delete; choosing a file that is already there offers to check that copy instead.
2. **Check.** Restorwell reads every byte and shows what is inside: the source address, versions, files, database, plugins, theme and password. Then it names each limit on this server: free disk space needed and available, the database statement size, newer WordPress or PHP, multisite, a missing or wrong password, a damaged or incomplete file. Restore stays off while anything blocks it.
3. **Restore.** Tick the confirmation and click Restore. Files and tables are prepared beside your live site in short steps, then switched in at the end. The old site address and paths become the new ones, inside stored settings and page-builder data too; e-mail addresses keep their old domain. Elementor pages keep their look: Elementor rebuilds its styles on the first visit. On Apache, Restorwell writes WordPress's rewrite rules to .htaccess when it can, and says so when it cannot. Then you log in with an account from the backup, and Restorwell offers to delete the backup file.

= Command line, also free =

`wp restorwell list`, `wp restorwell check <file>` and `wp restorwell restore <file> --password-stdin --yes`.

= When you do not need Restorwell =

If your backup is smaller than the upload limit your host shows, All-in-One WP Migration's own Import screen restores it for free. Restorwell is for the rest: a backup over the limit, a password, the command line, or a full check before anything is touched. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

Two other free plugins also read .wpress files: Shiftbox restores large ones, but not password-protected ones, and Poly Bright Quick Restore restores them up to 512 MB.

= What it does not do =

It does not make backups, restore multisite networks or formats other than .wpress, or restore into anything but MySQL or MariaDB.

= Restorwell Pro (optional, $19 once) =

For a backup on another server, such as the old host: paste its direct download address (or run `wp restorwell fetch <url>`), and your server downloads it itself, resuming where the remote server allows, then runs the same Check and Restore. The file never passes through your own connection. $19 once, unlimited sites, no renewal, no licence checks. At ochrestack.com/restorwell.

= External services =

None. Restorwell contacts no outside server: no analytics, telemetry, licence or update calls. Your backup and its password stay on your server.

== Installation ==

1. Plugins > Add New, search for "Restorwell", Install Now, Activate.
2. Tools > Restorwell: upload the .wpress file, or pick one already on the server, and click Check.
3. Read the report, type the password if asked, tick the confirmation and click Restore.

== Frequently Asked Questions ==

= Is restoring really free? =

Yes, at any size, with or without a password, from the screen or from WP-CLI. Pro only changes how the file reaches your server.

= My backup is bigger than my host's upload limit. =

Restorwell sends it in pieces smaller than the limit, so the limit no longer matters; free disk space does, and the Check shows both numbers. If the web server refuses a piece (HTTP 413), the pieces get smaller by themselves.

= I raised the limit and it still asks me to pay. =

Restorwell has no limit of its own and nothing to pay for restoring. You do not need to raise any limit.

= My import keeps stopping halfway, or at 100%. =

Restorwell works in short steps, each well inside PHP's time limit, with a named progress line. If the page is closed, Tools > Restorwell offers to continue or cancel.

= It says "Corrupted File". Is my backup broken? =

Run the Check. It says whether the file is incomplete (usually a download that stopped early: copy it again), damaged (it names the damaged file inside), or simply needs a password.

= My backup has a password. =

Type it on the Check screen. It is used only while checking and restoring, and never written to the database, a file or a log. Backups made before February 2026 use an older password format, which is read correctly (the versions tested are listed below).

= What if the restore stops halfway? =

Your live site is not touched until the final switch. If a step fails or you click Cancel, your site is as it was. If the server killed the restore during the switch, Tools > Restorwell says so and offers Continue or Cancel.

= The Check says a statement is larger than max_allowed_packet (the database's limit on one statement). =

Ask your host to raise the database setting max_allowed_packet to the size the Check gives, then check again.

= Which backups has it been tested with? =

All-in-One WP Migration 7.113: plain, gzip, bzip2, password-protected and password-protected plus compressed. 7.62, 7.80, 7.98, 7.100 and 7.101 password-protected. 7.0, 7.40, 7.62, 7.80 and 7.100 plain. Restorwell is not affiliated with or endorsed by All-in-One WP Migration or ServMask.

= Will my Elementor pages look the same? =

Yes, in our tests: an Elementor 4.4.0 page and a Twenty Twenty-Five block-theme post matched the old site pixel for pixel; Elementor rebuilds its styles on the first visit. Other page builders were not tested.

= What stays that is not in the backup? =

Plugins, themes and database tables on this site that are not in the backup stay, with their data. The Check names those tables first; delete them afterwards if you do not need them.

= Are my backups safe in wp-content? =

The folder blocks web access with .htaccess, web.config and an index file. On nginx, ask your host to deny `wp-content/restorwell-backups`, or delete the backup after restoring (Restorwell offers to).

== Screenshots ==

1. The Check report for a 2.29 GB password-protected backup: what is inside, then each limit on this server marked OK, before anything changes.
2. Uploading the 2.29 GB backup in 6 MB pieces on a host whose upload limit is 8 MB.
3. A password-protected backup: "Password needed", and Restore stays off until the password is accepted.
4. Not enough free disk space: both numbers, and Restore off. Nothing on the site has changed.
5. A backup that stopped downloading early is named as incomplete, before anything changes.
6. Restoring: files are unpacked beside the live site, which keeps running until the final switch.
7. Restore finished: 820 files and 12 tables restored, and the offer to delete the backup file.

== Support ==

Questions or a problem: support@ochrestack.com. Send your WordPress and PHP versions and the lines marked ✕ from the Check.

== Changelog ==

= 1.2.4 =
* Fix: a damaged password backup lists no plugin or theme names before its password is typed.
* Fix: one "Keep it and close" button on the finished card; right after a restore the screen shows no toolbar or menu of the ended session; a delete question puts its buttons on their own line; a folder path breaks only at a slash.

= 1.2.3 =
* Fix: a damaged password backup shows what is known and does not ask for a password; a wrong password leaves the Check's rows and disk figure as they were.
* Fix: when the Check passes, the screen scrolls to Restore; "Checking it now" gives way to the result; the three steps stay in one row on a phone.
* Fix: a restore that stopped at the final switch no longer says the site has not changed; after a clean restore on Apache the finished message says nothing about page addresses.

= 1.2.2 =
* Fix: a cut-off or unrecognisable file shows its name, its size and the reason, not rows of "not known", and asks for no password.
* Fix: a file under the minimum size no longer says that what arrived is kept.

= Earlier =
* 1.2.1: from WP-CLI, a backup from an Apache site gets WordPress's rewrite rules in .htaccess; a copy the Check calls damaged or incomplete can be deleted from the Check's result.
* 1.2.0: on Apache, WordPress's rewrite rules are written to .htaccess after a restore; Delete on each listed backup; a file already on the server is offered for Check, not uploaded again.
