/**
 * Restorwell screen: piecewise upload with resume, file list, Check report,
 * restore progress and the finished screen. No libraries beyond wp.i18n.
 */
( function () {
	'use strict';

	var data = window.restorwellData;
	if ( data ) {
		// wp_localize_script() turns top-level numbers into strings.
		data.chunkSize = parseInt( data.chunkSize, 10 );
		data.uploadLimit = parseInt( data.uploadLimit, 10 );
		data.review = !! data.review && '0' !== data.review && '' !== data.review;
	}
	var i18n = window.wp && window.wp.i18n;
	var __ = i18n.__;
	var sprintf = i18n.sprintf;
	var root = document.getElementById( 'restorwell' );
	if ( ! root || ! data ) {
		return;
	}

	var state = { ref: null, name: '', token: null, report: null, busy: false, restoring: false, cancelRequested: false };

	function $( id ) {
		return document.getElementById( id );
	}

	function el( tag, attrs, children ) {
		var node = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( key ) {
			if ( 'text' === key ) {
				node.textContent = attrs[ key ];
			} else if ( 'className' === key ) {
				node.className = attrs[ key ];
			} else if ( 'on' === key ) {
				Object.keys( attrs.on ).forEach( function ( ev ) {
					node.addEventListener( ev, attrs.on[ ev ] );
				} );
			} else {
				node.setAttribute( key, attrs[ key ] );
			}
		} );
		( children || [] ).forEach( function ( child ) {
			node.appendChild( 'string' === typeof child ? document.createTextNode( child ) : child );
		} );
		return node;
	}

	function sizeLabel( bytes ) {
		var units = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
		var i = 0;
		while ( bytes >= 1024 && i < units.length - 1 ) {
			bytes /= 1024;
			i++;
		}
		return ( i === 0 ? bytes : bytes.toFixed( i >= 3 ? 2 : 1 ) ) + ' ' + units[ i ];
	}

	function notice( message, type ) {
		var box = $( 'rw-notice' );
		box.hidden = ! message;
		box.className = 'rw-notice notice inline notice-' + ( type || 'info' );
		box.textContent = '';
		if ( message ) {
			box.appendChild( el( 'p', { text: message } ) );
		}
	}

	function setStep( step ) {
		root.querySelectorAll( '.rw-step' ).forEach( function ( li ) {
			li.classList.toggle( 'is-current', li.getAttribute( 'data-step' ) === step );
		} );
		$( 'rw-choose' ).hidden = 'choose' !== step;
		$( 'rw-check' ).hidden = 'check' !== step;
		$( 'rw-restore-section' ).hidden = 'restore' !== step;
	}

	function setProgress( container, percent, label ) {
		container.hidden = false;
		container.querySelector( '.rw-bar span' ).style.width = Math.max( 0, Math.min( 100, percent ) ) + '%';
		container.querySelector( '.rw-progress-label' ).textContent = label;
	}

	function sleep( ms ) {
		return new Promise( function ( resolve ) {
			setTimeout( resolve, ms );
		} );
	}

	/**
	 * Posts to admin-ajax. Resolves with `data`, rejects with an Error whose
	 * `info` holds the error payload.
	 */
	function api( action, fields, blob ) {
		var body = new FormData();
		body.append( 'action', 'restorwell_' + action );
		body.append( 'nonce', data.nonce );
		Object.keys( fields || {} ).forEach( function ( key ) {
			body.append( key, fields[ key ] );
		} );
		if ( blob ) {
			body.append( 'chunk', blob, 'chunk.bin' );
		}
		return fetch( data.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' } ).then( function ( response ) {
			return response.text().then( function ( text ) {
				var json = null;
				try {
					json = JSON.parse( text );
				} catch ( e ) {
					json = null;
				}
				if ( json && json.success ) {
					return json.data;
				}
				var info = json && json.data ? json.data : {};
				var err = new Error( info.message || ( '-1' === text || '0' === text ? __( 'Your session expired. Reload the page and log in again.', 'restorwell' ) : sprintf( __( 'The server answered with an error (HTTP %d).', 'restorwell' ), response.status ) ) );
				err.info = info;
				err.status = response.status;
				throw err;
			} );
		} );
	}

	/** Retries network failures (not refusals) a few times. */
	function apiRetry( action, fields, blob, tries ) {
		tries = tries || 5;
		return api( action, fields, blob ).catch( function ( err ) {
			var retryable = ! err.status || err.status >= 502;
			if ( retryable && tries > 1 ) {
				return sleep( 1500 * ( 6 - tries ) ).then( function () {
					return apiRetry( action, fields, blob, tries - 1 );
				} );
			}
			throw err;
		} );
	}

	window.addEventListener( 'beforeunload', function ( e ) {
		if ( state.busy ) {
			e.preventDefault();
			e.returnValue = '';
		}
	} );

	/* ---------- File list ---------- */

	function renderFiles( files, partials ) {
		var box = $( 'rw-files' );
		box.textContent = '';
		state.files = {};
		files.forEach( function ( f ) {
			state.files[ f.ref ] = f;
		} );
		if ( ! files.length ) {
			box.appendChild( el( 'p', { className: 'rw-muted', text: __( 'No .wpress files found yet.', 'restorwell' ) } ) );
		} else {
			var tbody = el( 'tbody' );
			files.forEach( function ( f ) {
				tbody.appendChild(
					el( 'tr', {}, [
						el( 'td', {}, 0 === f.ref.indexOf( 'ai1wm:' ) ? [ el( 'strong', { text: f.name } ), el( 'br' ), el( 'span', { className: 'rw-muted', text: f.folder } ) ] : [ el( 'strong', { text: f.name } ) ] ),
						el( 'td', { text: f.sizeLabel } ),
						el( 'td', { text: f.date } ),
						el( 'td', { className: 'rw-row-actions' }, rowActions( f ) ),
					] )
				);
			} );
			box.appendChild(
				el( 'table', { className: 'widefat striped rw-file-table' }, [
					el( 'thead', {}, [ el( 'tr', {}, [ el( 'th', { text: __( 'File', 'restorwell' ) } ), el( 'th', { text: __( 'Size', 'restorwell' ) } ), el( 'th', { text: __( 'Date', 'restorwell' ) } ), el( 'th', { text: '' } ) ] ) ] ),
					tbody,
				] )
			);
		}
		renderPartials( partials || [] );
	}

	/** The row's own question before a backup file is deleted: what goes, from where, and two buttons. */
	function deleteAsk( f, onKeep ) {
		return el( 'span', { className: 'rw-ask', hidden: '' }, [
			el( 'span', { className: 'rw-ask-text', text: sprintf( __( 'Delete %1$s (%2$s) from %3$s? This cannot be undone.', 'restorwell' ), f.name, f.sizeLabel, f.folder ) } ),
			' ',
			el( 'button', {
				type: 'button',
				className: 'button rw-delete-yes',
				text: __( 'Yes, delete it', 'restorwell' ),
				on: {
					click: function ( e ) {
						// A second click on the same button must not ask again.
						e.currentTarget.disabled = true;
						deleteRow( f );
					},
				},
			} ),
			' ',
			el( 'button', {
				type: 'button',
				className: 'button-link',
				text: __( 'Keep it', 'restorwell' ),
				on: {
					click: onKeep,
				},
			} ),
		] );
	}

	/** Check and Delete for one row. Delete asks once, in the row, before it removes anything. */
	function rowActions( f ) {
		var cell = [];
		function showButtons() {
			cell.forEach( function ( node ) {
				node.hidden = false;
			} );
			ask.hidden = true;
		}
		var check = el( 'button', {
			type: 'button',
			className: 'button',
			text: __( 'Check', 'restorwell' ),
			'aria-label': sprintf( __( 'Check %s', 'restorwell' ), f.name ),
			on: {
				click: function () {
					startCheck( f.ref, f.name );
				},
			},
		} );
		var del = el( 'button', {
			type: 'button',
			className: 'button rw-delete-row',
			text: __( 'Delete', 'restorwell' ),
			'aria-label': sprintf( __( 'Delete %s', 'restorwell' ), f.name ),
			on: {
				click: function () {
					cell.forEach( function ( node ) {
						node.hidden = true;
					} );
					ask.hidden = false;
					ask.querySelector( 'button' ).focus();
				},
			},
		} );
		cell = [ check, del ];
		var ask = deleteAsk( f, showButtons );
		return cell.concat( [ ask ] );
	}

	function deleteRow( f ) {
		notice( '' );
		api( 'delete_backup', { ref: f.ref } )
			.then( function () {
				if ( state.ref === f.ref ) {
					state.ref = null;
					// The Check of a copy that is gone has nothing left to show.
					setStep( 'choose' );
				}
				// The box that offered this copy would point at a file that is gone.
				$( 'rw-duplicate' ).hidden = true;
				notice( sprintf( __( 'Deleted %1$s (%2$s).', 'restorwell' ), f.name, f.sizeLabel ), 'success' );
			} )
			.catch( function ( err ) {
				notice( err.message, 'error' );
			} )
			.then( refreshList );
	}

	function renderPartials( partials ) {
		var box = $( 'rw-partials' );
		box.textContent = '';
		box.hidden = ! partials.length;
		partials.forEach( function ( p ) {
			box.appendChild(
				el( 'p', { className: 'rw-partial' }, [
					sprintf( __( 'Unfinished upload: %1$s, %2$s of %3$s. Choose the same file and click Upload to continue.', 'restorwell' ), p.name, sizeLabel( p.received ), sizeLabel( p.size ) ),
					' ',
					el( 'button', {
						type: 'button',
						className: 'button-link rw-remove',
						text: __( 'Remove', 'restorwell' ),
						on: {
							click: function () {
								api( 'delete_partial', { id: p.id } ).then( function ( res ) {
									renderPartials( res.partials );
								} );
							},
						},
					} ),
				] )
			);
		} );
	}

	function refreshList() {
		return api( 'list', {} )
			.then( function ( res ) {
				renderFiles( res.files, res.partials );
				return res;
			} )
			.catch( function ( err ) {
				notice( err.message, 'error' );
			} );
	}

	/* ---------- Upload ---------- */

	var fileInput = $( 'rw-file' );
	var uploadBtn = $( 'rw-upload' );

	/** A disabled Upload says why: the reason is on the control as well as on the screen. */
	function setUploadEnabled( enabled, reason ) {
		uploadBtn.disabled = ! enabled;
		if ( enabled ) {
			uploadBtn.removeAttribute( 'title' );
		} else {
			uploadBtn.setAttribute( 'title', reason || __( 'Choose a .wpress file first.', 'restorwell' ) );
		}
	}
	setUploadEnabled( false );

	fileInput.addEventListener( 'change', function () {
		var file = fileInput.files[ 0 ];
		notice( '' );
		$( 'rw-duplicate' ).hidden = true;
		if ( file && ! /\.wpress$/i.test( file.name ) ) {
			notice( __( 'Choose a .wpress file. Other files cannot be restored.', 'restorwell' ), 'error' );
			setUploadEnabled( false, __( 'The chosen file is not a .wpress file.', 'restorwell' ) );
			return;
		}
		setUploadEnabled( !! file );
	} );

	uploadBtn.addEventListener( 'click', function () {
		var file = fileInput.files[ 0 ];
		if ( file ) {
			upload( file );
		}
	} );

	var MIN_CHUNK = 65536;

	/** The chosen file is already on the server: offer to check that copy instead of filling the disk twice. */
	function offerExisting( file, copy ) {
		var box = $( 'rw-duplicate' );
		box.textContent = '';
		box.hidden = false;
		var where = file.name === copy.name
			? sprintf( __( '%1$s (%2$s) is already on this server, in %3$s.', 'restorwell' ), file.name, sizeLabel( file.size ), copy.folder )
			: sprintf( __( '%1$s (%2$s) is already on this server as %3$s, in %4$s.', 'restorwell' ), file.name, sizeLabel( file.size ), copy.name, copy.folder );
		box.appendChild( el( 'p', { text: where + ' ' + __( 'Uploading it again would use that much disk space a second time.', 'restorwell' ) } ) );
		box.appendChild(
			el( 'p', {}, [
				el( 'button', {
					type: 'button',
					className: 'button button-primary rw-use-existing',
					text: __( 'Check the copy already here', 'restorwell' ),
					on: {
						click: function () {
							box.hidden = true;
							fileInput.value = '';
							setUploadEnabled( false );
							startCheck( copy.ref, copy.name );
						},
					},
				} ),
				' ',
				el( 'button', {
					type: 'button',
					className: 'button rw-upload-again',
					text: __( 'Upload it again anyway', 'restorwell' ),
					on: {
						click: function () {
							box.hidden = true;
							upload( file, true );
						},
					},
				} ),
			] )
		);
		box.querySelector( 'button' ).focus();
	}

	function upload( file, again ) {
		var meta = { name: file.name, size: file.size, modified: file.lastModified || 0 };
		var box = $( 'rw-upload-progress' );
		var started = Date.now();
		var startOffset = 0;
		var firstChunk = 0;
		var sent = 0;
		state.busy = true;
		setUploadEnabled( false, __( 'An upload is running.', 'restorwell' ) );
		fileInput.disabled = true;
		notice( '' );
		// The "Unfinished upload ... choose the same file" line is answered by this very upload.
		$( 'rw-partials' ).hidden = true;
		closeLast();

		function label( received, resumed ) {
			var pct = Math.floor( ( received / file.size ) * 100 );
			var text = sprintf( __( 'Uploading %1$s: %2$s of %3$s (%4$d%%)', 'restorwell' ), file.name, sizeLabel( received ), sizeLabel( file.size ), pct );
			if ( resumed ) {
				text += ' ' + sprintf( __( '– continued from %s', 'restorwell' ), sizeLabel( resumed ) );
			}
			setProgress( box, pct, text );
		}

		function finish() {
			state.busy = false;
			fileInput.disabled = false;
			setUploadEnabled( !! fileInput.files[ 0 ] );
		}

		return apiRetry( 'upload_status', meta )
			.then( function ( status ) {
				if ( status.existing && ! again ) {
					finish();
					offerExisting( file, status.existing );
					return null;
				}
				// A smaller size learned from a 413 earlier on this page is kept.
				var chunk = Math.min( parseInt( status.chunkSize, 10 ) || data.chunkSize, data.chunkSize );
				firstChunk = chunk;
				var offset = parseInt( status.received, 10 ) || 0;
				startOffset = offset;
				sent = offset;
				label( offset, offset > 0 ? offset : 0 );

				function next() {
					if ( offset >= file.size ) {
						return Promise.resolve( null );
					}
					var end = Math.min( offset + chunk, file.size );
					var fields = Object.assign( { offset: offset }, meta );
					return apiRetry( 'upload_chunk', fields, file.slice( offset, end ), 6 ).then(
						function ( res ) {
							offset = res.received;
							sent = offset;
							label( offset, startOffset );
							if ( res.complete ) {
								return res;
							}
							return next();
						},
						function ( err ) {
							// 413: the web server in front of PHP takes less than PHP does. Send smaller pieces.
							if ( 413 === err.status && chunk > MIN_CHUNK ) {
								var smaller = Math.max( MIN_CHUNK, Math.floor( chunk / 2 / MIN_CHUNK ) * MIN_CHUNK );
								notice( sprintf( __( 'The web server refused a piece of %1$s (HTTP 413, its own size limit is lower than PHP\'s). Sending pieces of %2$s instead.', 'restorwell' ), sizeLabel( chunk ), sizeLabel( smaller ) ), 'warning' );
								chunk = smaller;
								data.chunkSize = smaller;
								return next();
							}
							if ( err.info && 'number' === typeof err.info.received && err.status === 400 && ! /space|writ/i.test( err.message ) ) {
								offset = err.info.received;
								return next();
							}
							throw err;
						}
					);
				}
				return next();
			} )
			.then( function ( res ) {
				if ( ! res ) {
					// Not uploaded: the file is already on the server and the page said so.
					return;
				}
				finish();
				var seconds = Math.max( 1, Math.round( ( Date.now() - started ) / 1000 ) );
				var done = startOffset > 0
					? sprintf( __( 'Upload complete: %1$s (%2$s). The last %3$s arrived in %4$d s after it continued. Checking it now.', 'restorwell' ), res.name, sizeLabel( file.size ), sizeLabel( file.size - startOffset ), seconds )
					: sprintf( __( 'Upload complete: %1$s (%2$s) in %3$d s. Checking it now.', 'restorwell' ), res.name, sizeLabel( file.size ), seconds );
				if ( data.chunkSize < firstChunk ) {
					done += ' ' + sprintf( __( 'The web server only accepted pieces of %s, so smaller pieces were sent.', 'restorwell' ), sizeLabel( data.chunkSize ) );
				}
				notice( done, 'success' );
				fileInput.value = '';
				setUploadEnabled( false );
				refreshList();
				startCheck( res.ref, res.name );
			} )
			.catch( function ( err ) {
				finish();
				if ( 413 === err.status ) {
					notice( __( 'The web server refuses even the smallest pieces (64 KB, HTTP 413). Ask your host to raise the web server\'s request size limit (for nginx: client_max_body_size), or copy the backup into wp-content/restorwell-backups with FTP or your host\'s File Manager and click Refresh list.', 'restorwell' ), 'error' );
					refreshList();
					return;
				}
				// Only an upload that had begun keeps anything: a refusal before the first piece keeps nothing.
				var kept = sent > 0 ? ' ' + __( 'What arrived is kept: choose the same file and click Upload to continue.', 'restorwell' ) : '';
				notice( err.message + kept, 'error' );
				refreshList();
			} );
	}

	/* ---------- Check ---------- */

	function password() {
		return $( 'rw-password-input' ).value;
	}

	/** The previous "Restore finished" card goes once a new backup is uploaded or checked. */
	function closeLast() {
		var box = $( 'rw-finished' );
		if ( data.last && ! box.hidden ) {
			box.hidden = true;
			data.last = null;
			api( 'dismiss', { what: 'finished' } ).catch( function () {} );
		}
	}

	function startCheck( ref, name ) {
		closeLast();
		state.ref = ref;
		state.name = name;
		state.token = null;
		state.report = null;
		$( 'rw-confirm-input' ).checked = false;
		setStep( 'check' );
		$( 'rw-check-title' ).textContent = sprintf( __( 'Check: %s', 'restorwell' ), name );
		[ 'rw-report', 'rw-limits', 'rw-limits-title', 'rw-confirm', 'rw-blocked', 'rw-blocked-actions' ].forEach( function ( id ) {
			$( id ).hidden = true;
		} );
		runCheck();
	}

	function runCheck( token ) {
		var box = $( 'rw-check-progress' );
		var fields = { password: password() };
		if ( token ) {
			fields.token = token;
		} else {
			fields.ref = state.ref;
			setProgress( box, 0, __( 'Reading the whole backup…', 'restorwell' ) );
		}
		state.busy = true;
		return apiRetry( 'check', fields )
			.then( function ( res ) {
				state.token = res.token;
				if ( ! res.done ) {
					setProgress( box, res.report.progress, sprintf( __( 'Reading the whole backup and checking its checksums: %d%%. Nothing on the site changes during the check.', 'restorwell' ), res.report.progress ) );
					return runCheck( res.token );
				}
				state.busy = false;
				box.hidden = true;
				showReport( res.report, res.rows );
			} )
			.catch( function ( err ) {
				state.busy = false;
				box.hidden = true;
				notice( err.message, 'error' );
				if ( 404 === err.status ) {
					// The file is gone: the list still shows it.
					refreshList();
				}
			} );
	}

	var icons = { ok: '✓', warn: '!', block: '✕' };
	var levelText = { ok: __( 'OK', 'restorwell' ), warn: __( 'Warning', 'restorwell' ), block: __( 'Blocks restore', 'restorwell' ) };

	function showReport( report, rows ) {
		state.report = report;
		var tbody = $( 'rw-report' ).querySelector( 'tbody' );
		tbody.textContent = '';
		rows.forEach( function ( row ) {
			tbody.appendChild( el( 'tr', {}, [ el( 'th', { scope: 'row', text: row[ 0 ] } ), el( 'td', { text: row[ 1 ] } ) ] ) );
		} );
		$( 'rw-report' ).hidden = false;

		var list = $( 'rw-limits' );
		list.textContent = '';
		report.limits.forEach( function ( limit ) {
			list.appendChild(
				el( 'li', { className: 'rw-limit rw-' + limit.level, 'data-code': limit.code }, [
					el( 'span', { className: 'rw-icon', 'aria-hidden': 'true', text: icons[ limit.level ] } ),
					el( 'span', { className: 'screen-reader-text', text: levelText[ limit.level ] + ': ' } ),
					el( 'span', { className: 'rw-limit-text', text: limit.message } ),
				] )
			);
		} );
		list.hidden = false;
		$( 'rw-limits-title' ).hidden = false;

		var pw = $( 'rw-password' );
		// A damaged or cut-off copy cannot be restored with any password: do not ask for one.
		var unreadable = !! report.error && 'password_wrong' !== report.error.reason;
		pw.hidden = ! report.encrypted || 'ok' === report.password || unreadable;
		if ( ! pw.hidden ) {
			$( 'rw-password-input' ).focus();
		}

		$( 'rw-confirm' ).hidden = ! report.can_restore;
		$( 'rw-blocked' ).hidden = report.can_restore;
		$( 'rw-blocked' ).textContent = report.can_restore ? '' : __( 'Restore stays off until every limit marked ✕ is solved. Nothing on your site has changed.', 'restorwell' );
		showBlockedActions( report );
		updateRestoreButton();
	}

	function backToList() {
		notice( '' );
		setStep( 'choose' );
	}

	/**
	 * When a limit blocks the restore the Check is a dead end unless it says where to go: back to the list.
	 * A copy the Check calls damaged or incomplete can only be replaced, so it also offers to delete it, with the row's own question.
	 */
	function showBlockedActions( report ) {
		var box = $( 'rw-blocked-actions' );
		box.textContent = '';
		box.hidden = report.can_restore;
		if ( box.hidden ) {
			return;
		}
		var f = state.files && state.files[ state.ref ];
		var broken = report.limits.some( function ( limit ) {
			return 'structure' === limit.code && 'block' === limit.level;
		} );
		var back = el( 'button', { type: 'button', className: 'button rw-back-blocked', text: __( 'Choose another backup', 'restorwell' ), on: { click: backToList } } );
		if ( f && broken ) {
			var button = el( 'button', {
				type: 'button',
				className: 'button rw-delete-damaged',
				text: __( 'Delete this copy', 'restorwell' ),
				'aria-label': sprintf( __( 'Delete %s', 'restorwell' ), f.name ),
				on: {
					click: function () {
						text.hidden = true;
						button.hidden = true;
						ask.hidden = false;
						ask.querySelector( 'button' ).focus();
					},
				},
			} );
			var text = el( 'span', { className: 'rw-blocked-text', text: __( 'This copy cannot be restored. Choose a fresh copy of the backup, and delete this one to free its space.', 'restorwell' ) + ' ' } );
			var ask = deleteAsk( f, function () {
				ask.hidden = true;
				text.hidden = false;
				button.hidden = false;
			} );
			box.appendChild( text );
			box.appendChild( button );
			box.appendChild( ask );
		}
		box.appendChild( back );
	}

	function updateRestoreButton() {
		var ready = !! ( state.report && state.report.can_restore && $( 'rw-confirm-input' ).checked );
		var button = $( 'rw-restore' );
		button.disabled = ! ready;
		if ( ready ) {
			button.removeAttribute( 'title' );
		} else {
			button.setAttribute( 'title', __( 'Tick the confirmation first.', 'restorwell' ) );
		}
	}

	$( 'rw-confirm-input' ).addEventListener( 'change', updateRestoreButton );
	$( 'rw-password-check' ).addEventListener( 'click', function () {
		notice( '' );
		[ 'rw-report', 'rw-limits', 'rw-limits-title', 'rw-confirm', 'rw-blocked', 'rw-blocked-actions' ].forEach( function ( id ) {
			$( id ).hidden = true;
		} );
		runCheck();
	} );
	$( 'rw-password-input' ).addEventListener( 'keydown', function ( e ) {
		if ( 'Enter' === e.key ) {
			e.preventDefault();
			$( 'rw-password-check' ).click();
		}
	} );
	$( 'rw-back' ).addEventListener( 'click', backToList );
	$( 'rw-refresh' ).addEventListener( 'click', refreshList );

	/* ---------- Restore ---------- */

	$( 'rw-restore' ).addEventListener( 'click', function () {
		notice( '' );
		setStep( 'restore' );
		setRestoreProgress( { percent: 0, label: __( 'Starting…', 'restorwell' ) } );
		beginRestore();
		api( 'restore_start', { token: state.token, password: password(), confirm: '1' } )
			.then( runRestore )
			.catch( restoreFailed );
	} );

	function beginRestore() {
		state.busy = true;
		state.restoring = true;
		state.cancelRequested = false;
		$( 'rw-cancel' ).disabled = false;
	}

	function endRestore() {
		state.busy = false;
		state.restoring = false;
		state.cancelRequested = false;
		$( 'rw-cancel' ).disabled = false;
	}

	function setRestoreProgress( job ) {
		setProgress( $( 'rw-restore-section' ).querySelector( '.rw-progress' ), job.percent, job.label );
	}

	function runRestore( job ) {
		setRestoreProgress( job );
		if ( job.switched || 'done' === job.stage ) {
			endRestore();
			finishedNow( job );
			return null;
		}
		// Cancel waits for the step that was running, then stops the loop here.
		if ( state.cancelRequested ) {
			return cancelRestore();
		}
		var wait = job.busy ? sleep( 2000 ) : Promise.resolve();
		return wait
			.then( function () {
				return apiRetry( 'restore_step', { password: password() } );
			} )
			.then( runRestore );
	}

	function restoreFailed( err ) {
		endRestore();
		if ( err.info && err.info.password ) {
			setStep( 'check' );
		} else {
			setStep( err.info && err.info.stopped ? 'choose' : 'check' );
		}
		notice( err.message, 'error' );
		refreshList();
	}

	$( 'rw-cancel' ).addEventListener( 'click', function () {
		if ( state.cancelRequested ) {
			return;
		}
		state.cancelRequested = true;
		$( 'rw-cancel' ).disabled = true;
		$( 'rw-restore-label' ).textContent = __( 'Cancelling: waiting for the current step to finish…', 'restorwell' );
		if ( ! state.restoring ) {
			cancelRestore().catch( restoreFailed );
		}
	} );

	/** Asks the server to cancel. It waits for a running step and puts back anything already moved. */
	function cancelRestore() {
		$( 'rw-restore-label' ).textContent = __( 'Cancelling and removing the temporary data…', 'restorwell' );
		return apiRetry( 'restore_cancel', {} ).then( function ( res ) {
			if ( res.switched && res.job ) {
				// Too late: the switch was made. Finish it instead.
				state.cancelRequested = false;
				notice( res.message, 'warning' );
				return runRestore( res.job );
			}
			endRestore();
			setStep( 'choose' );
			notice( res.message, 'info' );
			refreshList();
			return null;
		} );
	}

	function tablesText( count ) {
		return sprintf( i18n._n( '%d database table', '%d database tables', count, 'restorwell' ), count );
	}

	/** What the restore left out on purpose, and what it did about the page addresses. */
	function restoredNotes( box, info ) {
		if ( info.leftOut ) {
			box.appendChild( el( 'p', { className: 'rw-muted', text: info.leftOut } ) );
		}
		if ( info.pages ) {
			box.appendChild( el( 'p', { className: info.pagesWarn ? 'rw-warn-text' : 'rw-muted', text: info.pages } ) );
		}
	}

	/** Shown in the same page right after the switch: the session is gone now. */
	function finishedNow( job ) {
		root.querySelectorAll( '.rw-section, .rw-steps, .rw-footnote' ).forEach( function ( node ) {
			node.hidden = true;
		} );
		var box = $( 'rw-finished' );
		box.textContent = '';
		box.hidden = false;
		box.appendChild( el( 'h2', { text: __( 'Restore finished', 'restorwell' ) } ) );
		box.appendChild( el( 'p', { text: sprintf( __( 'The site from %1$s is now live at %2$s: %3$s files and %4$s restored.', 'restorwell' ), job.source, data.homeUrl, job.filesText, tablesText( job.tables ) ) } ) );
		restoredNotes( box, job );
		box.appendChild( el( 'p', { text: __( 'The accounts on this site are now the ones in the backup, so you have been signed out. Log in with a username and password from the backup.', 'restorwell' ) } ) );
		( job.warnings || [] ).forEach( function ( w ) {
			box.appendChild( el( 'p', { className: 'rw-warn-text', text: w } ) );
		} );
		box.appendChild(
			el( 'p', { className: 'rw-actions' }, [
				el( 'a', { className: 'button button-primary button-hero', href: data.loginUrl, text: __( 'Log in with an account from the backup', 'restorwell' ) } ),
				el( 'a', { className: 'button button-hero', href: data.homeUrl, target: '_blank', rel: 'noopener', text: __( 'View the site', 'restorwell' ) } ),
			] )
		);
		box.focus();
	}

	/* ---------- After login: finished panel, resume panel ---------- */

	function showLast( last ) {
		var box = $( 'rw-finished' );
		box.textContent = '';
		box.hidden = false;
		box.appendChild( el( 'h2', { text: __( 'Restore finished', 'restorwell' ) } ) );
		box.appendChild( el( 'p', { text: sprintf( __( '%1$s, restored on %2$s from %3$s: %4$s files and %5$s.', 'restorwell' ), last.name, last.date, last.source, last.filesText, tablesText( last.tables ) ) } ) );
		restoredNotes( box, last );

		if ( last.ref ) {
			var del = el( 'p', { className: 'rw-delete' }, [
				sprintf( __( 'The backup file (%s) is still on the server. Delete it now to free the space?', 'restorwell' ), last.sizeLabel ),
				' ',
			] );
			del.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button',
					id: 'rw-delete-backup',
					text: __( 'Delete backup file', 'restorwell' ),
					on: {
						click: function () {
							api( 'delete_backup', { ref: last.ref } )
								.then( function ( res ) {
									del.textContent = res.message;
									refreshList();
								} )
								.catch( function ( err ) {
									notice( err.message, 'error' );
								} );
						},
					},
				} )
			);
			del.appendChild( document.createTextNode( ' ' ) );
			del.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button-link',
					text: __( 'Keep it', 'restorwell' ),
					on: {
						click: function () {
							del.remove();
						},
					},
				} )
			);
			box.appendChild( del );
		}

		if ( data.review ) {
			var line = el( 'p', { className: 'rw-review', id: 'rw-review' }, [
				__( 'Did Restorwell get your site back? A short review on WordPress.org helps other people find it.', 'restorwell' ),
				' ',
				el( 'a', { href: data.reviewUrl, target: '_blank', rel: 'noopener noreferrer', text: __( 'Leave a review', 'restorwell' ) } ),
				' ',
			] );
			line.appendChild(
				el( 'button', {
					type: 'button',
					className: 'button-link rw-dismiss',
					text: __( 'Dismiss', 'restorwell' ),
					'aria-label': __( 'Dismiss the review request', 'restorwell' ),
					on: {
						click: function () {
							api( 'dismiss', { what: 'review' } );
							line.remove();
						},
					},
				} )
			);
			box.appendChild( line );
		}

		box.appendChild(
			el( 'p', {}, [
				el( 'button', {
					type: 'button',
					className: 'button',
					id: 'rw-close-finished',
					text: __( 'Close', 'restorwell' ),
					on: {
						click: function () {
							api( 'dismiss', { what: 'finished' } );
							box.hidden = true;
						},
					},
				} ),
			] )
		);
	}

	function showChooser( visible ) {
		root.querySelector( '.rw-steps' ).hidden = ! visible;
		$( 'rw-choose' ).hidden = ! visible;
	}

	function showResume( job ) {
		var box = $( 'rw-resume' );
		box.textContent = '';
		box.hidden = false;
		// One restore at a time: the backup chooser comes back once this one is continued or cancelled.
		showChooser( false );
		box.appendChild( el( 'h2', { text: __( 'A restore was interrupted', 'restorwell' ) } ) );
		box.appendChild(
			el( 'p', {
				text: job.moved
					? sprintf( __( 'Restoring %1$s stopped in the middle of the switch: some restored folders were already moved in, and your site\'s own folders are kept aside. Continue finishes the restore. Cancel puts your site\'s own folders back and then removes the temporary data.', 'restorwell' ), job.name )
					: job.point
						? sprintf( __( 'Restoring %1$s stopped while %2$s. Continue picks up from the last saved point (%3$s). Your live site has not changed yet.', 'restorwell' ), job.name, job.doing, job.point )
						: sprintf( __( 'Restoring %1$s stopped while %2$s. Your live site has not changed yet.', 'restorwell' ), job.name, job.doing ),
			} )
		);
		var row = el( 'p', { className: 'rw-actions' } );
		if ( job.encrypted ) {
			box.appendChild( el( 'label', { for: 'rw-resume-password', text: __( 'Backup password', 'restorwell' ) } ) );
			box.appendChild( el( 'br' ) );
			box.appendChild( el( 'input', { type: 'password', id: 'rw-resume-password', className: 'regular-text', autocomplete: 'off' } ) );
		}
		row.appendChild(
			el( 'button', {
				type: 'button',
				className: 'button button-primary',
				text: __( 'Continue restore', 'restorwell' ),
				on: {
					click: function () {
						if ( job.encrypted ) {
							$( 'rw-password-input' ).value = $( 'rw-resume-password' ).value;
						}
						box.hidden = true;
						root.querySelector( '.rw-steps' ).hidden = false;
						setStep( 'restore' );
						beginRestore();
						runRestore( job ).catch( restoreFailed );
					},
				},
			} )
		);
		row.appendChild(
			el( 'button', {
				type: 'button',
				className: 'button',
				text: __( 'Cancel and remove temporary data', 'restorwell' ),
				on: {
					click: function () {
						api( 'restore_cancel', {} )
							.then( function ( res ) {
								box.hidden = true;
								showChooser( true );
								if ( res.switched && res.job ) {
									notice( res.message, 'warning' );
									setStep( 'restore' );
									beginRestore();
									return runRestore( res.job ).catch( restoreFailed );
								}
								setStep( 'choose' );
								notice( res.message, 'info' );
								refreshList();
								return null;
							} )
							.catch( function ( err ) {
								notice( err.message, 'error' );
							} );
					},
				},
			} )
		);
		box.appendChild( row );
	}

	function cleanupLoop() {
		return api( 'cleanup', {} ).then( function ( res ) {
			if ( ! res.done ) {
				return cleanupLoop();
			}
			return null;
		} );
	}

	// A small interface for add-ons such as Restorwell Pro.
	window.restorwell = {
		api: api,
		notice: notice,
		sizeLabel: sizeLabel,
		setProgress: setProgress,
		refreshList: refreshList,
		startCheck: startCheck,
		closeLast: closeLast,
		setBusy: function ( busy ) {
			state.busy = !! busy;
		},
	};

	if ( data.job ) {
		if ( data.job.switched ) {
			cleanupLoop().catch( function () {} );
		} else {
			showResume( data.job );
		}
	}
	// An interrupted restore comes first; an older "Restore finished" card would only confuse it.
	if ( data.last && ! ( data.job && ! data.job.switched ) ) {
		showLast( data.last );
	}
	refreshList();
} )();
