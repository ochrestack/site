<?php
/**
 * Reader for the .wpress backup format written by All-in-One WP Migration.
 *
 * Layout: a sequence of entries, each a 4377-byte header followed by the
 * stored bytes, then a 4377-byte end block. Header fields: name (255),
 * stored size (14), modification time (12), folder (4088) and the CRC-32
 * of the original bytes (8). The end block is all zero bytes, or carries
 * the archive size and the CRC-32 of every byte before it.
 * When a backup is compressed, every stored piece is preceded by its
 * length (4 bytes, big-endian); when it has a password, every piece is
 * AES-256-CBC with its own 16-byte IV in front. package.json and
 * multisite.json are always stored as they are.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sequential, resumable reader for one .wpress file.
 */
final class Restorwell_Archive {

	const HEADER_SIZE = 4377;
	const CHUNK_SIZE  = 512000;
	const IV_LENGTH   = 16;
	const CIPHER      = 'AES-256-CBC';

	/**
	 * Plain text that All-in-One WP Migration encrypts with the backup password
	 * and stores in package.json as "EncryptedSignature", so the password can be
	 * checked without touching the files. It is part of the file format.
	 */
	const SIGN_TEXT = '"How long do you want these messages to remain secret? I want them to remain secret for as long as men are capable of evil." - Neal Stephenson';

	/**
	 * Entries that are never compressed or encrypted.
	 *
	 * @var string[]
	 */
	private static $config_files = array( 'package.json', 'multisite.json' );

	/**
	 * Absolute path of the backup.
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Open handle.
	 *
	 * @var resource
	 */
	private $handle;

	/**
	 * Size of the backup in bytes.
	 *
	 * @var int
	 */
	private $size;

	/**
	 * Running CRC-32 of every raw byte read, while raw hashing is on.
	 *
	 * @var HashContext|resource|null
	 */
	private $raw_ctx = null;

	/**
	 * Number of raw bytes added to $raw_ctx.
	 *
	 * @var int
	 */
	private $raw_len = 0;

	/**
	 * Opens a backup for reading.
	 *
	 * @param string $path Absolute path.
	 * @throws Restorwell_Exception When the file cannot be opened.
	 */
	public function __construct( $path ) {
		$this->path = $path;
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Streaming multi-gigabyte files in pieces; WP_Filesystem has no seekable stream API.
		$handle = is_readable( $path ) ? fopen( $path, 'rb' ) : false;
		if ( false === $handle ) {
			throw new Restorwell_Exception( 'unreadable', esc_html__( 'The backup file cannot be opened. Check that it still exists and that the web server may read it.', 'restorwell' ) );
		}
		$this->handle = $handle;
		$stat         = fstat( $handle );
		$this->size   = (int) $stat['size'];
	}

	/**
	 * Closes the file.
	 */
	public function close() {
		if ( is_resource( $this->handle ) ) {
			fclose( $this->handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		}
	}

	/**
	 * Returns the size of the backup in bytes.
	 *
	 * @return int
	 */
	public function size() {
		return $this->size;
	}

	/**
	 * Starts adding every raw byte read to a CRC-32.
	 */
	public function start_raw_hash() {
		$this->raw_ctx = hash_init( 'crc32b' );
		$this->raw_len = 0;
	}

	/**
	 * Stops raw hashing and returns the CRC and length of the bytes read since start.
	 *
	 * @return array{0:string,1:int}
	 */
	public function end_raw_hash() {
		$crc           = null === $this->raw_ctx ? '00000000' : hash_final( $this->raw_ctx );
		$len           = $this->raw_len;
		$this->raw_ctx = null;
		$this->raw_len = 0;
		return array( $crc, $len );
	}

	/**
	 * Reads exactly $length bytes at the current position.
	 *
	 * @param int $length Number of bytes.
	 * @return string
	 * @throws Restorwell_Exception When the file ends early.
	 */
	private function read( $length ) {
		$data = '';
		$have = 0;
		while ( $have < $length ) {
			$piece = fread( $this->handle, $length - $have ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
			if ( false === $piece || '' === $piece ) {
				$exception = self::truncated();
				throw $exception;
			}
			$data .= $piece;
			$have += strlen( $piece );
		}
		if ( null !== $this->raw_ctx ) {
			hash_update( $this->raw_ctx, $data );
			$this->raw_len += $length;
		}
		return $data;
	}

	/**
	 * Moves to an absolute offset.
	 *
	 * @param int $offset Offset in bytes.
	 * @throws Restorwell_Exception When seeking fails.
	 */
	private function seek( $offset ) {
		if ( $offset > $this->size || -1 === fseek( $this->handle, $offset ) ) {
			$exception = self::truncated();
			throw $exception;
		}
	}

	/**
	 * The exception for a backup that ends before its end block.
	 *
	 * @return Restorwell_Exception
	 */
	public static function truncated() {
		return new Restorwell_Exception( 'truncated', esc_html__( 'The backup file is incomplete: it ends before its last part. This usually means the download or upload stopped early. Copy the backup again and choose the new copy.', 'restorwell' ) );
	}

	/**
	 * The exception for a backup whose bytes do not match its checksum.
	 *
	 * @param string $what Which part failed, for the message, already escaped for HTML.
	 * @return Restorwell_Exception
	 */
	public static function checksum_failed( $what = '' ) {
		$message = esc_html__( 'The backup file is damaged: its contents do not match the checksum stored inside it, so at least one byte changed after the backup was made. Copy the backup again from where it was made and choose the new copy.', 'restorwell' );
		if ( '' !== $what ) {
			/* translators: %s: path of a file inside the backup. */
			$message .= ' ' . sprintf( esc_html__( 'First damaged part: %s', 'restorwell' ), $what );
		}
		return new Restorwell_Exception( 'checksum', $message );
	}

	/**
	 * The exception for a header that cannot be read.
	 *
	 * @return Restorwell_Exception
	 */
	public static function not_wpress() {
		return new Restorwell_Exception( 'damaged', esc_html__( 'This file is not a readable .wpress backup: its structure is damaged or it was made by another program.', 'restorwell' ) );
	}

	/**
	 * Reads and parses the header at an offset.
	 *
	 * @param int $offset Offset of the header.
	 * @return array Parsed header; 'type' is 'file' or 'eof'.
	 * @throws Restorwell_Exception When the header is missing or damaged.
	 */
	public function header_at( $offset ) {
		if ( $offset + self::HEADER_SIZE > $this->size ) {
			$exception = self::truncated();
			throw $exception;
		}
		$this->seek( $offset );
		$block  = $this->read( self::HEADER_SIZE );
		$header = self::parse_header( $block );
		if ( null === $header ) {
			$exception = self::not_wpress();
			throw $exception;
		}
		$header['offset']      = $offset;
		$header['data_offset'] = $offset + self::HEADER_SIZE;
		return $header;
	}

	/**
	 * Parses one 4377-byte block.
	 *
	 * @param string $block Raw block.
	 * @return array|null Null when the block is not a valid header.
	 */
	public static function parse_header( $block ) {
		if ( strlen( $block ) !== self::HEADER_SIZE ) {
			return null;
		}
		if ( str_repeat( "\0", self::HEADER_SIZE ) === $block ) {
			return array(
				'type'    => 'eof',
				'eof_len' => null,
				'eof_crc' => null,
			);
		}
		$f = unpack( 'a255name/a14size/a12mtime/a4088path/a8crc', $block );
		if ( false === $f ) {
			return null;
		}
		$name = trim( $f['name'] );
		$size = trim( $f['size'] );
		$crc  = trim( $f['crc'] );

		// Version 2 end block: empty name and path, archive size and CRC.
		if ( '' === $name && '' === trim( $f['mtime'] ) && '' === trim( $f['path'] ) ) {
			if ( ctype_digit( $size ) && 1 === preg_match( '/^[0-9a-f]{8}$/i', $crc ) ) {
				return array(
					'type'    => 'eof',
					'eof_len' => (int) $size,
					'eof_crc' => strtolower( $crc ),
				);
			}
			return null;
		}

		if ( '' === $name || ! ctype_digit( $size ) ) {
			return null;
		}
		if ( '' !== $crc && 1 !== preg_match( '/^[0-9a-f]{8}$/i', $crc ) ) {
			return null;
		}
		$folder   = trim( $f['path'] );
		$relative = self::relative_path( $folder, $name );
		return array(
			'type'     => 'file',
			'name'     => $name,
			'folder'   => $folder,
			'relative' => $relative,
			'safe'     => false !== $relative,
			'size'     => (int) $size,
			'mtime'    => (int) trim( $f['mtime'] ),
			'crc'      => strtolower( $crc ),
		);
	}

	/**
	 * Builds the path of an entry relative to wp-content, refusing anything
	 * that could point outside it.
	 *
	 * @param string $folder Folder field of the header.
	 * @param string $name   Name field of the header.
	 * @return string|false Relative path with forward slashes, or false when unsafe.
	 */
	public static function relative_path( $folder, $name ) {
		$folder = str_replace( '\\', '/', $folder );
		$name   = str_replace( '\\', '/', $name );
		if ( false !== strpos( $name, '/' ) ) {
			return false;
		}
		$path = ( '' === $folder || '.' === $folder ) ? $name : $folder . '/' . $name;
		if ( false !== strpos( $path, "\0" ) || '/' === $path[0] || 1 === preg_match( '#^[a-zA-Z]:#', $path ) ) {
			return false;
		}
		foreach ( explode( '/', $path ) as $segment ) {
			if ( '' === $segment || '.' === $segment || '..' === $segment ) {
				return false;
			}
		}
		return $path;
	}

	/**
	 * Whether an entry is stored without compression or encryption.
	 *
	 * @param string $relative Relative path.
	 * @return bool
	 */
	public static function is_config_file( $relative ) {
		return in_array( $relative, self::$config_files, true );
	}

	/**
	 * Whether an entry is stored as plain bytes in a password-protected backup.
	 * All-in-One WP Migration 7.101 and older left every file named
	 * package.json unencrypted (themes and plugins ship one too); 7.102 and
	 * later leave only the root config files unencrypted.
	 *
	 * @param string $relative  Relative path.
	 * @param string $made_with Version of All-in-One WP Migration that made the backup.
	 * @return bool
	 */
	public static function is_stored_plain( $relative, $made_with ) {
		if ( self::is_config_file( $relative ) ) {
			return true;
		}
		return '' !== (string) $made_with
			&& version_compare( (string) $made_with, '7.102', '<' )
			&& 'package.json' === basename( $relative );
	}

	/**
	 * Reads a small entry completely, without decoding.
	 *
	 * @param array $header Parsed header.
	 * @param int   $limit  Largest size accepted.
	 * @return string
	 * @throws Restorwell_Exception When the entry is too large or cut short.
	 */
	public function read_raw_entry( array $header, $limit = 4194304 ) {
		if ( $header['size'] > $limit ) {
			$exception = self::not_wpress();
			throw $exception;
		}
		$this->seek( $header['data_offset'] );
		return $header['size'] > 0 ? $this->read( $header['size'] ) : '';
	}

	/**
	 * Reads raw bytes of the file (used to checksum the whole archive).
	 *
	 * @param int $offset Start.
	 * @param int $length Length.
	 * @return string
	 */
	public function raw_bytes( $offset, $length ) {
		$this->seek( $offset );
		return $this->read( $length );
	}

	/**
	 * Derives the AES key All-in-One WP Migration uses for a password.
	 *
	 * @param string $password Backup password.
	 * @return string 32-byte key.
	 */
	private static function key( $password ) {
		return str_pad( substr( sha1( $password, true ), 0, self::IV_LENGTH ), 32, "\0" );
	}

	/**
	 * Decrypts one stored piece.
	 *
	 * @param string $data     IV followed by cipher text.
	 * @param string $password Backup password.
	 * @return string|false Plain bytes, or false when the password is wrong or the piece damaged.
	 */
	public static function decrypt( $data, $password ) {
		if ( strlen( $data ) < self::IV_LENGTH * 2 ) {
			return false;
		}
		return openssl_decrypt( substr( $data, self::IV_LENGTH ), self::CIPHER, self::key( $password ), OPENSSL_RAW_DATA, substr( $data, 0, self::IV_LENGTH ) );
	}

	/**
	 * Checks a password against package.json's EncryptedSignature.
	 *
	 * @param string $signature Base64 signature from package.json.
	 * @param string $password  Password to test.
	 * @return bool
	 */
	public static function password_matches_signature( $signature, $password ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- The backup format stores the signature as base64.
		$raw = base64_decode( (string) $signature, true );
		if ( false === $raw || '' === $password ) {
			return false;
		}
		return self::SIGN_TEXT === self::decrypt( $raw, $password );
	}

	/**
	 * Decodes part of one entry, handing plain bytes to $sink, until the entry
	 * ends or the deadline passes. $cursor carries the position between calls:
	 * 'consumed' stored bytes, 'written' plain bytes, 'crc' of the plain bytes so far.
	 *
	 * @param array    $header      Parsed header of the entry.
	 * @param array    $cursor      Position, updated in place.
	 * @param string   $password    Password, or '' when the backup has none.
	 * @param string   $compression '', 'gzip' or 'bzip2'.
	 * @param callable $sink        Receives each piece of plain bytes.
	 * @param float    $deadline    microtime(true) after which to stop.
	 * @return bool True when the entry is complete and its checksum matched.
	 * @throws Restorwell_Exception On damage, a wrong password or a checksum failure.
	 */
	public function decode( array $header, array &$cursor, $password, $compression, $sink, $deadline ) {
		$cursor   += array(
			'consumed' => 0,
			'written'  => 0,
			'crc'      => '',
		);
		$size      = $header['size'];
		$process   = ! self::is_config_file( $header['relative'] );
		$encrypted = $process && '' !== $password;
		$packed    = $process && '' !== $compression;

		$this->seek( $header['data_offset'] + $cursor['consumed'] );
		$ctx     = hash_init( 'crc32b' );
		$seg_len = 0;

		while ( $cursor['consumed'] < $size ) {
			$remaining = $size - $cursor['consumed'];
			if ( $packed ) {
				if ( $remaining < 4 ) {
					$exception = self::not_wpress();
					throw $exception;
				}
				$length = unpack( 'Nlen', $this->read( 4 ) );
				$length = (int) $length['len'];
				if ( $length <= 0 || $length > $remaining - 4 ) {
					$exception = self::checksum_failed( esc_html( $header['relative'] ) );
					throw $exception;
				}
				$data                = $this->read( $length );
				$cursor['consumed'] += 4 + $length;
				if ( $encrypted ) {
					$data = self::decrypt( $data, $password );
					if ( false === $data ) {
						$exception = self::cannot_decrypt( esc_html( $header['relative'] ) );
						throw $exception;
					}
				}
				$data = self::inflate( $data, $compression, $header['relative'] );
			} elseif ( $encrypted ) {
				$length = min( $remaining, self::CHUNK_SIZE );
				if ( $remaining > self::CHUNK_SIZE ) {
					$length = min( self::CHUNK_SIZE + self::IV_LENGTH * 2, $remaining );
				}
				$data                = $this->read( $length );
				$cursor['consumed'] += $length;
				$data                = self::decrypt( $data, $password );
				if ( false === $data ) {
					$exception = self::cannot_decrypt( esc_html( $header['relative'] ) );
					throw $exception;
				}
			} else {
				$length              = min( $remaining, self::CHUNK_SIZE );
				$data                = $this->read( $length );
				$cursor['consumed'] += $length;
			}

			hash_update( $ctx, $data );
			$seg_len           += strlen( $data );
			$cursor['written'] += strlen( $data );
			call_user_func( $sink, $data );

			if ( microtime( true ) > $deadline ) {
				break;
			}
		}

		$cursor['crc'] = Restorwell_Crc::combine( $cursor['crc'], hash_final( $ctx ), $seg_len );
		if ( $cursor['consumed'] < $size ) {
			return false;
		}
		if ( '' === $cursor['crc'] ) {
			$cursor['crc'] = '00000000';
		}
		if ( '' !== $header['crc'] && $header['crc'] !== $cursor['crc'] ) {
			$exception = self::checksum_failed( esc_html( $header['relative'] ) );
			throw $exception;
		}
		return true;
	}

	/**
	 * Uncompresses one piece.
	 *
	 * @param string $data        Compressed bytes.
	 * @param string $compression 'gzip' or 'bzip2'.
	 * @param string $relative    Entry path, for the message.
	 * @return string
	 * @throws Restorwell_Exception When the piece is damaged.
	 */
	private static function inflate( $data, $compression, $relative ) {
		if ( 'gzip' === $compression ) {
			$out = @gzuncompress( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- A damaged piece raises a warning; the false result is handled.
		} elseif ( 'bzip2' === $compression && function_exists( 'bzdecompress' ) ) {
			$out = bzdecompress( $data );
			if ( is_int( $out ) ) {
				$out = false;
			}
		} else {
			throw new Restorwell_Exception( 'compression', esc_html__( 'This backup uses a compression this server cannot read.', 'restorwell' ) );
		}
		if ( false === $out ) {
			$exception = self::checksum_failed( esc_html( $relative ) );
			throw $exception;
		}
		return $out;
	}

	/**
	 * The exception for a piece that cannot be decrypted.
	 *
	 * @param string $relative Entry path, already escaped for HTML.
	 * @return Restorwell_Exception
	 */
	private static function cannot_decrypt( $relative ) {
		return new Restorwell_Exception(
			'password_wrong',
			/* translators: %s: path of a file inside the backup. */
			sprintf( esc_html__( 'The password is wrong, or the backup is damaged: %s could not be decrypted.', 'restorwell' ), $relative )
		);
	}
}
