<?php
/**
 * Facts about this server that decide whether a backup can be restored here.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Server facts.
 */
final class Restorwell_Environment {

	/**
	 * Collects the facts the Check report compares against.
	 *
	 * @return array
	 */
	public static function snapshot() {
		global $wp_version, $wpdb;

		$free = null;
		if ( function_exists( 'disk_free_space' ) ) {
			$dir   = is_dir( Restorwell_Files::folder() ) ? Restorwell_Files::folder() : WP_CONTENT_DIR;
			$value = @disk_free_space( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Hosts may disable it; null means unknown.
			$free  = false === $value ? null : (float) $value;
		}
		/**
		 * Filters the free disk space Restorwell compares against, in bytes.
		 * Return null when it cannot be known.
		 *
		 * @param float|null $free Free bytes in wp-content, or null.
		 */
		$free = apply_filters( 'restorwell_free_disk_space', $free );

		$packet = null;
		if ( isset( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli ) {
			$value  = $wpdb->get_var( 'SELECT @@global.max_allowed_packet' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$packet = is_numeric( $value ) ? (int) $value : null;
		}

		return array(
			'other_disk'  => self::other_disk(),
			'wp_version'  => (string) $wp_version,
			'max_packet'  => $packet,
			'php_version' => PHP_VERSION,
			'free_bytes'  => null === $free ? null : (float) $free,
			'multisite'   => is_multisite(),
			'mysql'       => isset( $wpdb->dbh ) && $wpdb->dbh instanceof mysqli,
			'bz2'         => function_exists( 'bzdecompress' ),
			'openssl'     => function_exists( 'openssl_decrypt' ),
			'int_size'    => PHP_INT_SIZE,
		);
	}

	/**
	 * Folders a restore switches into place that sit on a different disk
	 * (filesystem) from Restorwell's backup folder, where restored folders are
	 * prepared. A folder cannot be moved in across disks, so the Check names them.
	 *
	 * @return string[] Folder paths relative to the WordPress folder.
	 */
	public static function other_disk() {
		$folder = Restorwell_Files::folder();
		$stat   = is_dir( $folder ) ? @stat( $folder ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false means unknown.
		if ( false === $stat ) {
			return array();
		}
		$out = array();
		foreach ( array_unique( array( WP_CONTENT_DIR, WP_PLUGIN_DIR, get_theme_root(), WPMU_PLUGIN_DIR ) ) as $dir ) {
			$other = is_dir( $dir ) ? @stat( $dir ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $other && $other['dev'] !== $stat['dev'] ) {
				$out[] = ltrim( str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $dir ) ), '/' );
			}
		}
		return $out;
	}
}
