<?php
/**
 * WP-CLI commands: wp restorwell check, wp restorwell restore, wp restorwell list.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Checks and restores .wpress backups from the command line.
 *
 * Exit codes: 0 success, 1 other error, 2 password needed or wrong,
 * 3 backup damaged or incomplete, 4 not enough disk space,
 * 5 another limit blocks the restore (for example a multisite backup).
 */
class Restorwell_CLI {

	/**
	 * Checks a .wpress backup and prints the report, changing nothing.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : The .wpress file: a name as `wp restorwell list` prints it, or a path.
	 *
	 * [--password=<password>]
	 * : Password of a password-protected backup. It is never saved. Other users of this machine can see it in the process list while the command runs; use --password-stdin to avoid that.
	 *
	 * [--password-stdin]
	 * : Read the password from standard input instead: typed at a hidden prompt in a terminal, or piped in (the first line is used).
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: text
	 * options:
	 *   - text
	 *   - json
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp restorwell check site-20261101.wpress
	 *     wp restorwell check wp-content/ai1wm-backups/site-20261101.wpress
	 *     wp restorwell check backup.wpress --password-stdin
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Options.
	 */
	public function check( $args, $assoc_args ) {
		$path     = $this->path( $args[0] );
		$password = $this->password( $assoc_args );
		$state    = $this->run_check( $path, $password );
		$report   = Restorwell_Check::report( $state );
		if ( isset( $assoc_args['format'] ) && 'json' === $assoc_args['format'] ) {
			WP_CLI::line( (string) wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
		} else {
			$this->print_report( $report );
		}
		if ( ! $report['can_restore'] ) {
			$this->fail( $report );
		}
		WP_CLI::success( __( 'The backup can be restored on this server.', 'restorwell' ) );
	}

	/**
	 * Restores a .wpress backup into this site.
	 *
	 * Replaces this site's database, media, plugins and themes with the
	 * backup's. Runs the same Check first and stops if any limit blocks it.
	 * Nothing changes if the restore stops before the final switch.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : The .wpress file: a name as `wp restorwell list` prints it, or a path.
	 *
	 * [--password=<password>]
	 * : Password of a password-protected backup. It is never saved. Other users of this machine can see it in the process list while the command runs; use --password-stdin to avoid that.
	 *
	 * [--password-stdin]
	 * : Read the password from standard input instead: typed at a hidden prompt in a terminal, or piped in (the first line is used).
	 *
	 * [--yes]
	 * : Do not ask for confirmation.
	 *
	 * ## EXAMPLES
	 *
	 *     wp restorwell restore site.wpress --yes
	 *     wp restorwell restore site.wpress --password-stdin --yes
	 *     wp restorwell restore /home/me/backups/site.wpress --password='my secret' --yes
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Options.
	 */
	public function restore( $args, $assoc_args ) {
		$path     = $this->path( $args[0] );
		$password = $this->password( $assoc_args );
		$state    = $this->run_check( $path, $password );
		$report   = Restorwell_Check::report( $state );
		$this->print_report( $report );
		if ( ! $report['can_restore'] ) {
			$this->fail( $report );
		}
		WP_CLI::confirm( __( 'Replace this site\'s database, media, plugins and themes with the backup\'s?', 'restorwell' ), $assoc_args );

		$current = Restorwell_Restore::current();
		if ( $current && ! empty( $current['switched'] ) ) {
			while ( 'done' !== $current['stage'] ) {
				$current = Restorwell_Restore::cleanup( $current, 0.0 );
			}
		} elseif ( $current ) {
			$result = Restorwell_Restore::abort( $current );
			if ( 'busy' === $result ) {
				WP_CLI::error( __( 'Another restore is running right now. Wait for it to finish, or cancel it in Tools > Restorwell.', 'restorwell' ) );
			} elseif ( 'switched' === $result ) {
				WP_CLI::error( __( 'An interrupted restore had already switched its database in. Finish it first: Tools > Restorwell, Continue restore.', 'restorwell' ) );
			} elseif ( 'stuck' === $result ) {
				/* translators: %s: folder path. */
				WP_CLI::error( sprintf( __( 'An interrupted restore had moved folders in and Restorwell could not put all of your site\'s own folders back. They are kept, untouched, in %s. Write to support@ochrestack.com before you change anything.', 'restorwell' ), Restorwell_Restore::job_dir( $current['id'] ) . '/old' ) );
			}
			WP_CLI::warning( 'rolled_back' === $result ? __( 'An unfinished restore was found: the folders it had moved in were put back and its temporary data removed.', 'restorwell' ) : __( 'An unfinished restore was found and its temporary data removed.', 'restorwell' ) );
		}

		try {
			$job  = Restorwell_Restore::start( $state, $password );
			$last = '';
			while ( 'done' !== $job['stage'] ) {
				$job = Restorwell_Restore::step( $job, $password, microtime( true ) + $this->step_seconds() );
				if ( ! empty( $job['busy'] ) ) {
					sleep( 1 );
					continue;
				}
				$progress = Restorwell_Restore::progress( $job );
				if ( $progress['label'] !== $last ) {
					WP_CLI::log( $progress['label'] );
					$last = $progress['label'];
				}
			}
		} catch ( Restorwell_Exception $e ) {
			WP_CLI::error( $e->text(), false );
			WP_CLI::halt( $this->exit_code( $e->get_reason() ) );
		}

		if ( ! empty( $job['warnings'] ) ) {
			foreach ( $job['warnings'] as $warning ) {
				WP_CLI::warning( $warning );
			}
		}
		WP_CLI::log(
			sprintf(
				/* translators: 1: number of files, 2: number of tables. */
				__( 'Restored %1$s files and %2$s database tables. Permalinks will be rebuilt on the next page load.', 'restorwell' ),
				number_format_i18n( $job['files'] ),
				number_format_i18n( count( $job['tables'] ) )
			)
		);
		WP_CLI::log( __( 'Log in with a username and password from the backup: the accounts on this site are now the backup\'s.', 'restorwell' ) );
		WP_CLI::log(
			/* translators: %s: path of the backup file. */
			sprintf( __( 'The backup file is still at %s. Delete it when you no longer need it.', 'restorwell' ), $path )
		);
		WP_CLI::success( __( 'Restore finished.', 'restorwell' ) );
	}

	/**
	 * Lists the .wpress files Restorwell can see on this server.
	 *
	 * ## EXAMPLES
	 *
	 *     wp restorwell list
	 *
	 * @subcommand list
	 */
	public function list_() {
		$rows = array();
		foreach ( Restorwell_Files::list_backups() as $b ) {
			$rows[] = array(
				'file'     => $b['name'],
				'folder'   => $b['folder'],
				'size'     => Restorwell_Files::size_label( $b['size'] ),
				'modified' => wp_date( 'Y-m-d H:i', $b['modified'] ),
			);
		}
		WP_CLI\Utils\format_items( 'table', $rows, array( 'file', 'folder', 'size', 'modified' ) );
	}

	/**
	 * The backup password from --password or --password-stdin.
	 *
	 * @param array $assoc_args Options.
	 * @return string
	 */
	private function password( array $assoc_args ) {
		if ( empty( $assoc_args['password-stdin'] ) ) {
			return isset( $assoc_args['password'] ) ? (string) $assoc_args['password'] : '';
		}
		if ( function_exists( 'posix_isatty' ) && posix_isatty( STDIN ) ) {
			return (string) \cli\prompt( __( 'Backup password', 'restorwell' ), false, ': ', true );
		}
		$line = fgets( STDIN );
		return false === $line ? '' : rtrim( $line, "\r\n" );
	}

	/**
	 * Resolves and validates a path argument.
	 *
	 * @param string $arg Argument.
	 * @return string
	 */
	private function path( $arg ) {
		$path = realpath( $arg );
		if ( false === $path || ! is_file( $path ) ) {
			$path = false;
			// A bare name, as `wp restorwell list` prints it: look in the listed folders.
			if ( false === strpbrk( $arg, '/\\' ) ) {
				foreach ( array_keys( Restorwell_Files::sources() ) as $source ) {
					$path = Restorwell_Files::resolve( Restorwell_Files::ref( $source, $arg ) );
					if ( false !== $path ) {
						break;
					}
				}
			} elseif ( ! path_is_absolute( $arg ) ) {
				// A path relative to the WordPress folder, from anywhere with --path.
				$path = realpath( ABSPATH . $arg );
			}
		}
		if ( false === $path || ! is_file( $path ) ) {
			/* translators: %s: path typed. */
			WP_CLI::error( sprintf( __( 'File not found: %s', 'restorwell' ), $arg ) );
		}
		if ( 1 !== preg_match( '/\.wpress$/i', $path ) ) {
			WP_CLI::error( __( 'This is not a .wpress file.', 'restorwell' ) );
		}
		return $path;
	}

	/**
	 * Runs the check, printing progress for large files.
	 *
	 * @param string $path     File.
	 * @param string $password Password.
	 * @return array
	 */
	private function run_check( $path, $password ) {
		$state = Restorwell_Check::start( $path );
		while ( 'done' !== $state['phase'] ) {
			$state = Restorwell_Check::step( $state, $password, microtime( true ) + $this->step_seconds() );
		}
		return $state;
	}

	/**
	 * Seconds per step (WP-CLI has no time limit; steps only pace progress output).
	 *
	 * @return float
	 */
	private function step_seconds() {
		return (float) apply_filters( 'restorwell_cli_step_seconds', 10 );
	}

	/**
	 * Prints the Check report.
	 *
	 * @param array $r Report.
	 */
	private function print_report( array $r ) {
		foreach ( Restorwell_Admin::report_rows( $r ) as $row ) {
			WP_CLI::log( $row[0] . ': ' . $row[1] );
		}
		WP_CLI::log( '' );
		WP_CLI::log( __( 'Limits on this server:', 'restorwell' ) );
		$labels = array(
			'ok'    => __( 'OK', 'restorwell' ),
			'warn'  => __( 'WARNING', 'restorwell' ),
			'block' => __( 'BLOCKS RESTORE', 'restorwell' ),
		);
		foreach ( $r['limits'] as $limit ) {
			WP_CLI::log( '  [' . $labels[ $limit['level'] ] . '] ' . $limit['message'] );
		}
		WP_CLI::log( '' );
	}

	/**
	 * Exits with the code for the first blocking limit.
	 *
	 * @param array $report Report.
	 */
	private function fail( array $report ) {
		$code    = 5;
		$message = __( 'This backup cannot be restored on this server.', 'restorwell' );
		foreach ( $report['limits'] as $limit ) {
			if ( 'block' === $limit['level'] ) {
				$code    = $this->exit_code( $limit['code'], $report );
				$message = $limit['message'];
				break;
			}
		}
		WP_CLI::error( $message, false );
		WP_CLI::halt( $code );
	}

	/**
	 * Maps a limit code or reason to an exit code.
	 *
	 * @param string     $code   Code.
	 * @param array|null $report Report.
	 * @return int
	 */
	private function exit_code( $code, $report = null ) {
		if ( 'structure' === $code && $report && $report['error'] ) {
			$code = $report['error']['reason'];
		}
		switch ( $code ) {
			case 'password':
			case 'password_wrong':
			case 'password_needed':
				return 2;
			case 'checksum':
			case 'truncated':
			case 'damaged':
			case 'not_wpress':
			case 'unsafe':
			case 'structure':
				return 3;
			case 'disk':
			case 'disk_full':
				return 4;
			case 'failed':
			case 'cancelled':
			case 'database':
			case 'not_writable':
				return 1;
		}
		return 5;
	}
}
