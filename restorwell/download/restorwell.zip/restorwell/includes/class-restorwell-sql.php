<?php
/**
 * Rewrites the statements of a backup's database.sql so they can only
 * create and fill Restorwell's temporary tables, with the new table prefix
 * and the new site address inside every value.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Statement rewriter.
 */
final class Restorwell_Sql {

	const PLACEHOLDER = 'SERVMASK_PREFIX_';

	/**
	 * Temporary table prefix.
	 *
	 * @var string
	 */
	private $tmp_prefix;

	/**
	 * Prefix of this site's tables.
	 *
	 * @var string
	 */
	private $target_prefix;

	/**
	 * Replacer.
	 *
	 * @var Restorwell_Replace
	 */
	private $replace;

	/**
	 * Collation name => replacement for collations this server lacks.
	 *
	 * @var array<string,string>
	 */
	private $collations;

	/**
	 * Old values in their SQL-escaped form, to skip statements quickly.
	 *
	 * @var string[]
	 */
	private $probes = array();

	/**
	 * Constructor.
	 *
	 * @param string             $tmp_prefix    Temporary prefix.
	 * @param string             $target_prefix Live prefix.
	 * @param Restorwell_Replace $replace       Replacer.
	 * @param array              $collations    Collation map.
	 */
	public function __construct( $tmp_prefix, $target_prefix, Restorwell_Replace $replace, array $collations = array() ) {
		$this->tmp_prefix    = $tmp_prefix;
		$this->target_prefix = $target_prefix;
		$this->replace       = $replace;
		$this->collations    = $collations;
		foreach ( array_keys( $replace->pairs() ) as $old ) {
			$this->probes[] = self::escape( (string) $old );
		}
	}

	/**
	 * Rewrites one statement.
	 *
	 * @param string $statement Statement as read from database.sql.
	 * @return array{type:string,table?:string,sql?:string} type is create, insert, drop or skip.
	 */
	public function rewrite( $statement ) {
		$sql = self::strip_comments( $statement );
		if ( '' === $sql ) {
			return array( 'type' => 'skip' );
		}
		if ( preg_match( '/^DROP\s+TABLE\s+IF\s+EXISTS\s+`' . self::PLACEHOLDER . '([^`]+)`\s*;?$/i', $sql, $m ) ) {
			return array(
				'type'  => 'drop',
				'table' => $this->tmp_prefix . $m[1],
				'sql'   => 'DROP TABLE IF EXISTS `' . $this->tmp_prefix . $m[1] . '`',
			);
		}
		if ( preg_match( '/^CREATE\s+TABLE\s+`' . self::PLACEHOLDER . '([^`]+)`/i', $sql, $m ) ) {
			$sql = $this->scan( $sql, false );
			if ( $this->collations ) {
				$sql = strtr( $sql, $this->collations );
			}
			return array(
				'type'  => 'create',
				'table' => $this->tmp_prefix . $m[1],
				'sql'   => rtrim( $sql, "; \n\r\t" ),
			);
		}
		if ( preg_match( '/^INSERT\s+INTO\s+`' . self::PLACEHOLDER . '([^`]+)`/i', $sql, $m ) ) {
			$values_need = false !== strpos( $sql, self::PLACEHOLDER, strlen( $m[0] ) );
			if ( ! $values_need ) {
				foreach ( $this->probes as $probe ) {
					if ( false !== strpos( $sql, $probe ) ) {
						$values_need = true;
						break;
					}
				}
			}
			if ( $values_need ) {
				$sql = $this->scan( $sql, true );
			} else {
				$sql = substr_replace( $sql, '`' . $this->tmp_prefix . $m[1] . '`', strpos( $sql, '`' ), strlen( self::PLACEHOLDER . $m[1] ) + 2 );
			}
			return array(
				'type'  => 'insert',
				'table' => $this->tmp_prefix . $m[1],
				'sql'   => rtrim( $sql, "; \n\r\t" ),
			);
		}
		return array( 'type' => 'skip' );
	}

	/**
	 * Removes leading comment lines and blank lines.
	 *
	 * @param string $statement Statement.
	 * @return string
	 */
	private static function strip_comments( $statement ) {
		$statement = ltrim( $statement );
		while ( 0 === strpos( $statement, '--' ) || 0 === strpos( $statement, '#' ) ) {
			$nl = strpos( $statement, "\n" );
			if ( false === $nl ) {
				return '';
			}
			$statement = ltrim( substr( $statement, $nl + 1 ) );
		}
		return trim( $statement );
	}

	/**
	 * Walks a statement, rewriting `identifiers` that use the placeholder
	 * prefix and, when asked, every 'string literal'.
	 *
	 * @param string $s        Statement.
	 * @param bool   $literals Whether to rewrite literals.
	 * @return string
	 */
	private function scan( $s, $literals ) {
		$out = '';
		$i   = 0;
		$n   = strlen( $s );
		while ( $i < $n ) {
			$j    = strcspn( $s, "'`", $i );
			$out .= substr( $s, $i, $j );
			$i   += $j;
			if ( $i >= $n ) {
				break;
			}
			if ( '`' === $s[ $i ] ) {
				$k = strpos( $s, '`', $i + 1 );
				if ( false === $k ) {
					$out .= substr( $s, $i );
					break;
				}
				$ident = substr( $s, $i + 1, $k - $i - 1 );
				if ( 0 === strpos( $ident, self::PLACEHOLDER ) ) {
					$ident = $this->tmp_prefix . substr( $ident, strlen( self::PLACEHOLDER ) );
				}
				$out .= '`' . $ident . '`';
				$i    = $k + 1;
				continue;
			}
			$k = $i + 1;
			while ( true ) {
				$k += strcspn( $s, "\\'", $k );
				if ( $k >= $n ) {
					$out .= substr( $s, $i );
					return $out;
				}
				if ( '\\' === $s[ $k ] ) {
					$k += 2;
					continue;
				}
				break;
			}
			$raw  = substr( $s, $i + 1, $k - $i - 1 );
			$out .= "'" . ( $literals ? $this->literal( $raw ) : $raw ) . "'";
			$i    = $k + 1;
		}
		return $out;
	}

	/**
	 * Rewrites one string literal (still in its escaped form).
	 *
	 * @param string $raw Escaped literal body.
	 * @return string
	 */
	private function literal( $raw ) {
		$value = false === strpos( $raw, '\\' ) ? $raw : self::unescape( $raw );
		$new   = $value;
		if ( false !== strpos( $new, self::PLACEHOLDER ) ) {
			$new = str_replace( self::PLACEHOLDER, $this->target_prefix, $new );
		}
		$new = $this->replace->value( $new );
		return $new === $value ? $raw : self::escape( $new );
	}

	/**
	 * Reverses mysqli_real_escape_string().
	 *
	 * @param string $s Escaped.
	 * @return string
	 */
	public static function unescape( $s ) {
		return strtr(
			$s,
			array(
				'\\0'  => "\0",
				'\\n'  => "\n",
				'\\r'  => "\r",
				'\\t'  => "\t",
				'\\b'  => "\x08",
				'\\Z'  => "\x1a",
				'\\\\' => '\\',
				"\\'"  => "'",
				'\\"'  => '"',
			)
		);
	}

	/**
	 * Escapes like mysqli_real_escape_string().
	 *
	 * @param string $s Plain.
	 * @return string
	 */
	public static function escape( $s ) {
		return strtr(
			$s,
			array(
				'\\'   => '\\\\',
				"\0"   => '\\0',
				"\n"   => '\\n',
				"\r"   => '\\r',
				"\x1a" => '\\Z',
				"'"    => "\\'",
				'"'    => '\\"',
			)
		);
	}
}
