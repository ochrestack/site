<?php
/**
 * CRC-32 helpers that let a checksum be carried across several short requests.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Combines CRC-32 (crc32b) values of consecutive pieces of data, the way
 * zlib's crc32_combine() does, so a long file can be checksummed in steps.
 */
final class Restorwell_Crc {

	/**
	 * Returns the CRC-32 of A followed by B, given crc(A), crc(B) and len(B).
	 *
	 * @param string $crc1 Hex CRC of the first piece, or '' when there is none yet.
	 * @param string $crc2 Hex CRC of the second piece.
	 * @param int    $len2 Length in bytes of the second piece.
	 * @return string Hex CRC, 8 lowercase characters.
	 */
	public static function combine( $crc1, $crc2, $len2 ) {
		if ( '' === $crc1 || null === $crc1 ) {
			return strtolower( $crc2 );
		}
		$a = (int) hexdec( $crc1 );
		$b = (int) hexdec( $crc2 );
		if ( $len2 <= 0 ) {
			return sprintf( '%08x', $a );
		}

		$odd    = array();
		$even   = array();
		$odd[0] = 0xEDB88320;
		$row    = 1;
		for ( $n = 1; $n < 32; $n++ ) {
			$odd[ $n ] = $row;
			$row     <<= 1;
		}
		$even = self::square( $odd );
		$odd  = self::square( $even );

		do {
			$even = self::square( $odd );
			if ( $len2 & 1 ) {
				$a = self::times( $even, $a );
			}
			$len2 >>= 1;
			if ( 0 === $len2 ) {
				break;
			}
			$odd = self::square( $even );
			if ( $len2 & 1 ) {
				$a = self::times( $odd, $a );
			}
			$len2 >>= 1;
		} while ( 0 !== $len2 );

		return sprintf( '%08x', ( $a ^ $b ) & 0xFFFFFFFF );
	}

	/**
	 * Multiplies a GF(2) 32x32 matrix by a vector.
	 *
	 * @param int[] $mat Matrix rows.
	 * @param int   $vec Vector.
	 * @return int
	 */
	private static function times( array $mat, $vec ) {
		$sum = 0;
		$i   = 0;
		while ( $vec ) {
			if ( $vec & 1 ) {
				$sum ^= $mat[ $i ];
			}
			$vec >>= 1;
			++$i;
		}
		return $sum & 0xFFFFFFFF;
	}

	/**
	 * Squares a GF(2) 32x32 matrix.
	 *
	 * @param int[] $mat Matrix rows.
	 * @return int[]
	 */
	private static function square( array $mat ) {
		$out = array();
		for ( $n = 0; $n < 32; $n++ ) {
			$out[ $n ] = self::times( $mat, $mat[ $n ] );
		}
		return $out;
	}
}
