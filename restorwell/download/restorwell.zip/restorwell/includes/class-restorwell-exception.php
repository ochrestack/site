<?php
/**
 * Exception with a machine-readable reason, so the screen and WP-CLI can
 * explain the problem in plain words and pick an exit code.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * A problem Restorwell can describe to the person restoring.
 */
class Restorwell_Exception extends Exception {

	/**
	 * Short reason code, for example "password_wrong" or "damaged".
	 *
	 * @var string
	 */
	private $reason;

	/**
	 * Constructor.
	 *
	 * @param string $reason  Reason code.
	 * @param string $message Plain-words message for the person restoring.
	 */
	public function __construct( $reason, $message ) {
		parent::__construct( $message );
		$this->reason = $reason;
	}

	/**
	 * Returns the message as plain text. Messages are built escaped for HTML;
	 * WP-CLI and the JSON answers (shown with textContent) need plain text.
	 *
	 * @return string
	 */
	public function text() {
		return html_entity_decode( $this->getMessage(), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * Returns the reason code.
	 *
	 * @return string
	 */
	public function get_reason() {
		return $this->reason;
	}
}
