<?php
/**
 * Replaces the old site address and file paths with the new ones, keeping
 * serialized PHP values valid (string lengths are recalculated) and
 * handling JSON-escaped and URL-encoded forms.
 *
 * @package Restorwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Address and path replacement.
 */
final class Restorwell_Replace {

	/**
	 * Old value => new value.
	 *
	 * @var array<string,string>
	 */
	private $pairs = array();

	/**
	 * One pattern matching every old value, longest first, when it is not
	 * followed by a character that continues a host name or a path segment.
	 *
	 * @var string
	 */
	private $pattern = '';

	/**
	 * Constructor.
	 *
	 * @param array<string,string> $pairs Old => new.
	 */
	public function __construct( array $pairs ) {
		$this->pairs = $pairs;
		$keys        = array_map( 'strval', array_keys( $pairs ) );
		usort(
			$keys,
			function ( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);
		$quoted = array();
		foreach ( $keys as $key ) {
			$quoted[] = preg_quote( $key, '/' );
		}
		// "http://example.com/blog" must not change inside "http://example.com/blogroll",
		// "http://example.com.au" or "http://example.community": the old value only
		// counts when the next character cannot continue the name it ends in. A dot
		// continues it only when a letter or digit follows ("example.com." ending a
		// sentence is still the old address).
		$this->pattern = $quoted ? '/(?:' . implode( '|', $quoted ) . ')(?![A-Za-z0-9_~\-\x80-\xff])(?!\.[A-Za-z0-9\x80-\xff])/' : '';
	}

	/**
	 * Returns the pairs.
	 *
	 * @return array<string,string>
	 */
	public function pairs() {
		return $this->pairs;
	}

	/**
	 * Builds the old => new pairs for a backup restored into this site.
	 *
	 * @param array $pkg    Package summary from Restorwell_Check::package_summary().
	 * @param array $target Target facts: site_url, home_url, uploads_url, abspath, content_dir, uploads_dir.
	 * @return array<string,string>
	 */
	public static function build_pairs( array $pkg, array $target ) {
		$urls  = array(
			array( $pkg['uploads_url'], $target['uploads_url'] ),
			array( $pkg['site_url'], $target['site_url'] ),
			array( $pkg['home_url'], $target['home_url'] ),
			array( $pkg['internal_site_url'], $target['site_url'] ),
			array( $pkg['internal_home_url'], $target['home_url'] ),
		);
		$pairs = array();
		$add   = function ( $from, $to ) use ( &$pairs ) {
			if ( '' !== $from && $from !== $to && ! isset( $pairs[ $from ] ) ) {
				$pairs[ $from ] = $to;
			}
		};
		foreach ( $urls as $u ) {
			list( $old, $new ) = $u;
			$old               = untrailingslashit( (string) $old );
			$new               = untrailingslashit( (string) $new );
			$old_host          = wp_parse_url( $old, PHP_URL_HOST );
			$new_host          = wp_parse_url( $new, PHP_URL_HOST );
			if ( ! $old_host || ! $new_host ) {
				continue;
			}
			$new_scheme = wp_parse_url( $new, PHP_URL_SCHEME );
			$new_rel    = substr( $new, strpos( $new, '//' ) );
			$variants   = array( $old );
			$variants[] = false !== stripos( $old, '//www.' ) ? str_ireplace( '//www.', '//', $old ) : str_ireplace( '//', '//www.', $old );
			foreach ( $variants as $variant ) {
				$rel = substr( $variant, strpos( $variant, '//' ) );
				$set = array(
					'http:' . $rel  => $new_scheme . ':' . $new_rel,
					'https:' . $rel => $new_scheme . ':' . $new_rel,
					$rel            => $new_rel,
				);
				foreach ( $set as $o => $n ) {
					$add( $o, $n );
					$add( str_replace( '/', '\\/', $o ), str_replace( '/', '\\/', $n ) );
					$add( rawurlencode( $o ), rawurlencode( $n ) );
					// Form-encoded copies of addresses (urlencode, not rawurlencode) are stored by some plugins.
					$add( urlencode( $o ), urlencode( $n ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode
				}
			}
		}
		$paths = array(
			array( $pkg['uploads_dir'], $target['uploads_dir'] ),
			array( $pkg['content_dir'], $target['content_dir'] ),
			array( $pkg['abspath'], $target['abspath'] ),
		);
		foreach ( $paths as $p ) {
			$old = untrailingslashit( (string) $p[0] );
			$new = untrailingslashit( (string) $p[1] );
			if ( strlen( $old ) < 4 ) {
				continue;
			}
			$add( $old, $new );
			$add( str_replace( '/', '\\/', $old ), str_replace( '/', '\\/', $new ) );
		}
		return $pairs;
	}

	/**
	 * Whether a string contains any old value.
	 *
	 * @param string $value Value.
	 * @return bool
	 */
	public function needs( $value ) {
		foreach ( $this->pairs as $old => $new ) {
			if ( false !== strpos( $value, (string) $old ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Replaces old values in a database value, keeping serialized data valid.
	 *
	 * @param string $value Value.
	 * @param int    $depth Nesting depth (serialized inside serialized).
	 * @return string
	 */
	public function value( $value, $depth = 0 ) {
		if ( '' === $value || ! $this->needs( $value ) ) {
			return $value;
		}
		if ( $depth < 16 && self::looks_serialized( $value ) ) {
			$pos = 0;
			$out = $this->walk( $value, $pos, $depth );
			if ( false !== $out && strlen( $value ) === $pos ) {
				return $out;
			}
		}
		return $this->replace( $value );
	}

	/**
	 * Replaces every old value that stands on its own in a plain string.
	 *
	 * @param string $value Value.
	 * @return string
	 */
	public function replace( $value ) {
		if ( '' === $this->pattern ) {
			return $value;
		}
		$pairs = $this->pairs;
		$out   = preg_replace_callback(
			$this->pattern,
			function ( $m ) use ( $pairs ) {
				return $pairs[ $m[0] ];
			},
			$value
		);
		return null === $out ? strtr( $value, $pairs ) : $out;
	}

	/**
	 * Quick test for serialized PHP data.
	 *
	 * @param string $value Value.
	 * @return bool
	 */
	public static function looks_serialized( $value ) {
		$value = rtrim( $value );
		if ( strlen( $value ) < 4 ) {
			return false;
		}
		$last = substr( $value, -1 );
		if ( ';' !== $last && '}' !== $last ) {
			return false;
		}
		return 1 === preg_match( '/^(?:[aOC]:\d+:|s:\d+:"|[bid]:|N;|E:\d+:)/', $value );
	}

	/**
	 * Walks one serialized value starting at $pos and returns it with old
	 * values replaced inside every string, lengths recalculated.
	 *
	 * @param string $s     Serialized data.
	 * @param int    $pos   Position, advanced past the value.
	 * @param int    $depth Depth.
	 * @return string|false False when the data is not valid serialized PHP.
	 */
	private function walk( $s, &$pos, $depth ) {
		$len = strlen( $s );
		if ( $pos >= $len ) {
			return false;
		}
		$type = $s[ $pos ];
		switch ( $type ) {
			case 'N':
				if ( 'N;' !== substr( $s, $pos, 2 ) ) {
					return false;
				}
				$pos += 2;
				return 'N;';
			case 'b':
			case 'i':
			case 'd':
			case 'r':
			case 'R':
				if ( ':' !== substr( $s, $pos + 1, 1 ) ) {
					return false;
				}
				$end = strpos( $s, ';', $pos );
				if ( false === $end ) {
					return false;
				}
				$out = substr( $s, $pos, $end - $pos + 1 );
				$pos = $end + 1;
				return $out;
			case 's':
				if ( ! preg_match( '/\Gs:(\d+):"/', $s, $m, 0, $pos ) ) {
					return false;
				}
				$n     = (int) $m[1];
				$start = $pos + strlen( $m[0] );
				if ( $start + $n + 2 > $len || '";' !== substr( $s, $start + $n, 2 ) ) {
					return false;
				}
				$inner = (string) substr( $s, $start, $n );
				$pos   = $start + $n + 2;
				$new   = $this->value( $inner, $depth + 1 );
				return 's:' . strlen( $new ) . ':"' . $new . '";';
			case 'a':
				if ( ! preg_match( '/\Ga:(\d+):\{/', $s, $m, 0, $pos ) ) {
					return false;
				}
				$pos += strlen( $m[0] );
				$out  = $m[0];
				for ( $i = 0, $n = 2 * (int) $m[1]; $i < $n; $i++ ) {
					$part = $this->walk( $s, $pos, $depth );
					if ( false === $part ) {
						return false;
					}
					$out .= $part;
				}
				if ( '}' !== substr( $s, $pos, 1 ) ) {
					return false;
				}
				++$pos;
				return $out . '}';
			case 'O':
				if ( ! preg_match( '/\GO:(\d+):"/', $s, $m, 0, $pos ) ) {
					return false;
				}
				$cls_start = $pos + strlen( $m[0] );
				$cls_len   = (int) $m[1];
				if ( ! preg_match( '/\G":(\d+):\{/', $s, $m2, 0, $cls_start + $cls_len ) ) {
					return false;
				}
				$out = substr( $s, $pos, $cls_start + $cls_len - $pos ) . $m2[0];
				$pos = $cls_start + $cls_len + strlen( $m2[0] );
				for ( $i = 0, $n = 2 * (int) $m2[1]; $i < $n; $i++ ) {
					$part = $this->walk( $s, $pos, $depth );
					if ( false === $part ) {
						return false;
					}
					$out .= $part;
				}
				if ( '}' !== substr( $s, $pos, 1 ) ) {
					return false;
				}
				++$pos;
				return $out . '}';
			case 'C':
				if ( ! preg_match( '/\GC:(\d+):"/', $s, $m, 0, $pos ) ) {
					return false;
				}
				$cls_start = $pos + strlen( $m[0] );
				$cls_len   = (int) $m[1];
				if ( ! preg_match( '/\G":(\d+):\{/', $s, $m2, 0, $cls_start + $cls_len ) ) {
					return false;
				}
				$data_start = $cls_start + $cls_len + strlen( $m2[0] );
				$end        = $data_start + (int) $m2[1];
				if ( '}' !== substr( $s, $end, 1 ) ) {
					return false;
				}
				$out = substr( $s, $pos, $end + 1 - $pos );
				$pos = $end + 1;
				return $out;
			case 'E':
				if ( ! preg_match( '/\GE:(\d+):"/', $s, $m, 0, $pos ) ) {
					return false;
				}
				$end = $pos + strlen( $m[0] ) + (int) $m[1];
				if ( '";' !== substr( $s, $end, 2 ) ) {
					return false;
				}
				$out = substr( $s, $pos, $end + 2 - $pos );
				$pos = $end + 2;
				return $out;
		}
		return false;
	}
}
