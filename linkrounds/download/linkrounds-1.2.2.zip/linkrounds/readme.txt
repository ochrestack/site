=== Linkrounds – Broken Link Checker ===
Contributors: ochrestack
Tags: broken links, link checker, dead links, broken images
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Finds broken links and images from your own server, and calls a link Broken only after it fails twice, an hour apart. No account, no link limit.

== Description ==

A broken link checker is no use if it wants a credit card before it starts, or if the links it reports open fine in your browser. Linkrounds checks every link and image from your own server, with no account, no card and no link limit. It calls a link **Broken** only when the same hard failure happens twice, at least an hour apart.

Open **Tools > Linkrounds** and click **Scan now**. Linkrounds reads your published posts, pages, public custom post types, synced patterns, the custom links in classic menus, and block-theme Navigation menus. It checks every link and image in small background batches through WP-Cron, with a live count ("115 of 708 links checked") and Pause and Resume.

= Four answers, in plain words =

* **Broken**: not found (404), gone (410), or the domain does not exist, and the same thing happened again on a second check at least an hour later (1, 6 or 24 hours, you choose).
* **Redirected**: the address forwards to one that works. The final address is shown, and the reason says when it lands on the home page or a search page.
* **Inconclusive**: the other site blocked the check (403, 999), wanted a login (401), asked us to slow down (429), had a server error, or did not answer in time. These are never counted as broken.
* **OK**: the link works.

A link that fails once is Inconclusive and counted under **Waiting for second check**; a line above the results says when that check runs.

Each row shows the page the link is on (with Edit and View), the full address, the link text, the status code, the reason and when it was last checked. Filter by answer or post type, search by address, and use **Re-check now** on any row.

= Fixes you can undo =

* **Unlink** removes the link and keeps the words. **Edit address** changes that one link, and the new address is checked straight away.
* Bulk actions change only the rows you ticked. In our tests, ticking 2 of 20 visible rows on a site with 300 results changed exactly 2 links. The message after Apply says what was done, or that nothing was changed.
* A fix changes only that link in that post and leaves the rest of the content byte for byte as it was (apart from a block's own copy of the address, below).
* Every fix is saved as a normal post revision, so you can restore the old version from the post's Revisions screen, even on sites that keep only one revision.
* In Cover, File and Navigation link blocks, Edit address also updates the block's own copy of the address, so the editor still opens the block normally. A File block links to its file twice (the name and the Download button); Edit address on either one changes both. Unlink is not offered where it would break a block (File and Button blocks).
* Only users who can edit a post can fix its links.

= Tested on a demo blog =

On a demo blog of a small 3D studio that we built for these tests (12 posts, 2 pages and a menu: 63 addresses used in 70 places), the first scan found nothing Broken and 7 places waiting for their second check. An hour later the second checks found 7 Broken addresses (7 places), 5 Redirected (7 places), 2 Inconclusive (4 places: a documentation site that answered "slow down" (429) and a site that refused the check with 403) and 49 OK (52 places). We opened every Broken address by hand: six returned 404, and the seventh is an image we deleted on purpose.

On a 300-post archive we built for testing (708 addresses in 2,702 places), Scan now took under 3 minutes with the screen open. All 71 addresses that failed once returned 404 when we opened them by hand.

= Exclusions and automatic re-checks =

* Exclude domains or address patterns with `*` wildcards (for example `*.example.com` or `example.com/members/*`), whole post types, synced patterns or menu links.
* **Ignore** a single link, and undo that from the Ignored filter.
* Broken and Inconclusive links are re-checked every day. Saving a post re-checks its links, so fixed links leave the list without a new scan.
* If the host kills a background batch, the scan picks itself up again.

= Gentle on your server =

* Links to your own posts, pages and uploads are checked against your own database and files, with no request to your site.
* Each address is requested once per scan. At most six requests run at once, and at most two go to the same site.
* A batch starts no new request after 10 seconds and ends within about 25.
* Addresses in private or local networks (10.x, 192.168.x, 127.0.0.1) are never requested, except your own site's address (on a local or staging install, your site is on such an address).

= Who it is for =

WordPress itself has no broken-link checker. Other free plugins also check links on your own server without an account: Broken Link Checker's local engine, Dragon Broken Links and DevDome Link Monitor. If you clean up your links once or twice a year, the free Linkrounds is all you need: there is no locked feature and no limit.

**Linkrounds Pro** is a separate add-on sold on ochrestack.com: $19 one-time for up to 3 sites (unlimited sites: $79, by email). No renewal, no licence check, and every future Pro update is included. Pro adds scheduled full-site scans, an emailed report of what broke since the last one, and a CSV for a client or an editor.

= What version 1 does not check =

Links inside page-builder layouts stored outside the post content, custom fields, widgets and comments are not checked in version one. Nor are theme options, excerpts, templates and template parts edited in the Site Editor, `srcset` image sets, or video and embed addresses. If a builder keeps its links in the post content they are found, but editing inside a builder layout is not offered, and an Unlink inside a third-party builder block can leave that block needing repair. Linkrounds never highlights or strikes through links on your site and adds no dashboard widget.

== External services ==

To check a link, Linkrounds sends a HEAD request from your server to the linked address (and a GET when HEAD does not succeed), with the User-Agent "Mozilla/5.0 (compatible; Linkrounds/1.0; link check)". This happens during a scan, on Re-check now, in the daily re-check, and when you save a post that contains links (from activation, even before the first scan). Nothing else is sent: no data about your site, your users or your content goes to Ochrestack or to any other service. There is no account, no telemetry and no update or licence check.

== Installation ==

1. Plugins > Add New Plugin, search for "Linkrounds", Install Now, Activate.
2. Open Tools > Linkrounds and click Scan now.
3. Watch the live count. On a site with visitors you can leave; the scan carries on.

WP-Cron runs when someone visits the site. On a quiet site (staging, local), keep the Linkrounds screen open while it scans (the screen keeps it moving), or set up a real cron job for `wp-cron.php`.

== Frequently Asked Questions ==

= Do I need an account, an API key or a credit card? =

No. Linkrounds runs inside your WordPress site. There is nothing to sign up for and no link limit.

= A link works in my browser. Why is it Inconclusive? =

Many sites refuse automated checks (403, 999), ask for a login (401) or slow down busy visitors (429). Linkrounds cannot tell whether those pages work for your readers, so it never calls them broken. Open the link yourself, or Ignore it.

= Why isn't a 404 shown as Broken straight away? =

One failure can be a hiccup on the other site. Linkrounds checks again after at least an hour and calls the link Broken only if it fails again. Until then the row says when the second check is due.

= Can Linkrounds still get a link wrong? =

Yes, in four known cases:

* A site that answers 404 to anything but a browser is reported Broken, although readers see the page. Linkrounds says honestly that it is a link checker. Open the link; if it works, Ignore it.
* A deleted page that forwards to its site's home page or a search page is Redirected, not Broken. The reason says where it lands.
* A server that never answers HEAD requests leaves its links Inconclusive ("no answer within 15 seconds"), never Broken.
* A file missing from your uploads folder is Broken from the disk check, so a redirect for the old file address is not seen.

= Can I undo a fix? =

Yes. Open the post's Revisions screen and restore the version before the change. If revisions are turned off, the message after the fix says so. Menu items have no revisions in WordPress.

= Will it slow down my site? =

Checks run in short background batches, a few at a time, and links to your own site are checked without a request.

= Does it work on multisite? =

There is no network-wide view in version 1. Deleting the plugin removes its tables and settings from every site of the network.

== Screenshots ==

1. Tools > Linkrounds after a scan on a demo blog: each link with the page it is on, the full address, the link text, the answer and the reason in plain words.
2. A scan running in the background, with the live count and Pause.
3. Inconclusive is not Broken: a site that blocks checkers (403), and two 404s waiting for their second check an hour later.
4. Edit address on one row: only that link changes, and the new address is checked at once.
5. The post's Revisions screen after a fix: one line changed, and the old version can be restored.
6. Settings: exclusions with wildcards, what to scan, and the wait before the second check.

== Changelog ==

= 1.2.2 =
* Scans use far less processor time.
* The running-scan line says to keep the page open on a quiet site.
* The "look broken" line keeps up with row actions.
* Redirects to a search page are called out.

Earlier versions are in changelog.txt.

== Upgrade Notice ==

= 1.2.2 =
Lighter on the processor during scans; clearer wording on quiet sites.
