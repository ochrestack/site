<?php
/**
 * Plugin Name:       Linkrounds – Broken Link Checker
 * Description:       Finds broken links and images in your posts, pages and menus from your own server. No account, no link limit. A link is called broken only after it fails twice.
 * Version:           1.2.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       linkrounds
 *
 * @package Linkrounds
 */

defined( 'ABSPATH' ) || exit;

define( 'LINKROUNDS_VERSION', '1.2.2' );
define( 'LINKROUNDS_DB_VERSION', '1' );
define( 'LINKROUNDS_FILE', __FILE__ );
define( 'LINKROUNDS_DIR', __DIR__ );

require_once __DIR__ . '/includes/class-settings.php';
require_once __DIR__ . '/includes/class-installer.php';
require_once __DIR__ . '/includes/class-store.php';
require_once __DIR__ . '/includes/class-parser.php';
require_once __DIR__ . '/includes/class-blocks.php';
require_once __DIR__ . '/includes/class-url-guard.php';
require_once __DIR__ . '/includes/class-http-checker.php';
require_once __DIR__ . '/includes/class-classifier.php';
require_once __DIR__ . '/includes/class-internal-resolver.php';
require_once __DIR__ . '/includes/class-collector.php';
require_once __DIR__ . '/includes/class-scanner.php';
require_once __DIR__ . '/includes/class-fixer.php';
require_once __DIR__ . '/includes/class-results-query.php';
require_once __DIR__ . '/includes/class-admin.php';
require_once __DIR__ . '/includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'Linkrounds\\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Linkrounds\\Installer', 'deactivate' ) );

Linkrounds\Plugin::init();
