<?php
/**
 * Files a check result as Broken, Redirected, Inconclusive or OK.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Turns raw check results into categories and plain-words reasons.
 */
class Classifier {

	/**
	 * Category labels.
	 *
	 * @return string[]
	 */
	public static function categories() {
		return array(
			'broken'       => __( 'Broken', 'linkrounds' ),
			'redirected'   => __( 'Redirected', 'linkrounds' ),
			'inconclusive' => __( 'Inconclusive', 'linkrounds' ),
			'ok'           => __( 'OK', 'linkrounds' ),
		);
	}

	/**
	 * Classifies a raw result.
	 *
	 * The 'hard' outcome (404, 410, a name that does not resolve) is not yet Broken:
	 * Scanner::record() calls a link Broken only when a hard failure repeats after the wait.
	 *
	 * @param array  $result   Result from Http_Checker or Internal_Resolver.
	 * @param string $original The address that was checked.
	 * @return array outcome ('ok' | 'redirected' | 'hard' | 'inconclusive'), reason_key, code, detail, final_url.
	 */
	public static function classify( array $result, $original ) {
		$code       = (int) $result['code'];
		$error      = (string) $result['error'];
		$out        = array(
			'outcome'    => 'inconclusive',
			'reason_key' => 'unexpected',
			'code'       => $code,
			'detail'     => isset( $result['detail'] ) ? (string) $result['detail'] : '',
			'final_url'  => '',
		);
		$redirected = ! empty( $result['hops'] ) && isset( $result['final_url'] ) && $result['final_url'] !== $original;

		if ( ! empty( $result['internal_ok'] ) ) {
			$out['outcome']    = 'ok';
			$out['reason_key'] = $result['reason_key'];
			return $out;
		}

		if ( '' !== $error ) {
			$hard = array( 'dns', 'internal_missing_post', 'internal_unpublished', 'internal_missing_file' );
			if ( in_array( $error, $hard, true ) ) {
				$out['outcome'] = 'hard';
			}
			$out['reason_key'] = $error;
			if ( $redirected ) {
				$out['final_url'] = $result['final_url'];
			}
			return $out;
		}

		if ( $code >= 200 && $code < 300 ) {
			if ( $redirected ) {
				$out['outcome']    = 'redirected';
				$out['reason_key'] = self::lands_on_home( $original, $result['final_url'] ) ? 'redirected_home' : ( self::lands_on_search( $original, $result['final_url'] ) ? 'redirected_search' : 'redirected' );
				$out['final_url']  = $result['final_url'];
			} else {
				$out['outcome']    = 'ok';
				$out['reason_key'] = isset( $result['reason_key'] ) ? $result['reason_key'] : 'ok';
			}
			return $out;
		}

		if ( $redirected ) {
			$out['final_url'] = $result['final_url'];
		}

		if ( 404 === $code || 410 === $code ) {
			$out['outcome']    = 'hard';
			$out['reason_key'] = 404 === $code ? 'not_found' : 'gone';
			return $out;
		}

		$map = array(
			401 => 'login',
			403 => 'forbidden',
			407 => 'login',
			429 => 'rate_limited',
			503 => 'unavailable',
			999 => 'blocked_999',
		);
		if ( isset( $map[ $code ] ) ) {
			$out['reason_key'] = $map[ $code ];
		} elseif ( $code >= 500 && $code < 600 ) {
			$out['reason_key'] = 'server_error';
		}
		return $out;
	}

	/**
	 * Whether an inner page forwards to the home page of the same site (a common "soft 404").
	 *
	 * @param string $original  Address checked.
	 * @param string $final_url Address it ended at.
	 * @return bool
	 */
	private static function lands_on_home( $original, $final_url ) {
		$from = wp_parse_url( $original );
		$to   = wp_parse_url( $final_url );
		if ( ! is_array( $from ) || ! is_array( $to ) || empty( $from['host'] ) || empty( $to['host'] ) ) {
			return false;
		}
		$same_site = preg_replace( '/^www\./', '', strtolower( $from['host'] ) ) === preg_replace( '/^www\./', '', strtolower( $to['host'] ) );
		$from_path = isset( $from['path'] ) ? trim( $from['path'], '/' ) : '';
		$to_path   = isset( $to['path'] ) ? trim( $to['path'], '/' ) : '';
		return $same_site && '' !== $from_path && '' === $to_path && empty( $to['query'] );
	}

	/**
	 * Whether an address forwards to a search or "not found" page of the same site, another common
	 * "soft 404" (for example /plugins/search/old-name/ or /search/?q=…&reason=package_not_found).
	 *
	 * @param string $original  Address checked.
	 * @param string $final_url Address it ended at.
	 * @return bool
	 */
	private static function lands_on_search( $original, $final_url ) {
		$from = wp_parse_url( $original );
		$to   = wp_parse_url( $final_url );
		if ( ! is_array( $from ) || ! is_array( $to ) || empty( $from['host'] ) || empty( $to['host'] ) ) {
			return false;
		}
		if ( preg_replace( '/^www\./', '', strtolower( $from['host'] ) ) !== preg_replace( '/^www\./', '', strtolower( $to['host'] ) ) ) {
			return false;
		}
		return ! self::looks_like_search( $from ) && self::looks_like_search( $to );
	}

	/**
	 * Whether a parsed address looks like a search or "not found" page.
	 *
	 * @param array $parts wp_parse_url() result.
	 * @return bool
	 */
	private static function looks_like_search( array $parts ) {
		$path = isset( $parts['path'] ) ? strtolower( $parts['path'] ) : '';
		if ( preg_match( '#(^|/)(search|404|not-found|notfound)(/|\.|$)#', $path ) ) {
			return true;
		}
		if ( empty( $parts['query'] ) ) {
			return false;
		}
		$query = array();
		wp_parse_str( $parts['query'], $query );
		foreach ( $query as $key => $value ) {
			if ( in_array( strtolower( (string) $key ), array( 's', 'q', 'query', 'search' ), true ) ) {
				return true;
			}
			if ( is_string( $value ) && preg_match( '/not[_-]?found|(^|[^0-9])404([^0-9]|$)/i', $value ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * A plain-words reason.
	 *
	 * @param string $key    Reason key.
	 * @param int    $code   HTTP status.
	 * @param string $detail Extra detail.
	 * @return string
	 */
	public static function reason_text( $key, $code, $detail = '' ) {
		$code = (int) $code;
		switch ( $key ) {
			case 'ok':
				/* translators: %d: HTTP status code. */
				return sprintf( __( 'The page answered normally (%d).', 'linkrounds' ), $code ? $code : 200 );
			case 'redirected':
				return __( 'The address forwards to another address, which works.', 'linkrounds' );
			case 'redirected_home':
				return __( 'The address forwards to the site’s home page. Sites often do this when a page was removed, so check that the home page is where readers should go.', 'linkrounds' );
			case 'redirected_search':
				return __( 'The address forwards to what looks like a search or “not found” page on the same site. Sites often do this when a page was removed, so open it and check that it is where readers should go.', 'linkrounds' );
			case 'internal_post':
				return __( 'Matches published content on this site (checked without a web request).', 'linkrounds' );
			case 'internal_file':
				return __( 'The file exists in this site’s uploads folder (checked without a web request).', 'linkrounds' );
			case 'internal_home':
				return __( 'This site’s home page (checked without a web request).', 'linkrounds' );
			case 'internal_missing_post':
				return __( 'Points to a post ID that does not exist on this site.', 'linkrounds' );
			case 'internal_unpublished':
				/* translators: %s: post status, for example "draft" or "trash". */
				return sprintf( __( 'Points to content on this site that is not published (status: %s), so visitors get a “not found” page.', 'linkrounds' ), $detail );
			case 'internal_missing_file':
				return __( 'The file is not in this site’s uploads folder.', 'linkrounds' );
			case 'internal_scheduled':
				return __( 'Points to scheduled content on this site that is not published yet.', 'linkrounds' );
			case 'not_found':
				return __( 'Page not found (404).', 'linkrounds' );
			case 'gone':
				return __( 'Page removed on purpose (410 Gone).', 'linkrounds' );
			case 'dns':
				/* translators: %s: host name. */
				return sprintf( __( 'The domain name %s does not exist or has no address (DNS lookup failed).', 'linkrounds' ), $detail );
			case 'private':
				/* translators: %s: IP address. */
				return sprintf( __( 'Not checked: the address points into a private or local network (%s). Linkrounds refuses to request such addresses for safety.', 'linkrounds' ), $detail );
			case 'idn':
				return __( 'Not checked: this server cannot convert the international domain name (the PHP intl extension is missing).', 'linkrounds' );
			case 'invalid':
				return __( 'Not checked: this is not a valid web address.', 'linkrounds' );
			case 'login':
				/* translators: %d: HTTP status code. */
				return sprintf( __( 'Login required (%d). The page may work for visitors who are signed in.', 'linkrounds' ), $code );
			case 'forbidden':
				return __( 'Access denied (403). Many sites refuse automated checks while working fine in a browser.', 'linkrounds' );
			case 'rate_limited':
				return __( 'Too many requests (429). The site asked us to slow down; it will be checked again later.', 'linkrounds' );
			case 'server_error':
				/* translators: %d: HTTP status code. */
				return sprintf( __( 'The other site had a server error (%d). This is often temporary.', 'linkrounds' ), $code );
			case 'unavailable':
				return __( 'Service unavailable (503). The other site is down or busy for now.', 'linkrounds' );
			case 'blocked_999':
				return __( 'Non-standard answer 999, which some sites use to block automated checks.', 'linkrounds' );
			case 'timeout':
				/* translators: %s: number of seconds. */
				return sprintf( __( 'No answer within %s seconds (timed out).', 'linkrounds' ), number_format_i18n( Http_Checker::url_time_limit() ) );
			case 'connect':
				return __( 'Could not connect to the server (it refused or dropped the connection).', 'linkrounds' );
			case 'ssl':
				return __( 'The secure connection failed (certificate or HTTPS problem).', 'linkrounds' );
			case 'too_many_redirects':
				/* translators: %d: maximum number of redirects. */
				return sprintf( __( 'Too many redirects (more than %d) or a redirect loop.', 'linkrounds' ), Http_Checker::MAX_REDIRECTS );
			case 'no_location':
				/* translators: %d: HTTP status code. */
				return sprintf( __( 'Answered with a redirect (%d) but no address to go to.', 'linkrounds' ), $code );
			case 'other':
				return __( 'The request failed for an unexpected reason.', 'linkrounds' );
			default:
				if ( $code ) {
					/* translators: %d: HTTP status code. */
					return sprintf( __( 'Unexpected answer (%d).', 'linkrounds' ), $code );
				}
				return __( 'Not checked yet.', 'linkrounds' );
		}
	}
}
