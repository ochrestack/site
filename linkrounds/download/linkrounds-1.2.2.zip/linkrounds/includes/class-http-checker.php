<?php
/**
 * Requests linked addresses and reports what came back.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

use WpOrg\Requests\Hooks;
use WpOrg\Requests\Requests;

defined( 'ABSPATH' ) || exit;

/**
 * Checks external addresses with the HTTP library bundled with WordPress.
 *
 * Redirects are followed by hand so every hop passes the private-network guard, and the
 * connection is pinned to the address that passed the guard. A HEAD request is tried
 * first; any answer other than 2xx or 3xx is asked again with GET before it counts.
 */
class Http_Checker {

	const MAX_REDIRECTS = 5;

	/**
	 * Seconds each request may take.
	 *
	 * @return float
	 */
	public static function request_timeout() {
		/**
		 * Filters the time, in seconds, a single request may take.
		 *
		 * @param float $seconds Default 10.
		 */
		return max( 0.5, (float) apply_filters( 'linkrounds_request_timeout', 10 ) );
	}

	/**
	 * Seconds one address may take in total, across redirects and the GET retry.
	 *
	 * @return float
	 */
	public static function url_time_limit() {
		/**
		 * Filters the total time, in seconds, one address may take across all its requests.
		 *
		 * @param float $seconds Default 15.
		 */
		return max( 1, (float) apply_filters( 'linkrounds_url_time_limit', 15 ) );
	}

	/**
	 * How many requests run at once, and how many of them may go to the same host.
	 *
	 * @return int[] concurrency, per_host.
	 */
	public static function limits() {
		/**
		 * Filters how many requests run at the same time. Default 6.
		 *
		 * @param int $concurrency Requests at once.
		 */
		$concurrency = max( 1, (int) apply_filters( 'linkrounds_concurrency', 6 ) );
		/**
		 * Filters how many requests may go to the same host at the same time. Default 2.
		 *
		 * @param int $per_host Requests per host at once.
		 */
		$per_host = max( 1, (int) apply_filters( 'linkrounds_requests_per_host', 2 ) );
		return array( $concurrency, $per_host );
	}

	/**
	 * Checks several addresses, a few at a time.
	 *
	 * @param string[] $urls Absolute addresses (unique).
	 * @return array[] Keyed by address: code, error, detail, final_url, hops.
	 */
	public function check_many( array $urls ) {
		list( $concurrency, $per_host ) = self::limits();

		$timeout = self::request_timeout();
		$limit   = self::url_time_limit();
		$jobs    = array();
		$results = array();
		foreach ( array_values( array_unique( $urls ) ) as $i => $url ) {
			$jobs[ $i ] = array(
				'url'      => $url,
				'current'  => $url,
				'method'   => Requests::HEAD,
				'hops'     => 0,
				'deadline' => 0,
				'visited'  => array(),
			);
		}

		while ( ! empty( $jobs ) ) {
			$requests = array();
			$guards   = array();
			$hosts    = array();
			foreach ( $jobs as $id => $job ) {
				if ( count( $requests ) >= $concurrency ) {
					break;
				}
				$guard = Url_Guard::inspect( $job['current'] );
				if ( ! $guard['ok'] ) {
					$results[ $job['url'] ] = $this->result( $job, 0, $guard['reason'], $guard['detail'] );
					unset( $jobs[ $id ] );
					continue;
				}
				$host = $guard['host'];
				if ( isset( $hosts[ $host ] ) && $hosts[ $host ] >= $per_host ) {
					continue;
				}
				if ( 0 === $job['deadline'] ) {
					$job['deadline'] = microtime( true ) + $limit;
					$jobs[ $id ]     = $job;
				}
				$remaining = $job['deadline'] - microtime( true );
				if ( $remaining < 0.2 ) {
					$results[ $job['url'] ] = $this->result( $job, 0, 'timeout', '' );
					unset( $jobs[ $id ] );
					continue;
				}
				$hosts[ $host ]  = isset( $hosts[ $host ] ) ? $hosts[ $host ] + 1 : 1;
				$guards[ $id ]   = $guard;
				$requests[ $id ] = $this->build_request( $job, $guard, min( $timeout, $remaining ) );
			}

			if ( empty( $requests ) ) {
				continue;
			}

			foreach ( $requests as $id => $request ) {
				/**
				 * Fires before an address is requested.
				 *
				 * @param string $url    Address.
				 * @param string $method HTTP method.
				 */
				do_action( 'linkrounds_before_request', $request['url'], $request['type'] );
			}

			try {
				$responses = Requests::request_multiple( $requests, array( 'useragent' => self::user_agent() ) );
			} catch ( \Exception $e ) {
				$responses = array_fill_keys( array_keys( $requests ), $e ); // Filed as failed requests below; the scan carries on.
			}

			foreach ( $requests as $id => $request ) {
				$job      = $jobs[ $id ];
				$response = isset( $responses[ $id ] ) ? $responses[ $id ] : null;

				if ( ! $response instanceof \WpOrg\Requests\Response ) {
					list( $error, $detail ) = self::describe_error( $response );
					if ( Requests::HEAD === $job['method'] && 'timeout' !== $error && 'ssl' !== $error ) {
						$jobs[ $id ]['method'] = Requests::GET; // Some servers drop HEAD requests.
						continue;
					}
					$results[ $job['url'] ] = $this->result( $job, 0, $error, $detail );
					unset( $jobs[ $id ] );
					continue;
				}

				$code = (int) $response->status_code;
				if ( $code >= 300 && $code < 400 && 304 !== $code ) {
					$location = isset( $response->headers['location'] ) ? trim( (string) $response->headers['location'] ) : '';
					if ( '' === $location ) {
						$results[ $job['url'] ] = $this->result( $job, $code, 'no_location', '' );
						unset( $jobs[ $id ] );
						continue;
					}
					$next = Url_Guard::check_url( \WP_Http::make_absolute_url( $location, $job['current'] ) );
					if ( $job['hops'] >= self::MAX_REDIRECTS || in_array( $next, $job['visited'], true ) || $next === $job['current'] ) {
						$results[ $job['url'] ] = $this->result( $job, $code, 'too_many_redirects', '' );
						unset( $jobs[ $id ] );
						continue;
					}
					$jobs[ $id ]['visited'][] = $job['current'];
					$jobs[ $id ]['current']   = $next;
					$jobs[ $id ]['method']    = Requests::HEAD;
					++$jobs[ $id ]['hops'];
					continue;
				}

				if ( Requests::HEAD === $job['method'] && ( $code < 200 || $code >= 300 ) ) {
					$jobs[ $id ]['method'] = Requests::GET;
					continue;
				}

				$results[ $job['url'] ] = $this->result( $job, $code, '', '' );
				unset( $jobs[ $id ] );
			}
		}

		return $results;
	}

	/**
	 * Checks one address.
	 *
	 * @param string $url Absolute address.
	 * @return array
	 */
	public function check( $url ) {
		$results = $this->check_many( array( $url ) );
		return $results[ $url ];
	}

	/**
	 * Builds a result.
	 *
	 * @param array  $job    Job.
	 * @param int    $code   HTTP status or 0.
	 * @param string $error  Error key or ''.
	 * @param string $detail Detail.
	 * @return array
	 */
	private function result( $job, $code, $error, $detail ) {
		return array(
			'code'      => (int) $code,
			'error'     => $error,
			'detail'    => (string) $detail,
			'final_url' => $job['current'],
			'hops'      => (int) $job['hops'],
		);
	}

	/**
	 * Builds one request for Requests::request_multiple().
	 *
	 * @param array $job     Job.
	 * @param array $guard   Result of Url_Guard::inspect().
	 * @param float $timeout Seconds.
	 * @return array
	 */
	private function build_request( $job, $guard, $timeout ) {
		$options = array(
			'timeout'          => $timeout,
			'connect_timeout'  => min( 5.0, $timeout ),
			'follow_redirects' => false,
			'redirects'        => 0,
			'verify'           => ABSPATH . WPINC . '/certificates/ca-bundle.crt',
			'useragent'        => self::user_agent(),
			'hooks'            => new Hooks(),
		);
		if ( Requests::GET === $job['method'] ) {
			$options['max_bytes'] = 65536;
		}
		$options['hooks']->register( 'curl.before_request', array( __CLASS__, 'yield_while_waiting' ) );

		$proxy = new \WP_HTTP_Proxy();
		if ( $proxy->is_enabled() && $proxy->send_through_proxy( $job['current'] ) ) {
			$options['proxy'] = new \WpOrg\Requests\Proxy\Http(
				$proxy->use_authentication()
					? array( $proxy->host() . ':' . $proxy->port(), $proxy->username(), $proxy->password() )
					: $proxy->host() . ':' . $proxy->port()
			);
		} else {
			// Pin the connection to the address that passed the guard, so a second DNS answer cannot differ.
			$ip      = $guard['ips'][0];
			$resolve = $guard['host'] . ':' . $guard['port'] . ':' . ( false !== strpos( $ip, ':' ) ? '[' . $ip . ']' : $ip );
			$options['hooks']->register(
				'curl.before_request',
				static function ( &$handle ) use ( $resolve ) {
					if ( defined( 'CURLOPT_RESOLVE' ) ) {
						curl_setopt( $handle, CURLOPT_RESOLVE, array( $resolve ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt -- Requests exposes the cURL handle only; pinning DNS has no WordPress API.
					}
				}
			);
		}

		return array(
			'url'     => $job['current'],
			'type'    => $job['method'],
			'headers' => array(
				'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'en;q=0.9,*;q=0.5',
			),
			'data'    => array(),
			'options' => $options,
		);
	}

	/**
	 * Lets the processor rest while requests wait for an answer.
	 *
	 * Requests::request_multiple() polls cURL in a tight loop with no wait, so a batch kept one
	 * processor core fully busy for as long as its slowest request took, and on hosts where PHP's
	 * time limit counts processor time a long batch could hit it. cURL calls this progress
	 * function on every pass of that loop; a one-millisecond pause there brings the processor time
	 * of a batch from its full length to a fraction of a second, without delaying any answer.
	 *
	 * @param resource|\CurlHandle $handle cURL handle (by reference).
	 */
	public static function yield_while_waiting( &$handle ) {
		// PHP 8.2 and later have CURLOPT_XFERINFOFUNCTION; earlier versions only the older
		// CURLOPT_PROGRESSFUNCTION, which cURL calls just as often.
		$option = defined( 'CURLOPT_XFERINFOFUNCTION' ) ? CURLOPT_XFERINFOFUNCTION : ( defined( 'CURLOPT_PROGRESSFUNCTION' ) ? CURLOPT_PROGRESSFUNCTION : 0 );
		if ( ! $option ) {
			return;
		}
		// phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt -- Requests exposes the cURL handle only; there is no WordPress API for a progress callback.
		curl_setopt( $handle, CURLOPT_NOPROGRESS, false );
		curl_setopt(
			$handle,
			$option,
			static function () {
				usleep( 1000 );
				return 0;
			}
		);
		// phpcs:enable
	}

	/**
	 * The User-Agent sent with each check.
	 *
	 * @return string
	 */
	public static function user_agent() {
		/**
		 * Filters the User-Agent header sent with link checks.
		 *
		 * @param string $agent User-Agent.
		 */
		return (string) apply_filters( 'linkrounds_user_agent', 'Mozilla/5.0 (compatible; Linkrounds/' . LINKROUNDS_VERSION . '; link check)' );
	}

	/**
	 * Turns a transport failure into an error key and a detail.
	 *
	 * @param mixed $failure Exception or anything else.
	 * @return string[]
	 */
	public static function describe_error( $failure ) {
		$message = $failure instanceof \Exception ? $failure->getMessage() : '';
		$code    = 0;
		if ( preg_match( '/cURL error (\d+)/i', $message, $m ) ) {
			$code = (int) $m[1];
		}
		if ( 28 === $code || false !== stripos( $message, 'timed out' ) ) {
			return array( 'timeout', $message );
		}
		if ( 6 === $code ) {
			return array( 'dns', $message );
		}
		if ( in_array( $code, array( 35, 51, 53, 54, 58, 59, 60, 77, 80, 82, 83, 90, 91 ), true ) || false !== stripos( $message, 'ssl' ) ) {
			return array( 'ssl', $message );
		}
		if ( in_array( $code, array( 7, 52, 55, 56 ), true ) || false !== stripos( $message, 'connect' ) ) {
			return array( 'connect', $message );
		}
		return array( 'other', $message );
	}
}
