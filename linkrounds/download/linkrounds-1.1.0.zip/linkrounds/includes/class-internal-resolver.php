<?php
/**
 * Resolves links to this site against its own content, without a web request.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Matches links to the site's own posts, pages, home page and uploaded files.
 */
class Internal_Resolver {

	/**
	 * Resolves an address on this site.
	 *
	 * @param string $url Absolute address.
	 * @return array|null A result like Http_Checker's, or null when the address is not one this
	 *                    resolver can decide (it is then checked with a normal request).
	 */
	public static function resolve( $url ) {
		$host = Url_Guard::host( $url );
		if ( '' === $host || ! Url_Guard::is_own_host( $host ) ) {
			return null;
		}

		$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
		$path  = '' === $path ? '/' : $path;
		$query = (string) wp_parse_url( $url, PHP_URL_QUERY );

		$uploads   = wp_get_upload_dir();
		$base_path = trailingslashit( (string) wp_parse_url( $uploads['baseurl'], PHP_URL_PATH ) );
		if ( '/' !== $base_path && 0 === strpos( $path, $base_path ) && Url_Guard::is_own_host( Url_Guard::host( $uploads['baseurl'] ) ) ) {
			$relative = rawurldecode( substr( $path, strlen( $base_path ) ) );
			if ( '' === $relative || false !== strpos( $relative, '..' ) || false !== strpos( $relative, "\0" ) ) {
				return null;
			}
			$file = trailingslashit( $uploads['basedir'] ) . $relative;
			return is_file( $file ) ? self::ok( $url, 'internal_file' ) : self::fail( $url, 'internal_missing_file', '' );
		}

		$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '' === $query && untrailingslashit( $path ) === untrailingslashit( '' === $home_path ? '/' : $home_path ) ) {
			return self::ok( $url, 'internal_home' );
		}

		$post_id = url_to_postid( $url );
		if ( ! $post_id ) {
			return null;
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return self::fail( $url, 'internal_missing_post', '' );
		}
		if ( 'publish' === $post->post_status || ( 'attachment' === $post->post_type && 'inherit' === $post->post_status ) ) {
			return self::ok( $url, 'internal_post' );
		}
		if ( 'future' === $post->post_status ) {
			return array(
				'code'      => 0,
				'error'     => 'internal_scheduled',
				'detail'    => '',
				'final_url' => $url,
				'hops'      => 0,
			);
		}
		return self::fail( $url, 'internal_unpublished', $post->post_status );
	}

	/**
	 * A positive result.
	 *
	 * @param string $url    Address.
	 * @param string $reason Reason key.
	 * @return array
	 */
	private static function ok( $url, $reason ) {
		return array(
			'code'        => 0,
			'error'       => '',
			'detail'      => '',
			'final_url'   => $url,
			'hops'        => 0,
			'reason_key'  => $reason,
			'internal_ok' => true,
		);
	}

	/**
	 * A hard failure.
	 *
	 * @param string $url    Address.
	 * @param string $reason Reason key.
	 * @param string $detail Detail.
	 * @return array
	 */
	private static function fail( $url, $reason, $detail ) {
		return array(
			'code'      => 0,
			'error'     => $reason,
			'detail'    => $detail,
			'final_url' => $url,
			'hops'      => 0,
		);
	}
}
