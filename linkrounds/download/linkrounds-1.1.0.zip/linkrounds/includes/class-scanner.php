<?php
/**
 * Runs scans in background batches through WP-Cron and files the results.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Scan state, batches, re-checks and the two-check rule for Broken.
 */
class Scanner {

	const STATE_OPTION = 'linkrounds_scan';
	const LOCK_OPTION  = 'linkrounds_batch_lock';

	/**
	 * Seconds after which a batch starts no new work. A batch can still finish the requests it
	 * already started, which take at most Http_Checker::url_time_limit() more seconds.
	 *
	 * @return float
	 */
	public static function batch_time_limit() {
		/**
		 * Filters the seconds after which a batch starts no new requests. Default 10.
		 *
		 * @param float $seconds Seconds.
		 */
		return max( 0.1, (float) apply_filters( 'linkrounds_batch_time_limit', 10 ) );
	}

	/**
	 * Longest a batch can run, in seconds: the time limit plus one address's time limit,
	 * plus a margin for database work.
	 *
	 * @return float
	 */
	public static function max_batch_duration() {
		return self::batch_time_limit() + Http_Checker::url_time_limit();
	}

	/**
	 * Scan state.
	 *
	 * @return array
	 */
	public static function state() {
		$defaults = array(
			'id'          => 0,
			'state'       => 'idle',
			'phase'       => '',
			'cursor'      => 0,
			'posts_total' => 0,
			'posts_done'  => 0,
			'started'     => 0,
			'finished'    => 0,
			'trigger'     => '',
		);
		$state    = get_option( self::STATE_OPTION, array() );
		return array_merge( $defaults, is_array( $state ) ? $state : array() );
	}

	/**
	 * Saves the scan state.
	 *
	 * @param array $state State.
	 */
	private static function save_state( $state ) {
		update_option( self::STATE_OPTION, $state, false );
	}

	/**
	 * Whether a full scan is running (not paused).
	 *
	 * @return bool
	 */
	public static function is_running() {
		$state = self::state();
		return 'running' === $state['state'];
	}

	/**
	 * Starts a full scan.
	 *
	 * @param string $trigger 'manual' or 'scheduled'.
	 * @return bool False when a scan is already running or paused.
	 */
	public static function start( $trigger = 'manual' ) {
		$state = self::state();
		if ( in_array( $state['state'], array( 'running', 'paused' ), true ) ) {
			return false;
		}
		$state = array(
			'id'          => (int) $state['id'] + 1,
			'state'       => 'running',
			'phase'       => 'collecting',
			'cursor'      => 0,
			'posts_total' => Collector::count_posts(),
			'posts_done'  => 0,
			'started'     => time(),
			'finished'    => 0,
			'trigger'     => sanitize_key( $trigger ),
		);
		self::save_state( $state );
		/**
		 * Fires when a full scan starts.
		 *
		 * @param array $state Scan state.
		 */
		do_action( 'linkrounds_scan_started', $state );
		self::schedule_batch();
		return true;
	}

	/**
	 * Pauses the running scan and all background checking.
	 *
	 * @return bool
	 */
	public static function pause() {
		$state = self::state();
		if ( 'running' !== $state['state'] ) {
			return false;
		}
		$state['state'] = 'paused';
		self::save_state( $state );
		wp_clear_scheduled_hook( 'linkrounds_batch' );
		return true;
	}

	/**
	 * Resumes a paused scan.
	 *
	 * @return bool
	 */
	public static function resume() {
		$state = self::state();
		if ( 'paused' !== $state['state'] ) {
			return false;
		}
		$state['state'] = 'running';
		self::save_state( $state );
		self::schedule_batch();
		return true;
	}

	/**
	 * Schedules the next batch to run as soon as WP-Cron runs.
	 */
	public static function schedule_batch() {
		if ( ! wp_next_scheduled( 'linkrounds_batch' ) ) {
			wp_schedule_single_event( time(), 'linkrounds_batch' );
		}
	}

	/**
	 * Progress numbers for the screen.
	 *
	 * @return array
	 */
	public static function progress() {
		$state  = self::state();
		$total  = Store::count_links();
		$queued = Store::count_queued();
		return array(
			'state'         => $state['state'],
			'phase'         => $state['phase'],
			'posts_total'   => (int) $state['posts_total'],
			'posts_done'    => (int) $state['posts_done'],
			'links_total'   => $total,
			'links_checked' => max( 0, $total - $queued ),
			'queued'        => $queued,
			'instances'     => Store::count_instances(),
			'started'       => (int) $state['started'],
			'finished'      => (int) $state['finished'],
		);
	}

	/**
	 * One background batch. Hooked to the linkrounds_batch event.
	 *
	 * @return array What the batch did: posts, checked, seconds.
	 */
	public static function run_batch() {
		$report = array(
			'posts'   => 0,
			'checked' => 0,
			'seconds' => 0.0,
		);
		$state  = self::state();
		if ( 'paused' === $state['state'] || ! self::lock() ) {
			return $report;
		}

		// If this batch is killed before it schedules the next one (a host time limit, memory, a
		// restart), the watchdog picks the work up again once the lock has expired.
		if ( ! wp_next_scheduled( 'linkrounds_watchdog' ) ) {
			wp_schedule_single_event( time() + (int) ceil( self::max_batch_duration() ) + 90, 'linkrounds_watchdog' );
		}

		$started = microtime( true );
		$budget  = self::batch_time_limit();

		if ( 'running' === $state['state'] && 'collecting' === $state['phase'] ) {
			while ( microtime( true ) - $started < $budget ) {
				$ids = Collector::next_post_ids( (int) $state['cursor'], 25 );
				if ( empty( $ids ) ) {
					Store::forget_unseen( (int) $state['id'] );
					$state['phase'] = 'checking';
					break;
				}
				foreach ( $ids as $id ) {
					Collector::collect_post( $id, (int) $state['id'], true );
					$state['cursor'] = $id;
					++$state['posts_done'];
					++$report['posts'];
				}
				self::save_state( $state );
			}
			self::save_state( $state );
		}

		while ( microtime( true ) - $started < $budget ) {
			$rows = Store::next_queued( 60 );
			if ( empty( $rows ) ) {
				break;
			}
			$report['checked'] += self::check_rows( $rows, $started + $budget );
			if ( 'paused' === self::fresh_state_value( 'state' ) ) {
				break;
			}
		}

		$state = self::state();
		if ( 'running' === $state['state'] && 'checking' === $state['phase'] && 0 === Store::count_queued() ) {
			self::finish( $state );
		}

		$report['seconds'] = microtime( true ) - $started;
		update_option( 'linkrounds_last_batch', time(), false );
		self::unlock();

		$state = self::state();
		if ( 'paused' !== $state['state'] && ( 'running' === $state['state'] || Store::count_queued() > 0 ) ) {
			self::schedule_batch();
		}
		self::schedule_confirmations();
		return $report;
	}

	/**
	 * Re-reads one state value from the database, so a Pause from another request is seen.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	private static function fresh_state_value( $key ) {
		wp_cache_delete( self::STATE_OPTION, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		$state = self::state();
		return $state[ $key ];
	}

	/**
	 * Marks the scan finished.
	 *
	 * @param array $state State.
	 */
	private static function finish( $state ) {
		$state['state']    = 'done';
		$state['phase']    = '';
		$state['finished'] = time();
		self::save_state( $state );
		/**
		 * Fires when a full scan has checked every link.
		 *
		 * @param array $state Scan state, including 'trigger' ('manual' or 'scheduled').
		 */
		do_action( 'linkrounds_scan_finished', $state );
	}

	/**
	 * Checks queued link rows until the deadline.
	 *
	 * Links to this site are resolved locally. Other addresses go out in small groups in
	 * which no host appears more than the per-host limit.
	 *
	 * @param object[] $rows     Rows with id, url, host.
	 * @param float    $deadline Start no new group after this microtime.
	 * @return int Links checked.
	 */
	private static function check_rows( $rows, $deadline ) {
		$settings = Settings::all();
		$external = array();
		$checked  = 0;
		foreach ( $rows as $row ) {
			if ( microtime( true ) >= $deadline ) {
				return $checked;
			}
			if ( Settings::is_excluded( $row->url, $settings['excluded_patterns'] ) ) {
				Store::delete_links( array( (int) $row->id ) );
				continue;
			}
			$local = Internal_Resolver::resolve( $row->url );
			if ( null !== $local ) {
				self::record( (int) $row->id, $row->url, $local, true );
				++$checked;
				continue;
			}
			$external[] = $row;
		}

		list( $concurrency, $per_host ) = Http_Checker::limits();
		$checker                        = new Http_Checker();
		while ( ! empty( $external ) && microtime( true ) < $deadline ) {
			$group = array();
			$hosts = array();
			foreach ( $external as $key => $row ) {
				if ( count( $group ) >= $concurrency ) {
					break;
				}
				$host = (string) $row->host;
				if ( isset( $hosts[ $host ] ) && $hosts[ $host ] >= $per_host ) {
					continue;
				}
				$hosts[ $host ] = isset( $hosts[ $host ] ) ? $hosts[ $host ] + 1 : 1;
				$group[]        = $row;
				unset( $external[ $key ] );
			}
			$urls = array();
			foreach ( $group as $row ) {
				$urls[] = $row->url;
			}
			$results = $checker->check_many( $urls );
			foreach ( $group as $row ) {
				self::record( (int) $row->id, $row->url, $results[ $row->url ], false );
				++$checked;
			}
		}
		return $checked;
	}

	/**
	 * Checks one link now, outside the batches.
	 *
	 * @param int $link_id Link ID.
	 * @return object|null The updated link row.
	 */
	public static function recheck_link( $link_id ) {
		$link = Store::get_link( $link_id );
		if ( ! $link ) {
			return null;
		}
		$local = Internal_Resolver::resolve( $link->url );
		if ( null !== $local ) {
			self::record( (int) $link->id, $link->url, $local, true );
		} else {
			$checker = new Http_Checker();
			self::record( (int) $link->id, $link->url, $checker->check( $link->url ), false );
		}
		self::schedule_confirmations();
		return Store::get_link( $link_id );
	}

	/**
	 * Files a result, applying the two-check rule.
	 *
	 * A hard failure (404, 410, a name that does not resolve, a missing local post or file)
	 * becomes Broken only when it happens again at least Settings::confirm_interval() seconds
	 * after the first one. Until then the link is Inconclusive and waits for its second check.
	 *
	 * @param int    $link_id  Link ID.
	 * @param string $url      Address.
	 * @param array  $result   Raw result.
	 * @param bool   $internal Resolved without a request.
	 */
	public static function record( $link_id, $url, array $result, $internal ) {
		$link = Store::get_link( $link_id );
		if ( ! $link ) {
			return;
		}
		$c    = Classifier::classify( $result, $url );
		$now  = Store::now();
		$data = array(
			'http_code'    => (int) $c['code'],
			'reason_key'   => $c['reason_key'],
			'detail'       => mb_substr( $c['detail'], 0, 255 ),
			'final_url'    => (string) $c['final_url'],
			'internal'     => $internal ? 1 : 0,
			'last_checked' => $now,
			'queued'       => 0,
		);

		if ( 'hard' === $c['outcome'] ) {
			$first = $link->first_failure_at;
			if ( $first && ( strtotime( $now . ' UTC' ) - strtotime( $first . ' UTC' ) ) >= Settings::confirm_interval() ) {
				$data['status']       = 'broken';
				$data['broken_since'] = ( 'broken' === $link->status && $link->broken_since ) ? $link->broken_since : $now;
			} else {
				$data['first_failure_at'] = $first ? $first : $now;
				$data['status']           = 'broken' === $link->status ? 'broken' : 'inconclusive';
			}
		} else {
			$data['status']           = $c['outcome'];
			$data['first_failure_at'] = null;
			$data['broken_since']     = null;
		}
		Store::update_link( $link_id, $data );
	}

	/**
	 * Schedules the confirming check for the earliest link waiting for one.
	 */
	public static function schedule_confirmations() {
		$earliest = Store::earliest_pending_confirmation();
		if ( ! $earliest ) {
			return;
		}
		$due  = strtotime( $earliest . ' UTC' ) + Settings::confirm_interval() + 30;
		$next = wp_next_scheduled( 'linkrounds_confirm' );
		if ( $next && $next <= $due ) {
			return;
		}
		wp_clear_scheduled_hook( 'linkrounds_confirm' );
		wp_schedule_single_event( max( time(), $due ), 'linkrounds_confirm' );
	}

	/**
	 * Queues links whose wait has passed. Hooked to the linkrounds_confirm event.
	 */
	public static function run_confirmations() {
		self::revive();
		$before = gmdate( 'Y-m-d H:i:s', time() - Settings::confirm_interval() );
		if ( Store::queue_due_confirmations( $before ) > 0 ) {
			self::schedule_batch();
		}
		self::schedule_confirmations();
	}

	/**
	 * Queues every Broken and Inconclusive link. Hooked to the daily linkrounds_daily_recheck event.
	 *
	 * @return int Links queued.
	 */
	public static function run_daily_recheck() {
		self::revive();
		$count = Store::queue_statuses( array( 'broken', 'inconclusive' ) );
		if ( $count > 0 ) {
			self::schedule_batch();
		}
		return $count;
	}

	/**
	 * Schedules the next batch when work is waiting but no batch is scheduled or running, which
	 * is what a killed batch leaves behind. Hooked to linkrounds_watchdog, and called from every
	 * other background event, so a scan never stays stuck in "running".
	 *
	 * @return bool Whether a batch was scheduled.
	 */
	public static function revive() {
		$state = self::state();
		if ( 'paused' === $state['state'] || ( 'running' !== $state['state'] && 0 === Store::count_queued() ) ) {
			return false;
		}
		if ( wp_next_scheduled( 'linkrounds_batch' ) || self::is_locked() ) {
			return false;
		}
		self::schedule_batch();
		return true;
	}

	/**
	 * Runs a batch in the current request when the background has stalled (for example when
	 * WP-Cron cannot reach the site), otherwise nudges WP-Cron. Called while the screen polls.
	 */
	public static function nudge() {
		$state = self::state();
		if ( 'paused' === $state['state'] ) {
			return;
		}
		if ( 'running' !== $state['state'] && 0 === Store::count_queued() ) {
			return;
		}
		$last = (int) get_option( 'linkrounds_last_batch', 0 );
		if ( time() - $last > 45 && ! self::is_locked() ) {
			self::run_batch();
			return;
		}
		if ( ! wp_next_scheduled( 'linkrounds_batch' ) ) {
			self::schedule_batch();
		}
		spawn_cron();
	}

	/**
	 * Takes the batch lock.
	 *
	 * @return bool
	 */
	private static function lock() {
		$until = time() + (int) ceil( self::max_batch_duration() ) + 30;
		if ( add_option( self::LOCK_OPTION, $until, '', false ) ) {
			return true;
		}
		$current = (int) get_option( self::LOCK_OPTION, 0 );
		if ( $current < time() ) {
			update_option( self::LOCK_OPTION, $until, false );
			return true;
		}
		return false;
	}

	/**
	 * Whether another batch holds the lock.
	 *
	 * @return bool
	 */
	private static function is_locked() {
		return (int) get_option( self::LOCK_OPTION, 0 ) >= time();
	}

	/**
	 * Releases the batch lock.
	 */
	private static function unlock() {
		delete_option( self::LOCK_OPTION );
	}
}
