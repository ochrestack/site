<?php
/**
 * Collects the links in published content and navigation menus.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Reads posts and menu items and keeps the instances table in step with them.
 */
class Collector {

	/**
	 * Post types read during a scan, including menu items when menus are scanned.
	 *
	 * @return string[]
	 */
	public static function post_types() {
		$types = Settings::scanned_post_types();
		if ( Settings::scans_patterns() ) {
			$types[] = 'wp_block';
		}
		if ( Settings::scans_menus() ) {
			$types[] = 'nav_menu_item';
			$types[] = 'wp_navigation';
		}
		return $types;
	}

	/**
	 * Whether a post's links are scanned.
	 *
	 * @param \WP_Post $post Post.
	 * @return bool
	 */
	public static function eligible( $post ) {
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return false;
		}
		if ( 'nav_menu_item' === $post->post_type ) {
			return Settings::scans_menus() && 'custom' === get_post_meta( $post->ID, '_menu_item_type', true );
		}
		if ( 'wp_navigation' === $post->post_type ) {
			return Settings::scans_menus();
		}
		if ( 'wp_block' === $post->post_type ) {
			return Settings::scans_patterns();
		}
		return in_array( $post->post_type, Settings::scanned_post_types(), true );
	}

	/**
	 * IDs of published posts to read, after a given ID.
	 *
	 * @param int $after Last ID read.
	 * @param int $limit Maximum IDs.
	 * @return int[]
	 */
	public static function next_post_ids( $after, $limit ) {
		global $wpdb;
		$types = self::post_types();
		if ( empty( $types ) ) {
			return array();
		}
		$args = array_merge( array( $wpdb->posts ), $types, array( (int) $after, (int) $limit ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Paging through post IDs once per batch; WP_Query cannot page by ID cursor.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM %i WHERE post_status = 'publish' AND post_type IN (" . implode( ',', array_fill( 0, count( $types ), '%s' ) ) . ') AND ID > %d ORDER BY ID ASC LIMIT %d', // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- The IN list is built from placeholders only.
				$args
			)
		);
		return array_map( 'intval', $ids );
	}

	/**
	 * Number of published posts that will be read.
	 *
	 * @return int
	 */
	public static function count_posts() {
		global $wpdb;
		$types = self::post_types();
		if ( empty( $types ) ) {
			return 0;
		}
		$args = array_merge( array( $wpdb->posts ), $types );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Counted once per scan for the progress display.
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE post_status = 'publish' AND post_type IN (" . implode( ',', array_fill( 0, count( $types ), '%s' ) ) . ')', // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- The IN list is built from placeholders only.
				$args
			)
		);
	}

	/**
	 * Links found in a post or menu item.
	 *
	 * @param \WP_Post $post Post.
	 * @return array[] source, raw, occurrence, text, url (the address that is checked).
	 */
	public static function found_in( $post ) {
		$found = array();
		if ( 'nav_menu_item' === $post->post_type ) {
			$raw = trim( (string) get_post_meta( $post->ID, '_menu_item_url', true ) );
			$url = Url_Guard::absolutize( $raw, home_url( '/' ) );
			if ( '' !== $url ) {
				$found[] = array(
					'source'     => 'menu',
					'raw'        => $raw,
					'occurrence' => 1,
					'text'       => $post->post_title,
					'url'        => Url_Guard::check_url( $url ),
				);
			}
			return $found;
		}

		if ( 'wp_navigation' === $post->post_type ) {
			foreach ( Blocks::navigation_links( $post->post_content ) as $item ) {
				$url = Url_Guard::absolutize( $item['raw'], home_url( '/' ) );
				if ( '' !== $url ) {
					$found[] = array(
						'source'     => 'navlink',
						'raw'        => $item['raw'],
						'occurrence' => $item['occurrence'],
						'text'       => $item['text'],
						'url'        => Url_Guard::check_url( $url ),
					);
				}
			}
			return $found;
		}

		$base = is_post_type_viewable( $post->post_type ) ? get_permalink( $post ) : '';
		$base = $base ? $base : home_url( '/' );
		foreach ( Parser::find( $post->post_content ) as $item ) {
			$url = Url_Guard::absolutize( $item['raw'], $base );
			if ( '' === $url ) {
				continue;
			}
			$found[] = array(
				'source'     => $item['source'],
				'raw'        => $item['raw'],
				'occurrence' => $item['occurrence'],
				'text'       => $item['text'],
				'url'        => Url_Guard::check_url( $url ),
			);
		}
		return $found;
	}

	/**
	 * Every link, image and navigation link in a post, in document order, as stored rows key them.
	 *
	 * @param \WP_Post $post Post.
	 * @return array[] source, raw, occurrence.
	 */
	public static function keys( $post ) {
		$out = array();
		if ( 'wp_navigation' === $post->post_type ) {
			foreach ( Blocks::navigation_links( $post->post_content ) as $item ) {
				$out[] = array(
					'source'     => 'navlink',
					'raw'        => $item['raw'],
					'occurrence' => $item['occurrence'],
				);
			}
			return $out;
		}
		foreach ( Parser::find( $post->post_content ) as $item ) {
			$out[] = array(
				'source'     => $item['source'],
				'raw'        => $item['raw'],
				'occurrence' => $item['occurrence'],
			);
		}
		return $out;
	}

	/**
	 * The key that identifies one stored place of a link.
	 *
	 * @param string $source     Source.
	 * @param string $raw        Address as written.
	 * @param int    $occurrence Occurrence.
	 * @return string
	 */
	public static function key_of( $source, $raw, $occurrence ) {
		return $source . '|' . (int) $occurrence . '|' . $raw;
	}

	/**
	 * Brings a post's instances in line with its current content.
	 *
	 * Existing instances keep their ID and their Ignore flag; links that left the content are
	 * removed; links to excluded addresses are skipped.
	 *
	 * @param \WP_Post|int $post      Post.
	 * @param int          $scan_id   Collection pass the instances belong to.
	 * @param bool         $queue_all Queue every link in the post for checking, not only new ones.
	 * @return int Instances now stored for the post.
	 */
	public static function collect_post( $post, $scan_id, $queue_all ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return 0;
		}
		if ( ! self::eligible( $post ) ) {
			Store::forget_post( $post->ID );
			return 0;
		}

		$existing = array();
		foreach ( Store::instances_for_post( $post->ID ) as $row ) {
			$existing[ self::key_of( $row->source, $row->raw_url, $row->occurrence ) ] = $row;
		}

		$settings = Settings::all();
		$kept     = array();
		$touched  = array();
		foreach ( self::found_in( $post ) as $item ) {
			if ( Settings::is_excluded( $item['url'], $settings['excluded_patterns'] ) ) {
				continue;
			}
			$link_id   = Store::ensure_link( $item['url'], $queue_all );
			$touched[] = $link_id;
			$key       = self::key_of( $item['source'], $item['raw'], $item['occurrence'] );
			$text      = mb_substr( (string) $item['text'], 0, 500 );
			if ( isset( $existing[ $key ] ) ) {
				$row    = $existing[ $key ];
				$kept[] = (int) $row->id;
				if ( (int) $row->link_id !== $link_id || $row->link_text !== $text || (int) $row->scan_id !== (int) $scan_id ) {
					$touched[] = (int) $row->link_id;
					Store::update_instance(
						(int) $row->id,
						array(
							'link_id'   => $link_id,
							'link_text' => $text,
							'scan_id'   => (int) $scan_id,
						)
					);
				}
				continue;
			}
			$kept[] = Store::insert_instance(
				array(
					'link_id'    => $link_id,
					'post_id'    => $post->ID,
					'source'     => $item['source'],
					'raw_url'    => $item['raw'],
					'occurrence' => (int) $item['occurrence'],
					'link_text'  => $text,
					'ignored'    => 0,
					'scan_id'    => (int) $scan_id,
				)
			);
		}

		$gone = array();
		foreach ( $existing as $row ) {
			if ( ! in_array( (int) $row->id, $kept, true ) ) {
				$gone[]    = (int) $row->id;
				$touched[] = (int) $row->link_id;
			}
		}
		if ( $gone ) {
			Store::delete_instances( $gone );
		}
		Store::delete_orphan_links( array_unique( $touched ) );
		return count( $kept );
	}
}
