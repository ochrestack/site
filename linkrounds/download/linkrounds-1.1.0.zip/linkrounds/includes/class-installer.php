<?php
/**
 * Tables, scheduled events, activation and removal.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Creates and removes the plugin's data.
 */
class Installer {

	/**
	 * Every scheduled event hook the plugin uses.
	 */
	const CRON_HOOKS = array( 'linkrounds_batch', 'linkrounds_daily_recheck', 'linkrounds_confirm', 'linkrounds_watchdog' );

	/**
	 * Every option the plugin stores.
	 */
	const OPTIONS = array( 'linkrounds_settings', 'linkrounds_db_version', 'linkrounds_scan', 'linkrounds_batch_lock', 'linkrounds_last_batch', 'linkrounds_stats' );

	/**
	 * Activation: create tables and schedule the daily re-check.
	 */
	public static function activate() {
		self::install();
	}

	/**
	 * Deactivation: unschedule every event. Data stays until the plugin is deleted.
	 */
	public static function deactivate() {
		foreach ( self::CRON_HOOKS as $hook ) {
			wp_unschedule_hook( $hook );
		}
		delete_option( 'linkrounds_batch_lock' );
	}

	/**
	 * Creates or upgrades the tables when the stored version differs. Runs on every load,
	 * which also covers network-activated multisite installs, one site at a time.
	 */
	public static function maybe_install() {
		if ( get_option( 'linkrounds_db_version' ) !== LINKROUNDS_DB_VERSION ) {
			self::install();
		}
		if ( ! wp_next_scheduled( 'linkrounds_daily_recheck' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'linkrounds_daily_recheck' );
		}
	}

	/**
	 * Creates the tables.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$links   = Store::links_table();
		$inst    = Store::instances_table();

		dbDelta(
			"CREATE TABLE {$links} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				url_hash char(32) NOT NULL,
				url text NOT NULL,
				host varchar(255) NOT NULL DEFAULT '',
				status varchar(20) NOT NULL DEFAULT 'unchecked',
				http_code smallint(5) unsigned NOT NULL DEFAULT 0,
				reason_key varchar(40) NOT NULL DEFAULT '',
				detail text NULL,
				final_url text NULL,
				internal tinyint(1) NOT NULL DEFAULT 0,
				first_failure_at datetime NULL,
				broken_since datetime NULL,
				last_checked datetime NULL,
				queued tinyint(1) NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				UNIQUE KEY url_hash (url_hash),
				KEY status (status),
				KEY queued (queued)
			) {$charset};"
		);
		dbDelta(
			"CREATE TABLE {$inst} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				link_id bigint(20) unsigned NOT NULL,
				post_id bigint(20) unsigned NOT NULL,
				source varchar(10) NOT NULL DEFAULT 'a',
				raw_url text NOT NULL,
				occurrence smallint(5) unsigned NOT NULL DEFAULT 1,
				link_text text NULL,
				ignored tinyint(1) NOT NULL DEFAULT 0,
				scan_id bigint(20) unsigned NOT NULL DEFAULT 0,
				PRIMARY KEY  (id),
				KEY link_id (link_id),
				KEY post_id (post_id)
			) {$charset};"
		);

		update_option( 'linkrounds_db_version', LINKROUNDS_DB_VERSION );
		if ( ! wp_next_scheduled( 'linkrounds_daily_recheck' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'linkrounds_daily_recheck' );
		}
	}

	/**
	 * Removes every table, option, event and user setting. Called from uninstall.php.
	 */
	public static function uninstall() {
		global $wpdb;
		foreach ( self::CRON_HOOKS as $hook ) {
			wp_unschedule_hook( $hook );
		}
		foreach ( self::OPTIONS as $option ) {
			delete_option( $option );
		}
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', Store::links_table() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Removing the plugin's own table on uninstall.
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', Store::instances_table() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Removing the plugin's own table on uninstall.
		delete_metadata( 'user', 0, 'linkrounds_review_prompt', '', true );
		delete_metadata( 'user', 0, 'linkrounds_notice', '', true );
	}
}
