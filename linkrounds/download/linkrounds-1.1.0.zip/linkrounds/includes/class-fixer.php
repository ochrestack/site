<?php
/**
 * Unlink and Edit address, saved as normal post revisions.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Applies fixes to exactly the links asked for.
 */
class Fixer {

	/**
	 * Most new addresses checked straight away in one request; the rest are queued.
	 */
	const INLINE_CHECKS = 5;

	/**
	 * Validates a new address typed by the user.
	 *
	 * @param string $url Input.
	 * @return string Clean address, or '' when not acceptable.
	 */
	public static function clean_new_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( '/' === $url[0] && ( ! isset( $url[1] ) || '/' !== $url[1] ) ) {
			return esc_url_raw( $url );
		}
		if ( ! preg_match( '#^https?://[^/?\#\s]+#i', $url ) ) {
			return '';
		}
		return esc_url_raw( $url, array( 'http', 'https' ) );
	}

	/**
	 * Applies fixes.
	 *
	 * @param array[] $fixes Each: instance (int), action ('unlink' | 'edit'), url (for edit).
	 * @return array done (int), posts (int), failed (string[]), checked (string[]), messages.
	 */
	public static function apply( array $fixes ) {
		$out = array(
			'done'    => 0,
			'posts'   => 0,
			'failed'  => array(),
			'checked' => array(),
		);

		$by_post = array();
		foreach ( $fixes as $fix ) {
			$instance = Store::get_instance( (int) $fix['instance'] );
			if ( ! $instance ) {
				$out['failed'][] = __( 'A link was not found. It may have been fixed or removed already.', 'linkrounds' );
				continue;
			}
			$action = 'unlink' === $fix['action'] ? 'unlink' : 'edit';
			$url    = 'edit' === $action ? self::clean_new_url( isset( $fix['url'] ) ? $fix['url'] : '' ) : '';
			$error  = self::refusal( $instance, $action, $url );
			if ( '' !== $error ) {
				$out['failed'][] = $error;
				continue;
			}
			$by_post[ (int) $instance->post_id ][] = array(
				'instance' => $instance,
				'action'   => $action,
				'url'      => $url,
			);
		}

		$new_urls = array();
		foreach ( $by_post as $post_id => $post_fixes ) {
			$post = get_post( $post_id );
			if ( 'nav_menu_item' === $post->post_type ) {
				foreach ( $post_fixes as $fix ) {
					update_post_meta( $post_id, '_menu_item_url', $fix['url'] );
					$new_urls[] = array( $fix['url'], home_url( '/' ) );
					++$out['done'];
				}
				Collector::collect_post( $post, self::scan_id(), false );
				++$out['posts'];
				continue;
			}

			$result = self::fix_post( $post, $post_fixes );
			if ( is_wp_error( $result ) ) {
				$out['failed'][] = $result->get_error_message();
				continue;
			}
			$out['done'] += $result;
			++$out['posts'];
			$base = is_post_type_viewable( $post->post_type ) ? get_permalink( $post ) : '';
			foreach ( $post_fixes as $fix ) {
				if ( 'edit' === $fix['action'] ) {
					$new_urls[] = array( $fix['url'], $base ? $base : home_url( '/' ) );
				}
			}
		}

		$checked = 0;
		$seen    = array();
		foreach ( $new_urls as $pair ) {
			$absolute = Url_Guard::absolutize( $pair[0], $pair[1] );
			if ( '' === $absolute ) {
				continue;
			}
			$check = Url_Guard::check_url( $absolute );
			if ( isset( $seen[ $check ] ) ) {
				continue;
			}
			$seen[ $check ] = true;
			$link           = Store::find_link( $check );
			if ( ! $link ) {
				continue;
			}
			if ( $checked < self::INLINE_CHECKS ) {
				$link = Scanner::recheck_link( (int) $link->id );
				++$checked;
				$categories       = Classifier::categories();
				$label            = isset( $categories[ $link->status ] ) ? $categories[ $link->status ] : $link->status;
				$out['checked'][] = sprintf(
					/* translators: 1: address, 2: category such as OK or Broken, 3: reason. */
					__( 'New address %1$s checked: %2$s. %3$s', 'linkrounds' ),
					$check,
					$label,
					Classifier::reason_text( $link->reason_key, $link->http_code, $link->detail )
				);
			} else {
				Store::update_link( (int) $link->id, array( 'queued' => 1 ) );
				Scanner::schedule_batch();
			}
		}

		if ( $out['done'] > 0 ) {
			$stats             = get_option( 'linkrounds_stats', array() );
			$stats             = is_array( $stats ) ? $stats : array();
			$stats['fixes']    = ( isset( $stats['fixes'] ) ? (int) $stats['fixes'] : 0 ) + $out['done'];
			$stats['last_fix'] = time();
			update_option( 'linkrounds_stats', $stats, false );
		}
		return $out;
	}

	/**
	 * Why a fix is refused, or '' when it is allowed.
	 *
	 * @param object $instance Instance joined with link.
	 * @param string $action   'unlink' or 'edit'.
	 * @param string $url      Clean new address for edits.
	 * @return string
	 */
	private static function refusal( $instance, $action, $url ) {
		$post = get_post( (int) $instance->post_id );
		if ( ! $post ) {
			return __( 'The post that held this link no longer exists.', 'linkrounds' );
		}
		$can = 'nav_menu_item' === $post->post_type ? current_user_can( 'edit_theme_options' ) : current_user_can( 'edit_post', $post->ID );
		if ( ! $can ) {
			/* translators: %s: post title. */
			return sprintf( __( 'You are not allowed to edit “%s”, so its links were left alone.', 'linkrounds' ), self::title( $post ) );
		}
		if ( 'unlink' === $action && 'a' !== $instance->source ) {
			if ( 'img' === $instance->source ) {
				return __( 'Images cannot be unlinked; use Edit address instead.', 'linkrounds' );
			}
			return 'navlink' === $instance->source
				? __( 'Navigation menu links cannot be unlinked; use Edit address or remove the link in the Site Editor.', 'linkrounds' )
				: __( 'Menu items cannot be unlinked; use Edit address or remove the item under Appearance > Menus.', 'linkrounds' );
		}
		if ( 'unlink' === $action ) {
			$blocker = self::unlink_blocker( $post, $instance );
			if ( '' !== $blocker ) {
				return $blocker;
			}
		}
		if ( 'edit' === $action && '' === $url ) {
			return __( 'Enter a full web address that starts with http:// or https:// (or a path on this site that starts with /).', 'linkrounds' );
		}
		return '';
	}

	/**
	 * Why a link cannot be unlinked without breaking its block, or ''.
	 *
	 * The File and Button blocks always render their link, and blocks such as File keep the
	 * address in their attributes too, so removing only the <a> tag would leave a block the
	 * editor reports as invalid.
	 *
	 * @param \WP_Post $post     Post.
	 * @param object   $instance Instance.
	 * @return string
	 */
	public static function unlink_blocker( $post, $instance ) {
		if ( 'a' !== $instance->source ) {
			return '';
		}
		$item = Parser::locate( $post->post_content, 'a', $instance->raw_url, (int) $instance->occurrence );
		if ( null === $item ) {
			return '';
		}
		$block = Blocks::enclosing( $post->post_content, $item['tag_start'] );
		if ( null === $block || ( 'core/button' !== $block['name'] && ! Blocks::holds( $block, $instance->raw_url ) ) ) {
			return '';
		}
		$type  = \WP_Block_Type_Registry::get_instance()->get_registered( $block['name'] );
		$label = $type && ! empty( $type->title ) ? $type->title : $block['name'];
		return sprintf(
			/* translators: 1: block name such as File or Button, 2: post title. */
			__( 'The link is part of a %1$s block in “%2$s”, and removing only the link would break the block. Use Edit address, or remove the block in the editor.', 'linkrounds' ),
			$label,
			self::title( $post )
		);
	}

	/**
	 * Where one stored link is in the content.
	 *
	 * @param string $content  Content.
	 * @param object $instance Instance.
	 * @return array|null start (offset) and, for links and images, the Parser item.
	 */
	private static function position( $content, $instance ) {
		if ( 'navlink' === $instance->source ) {
			foreach ( Blocks::navigation_links( $content ) as $link ) {
				if ( $link['raw'] === $instance->raw_url && (int) $link['occurrence'] === (int) $instance->occurrence ) {
					return array(
						'start' => $link['delimiter']['start'],
						'link'  => $link,
					);
				}
			}
			return null;
		}
		$item = Parser::locate( $content, $instance->source, $instance->raw_url, (int) $instance->occurrence );
		return null === $item ? null : array(
			'start' => $item['tag_start'],
			'item'  => $item,
		);
	}

	/**
	 * Applies fixes to one post in a single update, from the last link to the first so earlier
	 * links keep their place, and saves the change as a revision.
	 *
	 * An edited address is also changed in the attributes of the block it sits in when that
	 * block keeps the same address there (Cover, File, navigation links), so the editor still
	 * finds the block valid.
	 *
	 * @param \WP_Post $post  Post.
	 * @param array[]  $fixes Fixes for this post.
	 * @return int|\WP_Error Links changed.
	 */
	private static function fix_post( $post, $fixes ) {
		$content = $post->post_content;
		$planned = array();
		foreach ( $fixes as $fix ) {
			$where = self::position( $content, $fix['instance'] );
			if ( null === $where ) {
				return new \WP_Error(
					'linkrounds_moved',
					/* translators: %s: post title. */
					sprintf( __( 'A link in “%s” has changed since the last scan, so nothing was changed there. Re-check the post and try again.', 'linkrounds' ), self::title( $post ) )
				);
			}
			$planned[ $where['start'] ] = $fix;
		}
		krsort( $planned );

		// Later changes never move an earlier link's place in the count of identical links, so
		// each link is found again by its address and occurrence just before it is changed.
		$new = $content;
		foreach ( $planned as $fix ) {
			$i     = $fix['instance'];
			$where = self::position( $new, $i );
			if ( isset( $where['link'] ) ) {
				$new = Blocks::replace_in_attrs( $new, $where['link']['delimiter'], $i->raw_url, $fix['url'] );
				continue;
			}
			$item = $where['item'];
			if ( 'unlink' === $fix['action'] ) {
				$new = Parser::unlink( $new, $item );
				continue;
			}
			$block = Blocks::enclosing( $new, $item['tag_start'] );
			$new   = Parser::replace_address( $new, $item, $fix['url'] );
			if ( null !== $block ) {
				// The block's opening comment comes before the link, so its offsets still hold.
				$new = Blocks::replace_in_attrs( $new, $block, $i->raw_url, $fix['url'] );
			}
		}
		if ( $new === $content ) {
			return count( $planned );
		}

		$before = Collector::keys( $post );

		// Keep the version from before the fix even when the site keeps only one revision: the
		// fix's own revision must not push it out. The site's limit applies again on the next save.
		$keep_hook = 'wp_' . $post->post_type . '_revisions_to_keep';
		$keep      = static function ( $num, $revision_post ) use ( $post ) {
			return ( $revision_post && (int) $revision_post->ID === (int) $post->ID && $num > 0 && $num < 2 ) ? 2 : $num;
		};
		add_filter( $keep_hook, $keep, PHP_INT_MAX, 2 );

		// Make sure the current content is in a revision, so the fix can be undone even on posts
		// that never had one (for example posts that were imported).
		if ( wp_revisions_enabled( $post ) ) {
			wp_save_post_revision( $post->ID );
		}

		$exact = static function ( $data, $postarr ) use ( $post, $new ) {
			if ( isset( $postarr['ID'] ) && (int) $postarr['ID'] === (int) $post->ID ) {
				$data['post_content'] = wp_slash( $new );
			}
			return $data;
		};
		// Save exactly the spliced content: content filters must not re-format the rest of the post.
		add_filter( 'wp_insert_post_data', $exact, PHP_INT_MAX, 2 );
		// The rows are brought up to date below, after the identical links have been moved.
		$refresh = has_action( 'wp_after_insert_post', array( 'Linkrounds\\Plugin', 'post_saved' ) );
		if ( false !== $refresh ) {
			remove_action( 'wp_after_insert_post', array( 'Linkrounds\\Plugin', 'post_saved' ), $refresh );
		}
		$result = wp_update_post(
			wp_slash(
				array(
					'ID'           => $post->ID,
					'post_content' => $new,
				)
			),
			true
		);
		remove_filter( 'wp_insert_post_data', $exact, PHP_INT_MAX );
		remove_filter( $keep_hook, $keep, PHP_INT_MAX );
		if ( false !== $refresh ) {
			add_action( 'wp_after_insert_post', array( 'Linkrounds\\Plugin', 'post_saved' ), $refresh, 2 );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		self::carry_over( $post->ID, $before, $planned );
		Collector::collect_post( $post->ID, self::scan_id(), false );
		return count( $planned );
	}

	/**
	 * Moves the stored rows of the links a fix did not touch to their new place in the count of
	 * identical links, so each keeps its Ignore flag. Rows of fixed links are removed; the
	 * collector adds the edited ones back under their new address.
	 *
	 * @param int     $post_id Post ID.
	 * @param array[] $before  Collector::keys() before the fix.
	 * @param array[] $planned Fixes applied.
	 */
	private static function carry_over( $post_id, $before, $planned ) {
		$fixed = array();
		foreach ( $planned as $fix ) {
			$i = $fix['instance'];
			$fixed[ Collector::key_of( $i->source, $i->raw_url, $i->occurrence ) ] = $fix['action'];
		}
		$after = Collector::keys( get_post( $post_id ) );

		$moves = array();
		$j     = 0;
		foreach ( $before as $old ) {
			$key = Collector::key_of( $old['source'], $old['raw'], $old['occurrence'] );
			if ( isset( $fixed[ $key ] ) && 'unlink' === $fixed[ $key ] ) {
				continue;
			}
			if ( ! isset( $after[ $j ] ) ) {
				return; // The content did not change the way the fix planned; let the collector decide.
			}
			if ( ! isset( $fixed[ $key ] ) ) {
				$moves[ $key ] = $after[ $j ];
			}
			++$j;
		}
		if ( count( $after ) !== $j ) {
			return;
		}

		$remove = array();
		$links  = array();
		foreach ( Store::instances_for_post( $post_id ) as $row ) {
			$key = Collector::key_of( $row->source, $row->raw_url, $row->occurrence );
			if ( isset( $fixed[ $key ] ) ) {
				$remove[] = (int) $row->id;
				$links[]  = (int) $row->link_id;
			} elseif ( isset( $moves[ $key ] ) && (int) $moves[ $key ]['occurrence'] !== (int) $row->occurrence ) {
				Store::update_instance( (int) $row->id, array( 'occurrence' => (int) $moves[ $key ]['occurrence'] ) );
			}
		}
		if ( $remove ) {
			Store::delete_instances( $remove );
			Store::delete_orphan_links( $links );
		}
	}

	/**
	 * Current scan ID, used to tag re-collected instances.
	 *
	 * @return int
	 */
	private static function scan_id() {
		$state = Scanner::state();
		return (int) $state['id'];
	}

	/**
	 * A post title for messages.
	 *
	 * @param \WP_Post $post Post.
	 * @return string
	 */
	public static function title( $post ) {
		$title = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return '' === $title ? __( '(no title)', 'linkrounds' ) : $title;
	}
}
