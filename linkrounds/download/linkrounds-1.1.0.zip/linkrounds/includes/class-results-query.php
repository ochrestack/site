<?php
/**
 * Queries the results shown on the screen and used by exports.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own tables, which change during every scan.

/**
 * Filtered, sorted, paged results: one row per place a link appears.
 */
class Results_Query {

	/**
	 * Filters accepted from the screen.
	 *
	 * @param array $input Raw, unslashed request values.
	 * @return array category, post_type, search, orderby, order.
	 */
	public static function args_from( array $input ) {
		$category = isset( $input['category'] ) ? sanitize_key( $input['category'] ) : '';
		if ( ! in_array( $category, array( '', 'broken', 'redirected', 'inconclusive', 'ok', 'unchecked', 'ignored' ), true ) ) {
			$category = '';
		}
		$post_type = isset( $input['post_type'] ) ? sanitize_key( $input['post_type'] ) : '';
		$orderby   = isset( $input['orderby'] ) ? sanitize_key( $input['orderby'] ) : '';
		if ( ! in_array( $orderby, array( 'url', 'page', 'checked', 'status' ), true ) ) {
			$orderby = '';
		}
		$order = isset( $input['order'] ) && 'asc' === strtolower( (string) $input['order'] ) ? 'ASC' : 'DESC';
		return array(
			'category'  => $category,
			'post_type' => $post_type,
			'search'    => isset( $input['s'] ) ? trim( sanitize_text_field( (string) $input['s'] ) ) : '',
			'orderby'   => $orderby,
			'order'     => $order,
		);
	}

	/**
	 * WHERE clause and its values.
	 *
	 * @param array $args Filters.
	 * @return array SQL with placeholders, values.
	 */
	private static function where( array $args ) {
		global $wpdb;
		$where  = array();
		$values = array();
		if ( ! empty( $args['instance'] ) ) {
			return array( 'i.id = %d', array( (int) $args['instance'] ) );
		}
		if ( 'ignored' === $args['category'] ) {
			$where[] = 'i.ignored = 1';
		} else {
			$where[] = 'i.ignored = 0';
			if ( '' !== $args['category'] ) {
				$where[]  = 'l.status = %s';
				$values[] = $args['category'];
			}
		}
		if ( '' !== $args['post_type'] ) {
			$where[]  = 'p.post_type = %s';
			$values[] = $args['post_type'];
		}
		if ( '' !== $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '( l.url LIKE %s OR i.raw_url LIKE %s )';
			$values[] = $like;
			$values[] = $like;
		}
		return array( implode( ' AND ', $where ), $values );
	}

	/**
	 * Matching rows.
	 *
	 * @param array $args   Filters.
	 * @param int   $limit  Rows, 0 for all.
	 * @param int   $offset Offset.
	 * @return object[]
	 */
	public static function rows( array $args, $limit = 20, $offset = 0 ) {
		global $wpdb;
		$args = array_merge( self::args_from( array() ), $args );

		list( $where, $values ) = self::where( $args );
		$dir                    = 'ASC' === $args['order'] ? 'ASC' : 'DESC';
		switch ( $args['orderby'] ) {
			case 'url':
				$order = "l.url {$dir}, i.id ASC";
				break;
			case 'page':
				$order = "p.post_title {$dir}, i.id ASC";
				break;
			case 'checked':
				$order = "l.last_checked {$dir}, i.id ASC";
				break;
			default:
				$order = "CASE l.status WHEN 'broken' THEN 0 WHEN 'inconclusive' THEN 1 WHEN 'redirected' THEN 2 WHEN 'unchecked' THEN 3 ELSE 4 END ASC, i.post_id ASC, i.id ASC";
		}
		$sql = 'SELECT i.id AS instance_id, i.post_id, i.source, i.raw_url, i.occurrence, i.link_text, i.ignored,
				l.id AS link_id, l.url, l.status, l.http_code, l.reason_key, l.detail, l.final_url, l.internal,
				l.first_failure_at, l.broken_since, l.last_checked, l.queued, p.post_title, p.post_type
			FROM %i i
			INNER JOIN %i l ON l.id = i.link_id
			INNER JOIN %i p ON p.ID = i.post_id
			WHERE ' . $where . ' ORDER BY ' . $order;

		$params = array_merge( array( Store::instances_table(), Store::links_table(), $wpdb->posts ), $values );
		if ( $limit > 0 ) {
			$sql     .= ' LIMIT %d OFFSET %d';
			$params[] = (int) $limit;
			$params[] = (int) $offset;
		}
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $sql holds only fixed SQL and placeholders; the ORDER BY comes from a fixed list.
	}

	/**
	 * One row by instance ID.
	 *
	 * @param int $instance_id Instance ID.
	 * @return object|null
	 */
	public static function row( $instance_id ) {
		$rows = self::rows( array( 'instance' => (int) $instance_id ), 1 );
		return $rows ? $rows[0] : null;
	}

	/**
	 * Number of matching rows.
	 *
	 * @param array $args Filters.
	 * @return int
	 */
	public static function count( array $args ) {
		global $wpdb;
		$args                   = array_merge( self::args_from( array() ), $args );
		list( $where, $values ) = self::where( $args );
		$sql                    = 'SELECT COUNT(*) FROM %i i INNER JOIN %i l ON l.id = i.link_id INNER JOIN %i p ON p.ID = i.post_id WHERE ' . $where;
		$params                 = array_merge( array( Store::instances_table(), Store::links_table(), $wpdb->posts ), $values );
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $sql holds only fixed SQL and placeholders.
	}

	/**
	 * Row counts per category, plus 'all' and 'ignored'.
	 *
	 * @return int[]
	 */
	public static function counts() {
		global $wpdb;
		$counts = array(
			'all'          => 0,
			'broken'       => 0,
			'redirected'   => 0,
			'inconclusive' => 0,
			'ok'           => 0,
			'unchecked'    => 0,
			'ignored'      => 0,
		);
		$rows   = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT l.status, i.ignored, COUNT(*) AS n FROM %i i INNER JOIN %i l ON l.id = i.link_id INNER JOIN %i p ON p.ID = i.post_id GROUP BY l.status, i.ignored',
				Store::instances_table(),
				Store::links_table(),
				$wpdb->posts
			)
		);
		foreach ( $rows as $row ) {
			if ( (int) $row->ignored ) {
				$counts['ignored'] += (int) $row->n;
				continue;
			}
			$counts['all'] += (int) $row->n;
			if ( isset( $counts[ $row->status ] ) ) {
				$counts[ $row->status ] += (int) $row->n;
			}
		}
		return $counts;
	}

	/**
	 * Post types that have results, for the filter menu.
	 *
	 * @return string[]
	 */
	public static function post_types_in_use() {
		global $wpdb;
		return $wpdb->get_col(
			$wpdb->prepare(
				'SELECT DISTINCT p.post_type FROM %i i INNER JOIN %i p ON p.ID = i.post_id ORDER BY p.post_type',
				Store::instances_table(),
				$wpdb->posts
			)
		);
	}
}
