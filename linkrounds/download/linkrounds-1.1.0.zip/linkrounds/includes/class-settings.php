<?php
/**
 * Plugin settings and exclusion rules.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes the plugin's settings.
 */
class Settings {

	const OPTION = 'linkrounds_settings';

	/**
	 * Allowed waits, in hours, between the first and the confirming hard failure.
	 */
	const CONFIRM_HOURS = array( 1, 6, 24 );

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'excluded_patterns'   => array(),
			'excluded_post_types' => array(),
			'confirm_hours'       => 1,
		);
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Cleans submitted settings.
	 *
	 * @param array $input Raw, unslashed input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$clean = self::defaults();

		$patterns = isset( $input['excluded_patterns'] ) ? (string) $input['excluded_patterns'] : '';
		$lines    = preg_split( '/[\r\n]+/', $patterns );
		foreach ( $lines as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' !== $line && ! in_array( $line, $clean['excluded_patterns'], true ) ) {
				$clean['excluded_patterns'][] = $line;
			}
		}

		$types = isset( $input['excluded_post_types'] ) ? (array) $input['excluded_post_types'] : array();
		foreach ( $types as $type ) {
			$type = sanitize_key( $type );
			if ( post_type_exists( $type ) ) {
				$clean['excluded_post_types'][] = $type;
			}
		}

		$hours = isset( $input['confirm_hours'] ) ? absint( $input['confirm_hours'] ) : 1;
		if ( in_array( $hours, self::CONFIRM_HOURS, true ) ) {
			$clean['confirm_hours'] = $hours;
		}

		return $clean;
	}

	/**
	 * Saves settings.
	 *
	 * @param array $settings Sanitised settings.
	 */
	public static function save( $settings ) {
		update_option( self::OPTION, $settings, false );
	}

	/**
	 * Seconds that must pass between the first hard failure and the confirming one.
	 *
	 * @return int
	 */
	public static function confirm_interval() {
		$settings = self::all();
		$seconds  = (int) $settings['confirm_hours'] * HOUR_IN_SECONDS;

		/**
		 * Filters the wait between the first and the second hard failure, in seconds.
		 * Values under one hour are raised to one hour.
		 *
		 * @param int $seconds Wait in seconds.
		 */
		$seconds = (int) apply_filters( 'linkrounds_confirm_interval', $seconds );
		return max( HOUR_IN_SECONDS, $seconds );
	}

	/**
	 * Public post types whose published content is scanned.
	 *
	 * @return string[]
	 */
	public static function scanned_post_types() {
		$settings = self::all();
		$types    = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		$types = array_diff( array_values( $types ), $settings['excluded_post_types'] );
		return array_values( $types );
	}

	/**
	 * Post types a user may exclude.
	 *
	 * @return \WP_Post_Type[]
	 */
	public static function excludable_post_types() {
		$types = get_post_types( array( 'public' => true ), 'objects' );
		unset( $types['attachment'] );
		return $types;
	}

	/**
	 * Whether synced patterns (reusable blocks) are scanned.
	 *
	 * @return bool
	 */
	public static function scans_patterns() {
		$settings = self::all();
		return ! in_array( 'wp_block', $settings['excluded_post_types'], true );
	}

	/**
	 * Whether menu links (classic menus and block-theme Navigation menus) are scanned.
	 *
	 * @return bool
	 */
	public static function scans_menus() {
		$settings = self::all();
		return ! in_array( 'nav_menu_item', $settings['excluded_post_types'], true );
	}

	/**
	 * Whether an address matches one of the exclusion patterns.
	 *
	 * A pattern without "/" is a domain. Without "*" it matches that host and its subdomains;
	 * with "*" (for example "*.example.com") it is matched against the host name only.
	 * A pattern with "/" is matched against the whole address, with "*" standing for any run of
	 * characters. A pattern without a scheme also matches the address without its scheme.
	 *
	 * @param string     $url      Absolute address.
	 * @param array|null $patterns Patterns, or null for the saved ones.
	 * @return bool
	 */
	public static function is_excluded( $url, $patterns = null ) {
		if ( null === $patterns ) {
			$settings = self::all();
			$patterns = $settings['excluded_patterns'];
		}
		if ( empty( $patterns ) ) {
			return false;
		}

		$host       = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$lower_url  = strtolower( $url );
		$no_scheme  = preg_replace( '#^[a-z][a-z0-9+.-]*://#', '', $lower_url );
		$host_no_ww = preg_replace( '/^www\./', '', $host );

		foreach ( $patterns as $pattern ) {
			$pattern = strtolower( trim( $pattern ) );
			if ( '' === $pattern ) {
				continue;
			}
			$regex = '#^' . str_replace( '\*', '.*', preg_quote( $pattern, '#' ) ) . '$#';
			if ( false === strpos( $pattern, '/' ) ) {
				if ( '' === $host ) {
					continue;
				}
				if ( false !== strpos( $pattern, '*' ) ) {
					if ( preg_match( $regex, $host ) ) {
						return true;
					}
					continue;
				}
				$domain = preg_replace( '/^www\./', '', $pattern );
				if ( $host_no_ww === $domain || substr( $host, -strlen( '.' . $domain ) ) === '.' . $domain ) {
					return true;
				}
				continue;
			}
			$has_scheme = (bool) preg_match( '#^[a-z][a-z0-9+.-]*://#', $pattern );
			if ( preg_match( $regex, $lower_url ) || ( ! $has_scheme && preg_match( $regex, $no_scheme ) ) ) {
				return true;
			}
		}
		return false;
	}
}
