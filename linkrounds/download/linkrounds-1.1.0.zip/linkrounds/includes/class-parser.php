<?php
/**
 * Finds links and images in post content and changes a single one in place.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * A small, byte-preserving HTML scanner for <a href> and <img src>.
 *
 * It never re-serialises the document: a change splices new bytes into the exact
 * range of the attribute or tag it touches, so the rest of the content stays identical.
 */
class Parser {

	/**
	 * Finds every <a href> and <img src> outside comments, scripts and styles.
	 *
	 * Each item: source ('a' or 'img'), raw (decoded attribute value), occurrence (1-based count of
	 * the same source and raw value so far), text, tag_start, tag_end, value_start, value_end, quote,
	 * close_start and close_end (for links; -1 when the link is never closed).
	 *
	 * @param string $html Post content.
	 * @return array[]
	 */
	public static function find( $html ) {
		$html    = (string) $html;
		$items   = array();
		$counter = array();
		$open    = null; // Index in $items of the link waiting for its </a>.

		foreach ( self::tags( $html ) as $tag ) {
			if ( 'a' !== $tag['name'] && 'img' !== $tag['name'] ) {
				continue;
			}
			if ( 'a' === $tag['name'] && null !== $open ) {
				if ( $tag['end_tag'] ) {
					$items[ $open ]['close_start'] = $tag['start'];
					$items[ $open ]['close_end']   = $tag['end'];
					$items[ $open ]['text']        = self::link_text( substr( $html, $items[ $open ]['tag_end'], $tag['start'] - $items[ $open ]['tag_end'] ) );
				}
				$open = null; // Closed, or another link opened first: this one was never closed.
			}
			if ( $tag['end_tag'] ) {
				continue;
			}

			$source = $tag['name'];
			$attr   = self::attribute( $tag, 'a' === $source ? 'href' : 'src' );
			if ( null === $attr ) {
				continue;
			}
			$raw = trim( html_entity_decode( $attr['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			if ( '' === $raw ) {
				continue;
			}

			$item = array(
				'source'      => $source,
				'raw'         => $raw,
				'tag_start'   => $tag['start'],
				'tag_end'     => $tag['end'],
				'value_start' => $attr['start'],
				'value_end'   => $attr['end'],
				'quote'       => $attr['quote'],
				'close_start' => -1,
				'close_end'   => -1,
				'text'        => '',
			);
			if ( 'img' === $source ) {
				$alt          = self::attribute( $tag, 'alt' );
				$item['text'] = null === $alt ? '' : trim( html_entity_decode( $alt['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			}

			$key                = $source . '|' . $raw;
			$counter[ $key ]    = isset( $counter[ $key ] ) ? $counter[ $key ] + 1 : 1;
			$item['occurrence'] = $counter[ $key ];
			$items[]            = $item;
			if ( 'a' === $source ) {
				$open = count( $items ) - 1;
			}
		}

		return $items;
	}

	/**
	 * Locates one link or image by source, decoded address and occurrence.
	 *
	 * @param string $html       Content.
	 * @param string $source     'a' or 'img'.
	 * @param string $raw        Decoded attribute value.
	 * @param int    $occurrence 1-based occurrence.
	 * @return array|null
	 */
	public static function locate( $html, $source, $raw, $occurrence ) {
		foreach ( self::find( $html ) as $item ) {
			if ( $item['source'] === $source && $item['raw'] === $raw && (int) $item['occurrence'] === (int) $occurrence ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * Removes the <a> tags around one link and keeps everything inside them.
	 *
	 * @param string $html Content.
	 * @param array  $item Item from find().
	 * @return string
	 */
	public static function unlink( $html, $item ) {
		if ( $item['close_start'] >= 0 ) {
			$html = substr( $html, 0, $item['close_start'] ) . substr( $html, $item['close_end'] );
		}
		return substr( $html, 0, $item['tag_start'] ) . substr( $html, $item['tag_end'] );
	}

	/**
	 * Replaces the address of one link or image. Only the attribute value changes.
	 *
	 * @param string $html    Content.
	 * @param array  $item    Item from find().
	 * @param string $new_url New address, already validated.
	 * @return string
	 */
	public static function replace_address( $html, $item, $new_url ) {
		$value = esc_url( $new_url );
		if ( '' === $item['quote'] ) {
			$value = '"' . $value . '"';
		} elseif ( "'" === $item['quote'] ) {
			$value = str_replace( "'", '&#039;', $value );
		}
		return substr( $html, 0, $item['value_start'] ) . $value . substr( $html, $item['value_end'] );
	}

	/**
	 * Visible text of a link.
	 *
	 * @param string $inner HTML inside the link.
	 * @return string
	 */
	private static function link_text( $inner ) {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $inner ) ) );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( '' === $text && self::first_img( $inner, $img ) ) {
			$alt = self::attribute( $img, 'alt' );
			/* translators: %s: alternative text of an image used as a link. */
			$text = null !== $alt && '' !== trim( $alt['value'] ) ? sprintf( __( 'Image: %s', 'linkrounds' ), trim( html_entity_decode( $alt['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) : __( 'Image', 'linkrounds' );
		}
		return $text;
	}

	/**
	 * The first <img> tag in a fragment.
	 *
	 * @param string $html Fragment.
	 * @param array  $img  Set to the tag.
	 * @return bool
	 */
	private static function first_img( $html, &$img ) {
		foreach ( self::tags( $html ) as $tag ) {
			if ( 'img' === $tag['name'] && ! $tag['end_tag'] ) {
				$img = $tag;
				return true;
			}
		}
		return false;
	}

	/**
	 * Splits HTML into start and end tags the way a browser's tokenizer does, skipping comments
	 * (including block delimiters), and the insides of scripts, styles, textareas and titles.
	 *
	 * Attribute values are read with the browser's rules: a quoted value runs to its own closing
	 * quote, so ">" or "href=" inside it is just text, and an unquoted value runs to the next
	 * space or ">", so an apostrophe inside it is just text. A tag that never ends (an unclosed
	 * quote, or the end of the content) is not a tag, and nothing after it is read.
	 *
	 * @param string $html Content.
	 * @return array[] name (lower case), end_tag (bool), start, end, attrs (each name, value,
	 *                 start and end offsets of the value, quote character).
	 */
	public static function tags( $html ) {
		$html = (string) $html;
		$len  = strlen( $html );
		$tags = array();
		$pos  = 0;
		while ( $pos < $len ) {
			$lt = strpos( $html, '<', $pos );
			if ( false === $lt || $lt + 1 >= $len ) {
				break;
			}
			$next = $html[ $lt + 1 ];

			if ( '!' === $next ) {
				if ( '<!--' === substr( $html, $lt, 4 ) ) {
					$close = strpos( $html, '-->', $lt + 4 );
					$pos   = false === $close ? $len : $close + 3;
				} else {
					$close = strpos( $html, '>', $lt + 2 );
					$pos   = false === $close ? $len : $close + 1;
				}
				continue;
			}
			if ( '?' === $next ) {
				$close = strpos( $html, '>', $lt + 2 );
				$pos   = false === $close ? $len : $close + 1;
				continue;
			}

			$end_tag    = '/' === $next;
			$name_start = $lt + ( $end_tag ? 2 : 1 );
			if ( $name_start >= $len || ! ctype_alpha( $html[ $name_start ] ) ) {
				if ( $end_tag ) {
					$close = strpos( $html, '>', $lt + 2 ); // "</" + non-letter is a bogus comment.
					$pos   = false === $close ? $len : $close + 1;
				} else {
					$pos = $lt + 1;
				}
				continue;
			}

			$name_len = strcspn( $html, " \t\n\f\r/>", $name_start );
			$name     = strtolower( substr( $html, $name_start, $name_len ) );
			$parsed   = self::attributes( $html, $name_start + $name_len );
			if ( null === $parsed ) {
				break; // The tag never ends.
			}
			$tags[] = array(
				'name'    => $name,
				'end_tag' => $end_tag,
				'start'   => $lt,
				'end'     => $parsed['end'],
				'attrs'   => $parsed['attrs'],
			);
			$pos    = $parsed['end'];

			if ( ! $end_tag && in_array( $name, array( 'script', 'style', 'textarea', 'title' ), true ) ) {
				if ( ! preg_match( '#</' . $name . '[\s/>]#i', $html, $m, PREG_OFFSET_CAPTURE, $pos ) ) {
					break;
				}
				$pos = $m[0][1];
			}
		}
		return $tags;
	}

	/**
	 * Reads a tag's attributes, starting right after its name.
	 *
	 * @param string $html Content.
	 * @param int    $pos  Offset after the tag name.
	 * @return array|null end (offset after ">") and attrs, or null when the tag never ends.
	 */
	private static function attributes( $html, $pos ) {
		$len   = strlen( $html );
		$attrs = array();
		$space = " \t\n\f\r";
		while ( true ) {
			$pos += strspn( $html, $space . '/', $pos );
			if ( $pos >= $len ) {
				return null;
			}
			if ( '>' === $html[ $pos ] ) {
				return array(
					'end'   => $pos + 1,
					'attrs' => $attrs,
				);
			}
			// An attribute name may start with "=" and runs to a space, "/", ">" or "=".
			$name_len = 1 + strcspn( $html, $space . '/>=', $pos + 1 );
			$name     = strtolower( substr( $html, $pos, $name_len ) );
			$pos     += $name_len;
			$after    = $pos + strspn( $html, $space, $pos );
			$attr     = array(
				'name'  => $name,
				'value' => '',
				'start' => $pos,
				'end'   => $pos,
				'quote' => '',
				'bare'  => true,
			);
			if ( $after < $len && '=' === $html[ $after ] ) {
				$pos = $after + 1 + strspn( $html, $space, $after + 1 );
				if ( $pos >= $len ) {
					return null;
				}
				$quote = $html[ $pos ];
				if ( '"' === $quote || "'" === $quote ) {
					$close = strpos( $html, $quote, $pos + 1 );
					if ( false === $close ) {
						return null;
					}
					$attr['start'] = $pos + 1;
					$attr['end']   = $close;
					$attr['quote'] = $quote;
					$pos           = $close + 1;
				} else {
					$value_len     = strcspn( $html, $space . '>', $pos );
					$attr['start'] = $pos;
					$attr['end']   = $pos + $value_len;
					$pos          += $value_len;
				}
				$attr['value'] = substr( $html, $attr['start'], $attr['end'] - $attr['start'] );
				$attr['bare']  = false;
			}
			$attrs[] = $attr;
		}
	}

	/**
	 * The first attribute of a name, as browsers use it (later duplicates are ignored).
	 *
	 * @param array  $tag  Tag from tags().
	 * @param string $name Lower-case attribute name.
	 * @return array|null
	 */
	private static function attribute( $tag, $name ) {
		foreach ( $tag['attrs'] as $attr ) {
			if ( $attr['name'] === $name ) {
				return $attr['bare'] ? null : $attr;
			}
		}
		return null;
	}
}
