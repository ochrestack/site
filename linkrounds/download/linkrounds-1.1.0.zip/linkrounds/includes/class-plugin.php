<?php
/**
 * Wires the plugin into WordPress.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Registers hooks.
 */
class Plugin {

	/**
	 * Adds the plugin's hooks.
	 */
	public static function init() {
		add_action( 'init', array( 'Linkrounds\\Installer', 'maybe_install' ) );
		add_action( 'linkrounds_batch', array( 'Linkrounds\\Scanner', 'run_batch' ) );
		add_action( 'linkrounds_confirm', array( 'Linkrounds\\Scanner', 'run_confirmations' ) );
		add_action( 'linkrounds_daily_recheck', array( 'Linkrounds\\Scanner', 'run_daily_recheck' ) );
		add_action( 'linkrounds_watchdog', array( 'Linkrounds\\Scanner', 'revive' ) );

		add_action( 'wp_after_insert_post', array( __CLASS__, 'post_saved' ), 20, 2 );
		add_action( 'trashed_post', array( __CLASS__, 'post_removed' ) );
		add_action( 'deleted_post', array( __CLASS__, 'post_removed' ) );
		add_action( 'wp_update_nav_menu_item', array( __CLASS__, 'menu_item_saved' ), 20, 2 );

		if ( is_admin() ) {
			Admin::init();
		}
	}

	/**
	 * Re-reads a post's links when it is saved and queues them for a re-check, so fixed links
	 * leave the list without a new full scan.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 */
	public static function post_saved( $post_id, $post ) {
		if ( ! $post instanceof \WP_Post || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		if ( 'nav_menu_item' === $post->post_type ) {
			return; // Menu item addresses are saved after the post; see menu_item_saved().
		}
		self::refresh( $post_id );
	}

	/**
	 * Re-reads a menu item after its address is saved.
	 *
	 * @param int $menu_id Menu ID.
	 * @param int $item_id Menu item ID.
	 */
	public static function menu_item_saved( $menu_id, $item_id ) {
		self::refresh( $item_id );
	}

	/**
	 * Forgets the links of a trashed or deleted post.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function post_removed( $post_id ) {
		if ( get_option( 'linkrounds_db_version' ) ) {
			Store::forget_post( (int) $post_id );
		}
	}

	/**
	 * Collects a post's links and schedules their checks.
	 *
	 * @param int $post_id Post ID.
	 */
	private static function refresh( $post_id ) {
		if ( ! get_option( 'linkrounds_db_version' ) ) {
			return;
		}
		$state = Scanner::state();
		Collector::collect_post( $post_id, (int) $state['id'], true );
		if ( Store::count_queued() > 0 && 'paused' !== $state['state'] ) {
			Scanner::schedule_batch();
		}
	}
}
