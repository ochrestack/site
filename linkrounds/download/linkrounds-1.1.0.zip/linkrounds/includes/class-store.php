<?php
/**
 * Database access for the links and link-instances tables.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own tables; rows change during every scan, so object caching would only serve stale results.

/**
 * Two tables: one row per unique checked address (links), and one row per place an
 * address appears (instances: a post or menu item, the tag type and the occurrence).
 */
class Store {

	/**
	 * Links table name.
	 *
	 * @return string
	 */
	public static function links_table() {
		global $wpdb;
		return $wpdb->prefix . 'linkrounds_links';
	}

	/**
	 * Instances table name.
	 *
	 * @return string
	 */
	public static function instances_table() {
		global $wpdb;
		return $wpdb->prefix . 'linkrounds_instances';
	}

	/**
	 * Current time in GMT, MySQL format.
	 *
	 * @return string
	 */
	public static function now() {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * A link row by address.
	 *
	 * @param string $url Check address.
	 * @return object|null
	 */
	public static function find_link( $url ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE url_hash = %s', self::links_table(), md5( $url ) ) );
	}

	/**
	 * A link row by ID.
	 *
	 * @param int $id Link ID.
	 * @return object|null
	 */
	public static function get_link( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', self::links_table(), $id ) );
	}

	/**
	 * Returns the ID of the link row for an address, creating it (queued) when new.
	 *
	 * @param string $url   Check address.
	 * @param bool   $queue Queue an existing link for checking too.
	 * @return int
	 */
	public static function ensure_link( $url, $queue ) {
		global $wpdb;
		$row = self::find_link( $url );
		if ( $row ) {
			if ( $queue && ! (int) $row->queued ) {
				self::update_link( (int) $row->id, array( 'queued' => 1 ) );
			}
			return (int) $row->id;
		}
		$wpdb->insert(
			self::links_table(),
			array(
				'url_hash'  => md5( $url ),
				'url'       => $url,
				'host'      => Url_Guard::host( $url ),
				'status'    => 'unchecked',
				'detail'    => '',
				'final_url' => '',
				'queued'    => 1,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Updates a link row.
	 *
	 * @param int   $id   Link ID.
	 * @param array $data Column => value.
	 */
	public static function update_link( $id, array $data ) {
		global $wpdb;
		$wpdb->update( self::links_table(), $data, array( 'id' => (int) $id ) );
	}

	/**
	 * Deletes links that no longer appear anywhere.
	 *
	 * @param int[]|null $ids Limit to these links, or null for all.
	 */
	public static function delete_orphan_links( $ids = null ) {
		global $wpdb;
		if ( is_array( $ids ) ) {
			$ids = array_filter( array_map( 'absint', $ids ) );
			foreach ( $ids as $id ) {
				$used = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE link_id = %d', self::instances_table(), $id ) );
				if ( ! (int) $used ) {
					$wpdb->delete( self::links_table(), array( 'id' => $id ), array( '%d' ) );
				}
			}
			return;
		}
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE id NOT IN ( SELECT link_id FROM %i )', self::links_table(), self::instances_table() ) );
	}

	/**
	 * Instances in one post or menu item.
	 *
	 * @param int $post_id Post ID.
	 * @return object[]
	 */
	public static function instances_for_post( $post_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE post_id = %d ORDER BY id', self::instances_table(), $post_id ) );
	}

	/**
	 * One instance joined with its link.
	 *
	 * @param int $id Instance ID.
	 * @return object|null
	 */
	public static function get_instance( $id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT i.*, l.url, l.status, l.http_code, l.reason_key, l.detail, l.final_url, l.first_failure_at, l.broken_since, l.last_checked, l.queued, l.internal
				FROM %i i INNER JOIN %i l ON l.id = i.link_id WHERE i.id = %d',
				self::instances_table(),
				self::links_table(),
				$id
			)
		);
	}

	/**
	 * Adds an instance.
	 *
	 * @param array $data Column => value.
	 * @return int
	 */
	public static function insert_instance( array $data ) {
		global $wpdb;
		$wpdb->insert( self::instances_table(), $data );
		return (int) $wpdb->insert_id;
	}

	/**
	 * Updates an instance.
	 *
	 * @param int   $id   Instance ID.
	 * @param array $data Column => value.
	 */
	public static function update_instance( $id, array $data ) {
		global $wpdb;
		$wpdb->update( self::instances_table(), $data, array( 'id' => (int) $id ) );
	}

	/**
	 * Deletes instances by ID.
	 *
	 * @param int[] $ids Instance IDs.
	 */
	public static function delete_instances( array $ids ) {
		global $wpdb;
		foreach ( array_filter( array_map( 'absint', $ids ) ) as $id ) {
			$wpdb->delete( self::instances_table(), array( 'id' => $id ), array( '%d' ) );
		}
	}

	/**
	 * Removes every instance of a post and the links that were used only there.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function forget_post( $post_id ) {
		global $wpdb;
		$link_ids = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT link_id FROM %i WHERE post_id = %d', self::instances_table(), $post_id ) );
		if ( empty( $link_ids ) ) {
			return;
		}
		$wpdb->delete( self::instances_table(), array( 'post_id' => (int) $post_id ), array( '%d' ) );
		self::delete_orphan_links( $link_ids );
	}

	/**
	 * Removes instances that were not seen in a finished collection pass.
	 *
	 * @param int $scan_id Scan ID.
	 */
	public static function forget_unseen( $scan_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE scan_id <> %d', self::instances_table(), $scan_id ) );
		self::delete_orphan_links();
	}

	/**
	 * Queues links by status.
	 *
	 * @param string[] $statuses Statuses.
	 * @return int Rows queued.
	 */
	public static function queue_statuses( array $statuses ) {
		global $wpdb;
		$count = 0;
		foreach ( $statuses as $status ) {
			$count += (int) $wpdb->query( $wpdb->prepare( 'UPDATE %i SET queued = 1 WHERE status = %s AND queued = 0', self::links_table(), $status ) );
		}
		return $count;
	}

	/**
	 * Queues links whose first hard failure is older than the wait and which are not Broken yet.
	 *
	 * @param string $before GMT datetime.
	 * @return int Rows queued.
	 */
	public static function queue_due_confirmations( $before ) {
		global $wpdb;
		return (int) $wpdb->query( $wpdb->prepare( "UPDATE %i SET queued = 1 WHERE first_failure_at IS NOT NULL AND first_failure_at <= %s AND status <> 'broken' AND queued = 0", self::links_table(), $before ) );
	}

	/**
	 * The earliest first hard failure still waiting for confirmation.
	 *
	 * @return string|null GMT datetime.
	 */
	public static function earliest_pending_confirmation() {
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare( "SELECT MIN(first_failure_at) FROM %i WHERE first_failure_at IS NOT NULL AND status <> 'broken'", self::links_table() ) );
	}

	/**
	 * Queued links, oldest first.
	 *
	 * @param int $limit Maximum rows.
	 * @return object[]
	 */
	public static function next_queued( $limit ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT id, url, host FROM %i WHERE queued = 1 ORDER BY id LIMIT %d', self::links_table(), $limit ) );
	}

	/**
	 * Number of queued links.
	 *
	 * @return int
	 */
	public static function count_queued() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE queued = 1', self::links_table() ) );
	}

	/**
	 * Number of unique addresses.
	 *
	 * @return int
	 */
	public static function count_links() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', self::links_table() ) );
	}

	/**
	 * Number of places links appear.
	 *
	 * @return int
	 */
	public static function count_instances() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', self::instances_table() ) );
	}

	/**
	 * All link rows (ID and address), for re-applying exclusions.
	 *
	 * @return object[]
	 */
	public static function all_link_urls() {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT id, url FROM %i', self::links_table() ) );
	}

	/**
	 * Deletes links and all their instances.
	 *
	 * @param int[] $ids Link IDs.
	 */
	public static function delete_links( array $ids ) {
		global $wpdb;
		foreach ( array_filter( array_map( 'absint', $ids ) ) as $id ) {
			$wpdb->delete( self::instances_table(), array( 'link_id' => $id ), array( '%d' ) );
			$wpdb->delete( self::links_table(), array( 'id' => $id ), array( '%d' ) );
		}
	}

	/**
	 * Deletes all instances in posts of the given types.
	 *
	 * @param string[] $types Post types.
	 */
	public static function forget_post_types( array $types ) {
		global $wpdb;
		foreach ( $types as $type ) {
			$wpdb->query(
				$wpdb->prepare(
					'DELETE FROM %i WHERE post_id IN ( SELECT ID FROM %i WHERE post_type = %s )',
					self::instances_table(),
					$wpdb->posts,
					$type
				)
			);
		}
		self::delete_orphan_links();
	}
}
