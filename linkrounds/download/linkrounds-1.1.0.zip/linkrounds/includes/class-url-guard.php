<?php
/**
 * Address helpers and the guard that keeps checks away from private networks.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Normalises addresses and decides whether the server may request them.
 */
class Url_Guard {

	/**
	 * Makes an address found in content absolute, or returns '' when it is not an http(s) link.
	 *
	 * @param string $raw  Address as written.
	 * @param string $base Address of the page it appears on.
	 * @return string
	 */
	public static function absolutize( $raw, $base ) {
		$raw = trim( $raw );
		if ( '' === $raw || '#' === $raw[0] ) {
			return '';
		}
		if ( preg_match( '#^([a-z][a-z0-9+.-]*):#i', $raw, $m ) ) {
			$scheme = strtolower( $m[1] );
			return in_array( $scheme, array( 'http', 'https' ), true ) && preg_match( '#^https?://[^/?\#]#i', $raw ) ? $raw : '';
		}
		if ( 0 === strpos( $raw, '//' ) ) {
			$scheme = wp_parse_url( home_url(), PHP_URL_SCHEME );
			return ( $scheme ? $scheme : 'https' ) . ':' . $raw;
		}
		return \WP_Http::make_absolute_url( $raw, $base );
	}

	/**
	 * The address that is actually checked: absolute, fragment removed, scheme and host lower-cased.
	 *
	 * @param string $url Absolute address.
	 * @return string
	 */
	public static function check_url( $url ) {
		$hash = strpos( $url, '#' );
		if ( false !== $hash ) {
			$url = substr( $url, 0, $hash );
		}
		if ( preg_match( '#^(https?)://([^/?\#]+)(.*)$#is', $url, $m ) ) {
			$url = strtolower( $m[1] ) . '://' . strtolower( $m[2] ) . ( '' === $m[3] ? '/' : $m[3] );
		}
		return $url;
	}

	/**
	 * Host of an address, lower-cased, without IPv6 brackets.
	 *
	 * @param string $url Address.
	 * @return string
	 */
	public static function host( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		return strtolower( trim( (string) $host, '[]' ) );
	}

	/**
	 * Whether the host is this site's own host (with or without "www.").
	 *
	 * @param string $host Host.
	 * @return bool
	 */
	public static function is_own_host( $host ) {
		$own = array();
		foreach ( array( home_url(), site_url() ) as $url ) {
			$h = self::host( $url );
			if ( '' !== $h ) {
				$own[] = $h;
				$own[] = 0 === strpos( $h, 'www.' ) ? substr( $h, 4 ) : 'www.' . $h;
			}
		}
		return in_array( strtolower( $host ), $own, true );
	}

	/**
	 * Ports on which the site's own host may be requested even when it resolves to a private
	 * address: the standard web ports, as in WordPress core's own safe-request check, plus the
	 * port of the site address.
	 *
	 * @return int[]
	 */
	private static function own_ports() {
		$ports = array( 80, 443, 8080 );
		foreach ( array( home_url(), site_url() ) as $url ) {
			$port = wp_parse_url( $url, PHP_URL_PORT );
			if ( $port ) {
				$ports[] = (int) $port;
			}
		}
		return $ports;
	}

	/**
	 * Resolves a host to its IP addresses. IP literals are returned as they are.
	 *
	 * @param string $host Host.
	 * @return string[] Empty when the name does not resolve.
	 */
	public static function resolve( $host ) {
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return array( $host );
		}
		$numeric = self::numeric_ipv4( $host );
		if ( null !== $numeric ) {
			return array( $numeric );
		}
		/**
		 * Short-circuits DNS resolution, for tests or custom resolvers.
		 *
		 * @param string[]|null $ips  Addresses, or null to use the system resolver.
		 * @param string        $host Host name.
		 */
		$pre = apply_filters( 'linkrounds_pre_resolve', null, $host );
		if ( is_array( $pre ) ) {
			return $pre;
		}
		if ( '' === $host || ! preg_match( '/^[a-z0-9._-]+$/i', $host ) || '.invalid' === substr( $host, -8 ) ) {
			return array();
		}
		$ips = gethostbynamel( $host );
		$ips = is_array( $ips ) ? $ips : array();
		if ( empty( $ips ) && function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- dns_get_record() warns on lookup failures, which are handled below.
			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( ! empty( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}
		return array_values( array_unique( $ips ) );
	}

	/**
	 * Reads the shorthand IPv4 forms that system resolvers accept (2130706433, 0177.0.0.1,
	 * 0x7f.1, 127.1) so they are judged as the address they really are.
	 *
	 * @param string $host Host.
	 * @return string|null Dotted IPv4 address, or null when the host is not numeric.
	 */
	public static function numeric_ipv4( $host ) {
		if ( ! preg_match( '/^(0x[0-9a-f]+|[0-9]+)(\.(0x[0-9a-f]+|[0-9]+)){0,3}$/i', $host ) ) {
			return null;
		}
		$parts  = explode( '.', strtolower( $host ) );
		$values = array();
		foreach ( $parts as $part ) {
			if ( 0 === strpos( $part, '0x' ) ) {
				$values[] = hexdec( substr( $part, 2 ) );
			} elseif ( strlen( $part ) > 1 && '0' === $part[0] ) {
				if ( preg_match( '/[89]/', $part ) ) {
					return null;
				}
				$values[] = octdec( $part );
			} else {
				$values[] = (float) $part;
			}
		}
		$last  = array_pop( $values );
		$count = count( $values );
		foreach ( $values as $value ) {
			if ( $value > 255 ) {
				return null;
			}
		}
		if ( $last >= pow( 256, 4 - $count ) ) {
			return null;
		}
		$number = $last;
		foreach ( $values as $i => $value ) {
			$number += $value * pow( 256, 3 - $i );
		}
		return long2ip( (int) $number );
	}

	/**
	 * Whether an IP address is private, loopback, link-local or otherwise not public.
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	public static function is_private_ip( $ip ) {
		$packed = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Invalid input returns false, handled below.
		if ( false === $packed ) {
			return true;
		}
		if ( 16 === strlen( $packed ) ) {
			// IPv4-mapped, IPv4-compatible-translated (NAT64) and 6to4 addresses embed an IPv4 address.
			if ( 0 === strncmp( $packed, str_repeat( "\0", 10 ) . "\xff\xff", 12 ) || 0 === strncmp( $packed, "\x00\x64\xff\x9b" . str_repeat( "\0", 8 ), 12 ) ) {
				return self::is_private_ip( inet_ntop( substr( $packed, 12 ) ) );
			}
			if ( 0 === strncmp( $packed, "\x20\x02", 2 ) ) {
				return self::is_private_ip( inet_ntop( substr( $packed, 2, 4 ) ) );
			}
			$blocks = array( '::/128', '::1/128', 'fc00::/7', 'fe80::/10', 'fec0::/10', 'ff00::/8', '100::/64', '2001:db8::/32' );
		} else {
			$blocks = array( '0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16', '172.16.0.0/12', '192.0.0.0/24', '192.0.2.0/24', '192.168.0.0/16', '198.18.0.0/15', '198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/4', '240.0.0.0/4' );
		}
		foreach ( $blocks as $block ) {
			list( $net, $bits ) = explode( '/', $block );
			$net_packed         = inet_pton( $net );
			if ( strlen( $net_packed ) !== strlen( $packed ) ) {
				continue;
			}
			$bytes = intdiv( (int) $bits, 8 );
			$rest  = (int) $bits % 8;
			if ( substr( $packed, 0, $bytes ) !== substr( $net_packed, 0, $bytes ) ) {
				continue;
			}
			if ( 0 === $rest ) {
				return true;
			}
			$mask = ( 0xff << ( 8 - $rest ) ) & 0xff;
			if ( ( ord( $packed[ $bytes ] ) & $mask ) === ( ord( $net_packed[ $bytes ] ) & $mask ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Decides whether an address may be requested.
	 *
	 * @param string $url Absolute address.
	 * @return array ok (bool), reason ('' | 'dns' | 'private' | 'invalid'), ips (string[]), detail.
	 */
	public static function inspect( $url ) {
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			return array(
				'ok'     => false,
				'reason' => 'invalid',
				'ips'    => array(),
				'detail' => '',
			);
		}
		$host = self::host( $url );
		$port = wp_parse_url( $url, PHP_URL_PORT );
		if ( preg_match( '/[^\x20-\x7e]/', $host ) ) {
			$ascii = function_exists( 'idn_to_ascii' ) ? idn_to_ascii( $host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46 ) : false;
			if ( ! $ascii ) {
				return array(
					'ok'     => false,
					'reason' => 'idn',
					'ips'    => array(),
					'detail' => $host,
				);
			}
			$host = strtolower( $ascii );
		}
		$ips = self::resolve( $host );
		if ( empty( $ips ) ) {
			return array(
				'ok'     => false,
				'reason' => 'dns',
				'ips'    => array(),
				'detail' => $host,
			);
		}
		$port_number = $port ? (int) $port : ( 0 === stripos( $url, 'https://' ) ? 443 : 80 );
		$own         = self::is_own_host( $host ) && in_array( $port_number, self::own_ports(), true );
		foreach ( $ips as $ip ) {
			if ( self::is_private_ip( $ip ) && ! $own ) {
				/**
				 * Allows requests to a private or loopback address. Off by default: links in content
				 * must not make the server reach into its own network.
				 *
				 * @param bool   $allowed Whether to allow the request.
				 * @param string $ip      Resolved address.
				 * @param string $host    Host name.
				 * @param int    $port    Port, or 0.
				 */
				if ( ! apply_filters( 'linkrounds_allow_private_address', false, $ip, $host, (int) $port ) ) {
					return array(
						'ok'     => false,
						'reason' => 'private',
						'ips'    => $ips,
						'detail' => $ip,
					);
				}
			}
		}
		return array(
			'ok'     => true,
			'reason' => '',
			'ips'    => $ips,
			'detail' => '',
			'host'   => $host,
			'port'   => $port ? (int) $port : ( 0 === stripos( $url, 'https://' ) ? 443 : 80 ),
		);
	}
}
