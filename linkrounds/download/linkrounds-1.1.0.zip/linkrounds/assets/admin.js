/* Linkrounds admin screen: live progress, row actions without a page reload, inline Edit address. */
( function () {
	'use strict';

	var cfg = window.linkroundsAdmin;
	if ( ! cfg ) {
		return;
	}

	function post( data ) {
		var body = new URLSearchParams();
		Object.keys( data ).forEach( function ( key ) {
			body.append( key, data[ key ] );
		} );
		return fetch( cfg.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} ).then( function ( response ) {
			return response.json();
		} );
	}

	function notify( message, ok ) {
		var region = document.getElementById( 'linkrounds-live' );
		if ( ! region ) {
			region = document.createElement( 'div' );
			region.id = 'linkrounds-live';
			region.setAttribute( 'aria-live', 'polite' );
			var heading = document.querySelector( '.linkrounds-wrap h1' );
			heading.parentNode.insertBefore( region, heading.nextSibling );
		}
		region.className = 'notice ' + ( ok ? 'notice-success' : 'notice-error' );
		region.innerHTML = '';
		var p = document.createElement( 'p' );
		p.textContent = message;
		region.appendChild( p );
	}

	/* Live progress while a scan runs. */
	var scan = document.getElementById( 'linkrounds-scan' );
	function poll() {
		post( { action: 'linkrounds_progress', _ajax_nonce: cfg.progressNonce } ).then( function ( res ) {
			if ( ! res || ! res.success ) {
				return;
			}
			var d = res.data;
			var text = scan.querySelector( '.linkrounds-progress-text' );
			var bar = scan.querySelector( '.linkrounds-progress' );
			if ( text ) {
				text.textContent = d.text;
			}
			if ( bar ) {
				bar.value = d.percent;
				bar.textContent = d.percent + '%';
			}
			if ( 'running' === d.state ) {
				window.setTimeout( poll, 3000 );
			} else if ( 'done' === d.state ) {
				window.location.reload();
			}
		} ).catch( function () {
			window.setTimeout( poll, 10000 );
		} );
	}
	if ( scan && 'running' === scan.getAttribute( 'data-state' ) ) {
		window.setTimeout( poll, 1500 );
	}

	/* Row actions. */
	function rowNonce( link ) {
		var match = /[?&]_wpnonce=([^&]+)/.exec( link.getAttribute( 'href' ) || '' );
		return match ? decodeURIComponent( match[ 1 ] ) : '';
	}

	function runRowAction( tr, op, nonce, extra ) {
		tr.classList.add( 'linkrounds-busy' );
		var data = {
			action: 'linkrounds_row',
			op: op,
			instance: tr.getAttribute( 'data-instance' ),
			category: cfg.category,
			_ajax_nonce: nonce
		};
		Object.keys( extra || {} ).forEach( function ( key ) {
			data[ key ] = extra[ key ];
		} );
		post( data ).then( function ( res ) {
			tr.classList.remove( 'linkrounds-busy' );
			var payload = res && res.data ? res.data : {};
			notify( payload.message || cfg.i18n.failed, !! ( res && res.success ) );
			if ( payload.counts ) {
				Object.keys( payload.counts ).forEach( function ( key ) {
					var count = document.querySelector( '.linkrounds-view-' + key + ' .count' );
					if ( count ) {
						count.textContent = '(' + Number( payload.counts[ key ] ).toLocaleString() + ')';
					}
				} );
			}
			if ( res && res.success ) {
				if ( payload.row ) {
					tr.insertAdjacentHTML( 'afterend', payload.row );
				}
				tr.parentNode.removeChild( tr );
			}
		} ).catch( function () {
			tr.classList.remove( 'linkrounds-busy' );
			notify( cfg.i18n.failed, false );
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest( 'a.linkrounds-row-action' );
		if ( link ) {
			var tr = link.closest( 'tr' );
			var op = link.getAttribute( 'data-op' );
			event.preventDefault();
			if ( 'edit' === op ) {
				var form = tr.querySelector( '.linkrounds-edit' );
				if ( form ) {
					form.hidden = false;
					form.querySelector( 'input' ).focus();
				}
				return;
			}
			var unlinkNonce = rowNonce( link );
			runRowAction( tr, op, unlinkNonce );
			return;
		}

		var save = event.target.closest( '.linkrounds-edit-save' );
		if ( save ) {
			var row = save.closest( 'tr' );
			var input = row.querySelector( '.linkrounds-edit input' );
			var any = row.querySelector( 'a.linkrounds-row-action[data-op="recheck"]' );
			if ( ! input.value.trim() ) {
				notify( cfg.i18n.needUrl, false );
				return;
			}
			runRowAction( row, 'edit', rowNonce( any ), { url: input.value.trim() } );
			return;
		}

		var cancel = event.target.closest( '.linkrounds-edit-cancel' );
		if ( cancel ) {
			cancel.closest( '.linkrounds-edit' ).hidden = true;
			return;
		}

		var dismiss = event.target.closest( '.linkrounds-review-dismiss' );
		if ( dismiss ) {
			event.preventDefault();
			post( { action: 'linkrounds_dismiss_review', _ajax_nonce: cfg.reviewNonce } );
			var prompt = document.getElementById( 'linkrounds-review' );
			if ( prompt ) {
				prompt.parentNode.removeChild( prompt );
			}
		}
	} );

	/* Show the new-address field only when the Edit address bulk action is chosen. */
	var bulkForm = document.getElementById( 'linkrounds-results-form' );
	if ( bulkForm ) {
		var field = bulkForm.querySelector( '.linkrounds-bulk-url' );
		var selects = bulkForm.querySelectorAll( 'select[name="action"], select[name="action2"]' );
		var sync = function () {
			var wantsUrl = false;
			selects.forEach( function ( select ) {
				if ( 'edit' === select.value ) {
					wantsUrl = true;
				}
			} );
			if ( field ) {
				field.hidden = ! wantsUrl;
			}
		};
		selects.forEach( function ( select ) {
			select.addEventListener( 'change', sync );
		} );
		sync();

		bulkForm.addEventListener( 'submit', function ( event ) {
			var chosen = '';
			selects.forEach( function ( select ) {
				if ( '-1' !== select.value && ! chosen ) {
					chosen = select.value;
				}
			} );
			if ( 'edit' === chosen ) {
				var urlInput = bulkForm.querySelector( '#linkrounds-bulk-url' );
				if ( ! urlInput.value.trim() ) {
					event.preventDefault();
					notify( cfg.i18n.needUrl, false );
				}
			}
		} );
	}
}() );
