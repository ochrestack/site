<?php
/**
 * Removes every table, option, scheduled event and user setting when the plugin is deleted.
 *
 * @package Linkrounds
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

require_once __DIR__ . '/includes/class-store.php';
require_once __DIR__ . '/includes/class-installer.php';

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $linkrounds_site_id ) {
		switch_to_blog( $linkrounds_site_id );
		Linkrounds\Installer::uninstall();
		restore_current_blog();
	}
} else {
	Linkrounds\Installer::uninstall();
}
