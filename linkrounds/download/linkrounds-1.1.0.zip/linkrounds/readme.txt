=== Linkrounds – Broken Link Checker ===
Contributors: ochrestack
Tags: broken links, link checker, dead links, broken images, redirects
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Find broken links and images from your own server. No account, no card, no link limit. A link is called Broken only after it fails twice.

== Description ==

**No account. No credit card. No link limit.** Linkrounds finds broken links on your own server, and only calls a link broken after it fails twice.

Linkrounds adds a screen under **Tools > Linkrounds**. Click **Scan now** and it reads every published post, page and public custom post type, your synced patterns, and the links in your navigation menus (classic menus and the Navigation menus of block themes), and checks each link and image. The scan runs in small batches in the background through WordPress's scheduled tasks (WP-Cron), with a live count ("1,240 of 3,100 links checked"), and you can Pause and Resume it.

= Results you can trust =

Every link is filed in one of four categories:

* **Broken**: the page is not found (404), was removed (410), or the domain does not exist, and this happened again on a second check at least an hour after the first.
* **Redirected**: the address forwards somewhere else that works. The final address is shown.
* **Inconclusive**: the other site blocked the check, wanted a login, asked us to slow down, had a server error or did not answer in time. The reason is given in plain words. These are never counted as broken.
* **OK**: the link works.

A link that fails once is listed as Inconclusive with the time of its second check. It becomes Broken only if it fails again.

= Fixes you can undo =

Each row shows the page the link is on (with Edit and View links), the full address, the link text, the status code, the reason and when it was last checked. You can filter by category and post type, search by address, and **Re-check now** a single row.

* **Unlink** removes the link and keeps its text.
* **Edit address** changes the address of that one link.
* Both work on a single row or as bulk actions on the rows you tick, and only those rows.
* A fix changes only that link in that post, leaves the rest of the content as it was, re-checks the new address, and is saved as a normal post revision, so you can restore the old version from the post's Revisions screen. This holds even on sites that keep only one revision.
* When a block also keeps the address in its own settings (the Cover block's image, the File block, a Navigation link), Edit address changes that setting too, so the editor still opens the block normally. Unlink is not offered where removing the link alone would break the block (File and Button blocks).
* Only users who can edit a post can fix its links.

= Exclusions and automatic re-checks =

* Exclude domains or address patterns, with `*` wildcards (for example `*.example.com` or `example.com/members/*`).
* Exclude whole post types, synced patterns, or menu links.
* **Ignore** a single link; undo it from the Ignored filter.
* Broken and Inconclusive links are re-checked automatically every day.
* When you save a post, its links are re-checked, so fixed links leave the list without a new full scan.

= Gentle on your server and on other sites =

* Links to your own posts, pages and uploaded files are matched against your own content, so the scan does not send requests to your own site for them.
* Each address is requested once per scan, however many posts use it.
* Only a few requests run at a time, and no more than two go to the same site at once.
* Addresses that point into a private or local network (such as 10.x.x.x, 192.168.x.x or 127.0.0.1) are never requested; they are listed as Inconclusive with the reason.

= Who it is for =

If you clean up your links once or twice a year, this free plugin is all you need. There is no link limit and no locked feature.

Linkrounds Pro is a separate add-on, sold on ochrestack.com for a one-time price, for people who want it hands-off: scheduled full-site scans, an emailed report of what broke since the last one, and a CSV export for a client or an editor. Everything described above is in the free plugin and stays free.

= What is not checked in version 1 =

Links in custom fields, page-builder data stored outside the post content, widgets, comments, theme options and excerpts are not checked. Links in template parts and templates edited in the Site Editor (other than Navigation menus) are not checked either. If a page builder stores the link in the post content it is found, but editing inside a builder layout is not offered. Linkrounds does not highlight or strike through links on your site, and it does not add a dashboard widget or notices outside its own screen.

== External services ==

To check a link, Linkrounds requests each linked address from your server, during a scan, when you click Re-check now, in the daily re-check, and (from the moment the plugin is activated, even before the first scan) when you save a post that contains links: a HEAD request, and a GET request when the HEAD answer is not a success. That request goes to the site the link points to, with the User-Agent "Mozilla/5.0 (compatible; Linkrounds/1.0; link check)". Nothing else is sent: no data about your site, your users or your content goes to Ochrestack or to any other service. The plugin contacts nothing else, has no account, and collects no usage statistics. Links to your own posts, pages and uploads are checked against your own database and files, without a request.

== Installation ==

1. In your dashboard go to **Plugins > Add New Plugin**, search for "Linkrounds" and click **Install Now**, then **Activate**. (Or upload `linkrounds.zip` under Plugins > Add New Plugin > Upload Plugin.)
2. Open **Tools > Linkrounds** and click **Scan now**.
3. Leave the page open to watch the live count, or come back later: the scan carries on in the background.

WP-Cron starts background tasks when someone visits the site. On a site with very few visitors, keep the Linkrounds screen open while it scans (the screen keeps the scan moving), or set up a real cron job for `wp-cron.php` as your host recommends.

== Frequently Asked Questions ==

= Do I need an account, an API key or a credit card? =

No. Linkrounds runs entirely inside your WordPress site. There is nothing to sign up for.

= Is there a limit on the number of links? =

No.

= Why is a link "Inconclusive" when it works in my browser? =

Many sites refuse automated checks (403 or 999), ask for a login (401), or slow down visitors who make many requests (429). Linkrounds cannot tell whether those pages work for your readers, so it does not call them broken. Open the link to check it yourself, or Ignore it.

= Can Linkrounds still get a link wrong? =

Yes, in a few known cases, and we would rather you knew them:

* A site that answers 404 to anything that is not a web browser is reported Broken, although your readers see the page. Linkrounds identifies itself honestly as a link checker instead of pretending to be a browser. Open the link; if it works, Ignore it.
* A page that was deleted and now forwards to its site's home page is Redirected, not Broken; the reason says it lands on the home page, so you can decide.
* A server that never answers HEAD requests leaves its links Inconclusive ("no answer within 15 seconds"), never Broken.
* A file missing from your uploads folder is Broken without a web request, so if a redirect plugin or your server forwards the old file address, Linkrounds does not see that.

= Why did a link that returns 404 not show up as Broken straight away? =

A single failure can be a hiccup on the other site. Linkrounds checks again after at least an hour (you can choose 1, 6 or 24 hours under Settings) and calls the link Broken only if it fails again.

= Can I undo a fix? =

Yes. Every Unlink or Edit address is saved as a normal post revision. Open the post, go to its Revisions screen, and restore the version before the change. If your site has revisions turned off, Linkrounds tells you so in the message after the fix. Menu items have no revisions; edit them under Appearance > Menus.

= Does "Select all" fix links I cannot see? =

No. Bulk actions apply only to the rows you ticked on the screen in front of you.

= Will it slow down my site? =

Checks run in short background batches, at most a few at a time. A batch stops starting new requests after 10 seconds and ends within about 25 seconds.

= Does it work on multisite? =

Yes, per site. Each site has its own results; there is no network-wide view.

== Screenshots ==

1. Tools > Linkrounds after a scan: the results split into Broken, Redirected, Inconclusive and OK, with the page, full address, link text, status code, reason and last-checked time for each link.
2. A scan in progress, with the live count and the Pause button.
3. Inconclusive links with their reasons in plain words, including a link waiting for its second check.
4. Editing one link's address in place; only that link changes.
5. The post's Revisions screen after a fix, showing the change can be restored.
6. Settings: excluded addresses with wildcards, the content types to scan, and the wait before the second check.

== Changelog ==

= 1.1.0 =
* Scans the Navigation menus of block themes and synced patterns.
* Edit address keeps a block's own copy of the address (Cover, File, Navigation link) in step, so the editor still finds the block valid; Unlink is refused where it would break a File or Button block.
* A fix stays restorable on sites that keep only one revision.
* Ignore stays on the link you ignored when a link to the same address before it is fixed.
* Links are read with the browser's rules for attributes, so an address inside another attribute or an apostrophe in an unquoted value can no longer make a fix change the wrong text.
* A scan stopped by a killed background task carries on by itself.
* A page that forwards to its site's home page is called out in the reason.

= 1.0.0 =
* First release: Scan now under Tools, background batches through WP-Cron with live count, Pause and Resume; Broken, Redirected, Inconclusive and OK with plain-words reasons and a second check before Broken; Unlink and Edit address saved as revisions; exclusions, Ignore, daily re-checks and re-check on save.

== Upgrade Notice ==

= 1.1.0 =
Safer fixes in blocks and with few revisions, block-theme menus and synced patterns are scanned, and stalled scans resume by themselves.

= 1.0.0 =
First release.
