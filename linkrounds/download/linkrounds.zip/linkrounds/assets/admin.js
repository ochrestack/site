/* Linkrounds admin screen: live progress, row actions without a page reload, inline Edit address. */
( function () {
	'use strict';

	var cfg = window.linkroundsAdmin;
	if ( ! cfg ) {
		return;
	}

	function post( data ) {
		var body = new URLSearchParams();
		Object.keys( data ).forEach( function ( key ) {
			body.append( key, data[ key ] );
		} );
		return fetch( cfg.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} ).then( function ( response ) {
			return response.json();
		} );
	}

	/* One message at a time: a new action removes the notice the page was loaded with, the last
	   client-side notice and the last in-table result line before it shows its own. */
	function clearNotices() {
		document.querySelectorAll( '.linkrounds-wrap .linkrounds-notice, .linkrounds-row-result' ).forEach( function ( el ) {
			el.parentNode.removeChild( el );
		} );
		var live = document.getElementById( 'linkrounds-live' );
		if ( live ) {
			live.parentNode.removeChild( live );
		}
	}

	function notify( message, ok ) {
		clearNotices();
		var region = document.getElementById( 'linkrounds-live' );
		if ( ! region ) {
			region = document.createElement( 'div' );
			region.id = 'linkrounds-live';
			region.setAttribute( 'aria-live', 'polite' );
			var heading = document.querySelector( '.linkrounds-wrap h1' );
			heading.parentNode.insertBefore( region, heading.nextSibling );
		}
		region.className = 'notice ' + ( ok ? 'notice-success' : 'notice-error' );
		region.innerHTML = '';
		var p = document.createElement( 'p' );
		p.textContent = message;
		region.appendChild( p );
	}

	/* Puts fresh numbers into the category links (All, Broken, Waiting …) above the table, and the
	   fresh "look broken" line above them. */
	function updateCounts( counts, waiting ) {
		var slot = document.getElementById( 'linkrounds-waiting-slot' );
		if ( slot && 'string' === typeof waiting ) {
			slot.innerHTML = waiting;
		}
		if ( ! counts ) {
			return;
		}
		Object.keys( counts ).forEach( function ( key ) {
			var count = document.querySelector( '.linkrounds-view-' + key + ' .count' );
			if ( count ) {
				count.textContent = '(' + Number( counts[ key ] ).toLocaleString() + ')';
			}
		} );
	}

	/* Live progress while a scan runs. */
	var scan = document.getElementById( 'linkrounds-scan' );
	var pendingAtLoad = scan && '1' === scan.getAttribute( 'data-pending' );
	function poll() {
		post( { action: 'linkrounds_progress', _ajax_nonce: cfg.progressNonce } ).then( function ( res ) {
			if ( ! res || ! res.success ) {
				return;
			}
			var d = res.data;
			var text = scan.querySelector( '.linkrounds-progress-text' );
			var bar = scan.querySelector( '.linkrounds-progress' );
			if ( text ) {
				text.textContent = d.text;
			}
			if ( bar ) {
				bar.value = d.percent;
				bar.textContent = d.percent + '%';
			}
			updateCounts( d.counts, d.waiting );
			if ( 'running' === d.state || d.pending ) {
				window.setTimeout( poll, 3000 );
			} else if ( 'done' === d.state || pendingAtLoad ) {
				window.location.reload();
			}
		} ).catch( function () {
			window.setTimeout( poll, 10000 );
		} );
	}
	/* While a scan runs, or checks are queued or due (second checks, re-checks), the open screen
	   keeps asking; that keeps the work moving on a site with no visitors, then shows the result. */
	if ( scan && ( 'running' === scan.getAttribute( 'data-state' ) || pendingAtLoad ) ) {
		window.setTimeout( poll, 1500 );
	} else if ( scan ) {
		/* Links that failed once: start asking when their second check is due. */
		var dueIn = parseInt( scan.getAttribute( 'data-due-in' ) || '0', 10 );
		if ( dueIn > 0 && dueIn <= 86400 ) {
			window.setTimeout( function () {
				pendingAtLoad = true;
				poll();
			}, ( dueIn + 5 ) * 1000 );
		}
	}

	/* A row that left this view (fixed, ignored, now in another category): the "N items" count above and below
	   the table follows, and an empty table says so instead of showing only its header. */
	function rowLeftView( body ) {
		document.querySelectorAll( '.displaying-num' ).forEach( function ( el ) {
			var n = parseInt( el.textContent.replace( /[^0-9]/g, '' ), 10 );
			if ( ! isNaN( n ) && n > 0 ) {
				n -= 1;
				el.textContent = ( 1 === n ? cfg.i18n.itemsOne : cfg.i18n.itemsMany ).replace( '%s', n.toLocaleString() );
			}
		} );
		if ( ! body.querySelector( 'tr[data-instance]' ) ) {
			var cols = document.querySelectorAll( '.linkrounds-results thead th, .linkrounds-results thead td' ).length || 6;
			body.insertAdjacentHTML( 'beforeend', '<tr class="no-items"><td class="colspanchange" colspan="' + cols + '"></td></tr>' );
			body.querySelector( '.no-items td' ).textContent = cfg.i18n.emptyView;
		}
	}

	/* Row actions. */
	function rowNonce( link ) {
		var match = /[?&]_wpnonce=([^&]+)/.exec( link.getAttribute( 'href' ) || '' );
		return match ? decodeURIComponent( match[ 1 ] ) : '';
	}

	/* The result of a row action is shown in the table, where the row was, so it is on screen
	   wherever on the page the row is. The line above the table is not used for row actions. */
	function resultRow( tr, message, ok ) {
		var cols = tr.children.length || 1;
		var row = document.createElement( 'tr' );
		row.className = 'linkrounds-row-result';
		var cell = document.createElement( 'td' );
		cell.colSpan = cols;
		cell.className = 'linkrounds-row-result-cell ' + ( ok ? 'is-ok' : 'is-error' );
		cell.setAttribute( 'role', ok ? 'status' : 'alert' );
		cell.textContent = message;
		row.appendChild( cell );
		return row;
	}

	function editError( tr, message ) {
		var box = tr.querySelector( '.linkrounds-edit-error' );
		var input = tr.querySelector( '.linkrounds-edit-url' );
		if ( ! box ) {
			return false;
		}
		box.textContent = message;
		box.hidden = false;
		if ( input ) {
			input.focus();
		}
		// The field grows with a long address, so the reason can fall under the bottom of the window: bring it into view.
		box.scrollIntoView( { block: 'nearest' } );
		return true;
	}

	/* The address field grows with its text, so a long address is never cut (a textarea wraps; an input cannot). */
	function fitField( field ) {
		field.style.height = 'auto';
		field.style.height = field.scrollHeight + 2 + 'px';
	}

	function closeEditor( tr ) {
		var form = tr.querySelector( '.linkrounds-edit' );
		if ( form ) {
			form.hidden = true;
			var box = form.querySelector( '.linkrounds-edit-error' );
			if ( box ) {
				box.hidden = true;
			}
		}
		tr.classList.remove( 'is-editing' );
	}

	/* Switches Export CSV (a Pro button beside Filter) off when the view has no rows to export. */
	function syncNeedsRows( body ) {
		var empty = ! body.querySelector( 'tr[data-instance]' );
		document.querySelectorAll( '[data-linkrounds-needs-rows]' ).forEach( function ( button ) {
			button.disabled = empty;
			if ( empty ) {
				button.setAttribute( 'title', button.getAttribute( 'data-empty-title' ) || '' );
			} else if ( button.getAttribute( 'data-full-title' ) ) {
				button.setAttribute( 'title', button.getAttribute( 'data-full-title' ) );
			}
		} );
	}

	function runRowAction( tr, op, nonce, extra ) {
		clearNotices();
		tr.classList.add( 'linkrounds-busy' );
		var data = {
			action: 'linkrounds_row',
			op: op,
			instance: tr.getAttribute( 'data-instance' ),
			category: cfg.category,
			_ajax_nonce: nonce
		};
		Object.keys( extra || {} ).forEach( function ( key ) {
			data[ key ] = extra[ key ];
		} );
		post( data ).then( function ( res ) {
			tr.classList.remove( 'linkrounds-busy' );
			var ok = !! ( res && res.success );
			var payload = res && res.data ? res.data : {};
			var message = payload.message || cfg.i18n.failed;
			updateCounts( payload.counts, payload.waiting );
			var line = document.querySelector( '#linkrounds-scan .linkrounds-progress-text' );
			if ( line && payload.text ) {
				line.textContent = payload.text;
			}
			if ( ! ok ) {
				// A refused address is explained under the field that was typed in.
				if ( 'edit' !== op || ! editError( tr, message ) ) {
					tr.parentNode.insertBefore( resultRow( tr, message, false ), tr );
				}
				return;
			}
			var body = tr.parentNode;
			var shown = resultRow( tr, message, true );
			body.insertBefore( shown, tr );
			if ( payload.row ) {
				tr.insertAdjacentHTML( 'afterend', payload.row );
			}
			body.removeChild( tr );
			if ( ! payload.row ) {
				rowLeftView( body );
			}
			syncNeedsRows( body );
			shown.scrollIntoView( { block: 'nearest' } );
		} ).catch( function () {
			tr.classList.remove( 'linkrounds-busy' );
			tr.parentNode.insertBefore( resultRow( tr, cfg.i18n.failed, false ), tr );
		} );
	}

	function saveEdit( row ) {
		var input = row.querySelector( '.linkrounds-edit-url' );
		var any = row.querySelector( 'a.linkrounds-row-action[data-op="recheck"]' );
		if ( ! input.value.trim() ) {
			editError( row, cfg.i18n.needUrl );
			return;
		}
		runRowAction( row, 'edit', rowNonce( any ), { url: input.value.replace( /\s*[\r\n]+\s*/g, '' ).trim() } );
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest( 'a.linkrounds-row-action' );
		if ( link ) {
			var tr = link.closest( 'tr' );
			var op = link.getAttribute( 'data-op' );
			event.preventDefault();
			if ( 'edit' === op ) {
				var form = tr.querySelector( '.linkrounds-edit' );
				if ( form ) {
					form.hidden = false;
					tr.classList.add( 'is-editing' );
					var field = form.querySelector( '.linkrounds-edit-url' );
					fitField( field );
					field.focus();
				}
				return;
			}
			var unlinkNonce = rowNonce( link );
			runRowAction( tr, op, unlinkNonce );
			return;
		}

		var save = event.target.closest( '.linkrounds-edit-save' );
		if ( save ) {
			saveEdit( save.closest( 'tr' ) );
			return;
		}

		var cancel = event.target.closest( '.linkrounds-edit-cancel' );
		if ( cancel ) {
			closeEditor( cancel.closest( 'tr' ) );
			return;
		}

		var dismiss = event.target.closest( '.linkrounds-review-dismiss' );
		if ( dismiss ) {
			event.preventDefault();
			post( { action: 'linkrounds_dismiss_review', _ajax_nonce: cfg.reviewNonce } );
			var prompt = document.getElementById( 'linkrounds-review' );
			if ( prompt ) {
				prompt.parentNode.removeChild( prompt );
			}
		}
	} );

	/* The inline address field sits inside the bulk-actions form, so Enter would submit that form
	   ("Please select a bulk action"). Enter saves the edit, Escape cancels it. */
	document.addEventListener( 'keydown', function ( event ) {
		var input = event.target.closest ? event.target.closest( '.linkrounds-edit-url' ) : null;
		if ( ! input ) {
			return;
		}
		var row = input.closest( 'tr' );
		if ( 'Enter' === event.key ) {
			event.preventDefault();
			saveEdit( row );
		} else if ( 'Escape' === event.key ) {
			event.preventDefault();
			closeEditor( row );
		}
	} );
	document.addEventListener( 'input', function ( event ) {
		if ( event.target.classList && event.target.classList.contains( 'linkrounds-edit-url' ) ) {
			fitField( event.target );
		}
		var box = event.target.closest ? event.target.closest( '.linkrounds-edit' ) : null;
		if ( box && box.querySelector( '.linkrounds-edit-error' ) ) {
			box.querySelector( '.linkrounds-edit-error' ).hidden = true;
		}
	} );

	/* Narrow screens: search and filters sit behind one button, so the first result row is on the first screen. */
	var filters = document.querySelector( '.linkrounds-filters' );
	var toggle = filters ? filters.querySelector( '.linkrounds-filters-toggle' ) : null;
	if ( toggle ) {
		toggle.addEventListener( 'click', function () {
			var open = filters.classList.toggle( 'is-open' );
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );
	}

	/* Narrow screens: the yellow line says only when the second check is; More opens the whole sentence. The slot is replaced after row actions, so the click is delegated. */
	document.addEventListener( 'click', function ( event ) {
		var more = event.target.closest ? event.target.closest( '.linkrounds-waiting-toggle' ) : null;
		if ( ! more ) {
			return;
		}
		var box = more.closest( '.linkrounds-waiting' );
		var open = box.classList.toggle( 'is-open' );
		more.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		more.textContent = open ? more.getAttribute( 'data-less' ) : more.getAttribute( 'data-more' );
	} );

	/* Show the new-address field only when the Edit address bulk action is chosen. */
	var bulkForm = document.getElementById( 'linkrounds-results-form' );
	if ( bulkForm ) {
		var field = bulkForm.querySelector( '.linkrounds-bulk-url' );
		var selects = bulkForm.querySelectorAll( 'select[name="action"], select[name="action2"]' );
		var sync = function () {
			var wantsUrl = false;
			selects.forEach( function ( select ) {
				if ( 'edit' === select.value ) {
					wantsUrl = true;
				}
			} );
			if ( field ) {
				field.classList.toggle( 'is-shown', wantsUrl );
			}
		};
		selects.forEach( function ( select ) {
			select.addEventListener( 'change', sync );
		} );
		sync();

		bulkForm.addEventListener( 'submit', function ( event ) {
			var chosen = '';
			selects.forEach( function ( select ) {
				if ( '-1' !== select.value && ! chosen ) {
					chosen = select.value;
				}
			} );
			if ( 'edit' === chosen ) {
				var urlInput = bulkForm.querySelector( '#linkrounds-bulk-url' );
				if ( ! urlInput.value.trim() ) {
					event.preventDefault();
					notify( cfg.i18n.needUrl, false );
				}
			}
		} );
	}
}() );
