<?php
/**
 * The Tools > Linkrounds screen and its actions.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Admin screen, row and bulk actions, settings and the live progress endpoint.
 */
class Admin {

	const REVIEW_URL = 'https://wordpress.org/support/plugin/linkrounds/reviews/#new-post';
	const PRO_URL    = 'https://ochrestack.com/linkrounds/';
	const DOCS_URL   = 'https://ochrestack.com/linkrounds/quick-start.html';

	/**
	 * Whether this request already showed the welcome notice (Pro then waits for the next page).
	 *
	 * @var bool
	 */
	public static $welcome_shown = false;

	/**
	 * Adds admin hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'set_screen_option_linkrounds_per_page', array( __CLASS__, 'save_per_page' ), 10, 3 );
		add_filter( 'plugin_action_links_' . plugin_basename( LINKROUNDS_FILE ), array( __CLASS__, 'action_links' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_meta' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'welcome_notice' ) );
		add_action( 'load-plugins.php', array( __CLASS__, 'drop_core_activated_notice' ) );

		add_action( 'admin_post_linkrounds_scan', array( __CLASS__, 'handle_scan' ) );
		add_action( 'admin_post_linkrounds_row', array( __CLASS__, 'handle_row' ) );
		add_action( 'admin_post_linkrounds_settings', array( __CLASS__, 'handle_settings' ) );
		add_action( 'admin_post_linkrounds_dismiss_review', array( __CLASS__, 'handle_dismiss_review' ) );
		add_action( 'wp_ajax_linkrounds_progress', array( __CLASS__, 'ajax_progress' ) );
		add_action( 'wp_ajax_linkrounds_row', array( __CLASS__, 'ajax_row' ) );
		add_action( 'wp_ajax_linkrounds_dismiss_review', array( __CLASS__, 'ajax_dismiss_review' ) );
	}

	/**
	 * Capability needed to open the screen and run scans.
	 *
	 * @return string
	 */
	public static function capability() {
		/**
		 * Filters the capability needed to see Tools > Linkrounds and run scans. Fixing a link
		 * always also needs permission to edit the post it is in.
		 *
		 * @param string $capability Default 'edit_others_posts' (Editors and Administrators).
		 */
		return (string) apply_filters( 'linkrounds_capability', 'edit_others_posts' );
	}

	/**
	 * Screen URL.
	 *
	 * @param array $args Query arguments.
	 * @return string
	 */
	public static function url( array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'linkrounds' ), $args ), admin_url( 'tools.php' ) );
	}

	/**
	 * Adds Tools > Linkrounds.
	 */
	public static function menu() {
		$hook = add_management_page( __( 'Linkrounds – Broken Link Checker', 'linkrounds' ), __( 'Linkrounds', 'linkrounds' ), self::capability(), 'linkrounds', array( __CLASS__, 'render' ) );
		add_action( 'load-' . $hook, array( __CLASS__, 'load_screen' ) );
	}

	/**
	 * Screen options.
	 */
	public static function load_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_bulk() checks the nonce.
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && ( isset( $_POST['instance'] ) || isset( $_POST['_wpnonce'] ) ) ) {
			self::handle_bulk();
		}
		add_screen_option(
			'per_page',
			array(
				'label'   => __( 'Results per page', 'linkrounds' ),
				'default' => 20,
				'option'  => 'linkrounds_per_page',
			)
		);
	}

	/**
	 * Saves the per-page screen option.
	 *
	 * @param mixed  $status Default.
	 * @param string $option Option name.
	 * @param mixed  $value  Value.
	 * @return int
	 */
	public static function save_per_page( $status, $option, $value ) {
		return min( 500, max( 1, absint( $value ) ) );
	}

	/**
	 * Adds "Open Linkrounds" to the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open Linkrounds', 'linkrounds' ) . '</a>' );
		return $links;
	}

	/**
	 * Core prints "Plugin activated." above the plugin's own welcome notice, a second green box that
	 * adds nothing. While a welcome notice (this plugin's or Pro's) is due, the Plugins screen is told
	 * that nothing was just activated, so there is one message.
	 */
	public static function drop_core_activated_notice() {
		$free_due = 'pending' === get_option( 'linkrounds_welcomed' ) && current_user_can( self::capability() );
		$pro_due  = defined( 'LINKROUNDS_PRO_VERSION' ) && 'pending' === get_option( 'linkrounds_pro_welcomed' ) && current_user_can( 'manage_options' );
		if ( $free_due || $pro_due ) {
			unset( $_GET['activate'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only hides core's notice.
		}
	}

	/**
	 * Says where Linkrounds is, once, right after it is first activated. Without it the only sign
	 * is WordPress's own "Plugin activated." and a menu entry under Tools that is easy to miss.
	 */
	public static function welcome_notice() {
		if ( 'pending' !== get_option( 'linkrounds_welcomed' ) || ! current_user_can( self::capability() ) ) {
			return;
		}
		update_option( 'linkrounds_welcomed', 'shown', false );
		self::$welcome_shown = true;
		echo '<div class="notice notice-success is-dismissible linkrounds-welcome"><p>';
		esc_html_e( 'Linkrounds is under Tools > Linkrounds. Click Scan now.', 'linkrounds' );
		echo '</p><p><a class="button button-primary" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open Linkrounds', 'linkrounds' ) . '</a></p></div>';
	}

	/**
	 * Adds Documentation and Support to the plugin's row on the Plugins screen.
	 *
	 * @param string[] $links Links under the description.
	 * @param string   $file  Plugin file of the row.
	 * @return string[]
	 */
	public static function row_meta( $links, $file ) {
		if ( plugin_basename( LINKROUNDS_FILE ) === $file ) {
			$links[] = '<a href="' . esc_url( self::DOCS_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Documentation', 'linkrounds' ) . '</a>';
			$links[] = '<a href="mailto:support@ochrestack.com">' . esc_html__( 'Support: support@ochrestack.com', 'linkrounds' ) . '</a>';
		}
		return $links;
	}

	/**
	 * Loads the script and styles on the screen only.
	 *
	 * @param string $hook Screen hook.
	 */
	public static function assets( $hook ) {
		if ( 'tools_page_linkrounds' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'linkrounds-admin', plugins_url( 'assets/admin.css', LINKROUNDS_FILE ), array(), LINKROUNDS_VERSION );
		wp_enqueue_script( 'linkrounds-admin', plugins_url( 'assets/admin.js', LINKROUNDS_FILE ), array(), LINKROUNDS_VERSION, true );
		$filters = Results_Query::args_from( wp_unslash( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display filters.
		wp_localize_script(
			'linkrounds-admin',
			'linkroundsAdmin',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'progressNonce' => wp_create_nonce( 'linkrounds_progress' ),
				'reviewNonce'   => wp_create_nonce( 'linkrounds_dismiss_review' ),
				'category'      => $filters['category'],
				'i18n'          => array(
					'working'     => __( 'Working…', 'linkrounds' ),
					'failed'      => __( 'The request failed. Reload the page and try again.', 'linkrounds' ),
					'confirmBulk' => __( 'Apply this to the ticked rows only?', 'linkrounds' ),
					'needUrl'     => __( 'Enter the new address first.', 'linkrounds' ),
					/* translators: %s: number of results. */
					'itemsOne'    => __( '%s item', 'linkrounds' ),
					/* translators: %s: number of results. */
					'itemsMany'   => __( '%s items', 'linkrounds' ),
					'emptyView'   => __( 'Nothing is left in this view.', 'linkrounds' ),
				),
			)
		);
	}

	/**
	 * Renders the screen.
	 */
	public static function render() {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'linkrounds' ) );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only navigation and filters.
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'results';
		$edit = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
		// phpcs:enable

		/**
		 * Filters the tabs on the Linkrounds screen. Add-ons render their tab on the
		 * 'linkrounds_render_tab_{slug}' action.
		 *
		 * @param string[] $tabs Slug => label.
		 */
		$tabs = apply_filters(
			'linkrounds_admin_tabs',
			array(
				'results'  => __( 'Results', 'linkrounds' ),
				'settings' => __( 'Settings', 'linkrounds' ),
			)
		);
		// Settings and Schedule & email are for administrators: other users get Results only, with no tab that just refuses.
		if ( ! current_user_can( 'manage_options' ) ) {
			$tabs = array_intersect_key( $tabs, array( 'results' => true ) );
		}
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'results';
		}
		?>
		<div class="wrap linkrounds-wrap">
			<h1><?php esc_html_e( 'Linkrounds', 'linkrounds' ); ?></h1>
			<?php self::render_notice( 'page' ); ?>
			<?php if ( count( $tabs ) > 1 ) : ?>
			<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e( 'Linkrounds sections', 'linkrounds' ); ?>">
				<?php foreach ( $tabs as $slug => $label ) : ?>
					<a href="<?php echo esc_url( self::url( array( 'tab' => $slug ) ) ); ?>" class="nav-tab<?php echo $slug === $tab ? ' nav-tab-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>
			<?php endif; ?>
			<?php
			if ( $edit ) {
				self::render_edit_form( $edit );
			} elseif ( 'results' === $tab ) {
				self::render_results();
			} elseif ( 'settings' === $tab ) {
				self::render_settings();
			} else {
				/**
				 * Renders an add-on tab.
				 */
				do_action( 'linkrounds_render_tab_' . $tab );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Shows and clears the message left by the last action.
	 *
	 * The answer to Scan now, Pause and Resume is shown inside the scan box ('scan'), under the status line, so the
	 * button the user pressed keeps its place; every other message is shown under the heading ('page').
	 *
	 * @param string $scope 'page' or 'scan'.
	 */
	private static function render_notice( $scope ) {
		$notice = get_user_meta( get_current_user_id(), 'linkrounds_notice', true );
		if ( ! is_array( $notice ) || empty( $notice['messages'] ) ) {
			return;
		}
		$belongs = ! empty( $notice['scope'] ) && 'scan' === $notice['scope'] ? 'scan' : 'page';
		// The scan box exists on the Results tab only: elsewhere a scan message stays on the page scope.
		if ( $belongs !== $scope ) {
			return;
		}
		delete_user_meta( get_current_user_id(), 'linkrounds_notice' );
		$type     = in_array( $notice['type'], array( 'success', 'warning', 'error', 'info' ), true ) ? $notice['type'] : 'info';
		$messages = (array) $notice['messages'];
		// "Scan started" and "Scan resumed" must not stay above a finished scan (a small site finishes before the page loads).
		if ( ! empty( $notice['scan_started'] ) && 'done' === Scanner::progress()['state'] ) {
			$messages = array( __( 'Scan finished. The results are below.', 'linkrounds' ) );
		}
		echo '<div class="notice linkrounds-notice notice-' . esc_attr( $type ) . ( 'scan' === $scope ? ' inline' : ' is-dismissible' ) . '">';
		foreach ( $messages as $message ) {
			echo '<p>' . esc_html( $message ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * Leaves a message for the next page load.
	 *
	 * @param string[] $messages     Messages.
	 * @param string   $type         success, warning, error or info.
	 * @param bool     $scan_started Whether this is the "Scan started" or "Scan resumed" message, which is replaced by
	 *                               "Scan finished" if the scan is already done when it is shown.
	 * @param string   $scope        'scan' for the answer to Scan now, Pause and Resume (shown in the scan box), else 'page'.
	 */
	public static function add_notice( array $messages, $type = 'success', $scan_started = false, $scope = 'page' ) {
		update_user_meta(
			get_current_user_id(),
			'linkrounds_notice',
			array(
				'messages'     => array_values( array_filter( $messages ) ),
				'type'         => $type,
				'scan_started' => (bool) $scan_started,
				'scope'        => $scope,
			)
		);
	}

	/**
	 * The scan status line.
	 *
	 * @param array $p Scanner::progress().
	 * @return string
	 */
	public static function progress_text( array $p ) {
		$checked = number_format_i18n( $p['links_checked'] );
		$total   = number_format_i18n( $p['links_total'] );
		// While the content is being read, the link counts still belong to the last scan: say only how many items are read.
		$reading = 'collecting' === $p['phase'];
		$read    = number_format_i18n( $p['posts_done'] );
		// Posts published while the content is being read are read too: never "12 of 10".
		$items = number_format_i18n( max( (int) $p['posts_total'], (int) $p['posts_done'] ) );
		switch ( $p['state'] ) {
			case 'running':
				if ( $reading ) {
					/* translators: 1: posts read, 2: posts in total. */
					return sprintf( __( 'Reading your content: %1$s of %2$s posts, pages and menu items read.', 'linkrounds' ), $read, $items );
				}
				/* translators: 1: links checked, 2: links in total. */
				return sprintf( __( '%1$s of %2$s links checked', 'linkrounds' ), $checked, $total );
			case 'paused':
				if ( $reading ) {
					/* translators: 1: posts read, 2: posts in total. */
					return sprintf( __( 'Paused while reading your content: %1$s of %2$s posts, pages and menu items read. Resume continues from there.', 'linkrounds' ), $read, $items );
				}
				/* translators: 1: links checked, 2: links in total. */
				return sprintf( __( 'Paused at %1$s of %2$s links checked. Resume continues from there.', 'linkrounds' ), $checked, $total );
			case 'done':
				$line = sprintf(
					/* translators: 1: date and time, 2: number of addresses, 3: number of places. The spaces after a number are no-break spaces. */
					__( 'Last scan finished %1$s: %2$s different addresses checked, used in %3$s places.', 'linkrounds' ),
					self::unbroken( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $p['finished'] ) ),
					number_format_i18n( $p['scan_addresses'] ),
					number_format_i18n( $p['scan_places'] )
				);
				// Fixes, Ignore, exclusions and saved posts change what the list holds after the scan: say which number is which.
				$listed = (int) Results_Query::counts()['all'];
				if ( $listed !== (int) $p['scan_places'] ) {
					$line .= ' ' . sprintf(
						/* translators: %s: number of places the list holds now. The space after the number is a no-break space. */
						_n( 'Listed now: %s place.', 'Listed now: %s places.', $listed, 'linkrounds' ),
						number_format_i18n( $listed )
					);
				}
				return $line;
			default:
				$counts  = Results_Query::counts();
				$checked = (int) $counts['all'] - (int) $counts['unchecked'];
				if ( $checked > 0 ) {
					// Posts saved since activation are checked on save, so there are results before any scan.
					return sprintf(
						/* translators: %s: number of links. */
						_n(
							'Linkrounds has checked %s link in the posts you saved. Scan now reads every published post, page and menu link, then checks each address once, from this server.',
							'Linkrounds has checked %s links in the posts you saved. Scan now reads every published post, page and menu link, then checks each address once, from this server.',
							$checked,
							'linkrounds'
						),
						number_format_i18n( $checked )
					);
				}
				return __( 'No scan yet. Scan now reads every published post, page and menu link, then checks each address once, from this server.', 'linkrounds' );
		}
	}

	/**
	 * How full the progress bar is: items read while content is being read, links checked after that.
	 *
	 * @param array $p Scanner::progress().
	 * @return int
	 */
	public static function progress_percent( array $p ) {
		if ( 'collecting' === $p['phase'] ) {
			return $p['posts_total'] > 0 ? min( 100, (int) floor( 100 * $p['posts_done'] / $p['posts_total'] ) ) : 0;
		}
		return $p['links_total'] > 0 ? (int) floor( 100 * $p['links_checked'] / $p['links_total'] ) : 0;
	}

	/**
	 * The Results tab.
	 */
	private static function render_results() {
		$progress = Scanner::progress();
		$filters  = Results_Query::args_from( wp_unslash( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display filters.
		$counts   = Results_Query::counts();
		require_once LINKROUNDS_DIR . '/includes/class-results-table.php';
		$table = new Results_Table( $filters );
		$table->prepare_items();
		$percent = self::progress_percent( $progress );
		?>
		<div id="linkrounds-scan" class="linkrounds-scan" data-state="<?php echo esc_attr( $progress['state'] ); ?>" data-pending="<?php echo Scanner::has_due_work() ? '1' : '0'; ?>" data-due-in="<?php echo esc_attr( (string) Scanner::seconds_to_next_confirmation() ); ?>">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="linkrounds-scan-buttons">
				<input type="hidden" name="action" value="linkrounds_scan" />
				<?php wp_nonce_field( 'linkrounds_scan' ); ?>
				<?php if ( 'running' === $progress['state'] ) : ?>
					<button type="submit" name="op" value="pause" class="button"><?php esc_html_e( 'Pause', 'linkrounds' ); ?></button>
				<?php elseif ( 'paused' === $progress['state'] ) : ?>
					<button type="submit" name="op" value="resume" class="button button-primary"><?php esc_html_e( 'Resume', 'linkrounds' ); ?></button>
				<?php else : ?>
					<button type="submit" name="op" value="start" class="button button-primary<?php echo $progress['finished'] ? ' button-large' : ' button-hero'; ?>"><?php esc_html_e( 'Scan now', 'linkrounds' ); ?></button>
				<?php endif; ?>
			</form>
			<div class="linkrounds-scan-status">
				<p class="linkrounds-progress-text" aria-live="polite"><?php echo esc_html( self::progress_text( $progress ) ); ?></p>
				<?php if ( in_array( $progress['state'], array( 'running', 'paused' ), true ) ) : ?>
					<progress class="linkrounds-progress" max="100" value="<?php echo esc_attr( (string) $percent ); ?>"><?php echo esc_html( $percent . '%' ); ?></progress>
				<?php endif; ?>
				<?php self::render_notice( 'scan' ); ?>
				<?php if ( 'running' === $progress['state'] ) : ?>
					<p class="description linkrounds-background-note"><?php esc_html_e( 'The scan runs in small background batches, which WordPress starts when someone visits your site. On a site with few visitors, such as a staging or local copy, keep this page open until the scan finishes: the open page keeps it moving.', 'linkrounds' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div id="linkrounds-waiting-slot"><?php echo self::waiting_html( $counts['waiting'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in waiting_html(). ?></div>
		<?php self::render_review_prompt( $progress ); ?>

		<ul class="subsubsub">
			<?php
			$views = array(
				''             => __( 'All', 'linkrounds' ),
				'broken'       => __( 'Broken', 'linkrounds' ),
				'redirected'   => __( 'Redirected', 'linkrounds' ),
				'inconclusive' => __( 'Inconclusive', 'linkrounds' ),
				'ok'           => __( 'OK', 'linkrounds' ),
				'ignored'      => __( 'Ignored', 'linkrounds' ),
			);
			if ( $counts['unchecked'] > 0 ) {
				$views = array_slice( $views, 0, 5, true ) + array( 'unchecked' => __( 'Not checked yet', 'linkrounds' ) ) + array_slice( $views, 5, null, true );
			}
			if ( $counts['waiting'] > 0 || 'waiting' === $filters['category'] ) {
				$views = array_slice( $views, 0, 2, true ) + array( 'waiting' => __( 'Looks broken', 'linkrounds' ) ) + array_slice( $views, 2, null, true );
			}
			// The category links keep the search and the post type that are in force.
			$keep = array();
			if ( '' !== $filters['search'] ) {
				$keep['s'] = rawurlencode( $filters['search'] );
			}
			if ( '' !== $filters['post_type'] ) {
				$keep['lr_type'] = $filters['post_type'];
			}
			$items = array();
			foreach ( $views as $key => $label ) {
				$count   = '' === $key ? $counts['all'] : $counts[ $key ];
				$items[] = sprintf(
					'<li class="linkrounds-view-%1$s"><a href="%2$s"%3$s>%4$s <span class="count">(%5$s)</span></a></li>',
					esc_attr( '' === $key ? 'all' : $key ),
					esc_url( self::url( '' === $key ? $keep : array_merge( array( 'category' => $key ), $keep ) ) ),
					$key === $filters['category'] ? ' class="current" aria-current="page"' : '',
					esc_html( $label ),
					esc_html( number_format_i18n( $count ) )
				);
			}
			// The bars between the items are drawn by the stylesheet, so a phone can wrap them without a bar at a line end.
			echo implode( '', $items ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each item is escaped above.
			?>
		</ul>

		<?php $filters_open = '' !== $filters['search'] || '' !== $filters['post_type']; ?>
		<form method="get" class="linkrounds-filters<?php echo $filters_open ? ' is-open' : ''; ?>">
			<button type="button" class="button linkrounds-filters-toggle" aria-controls="linkrounds-filter-fields" aria-expanded="<?php echo $filters_open ? 'true' : 'false'; ?>"><?php esc_html_e( 'Search and filter', 'linkrounds' ); ?></button>
			<input type="hidden" name="page" value="linkrounds" />
			<?php if ( '' !== $filters['category'] ) : ?>
				<input type="hidden" name="category" value="<?php echo esc_attr( $filters['category'] ); ?>" />
			<?php endif; ?>
			<p class="search-box" id="linkrounds-filter-fields">
				<label class="screen-reader-text" for="linkrounds-search"><?php esc_html_e( 'Search addresses', 'linkrounds' ); ?></label>
				<input type="search" id="linkrounds-search" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Search addresses', 'linkrounds' ); ?>" />
				<label class="screen-reader-text" for="linkrounds-post-type"><?php esc_html_e( 'Filter by post type', 'linkrounds' ); ?></label>
				<select id="linkrounds-post-type" name="lr_type">
					<option value=""><?php esc_html_e( 'All post types', 'linkrounds' ); ?></option>
					<?php foreach ( Results_Query::post_types_in_use() as $type_name ) : ?>
						<?php
						$type_object = get_post_type_object( $type_name );
						$type_label  = 'nav_menu_item' === $type_name ? __( 'Menu links', 'linkrounds' ) : ( $type_object ? $type_object->labels->name : $type_name );
						?>
						<option value="<?php echo esc_attr( $type_name ); ?>" <?php selected( $filters['post_type'], $type_name ); ?>><?php echo esc_html( $type_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="submit" class="button" value="<?php esc_attr_e( 'Filter', 'linkrounds' ); ?>" />
				<?php
				/**
				 * Fires after the Filter button, for add-on buttons that act on the filtered results (Pro's
				 * Export CSV). A button here belongs to another form through its form attribute.
				 *
				 * @param array $filters Current filters.
				 */
				do_action( 'linkrounds_filter_buttons', $filters );
				?>
			</p>
		</form>
		<?php
		/**
		 * Fires above the results table, for add-on forms such as the export's.
		 *
		 * @param array $filters Current filters.
		 */
		do_action( 'linkrounds_results_toolbar', $filters );
		?>

		<form method="post" action="<?php echo esc_url( self::current_url( $filters ) ); ?>" id="linkrounds-results-form" novalidate>
			<?php $table->display(); ?>
		</form>

		<p class="linkrounds-footer">
			<?php esc_html_e( 'Looks broken means one failure: “not found”, “gone” or a domain that does not exist. Broken means it failed again after the set wait. Blocked, login-required, rate-limited, server-error and timed-out answers are Inconclusive and are never counted as broken.', 'linkrounds' ); ?>
			<?php if ( ! defined( 'LINKROUNDS_PRO_VERSION' ) ) : ?>
				<br />
				<?php esc_html_e( 'Want scheduled scans, an emailed report and CSV export?', 'linkrounds' ); ?>
				<a href="<?php echo esc_url( self::PRO_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Linkrounds Pro is a one-time purchase.', 'linkrounds' ); ?></a>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * Keeps a date, a time or a duration on one line: a line never breaks inside "November 18, 2026 4:00 am".
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function unbroken( $text ) {
		return str_replace( ' ', "\xc2\xa0", (string) $text );
	}

	/**
	 * Says how many links failed once and when their second check is due, so a first scan with
	 * no Broken links yet does not look like nothing was found.
	 *
	 * Also sent with every row action, so the line never lags behind the counts.
	 *
	 * @param int $waiting Rows waiting for their second check.
	 * @return string HTML, empty when nothing is waiting.
	 */
	public static function waiting_html( $waiting ) {
		if ( $waiting < 1 ) {
			return '';
		}
		$first = Results_Query::earliest_waiting();
		if ( ! $first ) {
			return '';
		}
		// Count addresses, not places: one dead address used in five posts is one broken link
		// to fix in five places, and the scan line above also counts addresses.
		$addresses = max( 1, min( $waiting, Results_Query::waiting_addresses() ) );
		ob_start();
		$due    = strtotime( $first . ' UTC' ) + Settings::confirm_interval();
		$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		?>
		<div class="linkrounds-waiting">
			<p>
				<strong>
					<?php
					if ( $addresses === $waiting ) {
						/* translators: %s: number of links. */
						echo esc_html( sprintf( _n( '%s link looks broken.', '%s links look broken.', $waiting, 'linkrounds' ), number_format_i18n( $waiting ) ) );
					} else {
						?>
						<span class="linkrounds-waiting-long">
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: number of different addresses, 2: number of places they are used in. */
								_n( '%1$s address looks broken, used in %2$s places.', '%1$s different addresses look broken, used in %2$s places.', $addresses, 'linkrounds' ),
								number_format_i18n( $addresses ),
								number_format_i18n( $waiting )
							)
						);
						?>
						</span><span class="linkrounds-waiting-short">
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: number of different addresses, 2: number of places they are used in. */
								_n( '%1$s address looks broken (%2$s places).', '%1$s addresses look broken (%2$s places).', $addresses, 'linkrounds' ),
								number_format_i18n( $addresses ),
								number_format_i18n( $waiting )
							)
						);
						?>
						</span>
						<?php
					}
					?>
				</strong>
				<span class="linkrounds-waiting-long">
				<?php
				echo esc_html(
					$due > time()
						? sprintf(
							/* translators: 1: date and time, 2: time left, such as "58 mins". */
							_n(
								'It failed once and is checked again by itself after %1$s (in %2$s). It becomes Broken only if it fails again. You can fix it now.',
								'They failed once and are checked again by themselves from %1$s (in %2$s). Each becomes Broken only if it fails again. You can fix them now.',
								$addresses,
								'linkrounds'
							),
							self::unbroken( wp_date( $format, $due ) ),
							self::unbroken( human_time_diff( time(), $due ) )
						)
						: sprintf(
							/* translators: %s: date and time. */
							_n(
								'It failed once. Its second check was due at %s and runs within minutes while this screen is open; if it fails again it becomes Broken.',
								'They failed once. Their second checks were due from %s and run within minutes while this screen is open; each that fails again becomes Broken.',
								$addresses,
								'linkrounds'
							),
							self::unbroken( wp_date( $format, $due ) )
						)
				);
				?>
				</span>
				<span class="linkrounds-waiting-short">
					<?php
					if ( $due > time() ) {
						// Today: the time alone; another day: a short date and the time.
						$when = wp_date( 'Y-m-d', $due ) === wp_date( 'Y-m-d' ) ? wp_date( get_option( 'time_format' ), $due ) : wp_date( 'M j', $due ) . ', ' . wp_date( get_option( 'time_format' ), $due );
						/* translators: %s: time of day, or short date and time. */
						echo esc_html( sprintf( __( 'Second check from %s.', 'linkrounds' ), $when ) );
					} else {
						esc_html_e( 'Second check runs within minutes.', 'linkrounds' );
					}
					?>
				</span>
				<a href="<?php echo esc_url( self::url( array( 'category' => 'waiting' ) ) ); ?>">
					<?php
					if ( $addresses === $waiting ) {
						/* translators: %s: number of links. */
						echo esc_html( sprintf( _n( 'Show the %s link', 'Show the %s links', $waiting, 'linkrounds' ), number_format_i18n( $waiting ) ) );
					} else {
						/* translators: %s: number of places. */
						echo esc_html( sprintf( __( 'Show all %s places', 'linkrounds' ), number_format_i18n( $waiting ) ) );
					}
					?>
				</a>
				<button type="button" class="button-link linkrounds-waiting-toggle" aria-expanded="false" data-more="<?php esc_attr_e( 'More', 'linkrounds' ); ?>" data-less="<?php esc_attr_e( 'Less', 'linkrounds' ); ?>"><?php esc_html_e( 'More', 'linkrounds' ); ?></button>
			</p>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * The screen URL for the current filters, used to come back after an action.
	 *
	 * @param array $filters Filters.
	 * @return string
	 */
	private static function current_url( array $filters ) {
		$args = array();
		if ( '' !== $filters['category'] ) {
			$args['category'] = $filters['category'];
		}
		if ( '' !== $filters['post_type'] ) {
			$args['lr_type'] = $filters['post_type'];
		}
		if ( '' !== $filters['search'] ) {
			$args['s'] = rawurlencode( $filters['search'] );
		}
		if ( '' !== $filters['orderby'] ) {
			$args['orderby'] = $filters['orderby'];
			$args['order']   = strtolower( $filters['order'] );
		}
		$paged = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only paging.
		if ( $paged > 1 ) {
			$args['paged'] = $paged;
		}
		return self::url( $args );
	}

	/**
	 * The one-time review request, shown after a scan in which at least one link was fixed.
	 *
	 * @param array $progress Scanner::progress().
	 */
	private static function render_review_prompt( array $progress ) {
		if ( ! self::should_show_review_prompt( get_current_user_id(), $progress ) ) {
			return;
		}
		update_user_meta( get_current_user_id(), 'linkrounds_review_prompt', 'shown' );
		$dismiss = wp_nonce_url( admin_url( 'admin-post.php?action=linkrounds_dismiss_review' ), 'linkrounds_dismiss_review' );
		?>
		<p class="linkrounds-review" id="linkrounds-review">
			<?php esc_html_e( 'Glad Linkrounds helped you fix your links. If you have a minute, a review on WordPress.org helps other site owners find it.', 'linkrounds' ); ?>
			<a href="<?php echo esc_url( self::REVIEW_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Write a review', 'linkrounds' ); ?></a>
			&middot;
			<a href="<?php echo esc_url( $dismiss ); ?>" class="linkrounds-review-dismiss"><?php esc_html_e( 'Dismiss', 'linkrounds' ); ?></a>
		</p>
		<?php
	}

	/**
	 * Whether the review request should be shown to a user.
	 *
	 * @param int   $user_id  User ID.
	 * @param array $progress Scanner::progress().
	 * @return bool
	 */
	public static function should_show_review_prompt( $user_id, array $progress ) {
		if ( get_user_meta( $user_id, 'linkrounds_review_prompt', true ) || ! self::is_listed_on_wordpress_org() ) {
			return false;
		}
		$stats = get_option( 'linkrounds_stats', array() );
		if ( 'done' !== $progress['state'] || empty( $stats['fixes'] ) || empty( $stats['last_fix'] ) ) {
			return false;
		}
		return (int) $stats['last_fix'] >= (int) $progress['started'];
	}

	/**
	 * Whether WordPress.org lists this plugin, so its review page exists. Read from the answer
	 * WordPress's own update check already stored; Linkrounds makes no request for this. A copy
	 * downloaded from ochrestack.com before the directory listing exists gets no review request.
	 *
	 * @return bool
	 */
	public static function is_listed_on_wordpress_org() {
		$updates = get_site_transient( 'update_plugins' );
		$file    = basename( dirname( LINKROUNDS_FILE ) ) . '/' . basename( LINKROUNDS_FILE );
		foreach ( array( 'response', 'no_update' ) as $group ) {
			if ( ! is_object( $updates ) || empty( $updates->$group ) || ! is_array( $updates->$group ) || empty( $updates->{$group}[ $file ] ) ) {
				continue;
			}
			$item = (object) $updates->{$group}[ $file ];
			if ( isset( $item->id ) && 'w.org/plugins/linkrounds' === $item->id ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The fallback Edit address form (used without JavaScript).
	 *
	 * @param int $instance_id Instance ID.
	 */
	private static function render_edit_form( $instance_id ) {
		$item = Results_Query::row( $instance_id );
		if ( ! $item ) {
			echo '<p>' . esc_html__( 'This link is no longer in the results.', 'linkrounds' ) . '</p>';
			return;
		}
		$post = get_post( (int) $item->post_id );
		?>
		<h2><?php esc_html_e( 'Edit address', 'linkrounds' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: 1: address, 2: post title. */
				esc_html__( 'Change %1$s in “%2$s”. Only this link changes, and the change is saved as a revision you can restore.', 'linkrounds' ),
				'<code>' . esc_html( $item->raw_url ) . '</code>',
				esc_html( $post ? Fixer::title( $post ) : '' )
			);
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="linkrounds_row" />
			<input type="hidden" name="op" value="edit" />
			<input type="hidden" name="instance" value="<?php echo esc_attr( (string) $instance_id ); ?>" />
			<?php wp_nonce_field( 'linkrounds_row_' . $instance_id ); ?>
			<label for="linkrounds-new-url"><?php esc_html_e( 'New address', 'linkrounds' ); ?></label><br />
			<input type="url" id="linkrounds-new-url" name="url" class="large-text" value="<?php echo esc_attr( 'redirected' === $item->status && $item->final_url ? $item->final_url : $item->raw_url ); ?>" required />
			<?php submit_button( __( 'Save address', 'linkrounds' ) ); ?>
		</form>
		<?php
	}

	/**
	 * The Settings tab.
	 */
	private static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			echo '<p>' . esc_html__( 'Only administrators can change these settings.', 'linkrounds' ) . '</p>';
			return;
		}
		$settings = Settings::all();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="linkrounds_settings" />
			<?php wp_nonce_field( 'linkrounds_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="linkrounds-excluded"><?php esc_html_e( 'Excluded addresses', 'linkrounds' ); ?></label></th>
					<td>
						<textarea id="linkrounds-excluded" name="excluded_patterns" rows="6" class="large-text code"><?php echo esc_textarea( implode( "\n", $settings['excluded_patterns'] ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line. These links are never checked and never listed. A domain such as example.com also covers its subdomains. Use * as a wildcard: *.example.com, example.com/members/*, https://example.org/*.pdf', 'linkrounds' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Content to scan', 'linkrounds' ); ?></th>
					<td>
						<fieldset>
							<legend class="screen-reader-text"><?php esc_html_e( 'Content to scan', 'linkrounds' ); ?></legend>
							<?php foreach ( Settings::excludable_post_types() as $type ) : ?>
								<label><input type="checkbox" name="scan_types[]" value="<?php echo esc_attr( $type->name ); ?>" <?php checked( ! in_array( $type->name, $settings['excluded_post_types'], true ) ); ?> /> <?php echo esc_html( $type->labels->name ); ?></label><br />
							<?php endforeach; ?>
							<label><input type="checkbox" name="scan_types[]" value="wp_block" <?php checked( Settings::scans_patterns() ); ?> /> <?php esc_html_e( 'Synced patterns', 'linkrounds' ); ?></label><br />
							<label><input type="checkbox" name="scan_types[]" value="nav_menu_item" <?php checked( Settings::scans_menus() ); ?> /> <?php esc_html_e( 'Links in navigation menus (classic menus and block-theme Navigation menus)', 'linkrounds' ); ?></label>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Only published content is read. Unticking a type removes its links from the results straight away.', 'linkrounds' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="linkrounds-confirm"><?php esc_html_e( 'Second check after', 'linkrounds' ); ?></label></th>
					<td>
						<select id="linkrounds-confirm" name="confirm_hours">
							<?php foreach ( Settings::CONFIRM_HOURS as $hours ) : ?>
								<option value="<?php echo esc_attr( (string) $hours ); ?>" <?php selected( (int) $settings['confirm_hours'], $hours ); ?>>
									<?php
									/* translators: %d: number of hours. */
									echo esc_html( sprintf( _n( '%d hour', '%d hours', $hours, 'linkrounds' ), $hours ) );
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'A link is called Broken only when it fails with “not found”, “gone” or a missing domain twice, at least this long apart. Until then it is listed as Looks broken.', 'linkrounds' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save settings', 'linkrounds' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Start, Pause and Resume.
	 */
	public static function handle_scan() {
		check_admin_referer( 'linkrounds_scan' );
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'linkrounds' ), 403 );
		}
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		if ( 'start' === $op ) {
			if ( Scanner::start( 'manual' ) ) {
				self::add_notice( array( __( 'Scan started. It runs in the background; the count above updates as links are checked.', 'linkrounds' ) ), 'success', true, 'scan' );
				Scanner::nudge();
			} else {
				self::add_notice( array( __( 'A scan is already running.', 'linkrounds' ) ), 'info', false, 'scan' );
			}
		} elseif ( 'pause' === $op ) {
			// The status line beside the button states where it stopped; a notice would say it twice.
			Scanner::pause();
		} elseif ( 'resume' === $op ) {
			Scanner::resume();
			self::add_notice( array( __( 'Scan resumed.', 'linkrounds' ) ), 'success', true, 'scan' );
			Scanner::nudge();
		}
		self::redirect( self::url() );
	}

	/**
	 * Row action without JavaScript.
	 */
	public static function handle_row() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- The nonce is checked right below, per row.
		$id = isset( $_REQUEST['instance'] ) ? absint( $_REQUEST['instance'] ) : 0;
		check_admin_referer( 'linkrounds_row_' . $id );
		$op  = isset( $_REQUEST['op'] ) ? sanitize_key( wp_unslash( $_REQUEST['op'] ) ) : '';
		$url = isset( $_REQUEST['url'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['url'] ) ) : '';
		// phpcs:enable
		$result = self::row_action( $op, $id, $url );
		self::add_notice( array( $result['message'] ), $result['ok'] ? 'success' : 'error' );
		$back = wp_get_referer();
		self::redirect( $back && false === strpos( $back, 'edit=' ) ? $back : self::url() );
	}

	/**
	 * Row action through admin-ajax: returns the message and the updated row.
	 */
	public static function ajax_row() {
		$id = isset( $_POST['instance'] ) ? absint( $_POST['instance'] ) : 0;
		check_ajax_referer( 'linkrounds_row_' . $id );
		$op       = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$url      = isset( $_POST['url'] ) ? sanitize_text_field( wp_unslash( $_POST['url'] ) ) : '';
		$category = isset( $_POST['category'] ) ? sanitize_key( wp_unslash( $_POST['category'] ) ) : '';
		$result   = self::row_action( $op, $id, $url );

		$row_id = isset( $result['instance'] ) ? (int) $result['instance'] : 0;
		$html   = '';
		if ( $row_id ) {
			$item = Results_Query::row( $row_id );
			$hide = ! $item
				|| ( 'ignored' === $category && ! (int) $item->ignored )
				|| ( 'ignored' !== $category && (int) $item->ignored )
				|| ( 'waiting' === $category && ( 'inconclusive' !== $item->status || empty( $item->first_failure_at ) ) && 'recheck' !== $op )
				|| ( 'inconclusive' === $category && ( 'inconclusive' !== $item->status || ! empty( $item->first_failure_at ) ) && 'recheck' !== $op )
				|| ( ! in_array( $category, array( '', 'ignored', 'waiting', 'inconclusive' ), true ) && $item->status !== $category && 'recheck' !== $op );
			if ( ! $hide ) {
				require_once LINKROUNDS_DIR . '/includes/class-results-table.php';
				$table = new Results_Table( array( 'category' => $category ) );
				ob_start();
				$table->single_row( $item );
				$html = ob_get_clean();
			}
		}
		$counts  = Results_Query::counts();
		$payload = array(
			'message' => $result['message'],
			'row'     => $html,
			'counts'  => $counts,
			'waiting' => self::waiting_html( $counts['waiting'] ),
			'text'    => self::progress_text( Scanner::progress() ),
		);
		if ( $result['ok'] ) {
			wp_send_json_success( $payload );
		}
		wp_send_json_error( $payload );
	}

	/**
	 * Performs one row action. Callers check the nonce first.
	 *
	 * @param string $op  recheck, ignore, unignore, unlink or edit.
	 * @param int    $id  Instance ID.
	 * @param string $url New address for edit.
	 * @return array ok, message, instance (the row to show afterwards, 0 if none).
	 */
	public static function row_action( $op, $id, $url = '' ) {
		if ( ! current_user_can( self::capability() ) ) {
			return array(
				'ok'       => false,
				'message'  => __( 'Sorry, you are not allowed to do that.', 'linkrounds' ),
				'instance' => 0,
			);
		}
		$instance = Store::get_instance( $id );
		if ( ! $instance ) {
			return array(
				'ok'       => false,
				'message'  => __( 'This link is no longer in the results. It may have been fixed already.', 'linkrounds' ),
				'instance' => 0,
			);
		}

		switch ( $op ) {
			case 'recheck':
				$link  = Scanner::recheck_link( (int) $instance->link_id );
				$label = Classifier::label( $link->status, $link->first_failure_at );
				require_once LINKROUNDS_DIR . '/includes/class-results-table.php';
				$row = Results_Query::row( $id );
				return array(
					'ok'       => true,
					/* translators: 1: address, 2: category, 3: reason. */
					'message'  => sprintf( __( 'Re-checked %1$s: %2$s. %3$s', 'linkrounds' ), $link->url, $label, $row ? Results_Table::reason( $row ) : '' ),
					'instance' => $id,
				);

			case 'ignore':
			case 'unignore':
				Store::update_instance( $id, array( 'ignored' => 'ignore' === $op ? 1 : 0 ) );
				return array(
					'ok'       => true,
					'message'  => 'ignore' === $op
						/* translators: %s: address. */
						? sprintf( __( 'Ignored %s in this post. It stays out of the results until you choose Stop ignoring under the Ignored filter.', 'linkrounds' ), $instance->url )
						/* translators: %s: address. */
						: sprintf( __( 'Stopped ignoring %s. It is back in the results.', 'linkrounds' ), $instance->url ),
					'instance' => $id,
				);

			case 'unlink':
			case 'edit':
				$result = Fixer::apply(
					array(
						array(
							'instance' => $id,
							'action'   => $op,
							'url'      => $url,
						),
					)
				);
				if ( $result['done'] < 1 ) {
					return array(
						'ok'       => false,
						'message'  => implode( ' ', $result['failed'] ),
						'instance' => $id,
					);
				}
				$post = get_post( (int) $instance->post_id );
				if ( 'unlink' === $op ) {
					/* translators: 1: link text, 2: post title. */
					$message = sprintf( __( 'Removed the link from “%1$s” in “%2$s” and kept the text.', 'linkrounds' ), $instance->link_text, Fixer::title( $post ) );
				} else {
					/* translators: 1: old address, 2: post title. */
					$message = sprintf( __( 'Changed %1$s in “%2$s”.', 'linkrounds' ), $instance->raw_url, Fixer::title( $post ) );
				}
				if ( $result['synced'] ) {
					$message .= ' ' . implode( ' ', $result['synced'] );
				}
				$message .= ' ' . self::undo_hint( $post );
				if ( $result['checked'] ) {
					$message .= ' ' . implode( ' ', $result['checked'] );
				}
				return array(
					'ok'       => true,
					'message'  => $message,
					'instance' => 'edit' === $op ? self::instance_after_edit( $instance, $url ) : 0,
				);
		}
		return array(
			'ok'       => false,
			'message'  => __( 'Unknown action.', 'linkrounds' ),
			'instance' => 0,
		);
	}

	/**
	 * How to undo a fix.
	 *
	 * @param \WP_Post $post Post.
	 * @return string
	 */
	private static function undo_hint( $post ) {
		if ( 'nav_menu_item' === $post->post_type ) {
			return __( 'Menu items have no revisions; to undo, edit the menu item under Appearance > Menus.', 'linkrounds' );
		}
		if ( ! wp_revisions_enabled( $post ) ) {
			return __( 'Revisions are turned off on this site, so this change cannot be restored from the Revisions screen.', 'linkrounds' );
		}
		return __( 'Saved as a revision: you can restore the previous version from the post’s Revisions screen.', 'linkrounds' );
	}

	/**
	 * Finds the row that replaced an edited one.
	 *
	 * @param object $old Old instance.
	 * @param string $url New address as entered.
	 * @return int
	 */
	private static function instance_after_edit( $old, $url ) {
		$clean = Fixer::clean_new_url( $url );
		foreach ( Store::instances_for_post( (int) $old->post_id ) as $row ) {
			if ( $row->source === $old->source && html_entity_decode( esc_url( $clean ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) === $row->raw_url ) {
				return (int) $row->id;
			}
		}
		return 0;
	}

	/**
	 * Bulk actions on the ticked rows.
	 */
	public static function handle_bulk() {
		check_admin_referer( 'bulk-linkrounds-results' );
		$action = '';
		foreach ( array( 'action', 'action2' ) as $field ) {
			if ( '' === $action && isset( $_POST[ $field ] ) && '-1' !== $_POST[ $field ] ) {
				$action = sanitize_key( wp_unslash( $_POST[ $field ] ) );
			}
		}
		$ids    = isset( $_POST['instance'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['instance'] ) ) : array();
		$url    = isset( $_POST['bulk_url'] ) ? sanitize_text_field( wp_unslash( $_POST['bulk_url'] ) ) : '';
		$back   = self::current_url( Results_Query::args_from( wp_unslash( $_GET ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filters for the return address only.
		$result = self::bulk_action( $action, $ids, $url );
		self::add_notice( $result['messages'], isset( $result['type'] ) ? $result['type'] : ( $result['ok'] ? 'success' : 'error' ) );
		self::redirect( $back );
	}

	/**
	 * Applies a bulk action to exactly the given rows. Callers check the nonce first.
	 *
	 * @param string $action unlink, edit, recheck, ignore or unignore.
	 * @param int[]  $ids    Ticked instance IDs.
	 * @param string $url    New address for edit.
	 * @return array ok, messages, done, and for unlink and edit the notice type.
	 */
	public static function bulk_action( $action, array $ids, $url = '' ) {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		if ( ! current_user_can( self::capability() ) ) {
			return array(
				'ok'       => false,
				'messages' => array( __( 'Sorry, you are not allowed to do that.', 'linkrounds' ) ),
				'done'     => 0,
			);
		}
		if ( empty( $ids ) ) {
			return array(
				'ok'       => false,
				'messages' => array( __( 'No rows were ticked, so nothing was changed.', 'linkrounds' ) ),
				'done'     => 0,
			);
		}

		if ( in_array( $action, array( 'unlink', 'edit' ), true ) ) {
			$fixes   = array();
			$skipped = array(
				'img'  => 0,
				'menu' => 0,
			);
			foreach ( $ids as $id ) {
				// Unlinking removes a link and keeps its text; an image or a menu item has no text to
				// keep, so those rows are skipped (the row's own menu does not offer Unlink there either).
				$row = 'unlink' === $action ? Store::get_instance( $id ) : null;
				if ( $row && 'a' !== $row->source ) {
					++$skipped[ 'img' === $row->source ? 'img' : 'menu' ];
					continue;
				}
				$fixes[] = array(
					'instance' => $id,
					'action'   => $action,
					'url'      => $url,
				);
			}
			$result   = Fixer::apply( $fixes );
			$messages = array();
			if ( $result['done'] > 0 ) {
				$where = sprintf(
					/* translators: %s: number of posts or menus. */
					_n( '%s post or menu', '%s posts or menus', $result['posts'], 'linkrounds' ),
					number_format_i18n( $result['posts'] )
				);
				$messages[] = sprintf(
					'unlink' === $action
						/* translators: 1: number of links, 2: "3 posts or menus". */
						? _n( 'Unlinked %1$s link in %2$s, keeping the text.', 'Unlinked %1$s links in %2$s, keeping the text.', $result['done'], 'linkrounds' )
						/* translators: 1: number of links, 2: "3 posts or menus". */
						: _n( 'Changed the address of %1$s link in %2$s.', 'Changed the address of %1$s links in %2$s.', $result['done'], 'linkrounds' ),
					number_format_i18n( $result['done'] ),
					$where
				);
				$messages[] = __( 'Each changed post got a revision, so the previous version can be restored from its Revisions screen.', 'linkrounds' );
			}
			$messages = array_merge( $messages, $result['synced'], array_unique( $result['failed'] ), $result['checked'] );
			if ( $skipped['img'] > 0 ) {
				/* translators: %s: number of images. */
				$messages[] = sprintf( _n( 'Skipped %s image: it has no text to keep. Use Edit address for it.', 'Skipped %s images: they have no text to keep. Use Edit address for them.', $skipped['img'], 'linkrounds' ), number_format_i18n( $skipped['img'] ) );
			}
			if ( $skipped['menu'] > 0 ) {
				/* translators: %s: number of menu links. */
				$messages[] = sprintf( _n( 'Skipped %s menu link: use Edit address, or remove it from the menu.', 'Skipped %s menu links: use Edit address, or remove them from the menu.', $skipped['menu'], 'linkrounds' ), number_format_i18n( $skipped['menu'] ) );
			}
			if ( 0 === $result['done'] && empty( $result['failed'] ) && 0 === $skipped['img'] + $skipped['menu'] ) {
				$messages[] = __( 'Nothing was changed.', 'linkrounds' );
			}
			$ok = $result['done'] > 0 && empty( $result['failed'] );
			if ( $result['done'] < 1 && empty( $result['failed'] ) ) {
				$type = 'warning'; // Only skipped rows were ticked: nothing to do, nothing wrong.
			} else {
				$type = $ok ? 'success' : ( $result['done'] > 0 ? 'warning' : 'error' );
			}
			return array(
				'ok'       => $ok,
				'messages' => $messages,
				'done'     => $result['done'],
				'type'     => $type,
			);
		}

		if ( 'recheck' === $action ) {
			$links = array();
			foreach ( $ids as $id ) {
				$instance = Store::get_instance( $id );
				if ( $instance ) {
					$links[ (int) $instance->link_id ] = true;
				}
			}
			// At most 10 addresses are checked while you wait, and none started after the batch time
			// limit, so the request stays as short as a background batch; the rest are queued.
			$now   = 0;
			$start = microtime( true );
			foreach ( array_keys( $links ) as $i => $link_id ) {
				if ( $i < 10 && microtime( true ) - $start < Scanner::batch_time_limit() ) {
					Scanner::recheck_link( $link_id );
					++$now;
				} else {
					Store::update_link( $link_id, array( 'queued' => 1 ) );
				}
			}
			$queued = count( $links ) - $now;
			if ( $queued > 0 ) {
				Scanner::schedule_batch();
			}
			$messages = array(
				/* translators: %s: number of addresses. */
				sprintf( _n( 'Re-checked %s address.', 'Re-checked %s addresses.', $now, 'linkrounds' ), number_format_i18n( $now ) ),
			);
			if ( $queued > 0 ) {
				/* translators: %s: number of addresses. */
				$messages[] = sprintf( _n( '%s more address is queued and will be checked in the background.', '%s more addresses are queued and will be checked in the background.', $queued, 'linkrounds' ), number_format_i18n( $queued ) );
			}
			return array(
				'ok'       => true,
				'messages' => $messages,
				'done'     => count( $links ),
			);
		}

		if ( in_array( $action, array( 'ignore', 'unignore' ), true ) ) {
			$done = 0;
			foreach ( $ids as $id ) {
				if ( Store::get_instance( $id ) ) {
					Store::update_instance( $id, array( 'ignored' => 'ignore' === $action ? 1 : 0 ) );
					++$done;
				}
			}
			return array(
				'ok'       => true,
				'messages' => array(
					'ignore' === $action
						/* translators: %s: number of links. */
						? sprintf( _n( 'Ignored %s link. Find it under the Ignored filter to undo.', 'Ignored %s links. Find them under the Ignored filter to undo.', $done, 'linkrounds' ), number_format_i18n( $done ) )
						/* translators: %s: number of links. */
						: sprintf( _n( 'Stopped ignoring %s link.', 'Stopped ignoring %s links.', $done, 'linkrounds' ), number_format_i18n( $done ) ),
				),
				'done'     => $done,
			);
		}

		return array(
			'ok'       => false,
			'messages' => array( __( 'Choose a bulk action first.', 'linkrounds' ) ),
			'done'     => 0,
		);
	}

	/**
	 * Saves settings.
	 */
	public static function handle_settings() {
		check_admin_referer( 'linkrounds_settings' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'linkrounds' ), 403 );
		}
		$scan_types = isset( $_POST['scan_types'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['scan_types'] ) ) : array();
		$excluded   = array();
		foreach ( array_keys( Settings::excludable_post_types() ) as $type ) {
			if ( ! in_array( $type, $scan_types, true ) ) {
				$excluded[] = $type;
			}
		}
		foreach ( array( 'wp_block', 'nav_menu_item' ) as $type ) {
			if ( ! in_array( $type, $scan_types, true ) ) {
				$excluded[] = $type;
			}
		}
		$input   = array(
			'excluded_patterns'   => isset( $_POST['excluded_patterns'] ) ? sanitize_textarea_field( wp_unslash( $_POST['excluded_patterns'] ) ) : '',
			'excluded_post_types' => $excluded,
			'confirm_hours'       => isset( $_POST['confirm_hours'] ) ? absint( $_POST['confirm_hours'] ) : 1,
		);
		$before  = Settings::all();
		$places  = 0;
		$removed = self::save_settings( $input, $places );
		$message = array( __( 'Settings saved.', 'linkrounds' ) );
		if ( $removed > 0 ) {
			$message[] = sprintf(
				/* translators: 1: the number of addresses and their noun, 2: the number of places and their noun. */
				__( 'Removed from the results: %1$s, used in %2$s.', 'linkrounds' ),
				sprintf(
					/* translators: %s: number of addresses. The space after the number is a no-break space. */
					_n( '%s address now excluded', '%s addresses now excluded', $removed, 'linkrounds' ),
					number_format_i18n( $removed )
				),
				sprintf(
					/* translators: %s: number of places. The space after the number is a no-break space. */
					_n( '%s place', '%s places', $places, 'linkrounds' ),
					number_format_i18n( $places )
				)
			);
		}
		// Only when a content type was ticked that was unticked before.
		if ( array_diff( (array) $before['excluded_post_types'], Settings::all()['excluded_post_types'] ) ) {
			$message[] = __( 'Newly included content is read on the next Scan now.', 'linkrounds' );
		}
		self::add_notice( $message );
		self::redirect( self::url( array( 'tab' => 'settings' ) ) );
	}

	/**
	 * Saves settings and removes results that are now excluded.
	 *
	 * @param array $input  Raw settings.
	 * @param int   $places Receives the number of places (result rows) those addresses were used in.
	 * @return int Addresses removed by the address patterns.
	 */
	public static function save_settings( array $input, &$places = 0 ) {
		$settings = Settings::sanitize( $input );
		Settings::save( $settings );
		$removed = array();
		foreach ( Store::all_link_urls() as $link ) {
			if ( Settings::is_excluded( $link->url, $settings['excluded_patterns'] ) ) {
				$removed[] = (int) $link->id;
			}
		}
		$places = Store::count_instances_of_links( $removed );
		Store::delete_links( $removed );
		if ( $settings['excluded_post_types'] ) {
			Store::forget_post_types( $settings['excluded_post_types'] );
		}
		return count( $removed );
	}

	/**
	 * Live progress for the screen. Also keeps the background moving.
	 */
	public static function ajax_progress() {
		check_ajax_referer( 'linkrounds_progress' );
		if ( ! current_user_can( self::capability() ) ) {
			wp_send_json_error( null, 403 );
		}
		Scanner::nudge();
		$p            = Scanner::progress();
		$p['pending'] = Scanner::has_due_work();
		$p['text']    = self::progress_text( $p );
		$p['percent'] = self::progress_percent( $p );
		// The category counts move with the live count, so the row above the table never looks stuck.
		$p['counts']  = Results_Query::counts();
		$p['waiting'] = self::waiting_html( $p['counts']['waiting'] );
		wp_send_json_success( $p );
	}

	/**
	 * Dismisses the review request (no JavaScript).
	 */
	public static function handle_dismiss_review() {
		check_admin_referer( 'linkrounds_dismiss_review' );
		update_user_meta( get_current_user_id(), 'linkrounds_review_prompt', 'dismissed' );
		self::redirect( self::url() );
	}

	/**
	 * Dismisses the review request.
	 */
	public static function ajax_dismiss_review() {
		check_ajax_referer( 'linkrounds_dismiss_review' );
		update_user_meta( get_current_user_id(), 'linkrounds_review_prompt', 'dismissed' );
		wp_send_json_success();
	}

	/**
	 * Redirects and stops.
	 *
	 * @param string $url Target.
	 */
	private static function redirect( $url ) {
		wp_safe_redirect( $url );
		exit;
	}
}
