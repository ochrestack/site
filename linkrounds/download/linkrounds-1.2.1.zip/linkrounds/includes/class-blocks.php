<?php
/**
 * Reads block delimiters and changes block attributes in place.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

/**
 * Block comments ("<!-- wp:name {attributes} -->") with their byte offsets.
 *
 * Some blocks keep an address in their attributes as well as in their markup: the Cover block's
 * "url", the File block's "href", navigation links' "url". When only the markup changes, the
 * editor finds the block invalid and its "Attempt Block Recovery" rebuilds the markup from the
 * old attribute. So a fix changes both, and only that block's attributes.
 */
class Blocks {

	/**
	 * The block parser's own delimiter pattern (WP_Block_Parser::next_token).
	 */
	const DELIMITER = '/<!--\s+(?P<closer>\/)?wp:(?P<namespace>[a-z][a-z0-9_-]*\/)?(?P<name>[a-z][a-z0-9_-]*)\s+(?P<attrs>{(?:(?:[^}]+|}+(?=})|(?!}\s+\/?-->).)*+)?}\s+)?(?P<void>\/)?-->/s';

	/**
	 * Every block delimiter, in document order.
	 *
	 * @param string $html Content.
	 * @return array[] name (with namespace, core/ added), type (opener, closer, void), start, end,
	 *                 attrs_start and attrs_end (offsets of the JSON, -1 when none), attrs (array).
	 */
	public static function delimiters( $html ) {
		$out = array();
		if ( ! preg_match_all( self::DELIMITER, (string) $html, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			return $out;
		}
		foreach ( $matches as $m ) {
			$has_attrs = isset( $m['attrs'] ) && -1 !== $m['attrs'][1] && '' !== $m['attrs'][0];
			$json      = $has_attrs ? rtrim( $m['attrs'][0] ) : '';
			$attrs     = $has_attrs ? json_decode( $json, true ) : array();
			$namespace = isset( $m['namespace'] ) && -1 !== $m['namespace'][1] && '' !== $m['namespace'][0] ? $m['namespace'][0] : 'core/';
			$type      = 'opener';
			if ( isset( $m['closer'] ) && '/' === $m['closer'][0] ) {
				$type = 'closer';
			} elseif ( isset( $m['void'] ) && '/' === $m['void'][0] ) {
				$type = 'void';
			}
			$out[] = array(
				'name'        => $namespace . $m['name'][0],
				'type'        => $type,
				'start'       => $m[0][1],
				'end'         => $m[0][1] + strlen( $m[0][0] ),
				'attrs_start' => $has_attrs ? $m['attrs'][1] : -1,
				'attrs_end'   => $has_attrs ? $m['attrs'][1] + strlen( $json ) : -1,
				'attrs'       => is_array( $attrs ) ? $attrs : array(),
			);
		}
		return $out;
	}

	/**
	 * The innermost block whose markup contains an offset.
	 *
	 * @param string $html   Content.
	 * @param int    $offset Byte offset.
	 * @return array|null Its opening delimiter.
	 */
	public static function enclosing( $html, $offset ) {
		$stack = array();
		foreach ( self::delimiters( $html ) as $d ) {
			if ( $d['start'] > $offset ) {
				break;
			}
			if ( 'opener' === $d['type'] ) {
				$stack[] = $d;
			} elseif ( 'closer' === $d['type'] ) {
				array_pop( $stack );
			}
		}
		return $stack ? end( $stack ) : null;
	}

	/**
	 * Whether a block's attributes hold an address anywhere.
	 *
	 * @param array  $delimiter Delimiter from delimiters().
	 * @param string $address   Decoded address.
	 * @return bool
	 */
	public static function holds( $delimiter, $address ) {
		$found = false;
		array_walk_recursive(
			$delimiter['attrs'],
			static function ( $value ) use ( $address, &$found ) {
				$found = $found || ( is_string( $value ) && $value === $address );
			}
		);
		return $found;
	}

	/**
	 * Replaces every attribute value equal to an old address with a new one, in one block only.
	 * The rest of the content is left byte for byte as it was.
	 *
	 * @param string $html      Content.
	 * @param array  $delimiter Opening delimiter from delimiters() (on this same content).
	 * @param string $old       Decoded old address.
	 * @param string $address   New address.
	 * @return string
	 */
	public static function replace_in_attrs( $html, $delimiter, $old, $address ) {
		if ( $delimiter['attrs_start'] < 0 || ! self::holds( $delimiter, $old ) ) {
			return $html;
		}
		$attrs = $delimiter['attrs'];
		array_walk_recursive(
			$attrs,
			static function ( &$value ) use ( $old, $address ) {
				if ( is_string( $value ) && $value === $old ) {
					$value = $address;
				}
			}
		);
		return substr( $html, 0, $delimiter['attrs_start'] ) . serialize_block_attributes( $attrs ) . substr( $html, $delimiter['attrs_end'] );
	}

	/**
	 * The links and images in a block's own markup: between its opening and closing comments,
	 * leaving out any inner blocks.
	 *
	 * @param string $html   Content.
	 * @param array  $opener Opening delimiter from delimiters() (on this same content).
	 * @return array[] Items from Parser::find().
	 */
	public static function own_items( $html, $opener ) {
		if ( 'opener' !== $opener['type'] ) {
			return array();
		}
		$end   = strlen( $html );
		$depth = 0;
		$inner = array();
		$from  = -1;
		foreach ( self::delimiters( $html ) as $d ) {
			if ( $d['start'] < $opener['end'] ) {
				continue;
			}
			if ( 'void' === $d['type'] ) {
				if ( 0 === $depth ) {
					$inner[] = array( $d['start'], $d['end'] );
				}
				continue;
			}
			if ( 'opener' === $d['type'] ) {
				if ( 0 === $depth ) {
					$from = $d['start'];
				}
				++$depth;
				continue;
			}
			if ( 0 === $depth ) {
				$end = $d['start'];
				break;
			}
			--$depth;
			if ( 0 === $depth ) {
				$inner[] = array( $from, $d['end'] );
			}
		}
		$out = array();
		foreach ( Parser::find( $html ) as $item ) {
			if ( $item['tag_start'] < $opener['end'] || $item['tag_start'] >= $end ) {
				continue;
			}
			foreach ( $inner as $range ) {
				if ( $item['tag_start'] >= $range[0] && $item['tag_start'] < $range[1] ) {
					continue 2;
				}
			}
			$out[] = $item;
		}
		return $out;
	}

	/**
	 * Navigation links in a Navigation menu (wp_navigation) post.
	 *
	 * @param string $html Content.
	 * @return array[] raw (the "url" attribute), text (the label), occurrence, delimiter.
	 */
	public static function navigation_links( $html ) {
		$out     = array();
		$counter = array();
		foreach ( self::delimiters( $html ) as $d ) {
			if ( 'closer' === $d['type'] || ! in_array( $d['name'], array( 'core/navigation-link', 'core/navigation-submenu' ), true ) ) {
				continue;
			}
			$raw = isset( $d['attrs']['url'] ) && is_string( $d['attrs']['url'] ) ? trim( $d['attrs']['url'] ) : '';
			if ( '' === $raw ) {
				continue;
			}
			$counter[ $raw ] = isset( $counter[ $raw ] ) ? $counter[ $raw ] + 1 : 1;
			$label           = isset( $d['attrs']['label'] ) && is_string( $d['attrs']['label'] ) ? $d['attrs']['label'] : '';
			$out[]           = array(
				'raw'        => $raw,
				'text'       => trim( html_entity_decode( wp_strip_all_tags( $label ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ),
				'occurrence' => $counter[ $raw ],
				'delimiter'  => $d,
			);
		}
		return $out;
	}
}
