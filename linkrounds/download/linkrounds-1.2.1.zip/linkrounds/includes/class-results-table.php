<?php
/**
 * The results table on Tools > Linkrounds.
 *
 * @package Linkrounds
 */

namespace Linkrounds;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * One row per place a link appears.
 */
class Results_Table extends \WP_List_Table {

	/**
	 * Current filters.
	 *
	 * @var array
	 */
	private $filters;

	/**
	 * Constructor.
	 *
	 * @param array $filters Filters from Results_Query::args_from().
	 */
	public function __construct( array $filters = array() ) {
		$this->filters = array_merge( Results_Query::args_from( array() ), $filters );
		parent::__construct(
			array(
				'singular' => 'linkrounds-result',
				'plural'   => 'linkrounds-results',
				'ajax'     => false,
				'screen'   => 'tools_page_linkrounds',
			)
		);
	}

	/**
	 * Columns.
	 *
	 * @return string[]
	 */
	public function get_columns() {
		return array(
			'cb'      => '<input type="checkbox" />',
			'url'     => __( 'Address', 'linkrounds' ),
			'text'    => __( 'Link text', 'linkrounds' ),
			'page'    => __( 'Found on', 'linkrounds' ),
			'status'  => __( 'Status', 'linkrounds' ),
			'checked' => __( 'Last checked', 'linkrounds' ),
		);
	}

	/**
	 * Sortable columns.
	 *
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(
			'url'     => array( 'url', false ),
			'page'    => array( 'page', false ),
			'checked' => array( 'checked', true ),
		);
	}

	/**
	 * Bulk actions. They act on the ticked rows only.
	 *
	 * @return string[]
	 */
	protected function get_bulk_actions() {
		$actions = array(
			'unlink'  => __( 'Unlink', 'linkrounds' ),
			'edit'    => __( 'Edit address', 'linkrounds' ),
			'recheck' => __( 'Re-check now', 'linkrounds' ),
		);
		if ( 'ignored' === $this->filters['category'] ) {
			$actions['unignore'] = __( 'Stop ignoring', 'linkrounds' );
		} else {
			$actions['ignore'] = __( 'Ignore', 'linkrounds' );
		}
		return $actions;
	}

	/**
	 * Loads the rows for the current page.
	 */
	public function prepare_items() {
		$per_page = $this->get_items_per_page( 'linkrounds_per_page', 20 );
		$page     = $this->get_pagenum();
		$total    = Results_Query::count( $this->filters );

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'url' );
		$this->items           = Results_Query::rows( $this->filters, $per_page, ( $page - 1 ) * $per_page );
		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
			)
		);
	}

	/**
	 * Message when there are no rows.
	 */
	public function no_items() {
		if ( 'ignored' === $this->filters['category'] ) {
			esc_html_e( 'No ignored links.', 'linkrounds' );
		} elseif ( 'broken' === $this->filters['category'] && '' === $this->filters['search'] && '' === $this->filters['post_type'] && Results_Query::count( array( 'category' => 'waiting' ) ) > 0 ) {
			esc_html_e( 'Nothing is Broken yet: links that failed once are waiting for their second check.', 'linkrounds' );
			echo ' <a href="' . esc_url( admin_url( 'tools.php?page=linkrounds&category=waiting' ) ) . '">' . esc_html__( 'Show them', 'linkrounds' ) . '</a>';
		} elseif ( '' !== $this->filters['search'] || '' !== $this->filters['category'] || '' !== $this->filters['post_type'] ) {
			esc_html_e( 'No links match these filters.', 'linkrounds' );
		} else {
			esc_html_e( 'No links yet. Click Scan now to read your published content.', 'linkrounds' );
		}
	}

	/**
	 * Extra controls above the table: the address used by the Edit address bulk action.
	 *
	 * @param string $which 'top' or 'bottom'.
	 */
	protected function extra_tablenav( $which ) {
		if ( 'top' !== $which ) {
			return;
		}
		?>
		<div class="alignleft actions linkrounds-bulk-url" id="linkrounds-bulk-url-field">
			<label for="linkrounds-bulk-url"><?php esc_html_e( 'New address for Edit address:', 'linkrounds' ); ?></label>
			<input type="url" id="linkrounds-bulk-url" name="bulk_url" class="regular-text" placeholder="https://" />
		</div>
		<?php
	}

	/**
	 * Row attributes, so a single row can be replaced after an action.
	 *
	 * @param object $item Row.
	 */
	public function single_row( $item ) {
		printf( '<tr id="linkrounds-row-%1$d" data-instance="%1$d" class="linkrounds-status-%2$s">', (int) $item->instance_id, esc_attr( $item->status ) );
		$this->single_row_columns( $item );
		echo '</tr>';
	}

	/**
	 * Checkbox column.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_cb( $item ) {
		return sprintf(
			'<label class="screen-reader-text" for="linkrounds-cb-%1$d">%2$s</label><input type="checkbox" id="linkrounds-cb-%1$d" name="instance[]" value="%1$d" />',
			(int) $item->instance_id,
			/* translators: %s: link address. */
			esc_html( sprintf( __( 'Select %s', 'linkrounds' ), $item->url ) )
		);
	}

	/**
	 * Address column: the full address, where it forwards to, and the row actions.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_url( $item ) {
		$out = '<a class="linkrounds-url" href="' . esc_url( $item->url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $item->url ) . '</a>';
		if ( Url_Guard::check_url( $item->raw_url ) !== $item->url ) {
			/* translators: %s: address exactly as written in the content. */
			$out .= '<br /><span class="linkrounds-muted">' . esc_html( sprintf( __( 'Written as: %s', 'linkrounds' ), $item->raw_url ) ) . '</span>';
		}
		if ( '' !== (string) $item->final_url && $item->final_url !== $item->url ) {
			$out .= '<br /><span class="linkrounds-final">' . esc_html__( 'Ends at:', 'linkrounds' ) . ' <a href="' . esc_url( $item->final_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $item->final_url ) . '</a></span>';
		}
		if ( 'img' === $item->source ) {
			$out .= '<br /><span class="linkrounds-muted">' . esc_html__( 'Image', 'linkrounds' ) . '</span>';
		} elseif ( 'menu' === $item->source || 'navlink' === $item->source ) {
			$out .= '<br /><span class="linkrounds-muted">' . esc_html__( 'Menu link', 'linkrounds' ) . '</span>';
		}
		$out .= $this->edit_form( $item );
		return $out . $this->row_actions( $this->actions_for( $item ) );
	}

	/**
	 * Hidden inline form for Edit address (shown by the script).
	 *
	 * @param object $item Row.
	 * @return string
	 */
	private function edit_form( $item ) {
		if ( ! $this->can_fix( $item ) ) {
			return '';
		}
		$value = '' !== (string) $item->final_url && 'redirected' === $item->status ? $item->final_url : $item->raw_url;
		return sprintf(
			'<div class="linkrounds-edit" hidden><label class="screen-reader-text" for="linkrounds-edit-%1$d">%2$s</label><input type="url" id="linkrounds-edit-%1$d" class="large-text" value="%3$s" /> <button type="button" class="button button-primary linkrounds-edit-save">%4$s</button> <button type="button" class="button linkrounds-edit-cancel">%5$s</button></div>',
			(int) $item->instance_id,
			esc_html__( 'New address', 'linkrounds' ),
			esc_attr( $value ),
			esc_html__( 'Save', 'linkrounds' ),
			esc_html__( 'Cancel', 'linkrounds' )
		);
	}

	/**
	 * Whether the current user may change this link.
	 *
	 * @param object $item Row.
	 * @return bool
	 */
	private function can_fix( $item ) {
		return 'menu' === $item->source ? current_user_can( 'edit_theme_options' ) : current_user_can( 'edit_post', (int) $item->post_id );
	}

	/**
	 * Row actions for a row.
	 *
	 * @param object $item Row.
	 * @return string[]
	 */
	private function actions_for( $item ) {
		$id      = (int) $item->instance_id;
		$actions = array();
		$url     = static function ( $op ) use ( $id ) {
			return wp_nonce_url(
				add_query_arg(
					array(
						'action'   => 'linkrounds_row',
						'op'       => $op,
						'instance' => $id,
					),
					admin_url( 'admin-post.php' )
				),
				'linkrounds_row_' . $id
			);
		};
		$link    = static function ( $op, $label, $href ) {
			return sprintf( '<a href="%1$s" class="linkrounds-row-action" data-op="%2$s">%3$s</a>', esc_url( $href ), esc_attr( $op ), esc_html( $label ) );
		};

		if ( $this->can_fix( $item ) ) {
			$edit_href       = add_query_arg(
				array(
					'page' => 'linkrounds',
					'edit' => $id,
				),
				admin_url( 'tools.php' )
			);
			$actions['edit'] = $link( 'edit', __( 'Edit address', 'linkrounds' ), $edit_href );
			if ( 'a' === $item->source && '' === Fixer::unlink_blocker( get_post( (int) $item->post_id ), $item ) ) {
				$actions['unlink'] = $link( 'unlink', __( 'Unlink', 'linkrounds' ), $url( 'unlink' ) );
			}
		}
		$actions['recheck'] = $link( 'recheck', __( 'Re-check now', 'linkrounds' ), $url( 'recheck' ) );
		if ( (int) $item->ignored ) {
			$actions['unignore'] = $link( 'unignore', __( 'Stop ignoring', 'linkrounds' ), $url( 'unignore' ) );
		} else {
			$actions['ignore'] = $link( 'ignore', __( 'Ignore', 'linkrounds' ), $url( 'ignore' ) );
		}
		return $actions;
	}

	/**
	 * Link text column.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_text( $item ) {
		$text = (string) $item->link_text;
		return '' === $text ? '<span class="linkrounds-muted">' . esc_html__( '(no text)', 'linkrounds' ) . '</span>' : esc_html( $text );
	}

	/**
	 * Found on column: page title with Edit and View links.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_page( $item ) {
		$post = get_post( (int) $item->post_id );
		if ( ! $post ) {
			return '';
		}
		if ( 'nav_menu_item' === $post->post_type ) {
			$menus = wp_get_object_terms( $post->ID, 'nav_menu' );
			$menu  = ( ! is_wp_error( $menus ) && $menus ) ? $menus[0] : null;
			/* translators: %s: menu name. */
			$out = '<strong>' . esc_html( sprintf( __( 'Menu: %s', 'linkrounds' ), $menu ? $menu->name : __( '(unknown)', 'linkrounds' ) ) ) . '</strong>';
			if ( $menu && current_user_can( 'edit_theme_options' ) ) {
				$out .= '<div class="linkrounds-page-links"><a href="' . esc_url( admin_url( 'nav-menus.php?action=edit&menu=' . (int) $menu->term_id ) ) . '">' . esc_html__( 'Edit', 'linkrounds' ) . '</a></div>';
			}
			return $out;
		}

		$type  = get_post_type_object( $post->post_type );
		$out   = '<strong>' . esc_html( Fixer::title( $post ) ) . '</strong>';
		$out  .= $type ? ' <span class="linkrounds-muted">(' . esc_html( $type->labels->singular_name ) . ')</span>' : '';
		$links = array();
		if ( current_user_can( 'edit_post', $post->ID ) ) {
			$links[] = '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'Edit', 'linkrounds' ) . '</a>';
		}
		if ( is_post_type_viewable( $post->post_type ) ) {
			$links[] = '<a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View', 'linkrounds' ) . '</a>';
		}
		return $out . '<div class="linkrounds-page-links">' . implode( ' | ', $links ) . '</div>';
	}

	/**
	 * Status column: category, status code and reason.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_status( $item ) {
		$categories = Classifier::categories();
		if ( 'unchecked' === $item->status ) {
			return '<span class="linkrounds-badge linkrounds-badge-unchecked">' . esc_html__( 'Not checked yet', 'linkrounds' ) . '</span>';
		}
		$label = isset( $categories[ $item->status ] ) ? $categories[ $item->status ] : $item->status;
		$out   = '<span class="linkrounds-badge linkrounds-badge-' . esc_attr( $item->status ) . '">' . esc_html( $label ) . '</span>';
		$code  = (int) $item->http_code;
		$out  .= ' <span class="linkrounds-code">' . ( $code ? esc_html( (string) $code ) : '&mdash;' ) . '</span>';
		$out  .= '<div class="linkrounds-reason">' . esc_html( self::reason( $item ) ) . '</div>';
		return $out;
	}

	/**
	 * The reason shown for a row, including the wait for the second check.
	 *
	 * @param object $item Row with reason_key, http_code, detail, status, first_failure_at.
	 * @return string
	 */
	public static function reason( $item ) {
		$reason = Classifier::reason_text( $item->reason_key, $item->http_code, (string) $item->detail );
		if ( 'inconclusive' === $item->status && ! empty( $item->first_failure_at ) ) {
			$due     = strtotime( $item->first_failure_at . ' UTC' ) + Settings::confirm_interval();
			$reason .= ' ' . sprintf(
				/* translators: %s: date and time of the second check. */
				__( 'First failure: it is checked again after %s and called Broken only if it fails again.', 'linkrounds' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $due )
			);
		}
		return $reason;
	}

	/**
	 * Last checked column.
	 *
	 * @param object $item Row.
	 * @return string
	 */
	protected function column_checked( $item ) {
		if ( empty( $item->last_checked ) ) {
			return (int) $item->queued ? esc_html__( 'Waiting in the queue', 'linkrounds' ) : '&mdash;';
		}
		$time = strtotime( $item->last_checked . ' UTC' );
		$out  = sprintf(
			'<time datetime="%1$s">%2$s</time><br /><span class="linkrounds-muted">%3$s</span>',
			esc_attr( gmdate( 'c', $time ) ),
			esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time ) ),
			/* translators: %s: human-readable time difference, for example "5 mins". */
			esc_html( sprintf( __( '%s ago', 'linkrounds' ), human_time_diff( $time ) ) )
		);
		if ( (int) $item->queued ) {
			$out .= '<br /><span class="linkrounds-muted">' . esc_html__( 'Re-check queued', 'linkrounds' ) . '</span>';
		}
		return $out;
	}

	/**
	 * Fallback for unknown columns.
	 *
	 * @param object $item        Row.
	 * @param string $column_name Column.
	 * @return string
	 */
	protected function column_default( $item, $column_name ) {
		return '';
	}
}
