<?php
/**
 * Check 4, second part: Purchase pairs on the last 50 orders, as the store recorded them.
 *
 * Reads what Meta for WooCommerce stored on each order. It never says what Meta received or counted. It also counts the
 * orders on which PixelYourSite marked its own Purchase, because those are Purchases this check does not read.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Purchase pair counts.
 */
class Catalogwell_Purchases {

	const LIMIT = 50;

	/**
	 * Order meta PixelYourSite 11.4.5 writes when it has fired its own Purchase for an order (read from its source).
	 */
	const PYS_MARKER = '_pys_purchase_event_fired';

	/**
	 * Orders in a status where Meta for WooCommerce records a Purchase.
	 */
	const STATUSES = array( 'pending', 'on-hold', 'processing', 'completed' );

	/**
	 * Count the last 50 orders by what Meta for WooCommerce recorded on each.
	 *
	 * @return array{available:bool,total:int,both_shared:int,both_no_id:int,server_only:int,browser_only:int,neither:int,server_total:int,browser_total:int,pys_marked:int}
	 */
	public static function count() {
		$out = array(
			'available'     => false,
			'total'         => 0,
			'both_shared'   => 0,
			'both_no_id'    => 0,
			'server_only'   => 0,
			'browser_only'  => 0,
			'neither'       => 0,
			'server_total'  => 0,
			'browser_total' => 0,
			'pys_marked'    => 0,
		);
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return $out;
		}
		$out['available'] = true;

		$orders = wc_get_orders(
			array(
				'type'    => 'shop_order',
				'status'  => self::STATUSES,
				'limit'   => self::LIMIT,
				'orderby' => 'date',
				'order'   => 'DESC',
				'return'  => 'objects',
			)
		);

		foreach ( $orders as $order ) {
			++$out['total'];
			$browser = $order->meta_exists( '_meta_purchase_tracked_browser' );
			$server  = $order->meta_exists( '_meta_purchase_tracked_server' );
			$has_id  = '' !== trim( (string) $order->get_meta( '_meta_event_id' ) );
			if ( $order->meta_exists( self::PYS_MARKER ) ) {
				++$out['pys_marked'];
			}
			if ( $browser ) {
				++$out['browser_total'];
			}
			if ( $server ) {
				++$out['server_total'];
			}
			if ( $browser && $server ) {
				if ( $has_id ) {
					++$out['both_shared'];
				} else {
					++$out['both_no_id'];
				}
			} elseif ( $server ) {
				++$out['server_only'];
			} elseif ( $browser ) {
				++$out['browser_only'];
			} else {
				++$out['neither'];
			}
		}
		return $out;
	}
}
