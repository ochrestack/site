<?php
/**
 * The plain-text report for the support forum.
 *
 * It holds versions, states, IDs and counts. It never holds the access token, a customer name,
 * an e-mail address, an order or a site address.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Report builder.
 */
class Catalogwell_Report {

	const EXAMPLES = 10;

	/**
	 * Build the report.
	 *
	 * @param array $results Stored result.
	 * @return string
	 */
	public static function build( $results ) {
		global $wp_version;
		if ( empty( $results ) || empty( $results['connection'] ) ) {
			return '';
		}
		$meta   = $results['connection']['meta'];
		$google = $results['connection']['google'];
		$lines  = array();

		$lines[] = 'Catalogwell ' . $results['version'] . ' report, ' . gmdate( 'Y-m-d H:i', (int) $results['time'] ) . ' UTC';
		$lines[] = 'WordPress ' . $wp_version . ', PHP ' . PHP_VERSION . ', WooCommerce ' . ( defined( 'WC_VERSION' ) ? WC_VERSION : 'not active' );
		$lines[] = 'Meta for WooCommerce: ' . self::plugin_text( $meta['plugin'] ) . ' (Catalogwell rules read from ' . CATALOGWELL_META_REFERENCE . ')';
		$lines[] = 'Google for WooCommerce: ' . self::plugin_text( $google['plugin'] ) . ' (Catalogwell read from ' . CATALOGWELL_GOOGLE_REFERENCE . ')';
		$lines[] = '';

		$lines[] = '== Meta for WooCommerce: connection ==';
		foreach ( $meta['states'] as $state ) {
			$lines[] = $state['name'] . ' [' . Catalogwell_Connection::label_text( $state['label'] ) . ']';
			$lines[] = '  ' . $state['plain'];
			$lines[] = '  Next step: ' . $state['step'];
		}
		$lines[] = 'Access token stored: ' . ( $meta['token_stored'] ? 'yes (not shown)' : 'no' );
		$lines[] = 'Pixel ID in wc_facebook_pixel_id: ' . self::id( $meta['pixel_setting'] );
		$lines[] = 'Pixel ID in facebook_config: ' . self::id( $meta['pixel_config'] );
		$lines[] = 'Catalog ID: ' . self::id( $meta['catalog_id'] );
		$lines[] = 'Business Manager ID: ' . self::id( $meta['business_manager_id'] );
		$lines[] = 'External business ID: ' . self::id( $meta['external_business'] );
		$lines[] = 'Commerce account ID: ' . self::id( $meta['commerce_account_id'] );
		$lines[] = '"Access token is missing" lines in the WooCommerce logs, last 7 days: ' . Catalogwell_Logs::count_text( $meta['log_lines'], false );
		$lines[] = '';

		$lines[] = '== Google for WooCommerce: connection ==';
		foreach ( $google['states'] as $state ) {
			$lines[] = $state['name'] . ' [' . Catalogwell_Connection::label_text( $state['label'] ) . ']';
			$lines[] = '  ' . $state['plain'];
			$lines[] = '  Next step: ' . $state['step'];
		}
		$lines[] = 'Merchant Center ID: ' . self::id( $google['merchant_id'] );
		$lines[] = 'Google Ads ID: ' . self::id( $google['ads_id'] );
		$lines[] = 'Google account connected: ' . ( $google['google_account'] ? 'yes' : 'no' );
		$lines[] = 'WordPress.com connection: ' . ( $google['wordpress_com'] ? 'yes' : 'no' );
		$lines[] = 'Setup completed: ' . ( $google['setup_completed'] ? 'yes' : 'no' );
		$lines[] = 'Data stored by the plugin: ' . self::count_of( (int) $google['data_left']['options'], 'option', 'options' ) . ', ' . self::count_of( (int) $google['data_left']['products'], 'product with records', 'products with records' );
		$lines[] = '';

		$lines   = array_merge( $lines, self::catalog_lines( $results['catalog'], Catalogwell_Runner::meta_is_off( $results ) ) );
		$lines[] = '';
		$lines   = array_merge( $lines, self::pixel_lines( $results['pixel'] ) );
		$lines[] = '';
		$lines   = array_merge( $lines, self::events_lines( $results['events'] ) );

		// The screen ties dates and numbers together with non-breaking spaces; a report to paste has ordinary ones.
		return str_replace( "\xC2\xA0", ' ', implode( "\n", $lines ) ) . "\n";
	}

	/**
	 * Plugin state and version.
	 *
	 * @param array $plugin Plugin state.
	 * @return string
	 */
	private static function plugin_text( $plugin ) {
		if ( 'deleted' === $plugin['state'] ) {
			return 'not installed';
		}
		return $plugin['state'] . ', version ' . $plugin['version'];
	}

	/**
	 * ID or "empty".
	 *
	 * @param string $id ID.
	 * @return string
	 */
	private static function id( $id ) {
		return '' === $id ? 'empty or 0' : $id;
	}

	/**
	 * Catalog lines.
	 *
	 * @param array $catalog Catalog result.
	 * @param bool  $off     Whether Meta for WooCommerce is deactivated or deleted.
	 * @return string[]
	 */
	private static function catalog_lines( $catalog, $off ) {
		$lines   = array( '== Catalog ==' );
		$summary = $catalog['summary'];
		if ( $off ) {
			$lines[] = Catalogwell_Catalog::off_text();
		}
		$lines[] = Catalogwell_Catalog::count_text( $summary, $off ) . ' ' . Catalogwell_Catalog::not_synced_text( $summary, $off );
		foreach ( $summary['by_reason'] as $key => $count ) {
			$lines[] = '  ' . $count . ' x ' . Catalogwell_Catalog::reason_title( $key );
		}
		$feed = $catalog['feed'];
		if ( 'compared' === $feed['state'] ) {
			$lines[] = 'Feed file ' . $feed['file'] . ', written ' . gmdate( 'Y-m-d H:i', (int) $feed['date'] ) . ' UTC; ' . self::count_of( (int) $feed['checked'], 'row', 'rows' ) . ' read; ' . self::count_of( (int) $feed['difference_count'], 'row differs', 'rows differ' ) . ' from the rules today.';
			foreach ( array_slice( $feed['differences'], 0, self::EXAMPLES ) as $difference ) {
				$lines[] = '  product ID ' . $difference['id'] . ': file says ' . $difference['file'] . ', rules say ' . $difference['rules'];
			}
		} else {
			$lines[] = 'Feed file: ' . $feed['message'];
		}
		$lines[] = 'Feed job: ' . Catalogwell_Feed::job_text( $catalog['job'] );
		$google  = $catalog['google'];
		if ( $google['has_data'] ) {
			$lines[] = 'Google for WooCommerce stored sync status: synced ' . $google['statuses']['synced'] . ', not synced ' . $google['statuses']['not-synced'] . ', has errors ' . $google['statuses']['has-errors'] . ', pending ' . $google['statuses']['pending'];
			foreach ( $google['errors'] as $error ) {
				$lines[] = '  ' . $error['products'] . ' x ' . $error['message'];
			}
		} else {
			$lines[] = 'Google for WooCommerce stored no product sync records.';
		}
		return $lines;
	}

	/**
	 * Pixel lines.
	 *
	 * @param array $pixel Pixel result.
	 * @return string[]
	 */
	private static function pixel_lines( $pixel ) {
		$lines = array( '== Pixel on the pages ==' );
		foreach ( $pixel['pages'] as $page ) {
			if ( 'ok' !== $page['kind'] ) {
				$lines[] = $page['label'] . ': ' . ( '' !== $page['sentence'] ? self::strip_address( $page['sentence'] ) : 'not checked' );
				continue;
			}
			if ( empty( $page['pixels'] ) ) {
				$lines[] = $page['label'] . ': no Meta Pixel ID in the markup';
			}
			foreach ( $page['pixels'] as $row ) {
				$names   = array_map( array( 'Catalogwell_Pixel', 'plugin_name' ), $row['plugins'] );
				$lines[] = $page['label'] . ': Pixel ' . $row['id'] . ' printed by ' . implode( ', ', $names );
			}
			foreach ( $page['flags'] as $flag ) {
				$lines[] = '  Flag: ' . $flag['text'];
			}
		}
		$pair    = $pixel['pairing'];
		$lines[] = 'Stored pairing: Pixel ID ' . self::id( $pair['pixel_id'] ) . ', catalog ID ' . self::id( $pair['catalog_id'] ) . ' [' . Catalogwell_Connection::label_text( $pair['label'] ) . ']';
		return $lines;
	}

	/**
	 * Event ID lines.
	 *
	 * @param array $events Events result.
	 * @return string[]
	 */
	private static function events_lines( $events ) {
		$lines   = array( '== Event IDs and Purchase pairs ==' );
		$lines[] = $events['rule'];
		foreach ( $events['pages'] as $page ) {
			if ( 'ok' !== $page['kind'] ) {
				$lines[] = $page['label'] . ': ' . ( '' !== $page['sentence'] ? self::strip_address( $page['sentence'] ) : 'not checked' );
				continue;
			}
			$line = $page['label'] . ': ' . self::count_of( (int) $page['ok_loads'], 'load', 'loads' ) . '; ';
			if ( $page['no_events'] ) {
				$line .= 'no eventID in the HTML';
			} elseif ( empty( $page['repeated'] ) && empty( $page['dropped'] ) ) {
				$line .= 'no eventID repeated';
			} else {
				$line .= count( $page['repeated'] ) . ' repeated eventID' . ( 1 === count( $page['repeated'] ) ? '' : 's' );
				if ( ! empty( $page['dropped'] ) ) {
					$line .= ', ' . count( $page['dropped'] ) . ' the same in every load but dropped by the browser (copy more than 30 minutes old)';
				}
			}
			$line   .= '; cache: ' . ( empty( $page['caches'] ) ? 'not named' : implode( ', ', $page['caches'] ) );
			$line   .= '; page generated ' . ( $page['generated'] ? gmdate( 'Y-m-d H:i:s', (int) $page['generated'] ) . ' UTC' : 'marker not found' );
			$lines[] = $line;
			foreach ( $page['repeated'] as $repeat ) {
				$lines[] = '  repeated: different visitors would send the same event ID: ' . $repeat['name'] . ' ' . $repeat['id'] . ' in ' . $repeat['count'] . ' of ' . self::count_of( (int) $page['ok_loads'], 'load', 'loads' );
			}
			foreach ( $page['dropped'] as $dropped ) {
				$lines[] = '  no event ID sent: ' . $dropped['name'] . ' ' . $dropped['id'] . ' is the same in ' . $dropped['count'] . ' of ' . self::count_of( (int) $page['ok_loads'], 'load', 'loads' ) . ', but the copy is more than 30 minutes old, so visitors send the event with no event ID';
			}
		}
		$p = $events['purchases'];
		if ( ! $p['available'] ) {
			$lines[] = 'Purchase pairs: WooCommerce is not active.';
		} elseif ( 0 === $p['total'] ) {
			$lines[] = 'Purchase pairs: no orders in a status where Meta for WooCommerce records a Purchase.';
		} else {
			$lines[] = 'Purchase pairs on the last ' . self::count_of( (int) $p['total'], 'order', 'orders' ) . ', as Meta for WooCommerce recorded them on each order: both with one shared event ID ' . $p['both_shared'] . '; both, no event ID stored ' . $p['both_no_id'] . '; server only ' . $p['server_only'] . '; browser Purchase code only ' . $p['browser_only'] . '; neither recorded by Meta for WooCommerce ' . $p['neither'] . '.' . ( $p['pys_marked'] > 0 ? ' PixelYourSite marked ' . (int) $p['pys_marked'] . ' of these orders as having its own Purchase sent, which this check does not read.' : '' );
		}
		return $lines;
	}

	/**
	 * A count with its noun in the right number: "1 row", "2 rows".
	 *
	 * @param int    $count    Count.
	 * @param string $singular Noun (or noun and verb) for exactly one.
	 * @param string $plural   Noun (or noun and verb) for any other number.
	 * @return string
	 */
	private static function count_of( $count, $singular, $plural ) {
		return $count . ' ' . ( 1 === $count ? $singular : $plural );
	}

	/**
	 * Replace the site's address in a sentence with a plain word, so the report carries no address.
	 *
	 * @param string $sentence Sentence that may hold an address.
	 * @return string
	 */
	private static function strip_address( $sentence ) {
		$sentence = preg_replace( '#^(?:The address )?https?://[^\s”"]+#u', 'The page', $sentence );
		return preg_replace( '#https?://[^\s”"]+#', 'the page’s address', $sentence );
	}
}
