<?php
/**
 * Counts "access token is missing" lines that Meta for WooCommerce wrote to WooCommerce > Status > Logs.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads WooCommerce's log files and its database log table. Writes nothing.
 */
class Catalogwell_Logs {

	const PHRASE  = 'access token is missing';
	const SOURCES = array( 'facebook_for_woocommerce', 'facebook-for-woocommerce' );

	/**
	 * Largest part of one log file that is read, from its end.
	 */
	const MAX_BYTES = 20971520;

	/**
	 * Lines in the last N days, counted from the file handler and the database handler.
	 *
	 * @param int      $days Days to look back.
	 * @param int|null $now  Unix time to count back from (tests pass one).
	 * @return array{count:int,file:int,database:int,newest:int,checked:bool} The count, and the time of the newest line counted (0 when there is none).
	 */
	public static function missing_token_lines( $days = 7, $now = null ) {
		$now   = null === $now ? time() : (int) $now;
		$since = $now - ( $days * DAY_IN_SECONDS );
		$file  = self::count_in_files( $since );
		$db    = self::count_in_database( $since );
		return array(
			'count'    => $file['count'] + $db['count'],
			'file'     => $file['count'],
			'database' => $db['count'],
			'newest'   => max( $file['newest'], $db['newest'] ),
			'checked'  => true,
		);
	}

	/**
	 * The count as a sentence part: the number and, when there is one, the date of the newest line, so that lines
	 * written before a connection was fixed do not read as a fault that is still there.
	 *
	 * @param array $lines Result of missing_token_lines().
	 * @param bool  $tie   Whether the date is tied together with non-breaking spaces (the screen) or not (the report).
	 * @return string
	 */
	public static function count_text( $lines, $tie = true ) {
		$count = (int) $lines['count'];
		if ( $count < 1 || empty( $lines['newest'] ) ) {
			return (string) $count;
		}
		$when = Catalogwell_Environment::format_time( (int) $lines['newest'], $tie );
		if ( 1 === $count ) {
			/* translators: %s: date and time the line was written. */
			return sprintf( __( '1, written on %s', 'catalogwell' ), $when );
		}
		/* translators: 1: number of lines, 2: date and time the newest line was written. */
		return sprintf( __( '%1$s, the newest written on %2$s', 'catalogwell' ), number_format_i18n( $count ), $when );
	}

	/**
	 * Folder of WooCommerce's log files.
	 *
	 * @return string
	 */
	public static function log_dir() {
		if ( defined( 'WC_LOG_DIR' ) ) {
			return trailingslashit( WC_LOG_DIR );
		}
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( $uploads['basedir'] ) . 'wc-logs/';
	}

	/**
	 * Count matching lines in the file handler's logs.
	 *
	 * @param int $since Unix time.
	 * @return array{count:int,newest:int}
	 */
	private static function count_in_files( $since ) {
		$dir    = self::log_dir();
		$result = array(
			'count'  => 0,
			'newest' => 0,
		);
		if ( ! is_dir( $dir ) ) {
			return $result;
		}
		foreach ( self::SOURCES as $source ) {
			$files = glob( $dir . $source . '-*.log*' );
			if ( ! is_array( $files ) ) {
				continue;
			}
			foreach ( $files as $path ) {
				if ( ! is_file( $path ) || ! is_readable( $path ) ) {
					continue;
				}
				// A file last written before the window holds no line inside it.
				if ( (int) filemtime( $path ) < $since ) {
					continue;
				}
				$in_file          = self::count_in_file( $path, $since );
				$result['count'] += $in_file['count'];
				$result['newest'] = max( $result['newest'], $in_file['newest'] );
			}
		}
		return $result;
	}

	/**
	 * Count matching lines in one file whose own timestamp is inside the window.
	 *
	 * @param string $path  File path.
	 * @param int    $since Unix time.
	 * @return array{count:int,newest:int}
	 */
	private static function count_in_file( $path, $since ) {
		$size   = (int) filesize( $path );
		$result = array(
			'count'  => 0,
			'newest' => 0,
		);
		$handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- read-only stream of a log file.
		if ( ! $handle ) {
			return $result;
		}
		if ( $size > self::MAX_BYTES ) {
			fseek( $handle, -self::MAX_BYTES, SEEK_END );
			fgets( $handle ); // Drop the partial first line.
		}
		$fallback = (int) filemtime( $path );
		while ( false !== ( $line = fgets( $handle ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			if ( false === stripos( $line, self::PHRASE ) ) {
				continue;
			}
			$stamp = self::line_time( $line, $fallback );
			if ( $stamp >= $since ) {
				++$result['count'];
				$result['newest'] = max( $result['newest'], $stamp );
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return $result;
	}

	/**
	 * Time written at the start of a log line.
	 *
	 * @param string $line     Log line.
	 * @param int    $fallback Time to use when the line has no readable stamp.
	 * @return int
	 */
	private static function line_time( $line, $fallback ) {
		if ( preg_match( '/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:\d{2}|Z)?)/', $line, $m ) ) {
			$time = strtotime( $m[1] );
			if ( false !== $time ) {
				return $time;
			}
		}
		return $fallback;
	}

	/**
	 * Count matching rows in WooCommerce's database log table, when it exists.
	 *
	 * @param int $since Unix time.
	 * @return array{count:int,newest:int}
	 */
	private static function count_in_database( $since ) {
		global $wpdb;
		$none  = array(
			'count'  => 0,
			'newest' => 0,
		);
		$table = $wpdb->prefix . 'woocommerce_log';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only look at WooCommerce's own log table.
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
		if ( $exists !== $table ) {
			return $none;
		}
		$sources      = self::SOURCES;
		$placeholders = implode( ', ', array_fill( 0, count( $sources ), '%s' ) );
		$args         = array_merge( array( $table ), $sources, array( gmdate( 'Y-m-d H:i:s', $since ), '%' . $wpdb->esc_like( self::PHRASE ) . '%' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- read-only count; the table is bound with %i and the placeholders are generated from the fixed source list.
		$found = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS found, MAX(`timestamp`) AS newest FROM %i WHERE source IN ({$placeholders}) AND `timestamp` >= %s AND message LIKE %s",
				$args
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( ! is_array( $found ) || (int) $found['found'] < 1 ) {
			return $none;
		}
		$newest = strtotime( $found['newest'] . ' UTC' );
		return array(
			'count'  => (int) $found['found'],
			'newest' => false === $newest ? 0 : (int) $newest,
		);
	}
}
