<?php
/**
 * Counts "access token is missing" lines that Meta for WooCommerce wrote to WooCommerce > Status > Logs.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads WooCommerce's log files and its database log table. Writes nothing.
 */
class Catalogwell_Logs {

	const PHRASE  = 'access token is missing';
	const SOURCES = array( 'facebook_for_woocommerce', 'facebook-for-woocommerce' );

	/**
	 * Largest part of one log file that is read, from its end.
	 */
	const MAX_BYTES = 20971520;

	/**
	 * Lines in the last N days, counted from the file handler and the database handler.
	 *
	 * @param int      $days Days to look back.
	 * @param int|null $now  Unix time to count back from (tests pass one).
	 * @return array{count:int,file:int,database:int,checked:bool}
	 */
	public static function missing_token_lines( $days = 7, $now = null ) {
		$now   = null === $now ? time() : (int) $now;
		$since = $now - ( $days * DAY_IN_SECONDS );
		$file  = self::count_in_files( $since );
		$db    = self::count_in_database( $since );
		return array(
			'count'    => $file + $db,
			'file'     => $file,
			'database' => $db,
			'checked'  => true,
		);
	}

	/**
	 * Folder of WooCommerce's log files.
	 *
	 * @return string
	 */
	public static function log_dir() {
		if ( defined( 'WC_LOG_DIR' ) ) {
			return trailingslashit( WC_LOG_DIR );
		}
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( $uploads['basedir'] ) . 'wc-logs/';
	}

	/**
	 * Count matching lines in the file handler's logs.
	 *
	 * @param int $since Unix time.
	 * @return int
	 */
	private static function count_in_files( $since ) {
		$dir = self::log_dir();
		if ( ! is_dir( $dir ) ) {
			return 0;
		}
		$total = 0;
		foreach ( self::SOURCES as $source ) {
			$files = glob( $dir . $source . '-*.log*' );
			if ( ! is_array( $files ) ) {
				continue;
			}
			foreach ( $files as $path ) {
				if ( ! is_file( $path ) || ! is_readable( $path ) ) {
					continue;
				}
				// A file last written before the window holds no line inside it.
				if ( (int) filemtime( $path ) < $since ) {
					continue;
				}
				$total += self::count_in_file( $path, $since );
			}
		}
		return $total;
	}

	/**
	 * Count matching lines in one file whose own timestamp is inside the window.
	 *
	 * @param string $path  File path.
	 * @param int    $since Unix time.
	 * @return int
	 */
	private static function count_in_file( $path, $since ) {
		$size   = (int) filesize( $path );
		$handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- read-only stream of a log file.
		if ( ! $handle ) {
			return 0;
		}
		if ( $size > self::MAX_BYTES ) {
			fseek( $handle, -self::MAX_BYTES, SEEK_END );
			fgets( $handle ); // Drop the partial first line.
		}
		$fallback = (int) filemtime( $path );
		$count    = 0;
		while ( false !== ( $line = fgets( $handle ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			if ( false === stripos( $line, self::PHRASE ) ) {
				continue;
			}
			$stamp = self::line_time( $line, $fallback );
			if ( $stamp >= $since ) {
				++$count;
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return $count;
	}

	/**
	 * Time written at the start of a log line.
	 *
	 * @param string $line     Log line.
	 * @param int    $fallback Time to use when the line has no readable stamp.
	 * @return int
	 */
	private static function line_time( $line, $fallback ) {
		if ( preg_match( '/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:\d{2}|Z)?)/', $line, $m ) ) {
			$time = strtotime( $m[1] );
			if ( false !== $time ) {
				return $time;
			}
		}
		return $fallback;
	}

	/**
	 * Count matching rows in WooCommerce's database log table, when it exists.
	 *
	 * @param int $since Unix time.
	 * @return int
	 */
	private static function count_in_database( $since ) {
		global $wpdb;
		$table = $wpdb->prefix . 'woocommerce_log';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only look at WooCommerce's own log table.
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
		if ( $exists !== $table ) {
			return 0;
		}
		$sources      = self::SOURCES;
		$placeholders = implode( ', ', array_fill( 0, count( $sources ), '%s' ) );
		$args         = array_merge( array( $table ), $sources, array( gmdate( 'Y-m-d H:i:s', $since ), '%' . $wpdb->esc_like( self::PHRASE ) . '%' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- read-only count; the table is bound with %i and the placeholders are generated from the fixed source list.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE source IN ({$placeholders}) AND `timestamp` >= %s AND message LIKE %s",
				$args
			)
		);
		// phpcs:enable
		return (int) $count;
	}
}
