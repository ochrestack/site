<?php
/**
 * Check 2: which products go to Meta as "hidden", and why.
 *
 * The rules are read from Meta for WooCommerce 3.7.9 (Products::is_product_visible, the visibility block of
 * WC_Facebook_Product::prepare_product and ProductValidator). Nothing here calls Meta for WooCommerce's own
 * functions that write, and nothing is written to any product.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Catalog visibility check.
 */
class Catalogwell_Catalog {

	const PAGE_SIZE = 200;

	const VIS_PUBLISHED  = 'p';
	const VIS_HIDDEN     = 'h';
	const VIS_NOT_SYNCED = 'n';

	/**
	 * Count the items the check will look at: published products and published variations.
	 *
	 * @return int
	 */
	public static function count_items() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only count.
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ('product','product_variation') AND post_status = 'publish'" );
	}

	/**
	 * Scan one page of items after a post ID.
	 *
	 * The items are the ones Meta for WooCommerce's feed goes through: published products and published
	 * variations of published products, without the variable products that have published variations.
	 *
	 * @param int $after_id Last post ID of the previous page (0 to start).
	 * @param int $limit    Items per page.
	 * @return array{rows:array,last_id:int,done:bool,seen:int}
	 */
	public static function scan_page( $after_id, $limit = self::PAGE_SIZE ) {
		global $wpdb;
		$limit = max( 1, (int) $limit );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only paging by ID.
		$posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_type, post_parent FROM {$wpdb->posts} WHERE post_type IN ('product','product_variation') AND post_status = 'publish' AND ID > %d ORDER BY ID ASC LIMIT %d",
				(int) $after_id,
				$limit
			)
		);
		// phpcs:enable

		if ( empty( $posts ) ) {
			return array(
				'rows'    => array(),
				'last_id' => (int) $after_id,
				'done'    => true,
				'seen'    => 0,
			);
		}

		$last_id    = (int) $posts[ count( $posts ) - 1 ]->ID;
		$all_ids    = array();
		$product_id = array();
		$parent_ids = array();
		foreach ( $posts as $post ) {
			$all_ids[] = (int) $post->ID;
			if ( 'product' === $post->post_type ) {
				$product_id[] = (int) $post->ID;
			} else {
				$parent_ids[] = (int) $post->post_parent;
			}
		}

		$has_variations   = self::parents_with_published_variations( $product_id );
		$published_parent = self::published_products( $parent_ids );

		_prime_post_caches( $all_ids, false, true );

		$ctx  = array(
			'parents' => array(),
		);
		$rows = array();
		foreach ( $posts as $post ) {
			$id = (int) $post->ID;
			if ( 'product' === $post->post_type ) {
				if ( isset( $has_variations[ $id ] ) ) {
					continue; // A variable product with published variations is a group, not an item.
				}
			} elseif ( ! isset( $published_parent[ (int) $post->post_parent ] ) ) {
				continue; // A variation of an unpublished product is not in the feed.
			}
			$product = wc_get_product( $id );
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			$result = self::evaluate( $product, $ctx );
			$rows[] = array( $id, $result['visibility'], $result['reason'] );
		}

		return array(
			'rows'    => $rows,
			'last_id' => $last_id,
			'done'    => count( $posts ) < $limit,
			'seen'    => count( $posts ),
		);
	}

	/**
	 * Which of these products have at least one published variation.
	 *
	 * @param int[] $ids Product IDs.
	 * @return array<int,bool>
	 */
	private static function parents_with_published_variations( $ids ) {
		global $wpdb;
		if ( empty( $ids ) ) {
			return array();
		}
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- read-only; placeholders generated from the ID count.
		$found = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT post_parent FROM {$wpdb->posts} WHERE post_type = 'product_variation' AND post_status = 'publish' AND post_parent IN ({$placeholders})",
				$ids
			)
		);
		// phpcs:enable
		return array_fill_keys( array_map( 'intval', $found ), true );
	}

	/**
	 * Which of these IDs are published products.
	 *
	 * @param int[] $ids Post IDs.
	 * @return array<int,bool>
	 */
	private static function published_products( $ids ) {
		global $wpdb;
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- read-only; placeholders generated from the ID count.
		$found = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish' AND ID IN ({$placeholders})",
				$ids
			)
		);
		// phpcs:enable
		return array_fill_keys( array_map( 'intval', $found ), true );
	}

	/**
	 * Name of the product meta key that holds Facebook Sync "do not sync" for the current plugin mode.
	 *
	 * @return string
	 */
	private static function sync_meta_key() {
		return get_option( 'wc_facebook_master_sync_opt_out_time' ) ? '_wc_facebook_sync_enabled' : '_wc_facebook_sync_enabled_v2';
	}

	/**
	 * Meta for WooCommerce's own reason why a product is not synced, or null when it is synced.
	 *
	 * @param WC_Product $product Item.
	 * @param array      $ctx     Per-page cache.
	 * @return string|null Reason key.
	 */
	private static function not_synced_reason( $product, &$ctx ) {
		$reason = self::not_synced_by_product( $product, $ctx );
		if ( null !== $reason ) {
			return $reason;
		}
		return self::language_excludes( $product, $ctx ) ? 'ns_language' : null;
	}

	/**
	 * The sync rules that read the product itself (the sync field, the filter, the store catalog setting).
	 *
	 * @param WC_Product $product Item.
	 * @param array      $ctx     Per-page cache.
	 * @return string|null Reason key.
	 */
	private static function not_synced_by_product( $product, &$ctx ) {
		$parent = null;
		if ( $product->get_parent_id() ) {
			$parent = self::parent_of( $product, $ctx );
		}

		if ( ! apply_filters( 'wc_facebook_should_sync_product', true, $product ) ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Meta for WooCommerce's own filter, applied to read its answer.
			return 'ns_filter';
		}

		$key = self::sync_meta_key();
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( $child && 'no' !== $child->get_meta( $key ) ) {
					return self::catalog_hidden_reason( $product, $parent );
				}
			}
			return 'ns_field';
		}
		if ( 'variation' === $product->get_type() ) {
			if ( ! $parent instanceof WC_Product ) {
				return 'ns_field';
			}
			$parent_sync = $parent->get_meta( $key );
			if ( 'yes' === $parent_sync ) {
				return self::catalog_hidden_reason( $product, $parent );
			}
			if ( 'no' === $parent_sync ) {
				return 'ns_field';
			}
			$any = false;
			foreach ( $parent->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( $child && 'no' !== $child->get_meta( $key ) ) {
					$any = true;
					break;
				}
			}
			return $any ? self::catalog_hidden_reason( $product, $parent ) : 'ns_field';
		}
		if ( 'no' === $product->get_meta( $key ) ) {
			return 'ns_field';
		}
		return self::catalog_hidden_reason( $product, $parent );
	}

	/**
	 * Meta for WooCommerce excludes products hidden from the store catalog (catalog visibility "hidden" or "search").
	 *
	 * @param WC_Product      $product Item.
	 * @param WC_Product|null $parent_product Parent of a variation.
	 * @return string|null
	 */
	private static function catalog_hidden_reason( $product, $parent_product ) {
		$check   = $parent_product instanceof WC_Product ? $parent_product : $product;
		$setting = $check->get_catalog_visibility();
		// Same expression as ProductValidator::validate_product_visibility(), outside a search request.
		$visible = 'visible' === $setting || 'catalog' === $setting;
		if ( 'trash' === $check->get_status() || 'publish' !== $check->get_status() ) {
			$visible = false;
		}
		return $visible ? null : 'ns_catalog';
	}

	/**
	 * The product ID Meta for WooCommerce asks its language rules about: the parent for a variation.
	 *
	 * @param WC_Product $product Item.
	 * @return int
	 */
	private static function language_id( $product ) {
		return $product->get_parent_id() ? (int) $product->get_parent_id() : (int) $product->get_id();
	}

	/**
	 * Meta for WooCommerce's WPML rule, which Polylang's WPML compatibility layer also feeds: when
	 * ICL_LANGUAGE_CODE is defined, an item is sent as hidden unless the plugin's own WPMLInjector::should_hide()
	 * says no. Read-only: it asks the plugin's own function.
	 *
	 * @param WC_Product $product Item.
	 * @return bool
	 */
	private static function language_hides( $product ) {
		if ( ! defined( 'ICL_LANGUAGE_CODE' ) || ! class_exists( '\\WooCommerce\\Facebook\\WPMLInjector' ) || ! method_exists( '\\WooCommerce\\Facebook\\WPMLInjector', 'should_hide' ) ) {
			return false;
		}
		return (bool) \WooCommerce\Facebook\WPMLInjector::should_hide( self::language_id( $product ) );
	}

	/**
	 * Whether Polylang or WPML gives the item no language at all. Meta for WooCommerce's rule asks the same filter first:
	 * WPML answers a post it does not know with a WP_Error (or the filter is not answered at all), and Polylang answers a
	 * post with no language with an empty array. In each case the language code is missing, and that is the one language case
	 * a store owner fixes on the product.
	 *
	 * @param WC_Product $product Item.
	 * @return bool
	 */
	private static function has_no_language( $product ) {
		$details = apply_filters( 'wpml_post_language_details', null, self::language_id( $product ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPML's own filter, which Polylang also answers.
		return ! is_array( $details ) || empty( $details['language_code'] );
	}

	/**
	 * ProductValidator::validate_product_language(): while Meta for WooCommerce's language-feed switch is on and
	 * Polylang or WPML is active, only products in the default language are synced to the main catalog.
	 * Meta's own methods answer each question; a product whose language cannot be told is let through, as there.
	 *
	 * @param WC_Product $product Item.
	 * @param array      $ctx     Per-page cache.
	 * @return bool
	 */
	private static function language_excludes( $product, &$ctx ) {
		if ( ! array_key_exists( 'language', $ctx ) ) {
			$ctx['language'] = self::language_context();
		}
		if ( ! $ctx['language'] ) {
			return false;
		}
		try {
			$language = (string) $ctx['language']['integration']->get_product_language( self::language_id( $product ) );
			if ( '' === $language ) {
				return false;
			}
			return self::language_code( $language ) !== self::language_code( $ctx['language']['default'] );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * The language code in a locale or a language slug, as ProductValidator::extract_language_code() takes it.
	 *
	 * @param string $locale Locale or slug.
	 * @return string
	 */
	private static function language_code( $locale ) {
		$parts = explode( '_', $locale );
		return strtolower( $parts[0] );
	}

	/**
	 * Meta for WooCommerce's active localization integration and its default language, when its language rule
	 * applies; false otherwise.
	 *
	 * @return array|false
	 */
	private static function language_context() {
		try {
			$registry = '\\WooCommerce\\Facebook\\Integrations\\IntegrationRegistry';
			if ( ! function_exists( 'facebook_for_woocommerce' ) || ! class_exists( $registry ) ) {
				return false;
			}
			$integration = facebook_for_woocommerce()->get_integration();
			if ( ! $integration || ! method_exists( $integration, 'is_language_override_feed_generation_enabled' ) || ! $integration->is_language_override_feed_generation_enabled() ) {
				return false;
			}
			$localization = $registry::get_active_localization_integration();
			$default      = $localization ? $localization->get_default_language() : null;
			if ( ! $default ) {
				return false;
			}
			return array(
				'integration' => $localization,
				'default'     => (string) $default,
			);
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Parent product of a variation, cached for the page.
	 *
	 * @param WC_Product $product Variation.
	 * @param array      $ctx     Per-page cache.
	 * @return WC_Product|null
	 */
	private static function parent_of( $product, &$ctx ) {
		$parent_id = $product->get_parent_id();
		if ( ! isset( $ctx['parents'][ $parent_id ] ) ) {
			$parent                       = wc_get_product( $parent_id );
			$ctx['parents'][ $parent_id ] = $parent instanceof WC_Product ? $parent : false;
		}
		return $ctx['parents'][ $parent_id ] ? $ctx['parents'][ $parent_id ] : null;
	}

	/**
	 * Meta for WooCommerce's Products::is_product_visible(), with the reason it answers false.
	 *
	 * @param WC_Product $product Item.
	 * @return array{0:bool,1:string} Visible, reason key.
	 */
	private static function is_visible( $product ) {
		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) && ! $product->is_in_stock() ) {
			return array( false, 'setting_out_of_stock' );
		}
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( $child && self::is_visible( $child )[0] ) {
					return array( true, 'published' );
				}
			}
			return array( false, 'no_visible_variation' );
		}
		$meta = $product->get_meta( 'fb_visibility' );
		if ( $meta ) {
			return wc_string_to_bool( $meta ) ? array( true, 'published' ) : array( false, 'sync_hide' );
		}
		return array( true, 'published' );
	}

	/**
	 * Visibility Meta for WooCommerce gives one item, and the reason.
	 *
	 * @param WC_Product $product Simple product, variation, or a variable product with no variations.
	 * @param array      $ctx     Per-page cache (pass an empty array).
	 * @return array{visibility:string,reason:string}
	 */
	public static function evaluate( $product, &$ctx = array() ) {
		if ( ! isset( $ctx['parents'] ) ) {
			$ctx['parents'] = array();
		}
		$not_synced = self::not_synced_reason( $product, $ctx );
		if ( null !== $not_synced ) {
			return array(
				'visibility' => self::VIS_NOT_SYNCED,
				'reason'     => $not_synced,
			);
		}

		list( $visible, $reason ) = self::is_visible( $product );
		$vis                      = $visible ? self::VIS_PUBLISHED : self::VIS_HIDDEN;

		if ( 'variation' === $product->get_type() ) {
			$parent = self::parent_of( $product, $ctx );
			if ( $parent ) {
				$parent_meta = $parent->get_meta( 'fb_visibility' );
				if ( 'yes' === $parent_meta ) {
					$vis    = self::VIS_PUBLISHED;
					$reason = 'published';
				} elseif ( 'no' === $parent_meta ) {
					$vis    = self::VIS_HIDDEN;
					$reason = 'parent_sync_hide';
				} else {
					$any = false;
					foreach ( $parent->get_children() as $child_id ) {
						$child = wc_get_product( $child_id );
						if ( $child && self::is_visible( $child )[0] ) {
							$any = true;
							break;
						}
					}
					$vis    = $any ? self::VIS_PUBLISHED : self::VIS_HIDDEN;
					$reason = $any ? 'published' : 'no_visible_variation';
				}
			}
		}

		if ( self::language_hides( $product ) ) {
			$vis    = self::VIS_HIDDEN;
			$reason = self::has_no_language( $product ) ? 'language_none' : 'language';
		}

		if ( ! $product->is_in_stock() ) {
			$vis    = self::VIS_HIDDEN;
			$reason = 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ? 'setting_out_of_stock' : 'out_of_stock';
		}

		if ( true === $product->get_virtual() && 'bundle' !== $product->get_type() ) {
			$vis    = self::VIS_HIDDEN;
			$reason = 'virtual';
		}

		return array(
			'visibility' => $vis,
			'reason'     => $reason,
		);
	}

	/**
	 * Count rows by visibility and reason.
	 *
	 * @param array[] $rows Rows of [id, visibility, reason].
	 * @return array{hidden:int,listed:int,not_synced:int,by_reason:array<string,int>}
	 */
	public static function summarise( $rows ) {
		$summary = array(
			'hidden'     => 0,
			'listed'     => 0,
			'not_synced' => 0,
			'by_reason'  => array(),
		);
		foreach ( $rows as $row ) {
			$reason = $row[2];
			if ( ! isset( $summary['by_reason'][ $reason ] ) ) {
				$summary['by_reason'][ $reason ] = 0;
			}
			++$summary['by_reason'][ $reason ];
			if ( self::VIS_NOT_SYNCED === $row[1] ) {
				++$summary['not_synced'];
				continue;
			}
			++$summary['listed'];
			if ( self::VIS_HIDDEN === $row[1] ) {
				++$summary['hidden'];
			}
		}
		return $summary;
	}

	/**
	 * The sentence that opens the catalog result while Meta for WooCommerce is deactivated or deleted.
	 *
	 * @return string
	 */
	public static function off_text() {
		return __( 'Meta for WooCommerce is not active, so this site is not sending products to Meta now.', 'catalogwell' );
	}

	/**
	 * "2 of 22 products go to Meta as hidden." While the plugin is off, what would happen if it were switched on.
	 *
	 * @param array $summary Summary of the rows.
	 * @param bool  $off     Whether Meta for WooCommerce is deactivated or deleted.
	 * @return string
	 */
	public static function count_text( $summary, $off = false ) {
		$listed = (int) $summary['listed'];
		if ( $off ) {
			return sprintf(
				/* translators: 1: number of hidden products, 2: number of products that would go to Meta. */
				_n( 'If it is activated again, %1$s of %2$s product would go to Meta as hidden.', 'If it is activated again, %1$s of %2$s products would go to Meta as hidden.', $listed, 'catalogwell' ),
				number_format_i18n( $summary['hidden'] ),
				number_format_i18n( $listed )
			);
		}
		return sprintf(
			/* translators: 1: number of hidden products, 2: number of products that go to Meta. */
			_n( '%1$s of %2$s product goes to Meta as hidden.', '%1$s of %2$s products go to Meta as hidden.', $listed, 'catalogwell' ),
			number_format_i18n( $summary['hidden'] ),
			number_format_i18n( $listed )
		);
	}

	/**
	 * "2 more products are not synced at all."
	 *
	 * @param array $summary Summary of the rows.
	 * @param bool  $off     Whether Meta for WooCommerce is deactivated or deleted.
	 * @return string
	 */
	public static function not_synced_text( $summary, $off = false ) {
		$count = (int) $summary['not_synced'];
		if ( $off ) {
			return sprintf(
				/* translators: %s: number of products Meta for WooCommerce would not sync. */
				_n( '%s more product would not be synced at all.', '%s more products would not be synced at all.', $count, 'catalogwell' ),
				number_format_i18n( $count )
			);
		}
		return sprintf(
			/* translators: %s: number of products Meta for WooCommerce does not sync. */
			_n( '%s more product is not synced at all.', '%s more products are not synced at all.', $count, 'catalogwell' ),
			number_format_i18n( $count )
		);
	}

	/**
	 * Plain one-line reason for a reason key.
	 *
	 * @param string $key Reason key.
	 * @return string
	 */
	public static function reason_text( $key ) {
		switch ( $key ) {
			case 'published':
				return __( 'Published: nothing in WooCommerce or in Facebook Sync hides it.', 'catalogwell' );
			case 'setting_out_of_stock':
				return __( 'Out of stock, and the WooCommerce setting “Hide out of stock items from the catalog” (Settings > Products > Inventory) is on.', 'catalogwell' );
			case 'out_of_stock':
				return __( 'Out of stock (the product’s Stock status): Meta for WooCommerce sends every out-of-stock item as hidden.', 'catalogwell' );
			case 'sync_hide':
				return __( 'Facebook Sync is set to “Sync and hide in catalog” on this product (its field fb_visibility is “no”).', 'catalogwell' );
			case 'parent_sync_hide':
				return __( 'The parent product’s Facebook Sync is “Sync and hide in catalog” (its field fb_visibility is “no”), which hides its variations.', 'catalogwell' );
			case 'no_visible_variation':
				return __( 'No variation of this product is visible: every variation is out of stock or set to hide.', 'catalogwell' );
			case 'virtual':
				return __( 'Virtual product (the “Virtual” box on the product is ticked): Meta for WooCommerce sends virtual products, bundles excepted, as hidden.', 'catalogwell' );
			case 'language':
				return __( 'Hidden by Meta for WooCommerce’s language rule (Meta’s rule): Polylang or WPML says this product is in a language other than the default one, or in one set not to show.', 'catalogwell' );
			case 'language_none':
				return __( 'Hidden because Polylang or WPML gives this product no language (fix on this site: set the product’s language, then run Catalogwell again).', 'catalogwell' );
			case 'ns_language':
				return __( 'Not synced. Meta for WooCommerce only syncs products in the default language to the main catalog, and Polylang or WPML says this product is in another language.', 'catalogwell' );
			case 'ns_field':
				return __( 'Not synced. Meta for WooCommerce says: “Sync disabled in product field.”', 'catalogwell' );
			case 'ns_catalog':
				return __( 'Not synced. Meta for WooCommerce says: “This product cannot be synced to Facebook because it is hidden from your store catalog.”', 'catalogwell' );
			case 'ns_filter':
				return __( 'Not synced. Meta for WooCommerce says: “Product excluded by wc_facebook_should_sync_product filter.”', 'catalogwell' );
			default:
				return '';
		}
	}

	/**
	 * Short title for the reason groups at the top of the result.
	 *
	 * @param string $key Reason key.
	 * @return string
	 */
	public static function reason_title( $key ) {
		switch ( $key ) {
			case 'published':
				return __( 'Published', 'catalogwell' );
			case 'setting_out_of_stock':
				return __( 'Hidden: out of stock with “Hide out of stock items” on', 'catalogwell' );
			case 'out_of_stock':
				return __( 'Hidden: out of stock', 'catalogwell' );
			case 'sync_hide':
				return __( 'Hidden: Facebook Sync set to hide', 'catalogwell' );
			case 'parent_sync_hide':
				return __( 'Hidden: the parent’s Facebook Sync set to hide', 'catalogwell' );
			case 'no_visible_variation':
				return __( 'Hidden: no visible variation', 'catalogwell' );
			case 'virtual':
				return __( 'Hidden: virtual product', 'catalogwell' );
			case 'language':
				return __( 'Hidden: not in the default language (Polylang or WPML)', 'catalogwell' );
			case 'language_none':
				return __( 'Hidden: no language set (Polylang or WPML)', 'catalogwell' );
			case 'ns_language':
				return __( 'Not synced: not in the default language', 'catalogwell' );
			case 'ns_field':
				return __( 'Not synced: sync disabled in product field', 'catalogwell' );
			case 'ns_catalog':
				return __( 'Not synced: hidden from the store catalog', 'catalogwell' );
			case 'ns_filter':
				return __( 'Not synced: excluded by a filter', 'catalogwell' );
			default:
				return $key;
		}
	}
}
