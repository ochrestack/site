<?php
/**
 * What is installed and active: WooCommerce, Meta for WooCommerce, Google for WooCommerce.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin state helpers.
 */
class Catalogwell_Environment {

	const META_FILE   = 'facebook-for-woocommerce.php';
	const GOOGLE_FILE = 'google-listings-and-ads.php';

	/**
	 * Whether WooCommerce is loaded.
	 *
	 * @return bool
	 */
	public static function woocommerce_active() {
		/**
		 * Lets a test, or a site that loads WooCommerce late, say whether WooCommerce counts as active.
		 *
		 * @param bool $active Whether WooCommerce's classes are loaded.
		 */
		return (bool) apply_filters( 'catalogwell_woocommerce_active', class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' ) );
	}

	/**
	 * State of a plugin found by the file name of its main file.
	 *
	 * @param string $main_file File name, for example facebook-for-woocommerce.php.
	 * @return array{state:string,version:string,basename:string} state is active, inactive or deleted.
	 */
	public static function plugin_state( $main_file ) {
		if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$found = array(
			'state'    => 'deleted',
			'version'  => '',
			'basename' => '',
		);
		foreach ( get_plugins() as $basename => $data ) {
			if ( basename( $basename ) !== $main_file ) {
				continue;
			}
			$found['basename'] = $basename;
			$found['version']  = isset( $data['Version'] ) ? (string) $data['Version'] : '';
			$found['state']    = ( is_plugin_active( $basename ) || is_plugin_active_for_network( $basename ) ) ? 'active' : 'inactive';
			break;
		}
		return $found;
	}

	/**
	 * Meta for WooCommerce state.
	 *
	 * @return array
	 */
	public static function meta() {
		return self::plugin_state( self::META_FILE );
	}

	/**
	 * Google for WooCommerce state.
	 *
	 * @return array
	 */
	public static function google() {
		return self::plugin_state( self::GOOGLE_FILE );
	}

	/**
	 * Whether Meta for WooCommerce is active and its classes are loaded.
	 *
	 * @return bool
	 */
	public static function meta_loaded() {
		return class_exists( 'WC_Facebookcommerce' ) || function_exists( 'facebook_for_woocommerce' );
	}

	/**
	 * Absolute upload folder of Meta for WooCommerce's feed files.
	 *
	 * @return string
	 */
	public static function feed_dir() {
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( $uploads['basedir'] ) . 'facebook_for_woocommerce';
	}

	/**
	 * Date and time as the site writes them. On the screen the stamp is kept on one line (a date that breaks
	 * between the year and the hour reads as two things); in e-mail and in the report it has ordinary spaces.
	 *
	 * @param int  $timestamp Unix time.
	 * @param bool $tie       Whether to tie the stamp together with non-breaking spaces.
	 * @return string
	 */
	public static function format_time( $timestamp, $tie = true ) {
		$text = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $timestamp );
		return $tie ? str_replace( ' ', "\xC2\xA0", $text ) : $text;
	}

	/**
	 * The date and the time for a table cell: each tied together, with one ordinary space between them, so that a
	 * narrow column breaks the stamp between the date and the time and never inside either.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	public static function format_time_cell( $timestamp ) {
		$date = str_replace( ' ', "\xC2\xA0", wp_date( get_option( 'date_format' ), (int) $timestamp ) );
		$time = str_replace( ' ', "\xC2\xA0", wp_date( get_option( 'time_format' ), (int) $timestamp ) );
		return $date . ' ' . $time;
	}

	/**
	 * Remove e-mail addresses and the stored access token (or a 20-character piece of it) from text
	 * that came from another plugin, before it reaches the screen, a report or a file.
	 *
	 * @param string $text Text from another plugin.
	 * @return string
	 */
	public static function scrub( $text ) {
		$text  = (string) $text;
		$text  = preg_replace( '/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', '[e-mail removed]', $text );
		$token = trim( (string) get_option( 'wc_facebook_access_token', '' ) );
		if ( '' !== $token ) {
			if ( strlen( $token ) < 20 ) {
				$text = str_replace( $token, '[token removed]', $text );
			} else {
				$last = strlen( $token ) - 20;
				for ( $i = 0; $i <= $last; $i++ ) {
					$text = str_replace( substr( $token, $i, 20 ), '[token removed]', $text );
				}
			}
		}
		return $text;
	}
}
