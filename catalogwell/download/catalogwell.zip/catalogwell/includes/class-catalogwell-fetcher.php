<?php
/**
 * Loads the site's own pages as a logged-out visitor with no cookies.
 *
 * Requests go only to the host of home_url(). Nothing is sent to any other address.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Own-page fetcher.
 */
class Catalogwell_Fetcher {

	const USER_AGENT_PREFIX = 'Catalogwell/';
	const CRAWLER_LINE      = 'Blocked CAPI event for crawler: ';
	const MAX_REDIRECTS     = 3;
	const MAX_BYTES         = 3145728;

	/**
	 * Tell Meta for WooCommerce that a request made by Catalogwell is not a visitor.
	 *
	 * Meta for WooCommerce sends PageView and ViewContent to the store's Pixel from the server (Conversions API)
	 * while it renders a page, with no script needed, so a page load made for a check would be counted as a
	 * visit and would write a line to its log. Its own filter for crawlers makes it send nothing for the load.
	 * This runs on every request the plugin is loaded on, including the ones Catalogwell makes to the site.
	 *
	 * @param bool   $is_crawler Answer so far.
	 * @param string $user_agent Lower-case User-Agent of the request.
	 * @return bool
	 */
	public static function treat_as_crawler( $is_crawler, $user_agent ) {
		return $is_crawler || 0 === strpos( strtolower( (string) $user_agent ), strtolower( self::USER_AGENT_PREFIX ) );
	}

	/**
	 * Keep the log line Meta for WooCommerce writes about a blocked page load out of WooCommerce's log.
	 *
	 * For a request the crawler filter above answers true for, Meta for WooCommerce logs "Blocked CAPI event for
	 * crawler: <User-Agent>" once per event. It logs while its debug mode is on, and always while the store is not
	 * connected (it force-enables its log then), which is exactly where the "access token is missing" lines are read.
	 * A check loads pages about 18 times, so without this the log would fill with Catalogwell's own lines. Only a
	 * line whose User-Agent is Catalogwell's is dropped; every other line Meta for WooCommerce writes is kept.
	 *
	 * @param string|null $message Log message.
	 * @return string|null Null drops the line (WooCommerce 5.3 and later), anything else is logged as it was.
	 */
	public static function drop_own_crawler_line( $message ) {
		if ( is_string( $message ) && 0 === stripos( $message, self::CRAWLER_LINE . self::USER_AGENT_PREFIX ) ) {
			return null;
		}
		return $message;
	}

	/**
	 * Host (and port) every request must go to.
	 *
	 * @return string
	 */
	public static function own_host() {
		$parts = wp_parse_url( home_url( '/' ) );
		$host  = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
		if ( isset( $parts['port'] ) ) {
			$host .= ':' . $parts['port'];
		}
		return $host;
	}

	/**
	 * Whether an address is on the site's own host.
	 *
	 * @param string $url Address.
	 * @return bool
	 */
	public static function is_own( $url ) {
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) || ! in_array( isset( $parts['scheme'] ) ? $parts['scheme'] : '', array( 'http', 'https' ), true ) ) {
			return false;
		}
		$host = strtolower( $parts['host'] );
		if ( isset( $parts['port'] ) ) {
			$host .= ':' . $parts['port'];
		}
		return self::own_host() === $host;
	}

	/**
	 * Load one page.
	 *
	 * @param string $url Address on the site's own host.
	 * @return array{kind:string,status:int,url:string,type:string,body:string,headers:array<string,string>,sentence:string,redirected_from:string}
	 *               kind is ok, redirect_away, not_found, not_html, other_status, foreign_host or error.
	 */
	public static function get( $url ) {
		$result = array(
			'kind'            => 'error',
			'status'          => 0,
			'url'             => $url,
			'type'            => '',
			'body'            => '',
			'headers'         => array(),
			'sentence'        => '',
			'redirected_from' => '',
		);

		$current = $url;
		for ( $hop = 0; $hop <= self::MAX_REDIRECTS; $hop++ ) {
			if ( ! self::is_own( $current ) ) {
				$result['kind']     = 'foreign_host';
				$result['sentence'] = sprintf(
					/* translators: %s: address. */
					__( 'The address %s is not on this site’s own host, so Catalogwell did not load it.', 'catalogwell' ),
					$current
				);
				return $result;
			}

			Catalogwell_Runner::heartbeat();
			$response = wp_remote_get(
				$current,
				array(
					'timeout'             => 20,
					'redirection'         => 0,
					'cookies'             => array(),
					'user-agent'          => self::USER_AGENT_PREFIX . CATALOGWELL_VERSION . ' (checks this site’s own pages)',
					'sslverify'           => (bool) apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WordPress's own filter for requests to the site itself.
					'reject_unsafe_urls'  => false,
					'limit_response_size' => self::MAX_BYTES,
					'headers'             => array( 'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$result['kind']     = 'error';
				$result['url']      = $current;
				$result['sentence'] = sprintf(
					/* translators: 1: address, 2: error message. */
					__( 'The address %1$s could not be loaded: %2$s', 'catalogwell' ),
					$current,
					$response->get_error_message()
				);
				return $result;
			}

			$status  = (int) wp_remote_retrieve_response_code( $response );
			$headers = array();
			$raw     = wp_remote_retrieve_headers( $response );
			$all     = is_object( $raw ) && method_exists( $raw, 'getAll' ) ? $raw->getAll() : (array) $raw;
			foreach ( $all as $name => $value ) {
				$headers[ strtolower( (string) $name ) ] = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
			}
			$result['status']  = $status;
			$result['url']     = $current;
			$result['headers'] = $headers;

			if ( $status >= 300 && $status < 400 && ! empty( $headers['location'] ) ) {
				$next = self::absolute( $headers['location'], $current );
				if ( $hop >= self::MAX_REDIRECTS || ! self::is_own( $next ) ) {
					$result['kind']     = 'redirect_away';
					$result['sentence'] = sprintf(
						/* translators: 1: address, 2: HTTP status, 3: address it redirects to. */
						__( 'The address %1$s redirects (HTTP %2$d) to %3$s, which Catalogwell does not follow because it is another host or too many redirects deep.', 'catalogwell' ),
						$current,
						$status,
						$next
					);
					return $result;
				}
				if ( '' === $result['redirected_from'] ) {
					$result['redirected_from'] = $url;
				}
				$current = $next;
				continue;
			}

			if ( 404 === $status || 410 === $status ) {
				$result['kind']     = 'not_found';
				$result['sentence'] = sprintf(
					/* translators: %s: address. */
					__( 'The address %s answered “not found” (HTTP 404) to a visitor who is not logged in, so there was no page to read.', 'catalogwell' ),
					$current
				);
				return $result;
			}
			if ( 200 !== $status ) {
				$result['kind']     = 'other_status';
				$result['sentence'] = sprintf(
					/* translators: 1: address, 2: HTTP status. */
					__( 'The address %1$s answered HTTP %2$d to a visitor who is not logged in, so there was no page to read.', 'catalogwell' ),
					$current,
					$status
				);
				return $result;
			}

			$type = isset( $headers['content-type'] ) ? strtolower( trim( strtok( $headers['content-type'], ';' ) ) ) : '';
			if ( '' !== $type && 'text/html' !== $type && 'application/xhtml+xml' !== $type ) {
				$result['kind']     = 'not_html';
				$result['type']     = $type;
				$result['sentence'] = sprintf(
					/* translators: 1: address, 2: content type. */
					__( 'The address %1$s answered with %2$s, not a web page, so there was nothing to read.', 'catalogwell' ),
					$current,
					$type
				);
				return $result;
			}

			$result['kind']     = 'ok';
			$result['type']     = $type;
			$result['body']     = (string) wp_remote_retrieve_body( $response );
			$result['sentence'] = '' === $result['redirected_from']
				? ''
				: sprintf(
					/* translators: 1: address asked for, 2: address that was read. */
					__( '%1$s redirected to %2$s, and that page was read.', 'catalogwell' ),
					$result['redirected_from'],
					$current
				);
			return $result;
		}
		return $result;
	}

	/**
	 * Make a Location header absolute.
	 *
	 * @param string $location Location header value.
	 * @param string $base     Address the response came from.
	 * @return string
	 */
	private static function absolute( $location, $base ) {
		if ( preg_match( '#^https?://#i', $location ) ) {
			return $location;
		}
		$parts  = wp_parse_url( $base );
		$origin = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'http' ) . '://' . ( isset( $parts['host'] ) ? $parts['host'] : '' ) . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
		if ( 0 === strpos( $location, '//' ) ) {
			return ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'http' ) . ':' . $location;
		}
		if ( 0 === strpos( $location, '/' ) ) {
			return $origin . $location;
		}
		$path = isset( $parts['path'] ) ? preg_replace( '#/[^/]*$#', '/', $parts['path'] ) : '/';
		return $origin . $path . $location;
	}

	/**
	 * When the address belongs to a product that is not published, say so (a visitor gets a 404 for it).
	 *
	 * @param string $url Address.
	 * @return string Sentence, or an empty string.
	 */
	public static function unpublished_sentence( $url ) {
		$post_id = url_to_postid( $url );
		if ( ! $post_id ) {
			return '';
		}
		$status = get_post_status( $post_id );
		if ( ! $status || 'publish' === $status ) {
			return '';
		}
		return sprintf(
			/* translators: 1: address, 2: post status such as private or draft. */
			__( 'The address %1$s belongs to a product that is “%2$s”, so a visitor who is not logged in gets a 404 and there is nothing to check. Choose a published product.', 'catalogwell' ),
			$url,
			$status
		);
	}
}
