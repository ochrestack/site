<?php
/**
 * Who may open the screen and call its endpoints.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Capability and nonce checks, in one place.
 */
class Catalogwell_Access {

	const NONCE_ACTION = 'catalogwell_run';

	/**
	 * Capability needed for the screen: manage WooCommerce, or administrator while WooCommerce is inactive.
	 *
	 * @return string
	 */
	public static function capability() {
		return Catalogwell_Environment::woocommerce_active() ? 'manage_woocommerce' : 'manage_options';
	}

	/**
	 * Whether the current user may use Catalogwell.
	 *
	 * @return bool
	 */
	public static function allowed() {
		return current_user_can( self::capability() );
	}

	/**
	 * Create the nonce the screen's script sends with each request.
	 *
	 * @return string
	 */
	public static function create_nonce() {
		return wp_create_nonce( self::NONCE_ACTION );
	}

	/**
	 * Refuse the request unless the user may use Catalogwell and the nonce is right.
	 * Answers with a JSON error and stops.
	 *
	 * @return void
	 */
	public static function require_request() {
		if ( ! self::allowed() ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to run Catalogwell. It needs the WooCommerce manager or administrator role.', 'catalogwell' ) ),
				403
			);
		}
		$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json_error(
				array( 'message' => __( 'This page has expired. Reload it and run the checks again.', 'catalogwell' ) ),
				403
			);
		}
	}
}
