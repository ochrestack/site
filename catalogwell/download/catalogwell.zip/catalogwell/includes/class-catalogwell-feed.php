<?php
/**
 * Check 2, beside the count: the latest catalog feed file Meta for WooCommerce wrote, and the last run of its daily feed job.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Feed file and feed job. Reads only.
 */
class Catalogwell_Feed {

	const JOB_HOOK      = 'wc_facebook_regenerate_feed';
	const MAX_DIFFS     = 50;
	const MAX_FILE_SIZE = 268435456;

	/**
	 * Find the newest feed file (not the temporary one) in Meta for WooCommerce's upload folder.
	 *
	 * @return string Path, or an empty string.
	 */
	public static function latest_file() {
		$dir = Catalogwell_Environment::feed_dir();
		if ( ! is_dir( $dir ) ) {
			return '';
		}
		$files = glob( trailingslashit( $dir ) . '*.csv' );
		if ( ! is_array( $files ) ) {
			return '';
		}
		$best      = '';
		$best_time = -1;
		foreach ( $files as $path ) {
			if ( false !== strpos( basename( $path ), '_temp_' ) || ! is_file( $path ) ) {
				continue;
			}
			$time = (int) filemtime( $path );
			if ( $time > $best_time ) {
				$best      = $path;
				$best_time = $time;
			}
		}
		return $best;
	}

	/**
	 * Compare the feed file with the visibility the rules give today.
	 *
	 * @param array[]  $rows Rows of [id, visibility, reason] from the catalog check.
	 * @param int|null $now  Unix time (tests pass one).
	 * @return array{state:string,message:string,date:int,age:int,file:string,checked:int,differences:array[],difference_count:int,not_listed:int}
	 */
	public static function compare( $rows, $now = null ) {
		$now    = null === $now ? time() : (int) $now;
		$result = array(
			'state'            => 'none',
			'message'          => '',
			'date'             => 0,
			'age'              => 0,
			'file'             => '',
			'checked'          => 0,
			'differences'      => array(),
			'difference_count' => 0,
			'not_listed'       => 0,
		);

		$path = self::latest_file();
		if ( '' === $path ) {
			$result['message'] = __( 'No catalog feed file was found in wp-content/uploads/facebook_for_woocommerce/. Meta for WooCommerce writes one when its daily feed job runs.', 'catalogwell' );
			return $result;
		}
		$result['file'] = basename( $path );
		$result['date'] = (int) filemtime( $path );
		$result['age']  = max( 0, $now - $result['date'] );

		if ( ! is_readable( $path ) || (int) filesize( $path ) > self::MAX_FILE_SIZE ) {
			$result['state']   = 'unreadable';
			$result['message'] = __( 'The latest feed file could not be read, so it was not compared.', 'catalogwell' );
			return $result;
		}

		$handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- read-only stream of the feed file.
		if ( ! $handle ) {
			$result['state']   = 'unreadable';
			$result['message'] = __( 'The latest feed file could not be opened, so it was not compared.', 'catalogwell' );
			return $result;
		}
		$header = fgetcsv( $handle, 0, ',', '"', '\\' );
		$cols   = array();
		if ( is_array( $header ) ) {
			foreach ( $header as $index => $name ) {
				$cols[ strtolower( trim( (string) $name ) ) ] = $index;
			}
		}
		if ( ! isset( $cols['visibility'] ) || ( ! isset( $cols['external_variant_id'] ) && ! isset( $cols['id'] ) ) ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			$result['state']   = 'malformed';
			$result['message'] = __( 'The latest feed file is not in the shape Meta for WooCommerce writes (it has no id and visibility columns), so it was not compared.', 'catalogwell' );
			return $result;
		}

		$map = array();
		foreach ( $rows as $row ) {
			$map[ (int) $row[0] ] = $row[1];
		}

		while ( false !== ( $line = fgetcsv( $handle, 0, ',', '"', '\\' ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			if ( ! is_array( $line ) || ( 1 === count( $line ) && null === $line[0] ) ) {
				continue;
			}
			$id = self::row_id( $line, $cols );
			if ( 0 === $id ) {
				continue;
			}
			$file_value = isset( $line[ $cols['visibility'] ] ) ? strtolower( trim( (string) $line[ $cols['visibility'] ] ) ) : '';
			++$result['checked'];
			if ( ! isset( $map[ $id ] ) || Catalogwell_Catalog::VIS_NOT_SYNCED === $map[ $id ] ) {
				++$result['not_listed'];
				continue;
			}
			$rule_value = Catalogwell_Catalog::VIS_HIDDEN === $map[ $id ] ? 'hidden' : 'published';
			if ( $rule_value !== $file_value ) {
				++$result['difference_count'];
				if ( count( $result['differences'] ) < self::MAX_DIFFS ) {
					$result['differences'][] = array(
						'id'    => $id,
						'file'  => $file_value,
						'rules' => $rule_value,
					);
				}
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		$result['state'] = 'compared';
		return $result;
	}

	/**
	 * Visibility value the file holds for each product, by product ID (used by the Pro CSV).
	 *
	 * @return array<int,string>
	 */
	public static function file_values() {
		$out  = array();
		$path = self::latest_file();
		if ( '' === $path || ! is_readable( $path ) ) {
			return $out;
		}
		$handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- read-only stream of the feed file.
		if ( ! $handle ) {
			return $out;
		}
		$header = fgetcsv( $handle, 0, ',', '"', '\\' );
		$cols   = array();
		if ( is_array( $header ) ) {
			foreach ( $header as $index => $name ) {
				$cols[ strtolower( trim( (string) $name ) ) ] = $index;
			}
		}
		if ( isset( $cols['visibility'] ) && ( isset( $cols['external_variant_id'] ) || isset( $cols['id'] ) ) ) {
			while ( false !== ( $line = fgetcsv( $handle, 0, ',', '"', '\\' ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
				if ( ! is_array( $line ) ) {
					continue;
				}
				$id = self::row_id( $line, $cols );
				if ( $id && isset( $line[ $cols['visibility'] ] ) ) {
					$out[ $id ] = strtolower( trim( (string) $line[ $cols['visibility'] ] ) );
				}
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return $out;
	}

	/**
	 * WooCommerce product ID a feed row stands for.
	 *
	 * @param array $line One CSV row.
	 * @param array $cols Column positions by lower-case name.
	 * @return int 0 when the row has none.
	 */
	private static function row_id( $line, $cols ) {
		if ( isset( $cols['external_variant_id'] ) && isset( $line[ $cols['external_variant_id'] ] ) ) {
			$value = trim( (string) $line[ $cols['external_variant_id'] ] );
			if ( ctype_digit( $value ) ) {
				return (int) $value;
			}
		}
		if ( isset( $cols['id'] ) && isset( $line[ $cols['id'] ] ) ) {
			$value = trim( (string) $line[ $cols['id'] ] );
			if ( ctype_digit( $value ) ) {
				return (int) $value;
			}
			if ( preg_match( '/_(\d+)$/', $value, $m ) ) {
				return (int) $m[1];
			}
		}
		return 0;
	}

	/**
	 * Last run of the daily feed job, from WooCommerce > Status > Scheduled Actions.
	 *
	 * @return array{state:string,message:string,date:int}
	 */
	public static function job() {
		if ( ! class_exists( 'ActionScheduler' ) || ! function_exists( 'as_get_scheduled_actions' ) || ! class_exists( 'ActionScheduler_Store' ) ) {
			return array(
				'state'   => 'unavailable',
				'message' => __( 'Scheduled Actions is not available, so the feed job could not be looked up.', 'catalogwell' ),
				'date'    => 0,
			);
		}
		$store = ActionScheduler::store();

		$best = null;
		foreach ( array( ActionScheduler_Store::STATUS_COMPLETE, ActionScheduler_Store::STATUS_FAILED ) as $status ) {
			$ids = $store->query_actions(
				array(
					'hook'     => self::JOB_HOOK,
					'status'   => $status,
					'per_page' => 1,
					'orderby'  => 'date',
					'order'    => 'DESC',
				)
			);
			if ( empty( $ids ) ) {
				continue;
			}
			$id   = (int) $ids[0];
			$time = self::action_time( $store, $id );
			if ( null === $best || $time >= $best['date'] ) {
				$best = array(
					'status' => $status,
					'id'     => $id,
					'date'   => $time,
				);
			}
		}

		if ( null !== $best ) {
			if ( ActionScheduler_Store::STATUS_FAILED === $best['status'] ) {
				return array(
					'state'   => 'failed',
					'message' => self::failure_message( $best['id'] ),
					'date'    => $best['date'],
				);
			}
			return array(
				'state'   => 'complete',
				'message' => '',
				'date'    => $best['date'],
			);
		}

		$pending = $store->query_actions(
			array(
				'hook'     => self::JOB_HOOK,
				'status'   => ActionScheduler_Store::STATUS_PENDING,
				'per_page' => 1,
				'orderby'  => 'date',
				'order'    => 'ASC',
			)
		);
		if ( ! empty( $pending ) ) {
			return array(
				'state'   => 'pending',
				'message' => '',
				'date'    => self::action_time( $store, (int) $pending[0] ),
			);
		}
		return array(
			'state'   => 'missing',
			'message' => '',
			'date'    => 0,
		);
	}

	/**
	 * When an action ran (its last attempt), or when it was scheduled for if it has no attempt recorded.
	 *
	 * @param ActionScheduler_Store $store     Store.
	 * @param int                   $action_id Action ID.
	 * @return int Unix time.
	 */
	private static function action_time( $store, $action_id ) {
		$date = $store->get_date( $action_id );
		$time = $date instanceof DateTime ? $date->getTimestamp() : 0;
		if ( $time > 86400 ) {
			return $time;
		}
		$action   = $store->fetch_action( $action_id );
		$schedule = $action ? $action->get_schedule() : null;
		$planned  = $schedule ? $schedule->get_date() : null;
		return $planned instanceof DateTime ? $planned->getTimestamp() : 0;
	}

	/**
	 * The message Scheduled Actions stored for a failed action.
	 *
	 * @param int $action_id Action ID.
	 * @return string
	 */
	private static function failure_message( $action_id ) {
		$message = '';
		if ( class_exists( 'ActionScheduler' ) ) {
			$logs = ActionScheduler::logger()->get_logs( $action_id );
			foreach ( array_reverse( $logs ) as $log ) {
				$text = $log->get_message();
				if ( false !== stripos( $text, 'fail' ) || false !== stripos( $text, 'error' ) || false !== stripos( $text, 'exception' ) ) {
					$message = $text;
					break;
				}
			}
			if ( '' === $message && ! empty( $logs ) ) {
				$last    = end( $logs );
				$message = $last->get_message();
			}
		}
		return Catalogwell_Environment::scrub( wp_strip_all_tags( $message ) );
	}

	/**
	 * Plain sentence for a feed job result.
	 *
	 * @param array $job Result of job().
	 * @return string
	 */
	public static function job_text( $job ) {
		switch ( $job['state'] ) {
			case 'complete':
				/* translators: %s: date and time. */
				return sprintf( __( 'The last run of the daily feed job (wc_facebook_regenerate_feed, in WooCommerce > Status > Scheduled Actions) completed on %s.', 'catalogwell' ), Catalogwell_Environment::format_time( $job['date'] ) );
			case 'failed':
				if ( '' !== $job['message'] ) {
					/* translators: 1: date and time, 2: the message stored with the failed action. */
					return sprintf( __( 'The last run of the daily feed job (wc_facebook_regenerate_feed) failed on %1$s. Scheduled Actions stored this message: “%2$s”', 'catalogwell' ), Catalogwell_Environment::format_time( $job['date'] ), $job['message'] );
				}
				/* translators: %s: date and time. */
				return sprintf( __( 'The last run of the daily feed job (wc_facebook_regenerate_feed) failed on %s. Scheduled Actions stored no message.', 'catalogwell' ), Catalogwell_Environment::format_time( $job['date'] ) );
			case 'pending':
				return __( 'The daily feed job (wc_facebook_regenerate_feed) is scheduled and has not run yet.', 'catalogwell' );
			case 'missing':
				return __( 'The daily feed job (wc_facebook_regenerate_feed) is missing: Scheduled Actions has no action with that name, pending or finished.', 'catalogwell' );
			default:
				return $job['message'];
		}
	}
}
