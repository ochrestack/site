<?php
/**
 * Hooks: the menu, the assets, the AJAX endpoints.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin bootstrap.
 */
class Catalogwell_Plugin {

	const SLUG = 'catalogwell';

	/**
	 * Screen hook suffix returned by add_submenu_page().
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'wc_facebook_is_crawler_request', array( 'Catalogwell_Fetcher', 'treat_as_crawler' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CATALOGWELL_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'wp_ajax_catalogwell_step', array( __CLASS__, 'ajax_step' ) );
		add_action( 'wp_ajax_catalogwell_list', array( __CLASS__, 'ajax_list' ) );
		add_action( 'wp_ajax_catalogwell_dismiss', array( __CLASS__, 'ajax_dismiss' ) );
	}

	/**
	 * Address of the screen.
	 *
	 * @return string
	 */
	public static function screen_url() {
		$parent = Catalogwell_Environment::woocommerce_active() ? 'admin.php' : 'tools.php';
		return add_query_arg( 'page', self::SLUG, admin_url( $parent ) );
	}

	/**
	 * Add the screen: under WooCommerce, or under Tools while WooCommerce is inactive.
	 *
	 * @return void
	 */
	public static function menu() {
		$parent     = Catalogwell_Environment::woocommerce_active() ? 'woocommerce' : 'tools.php';
		self::$hook = (string) add_submenu_page(
			$parent,
			__( 'Catalogwell', 'catalogwell' ),
			__( 'Catalogwell', 'catalogwell' ),
			Catalogwell_Access::capability(),
			self::SLUG,
			array( 'Catalogwell_Screen', 'render' )
		);
	}

	/**
	 * Link on the Plugins screen row.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( Catalogwell_Access::allowed() ) {
			array_unshift( $links, '<a href="' . esc_url( self::screen_url() ) . '">' . esc_html__( 'Open Catalogwell', 'catalogwell' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Load the script and style on Catalogwell's own screen only.
	 *
	 * @param string $hook_suffix Current screen hook suffix.
	 * @return void
	 */
	public static function assets( $hook_suffix ) {
		if ( '' === self::$hook || $hook_suffix !== self::$hook ) {
			return;
		}
		wp_enqueue_style( 'catalogwell-admin', CATALOGWELL_URL . 'assets/admin.css', array(), CATALOGWELL_VERSION );
		wp_enqueue_script( 'catalogwell-admin', CATALOGWELL_URL . 'assets/admin.js', array(), CATALOGWELL_VERSION, true );
		wp_localize_script(
			'catalogwell-admin',
			'catalogwellData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => Catalogwell_Access::create_nonce(),
				'loads'   => Catalogwell_Events::LOADS,
				'i18n'    => array(
					'starting'     => __( 'Starting…', 'catalogwell' ),
					'connection'   => __( 'Reading what the plugins have stored…', 'catalogwell' ),
					/* translators: 1: products scanned so far, 2: total products. */
					'catalog'      => __( 'Catalog: %1$s of %2$s products scanned…', 'catalogwell' ),
					'catalogEnd'   => __( 'Catalog: reading the feed file, the feed job and Google’s records…', 'catalogwell' ),
					'pixel'        => __( 'Pixel: loading the home page and a product page…', 'catalogwell' ),
					/* translators: 1: page name, 2: load number, 3: number of loads. */
					'events'       => __( 'Event IDs: %1$s, load %2$s of %3$s…', 'catalogwell' ),
					'eventsEnd'    => __( 'Event IDs: comparing the loads and counting orders…', 'catalogwell' ),
					'finishing'    => __( 'Saving the result…', 'catalogwell' ),
					'done'         => __( 'Finished.', 'catalogwell' ),
					/* translators: %s: the reason the check stopped. */
					'failed'       => __( 'The check stopped: %s The last finished result is still shown below.', 'catalogwell' ),
					'copied'       => __( 'Copied.', 'catalogwell' ),
					'copyFailed'   => __( 'The browser did not allow copying. Select the text in the box and copy it.', 'catalogwell' ),
					'listFailed'   => __( 'The list could not be loaded. Reload the page.', 'catalogwell' ),
					'networkError' => __( 'The request failed. Check that the site is reachable and try again.', 'catalogwell' ),
				),
			)
		);
	}

	/**
	 * Handle one step of a run.
	 *
	 * @return void
	 */
	public static function ajax_step() {
		Catalogwell_Access::require_request();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the capability and the nonce were checked on the line above.

		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		$run  = isset( $_POST['run'] ) ? sanitize_key( wp_unslash( $_POST['run'] ) ) : '';
		if ( ! in_array( $step, array( 'start', 'release' ), true ) && ! Catalogwell_Runner::owns( $run ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'This check was replaced by a newer one, so it stopped without changing the last result. Reload the page to see where the other check stands.', 'catalogwell' ),
					'refused' => true,
				),
				409
			);
		}
		switch ( $step ) {
			case 'release':
				Catalogwell_Runner::release( $run );
				wp_send_json_success();
				break;
			case 'start':
				$url = isset( $_POST['product_url'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['product_url'] ) ) ) : '';
				$url = '' === $url ? '' : esc_url_raw( $url );
				if ( '' !== $url && ! Catalogwell_Fetcher::is_own( $url ) ) {
					wp_send_json_error(
						array(
							'message' => __( 'That address is not on this site. Catalogwell loads only this site’s own pages. Clear the field or paste a product page of this site.', 'catalogwell' ),
						)
					);
				}
				$started = Catalogwell_Runner::start( $url, null, $run );
				if ( is_wp_error( $started ) ) {
					wp_send_json_error(
						array(
							'message' => $started->get_error_message(),
							'refused' => true,
						),
						409
					);
				}
				wp_send_json_success(
					array(
						'run'   => $started['run'],
						'items' => $started['items'],
						'pages' => wp_list_pluck( $started['pages'], 'label', 'key' ),
					)
				);
				break;
			case 'connection':
				wp_send_json_success( Catalogwell_Runner::step_connection() );
				break;
			case 'catalog':
				$after = isset( $_POST['after'] ) ? absint( wp_unslash( $_POST['after'] ) ) : 0;
				wp_send_json_success( Catalogwell_Runner::step_catalog( $after ) );
				break;
			case 'catalog_finish':
				wp_send_json_success( Catalogwell_Runner::step_catalog_finish() );
				break;
			case 'pixel':
				wp_send_json_success( Catalogwell_Runner::step_pixel() );
				break;
			case 'events':
				$key    = isset( $_POST['page'] ) ? sanitize_key( wp_unslash( $_POST['page'] ) ) : '';
				$number = isset( $_POST['load'] ) ? absint( wp_unslash( $_POST['load'] ) ) : 1;
				wp_send_json_success( Catalogwell_Runner::step_events_load( $key, $number ) );
				break;
			case 'events_finish':
				wp_send_json_success( Catalogwell_Runner::step_events_finish() );
				break;
			case 'finish':
				$results = Catalogwell_Runner::finish();
				ob_start();
				Catalogwell_Screen::render_results( $results );
				$html = ob_get_clean();
				wp_send_json_success(
					array(
						'html'      => $html,
						'reviewDue' => Catalogwell_Runner::review_due(),
					)
				);
				break;
			default:
				wp_send_json_error( array( 'message' => __( 'Unknown step.', 'catalogwell' ) ), 400 );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Return one page of the product list.
	 *
	 * @return void
	 */
	public static function ajax_list() {
		Catalogwell_Access::require_request();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the capability and the nonce were checked on the line above.
		$filter = isset( $_POST['filter'] ) ? sanitize_key( wp_unslash( $_POST['filter'] ) ) : 'hidden';
		if ( ! in_array( $filter, array( 'hidden', 'published', 'not_synced', 'all' ), true ) ) {
			$filter = 'hidden';
		}
		$page = isset( $_POST['page'] ) ? absint( wp_unslash( $_POST['page'] ) ) : 1;
		ob_start();
		Catalogwell_Screen::render_list( $filter, $page );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Dismiss the review line for good.
	 *
	 * @return void
	 */
	public static function ajax_dismiss() {
		Catalogwell_Access::require_request();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- the capability and the nonce were checked on the line above.
		update_option( Catalogwell_Runner::OPT_DISMISSED, 1, false );
		wp_send_json_success();
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}
