<?php
/**
 * Runs the checks, one step at a time (for the screen) or all at once (for tests and Pro's daily run).
 *
 * A run builds its result in a scratch option and replaces the stored result only when it has finished,
 * so a run that was interrupted never leaves half of one on the screen. One run at a time holds the lock
 * (the screen open in two tabs, two shop managers, Pro's daily check): a second one is told so and changes nothing.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check runner and result store.
 */
class Catalogwell_Runner {

	const OPT_RESULTS   = 'catalogwell_results';
	const OPT_ROWS      = 'catalogwell_rows';
	const OPT_SCRATCH   = 'catalogwell_scratch';
	const OPT_RUNS      = 'catalogwell_runs';
	const OPT_DISMISSED = 'catalogwell_review_dismissed';
	const OPT_LOCK      = 'catalogwell_lock';

	/**
	 * Seconds without a sign of life after which a run is taken to be abandoned (a closed tab) and its lock may be
	 * taken. Every step and every page load renews the lock, and the longest thing a run does between two renewals
	 * is one page load, which gives up after 20 seconds.
	 */
	const LOCK_STALE_AFTER = 45;

	/**
	 * The lock record as stored, read straight from the database (never from a cache).
	 *
	 * @return array{run:string,started:int,touched:int,user:int}|null
	 */
	private static function lock_record() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the lock must be read fresh: two requests decide on it.
		$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::OPT_LOCK ) );
		return self::decode_lock( $raw );
	}

	/**
	 * Decode a stored lock value.
	 *
	 * @param string|null $raw Stored value.
	 * @return array|null
	 */
	private static function decode_lock( $raw ) {
		if ( ! is_string( $raw ) ) {
			return null;
		}
		$lock = json_decode( $raw, true );
		return is_array( $lock ) && isset( $lock['run'], $lock['touched'] ) ? $lock : null;
	}

	/**
	 * Take the lock if nobody holds it, or if its holder has been quiet for LOCK_STALE_AFTER seconds.
	 * Both ways are one statement the database decides, so two requests at the same moment cannot both win.
	 *
	 * @param int    $user User ID the run is for (0: a scheduled check).
	 * @param string $run  Run ID chosen by the screen, so that a window that is closed before the answer arrives can still give the run up.
	 * @return array{run:string,started:int,touched:int,user:int}|array{busy:array} The new lock, or the one that is held.
	 */
	private static function take_lock( $user, $run = '' ) {
		global $wpdb;
		$now = time();
		$new = array(
			'run'     => preg_match( '/^[a-f0-9-]{8,64}$/', $run ) ? $run : wp_generate_uuid4(),
			'started' => $now,
			'touched' => $now,
			'user'    => (int) $user,
		);
		$raw = wp_json_encode( $new );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- an atomic claim on one row of the options table.
		$inserted = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", self::OPT_LOCK, $raw ) );
		if ( 1 === (int) $inserted ) {
			return $new;
		}
		$held_raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::OPT_LOCK ) );
		$held     = self::decode_lock( $held_raw );
		if ( null === $held || $now - (int) $held['touched'] > self::LOCK_STALE_AFTER ) {
			$taken = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $raw, self::OPT_LOCK, (string) $held_raw ) );
			if ( 1 === (int) $taken ) {
				return $new;
			}
			$held = self::lock_record();
		}
		// phpcs:enable
		return array( 'busy' => null === $held ? $new : $held );
	}

	/**
	 * Renew the lock of the run this process is part of (called before each page load and by each step).
	 *
	 * @return void
	 */
	public static function heartbeat() {
		self::touch_lock();
	}

	/**
	 * Write the lock's last-activity time, when the lock is still the given run's.
	 *
	 * @param string $run Run ID ('' for the run this process holds, whatever its ID).
	 * @return bool Whether the lock is the run's.
	 */
	private static function touch_lock( $run = '' ) {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- compare-and-set on the one lock row.
		$held_raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::OPT_LOCK ) );
		$held     = self::decode_lock( $held_raw );
		if ( null === $held ) {
			return '' === $run;
		}
		if ( '' !== $run && $held['run'] !== $run ) {
			return false;
		}
		$held['touched'] = time();
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", wp_json_encode( $held ), self::OPT_LOCK, (string) $held_raw ) );
		// phpcs:enable
		return true;
	}

	/**
	 * The lock that is held by a run that is still active, or null.
	 *
	 * @return array|null
	 */
	public static function busy() {
		$held = self::lock_record();
		return null !== $held && time() - (int) $held['touched'] <= self::LOCK_STALE_AFTER ? $held : null;
	}

	/**
	 * Give the lock up, when it is the given run's (or any run's when none is named).
	 *
	 * @param string $run Run ID ('' for whatever lock is held).
	 * @return void
	 */
	public static function release( $run = '' ) {
		global $wpdb;
		$held = self::lock_record();
		if ( null === $held || ( '' !== $run && $held['run'] !== $run ) ) {
			return;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the lock row only.
		$wpdb->delete( $wpdb->options, array( 'option_name' => self::OPT_LOCK ) );
		delete_option( self::OPT_SCRATCH );
	}

	/**
	 * Whether the run with this ID still holds the lock.
	 *
	 * @param string $run Run ID the screen got from start().
	 * @return bool
	 */
	public static function owns( $run ) {
		$held = self::lock_record();
		return null !== $held && '' !== (string) $run && $held['run'] === (string) $run;
	}

	/**
	 * The sentence that says another check is running.
	 *
	 * @param array $held The lock that is held.
	 * @return string
	 */
	public static function busy_message( $held ) {
		$when = Catalogwell_Environment::format_time( (int) $held['started'] );
		$user = ! empty( $held['user'] ) ? get_userdata( (int) $held['user'] ) : false;
		if ( $user ) {
			$text = sprintf(
				/* translators: 1: time the running check started, 2: the name of the person who started it. */
				__( 'A check is already running (started %1$s by %2$s). Wait for it to finish, then run the checks again. If its window was closed, you can run the checks again in about a minute.', 'catalogwell' ),
				$when,
				$user->display_name
			);
		} else {
			$text = sprintf(
				/* translators: %s: time the running check started. */
				__( 'A check is already running (started %s by a scheduled check). Wait for it to finish, then run the checks again. If it was cut short, you can run the checks again in about a minute.', 'catalogwell' ),
				$when
			);
		}
		return $text;
	}

	/**
	 * Start a run: take the lock, clear the scratch, note the time and the address chosen.
	 *
	 * @param string   $product_url Product page chosen by the person (may be empty).
	 * @param int|null $user        User ID the run is for (null: the current user, 0 for a scheduled check).
	 * @param string   $run         Run ID chosen by the screen (empty: one is made).
	 * @return array|WP_Error Items, pages and the run's ID; an error when another run holds the lock.
	 */
	public static function start( $product_url = '', $user = null, $run = '' ) {
		$lock = self::take_lock( null === $user ? get_current_user_id() : (int) $user, $run );
		if ( isset( $lock['busy'] ) ) {
			return new WP_Error( 'catalogwell_busy', self::busy_message( $lock['busy'] ), $lock['busy'] );
		}
		// The pages are chosen once, here, so every step of the run loads the same product page.
		$scratch = array(
			'run'         => $lock['run'],
			'started'     => time(),
			'microtime'   => microtime( true ),
			'product_url' => $product_url,
			'pages'       => Catalogwell_Pixel::pages( $product_url ),
			'rows'        => array(),
			'events'      => array(),
			'items'       => Catalogwell_Environment::woocommerce_active() ? Catalogwell_Catalog::count_items() : 0,
		);
		update_option( self::OPT_SCRATCH, $scratch, false );
		return array(
			'run'   => $lock['run'],
			'items' => $scratch['items'],
			'pages' => $scratch['pages'],
		);
	}

	/**
	 * The pages the run loads, as chosen when it started.
	 *
	 * @param string $product_url Address chosen (used only when no run is in progress).
	 * @return array[]
	 */
	public static function page_plan( $product_url = '' ) {
		$scratch = self::scratch();
		if ( isset( $scratch['pages'] ) && is_array( $scratch['pages'] ) ) {
			return $scratch['pages'];
		}
		return Catalogwell_Pixel::pages( $product_url );
	}

	/**
	 * The scratch record of the run in progress.
	 *
	 * @return array
	 */
	private static function scratch() {
		$scratch = get_option( self::OPT_SCRATCH, array() );
		return is_array( $scratch ) ? $scratch : array();
	}

	/**
	 * Write the scratch, unless the run it belongs to has lost or given up the lock meanwhile: a step of a run
	 * that was replaced (a reloaded window whose last request was still running) must not write into the new run.
	 *
	 * @param array $scratch Scratch of the run.
	 * @return void
	 */
	private static function save_scratch( $scratch ) {
		if ( isset( $scratch['run'] ) ) {
			$held = self::lock_record();
			if ( null === $held || $held['run'] !== $scratch['run'] ) {
				return;
			}
		}
		update_option( self::OPT_SCRATCH, $scratch, false );
	}

	/**
	 * Step: connection.
	 *
	 * @return array
	 */
	public static function step_connection() {
		self::touch_lock();
		$scratch               = self::scratch();
		$scratch['connection'] = array(
			'meta'   => Catalogwell_Connection::meta(),
			'google' => Catalogwell_Connection::google(),
		);
		self::save_scratch( $scratch );
		return array( 'done' => true );
	}

	/**
	 * Step: one page of the catalog scan.
	 *
	 * @param int $after_id Last post ID of the previous page.
	 * @return array{done:bool,last_id:int,seen:int,rows:int}
	 */
	public static function step_catalog( $after_id ) {
		self::touch_lock();
		$scratch = self::scratch();
		if ( ! Catalogwell_Environment::woocommerce_active() ) {
			$scratch['rows'] = array();
			self::save_scratch( $scratch );
			return array(
				'done'    => true,
				'last_id' => 0,
				'seen'    => 0,
				'rows'    => 0,
			);
		}
		$page = Catalogwell_Catalog::scan_page( (int) $after_id );
		if ( 0 === (int) $after_id ) {
			$scratch['rows'] = array();
		}
		$scratch['rows'] = array_merge( isset( $scratch['rows'] ) ? $scratch['rows'] : array(), $page['rows'] );
		self::save_scratch( $scratch );
		return array(
			'done'    => $page['done'],
			'last_id' => $page['last_id'],
			'seen'    => $page['seen'],
			'rows'    => count( $scratch['rows'] ),
		);
	}

	/**
	 * Step: the parts of check 2 that come after the scan: the feed file, the feed job and Google's summary.
	 *
	 * @return array
	 */
	public static function step_catalog_finish() {
		self::touch_lock();
		$scratch = self::scratch();
		$rows    = isset( $scratch['rows'] ) ? $scratch['rows'] : array();

		$scratch['catalog'] = array(
			'summary' => Catalogwell_Catalog::summarise( $rows ),
			'feed'    => Catalogwell_Feed::compare( $rows ),
			'job'     => Catalogwell_Feed::job(),
			'google'  => Catalogwell_Google::summary(),
			'items'   => count( $rows ),
			'seconds' => round( microtime( true ) - ( isset( $scratch['microtime'] ) ? $scratch['microtime'] : microtime( true ) ), 1 ),
			'peak_mb' => round( memory_get_peak_usage( true ) / 1048576, 1 ),
		);
		self::save_scratch( $scratch );
		return array( 'done' => true );
	}

	/**
	 * Step: check 3, the Pixel IDs on the pages.
	 *
	 * @return array
	 */
	public static function step_pixel() {
		self::touch_lock();
		$scratch          = self::scratch();
		$scratch['pixel'] = Catalogwell_Pixel::run( isset( $scratch['product_url'] ) ? $scratch['product_url'] : '', self::page_plan() );
		self::save_scratch( $scratch );
		return array( 'done' => true );
	}

	/**
	 * Step: one load of one page for check 4.
	 *
	 * @param string $page_key home or product.
	 * @param int    $number   Load number from 1.
	 * @return array
	 */
	public static function step_events_load( $page_key, $number ) {
		self::touch_lock();
		$scratch = self::scratch();
		$page    = null;
		foreach ( self::page_plan() as $candidate ) {
			if ( $candidate['key'] === $page_key ) {
				$page = $candidate;
			}
		}
		if ( null === $page ) {
			return array( 'done' => true );
		}
		if ( 1 === (int) $number || ! isset( $scratch['events'][ $page_key ] ) ) {
			$scratch['events'][ $page_key ] = array();
		}
		if ( '' !== $page['url'] && Catalogwell_Fetcher::is_own( $page['url'] ) ) {
			$scratch['events'][ $page_key ][] = Catalogwell_Events::load_once( $page['url'] );
		} elseif ( '' !== $page['url'] ) {
			$scratch['events'][ $page_key ][] = array(
				'kind'      => 'foreign_host',
				'sentence'  => sprintf(
					/* translators: %s: address. */
					__( 'The address %s is not on this site’s own host, so Catalogwell did not load it.', 'catalogwell' ),
					$page['url']
				),
				'events'    => array(),
				'generated' => 0,
				'caches'    => array(),
				'at'        => time(),
			);
		}
		self::save_scratch( $scratch );
		return array( 'done' => true );
	}

	/**
	 * Step: compare the loads and count the Purchase pairs.
	 *
	 * @return array
	 */
	public static function step_events_finish() {
		self::touch_lock();
		$scratch = self::scratch();
		$pages   = array();
		foreach ( self::page_plan() as $page ) {
			$loads = isset( $scratch['events'][ $page['key'] ] ) ? $scratch['events'][ $page['key'] ] : array();
			$entry = Catalogwell_Events::analyse( $page, $loads );
			if ( 'not_found' === $entry['kind'] && '' !== $page['url'] ) {
				$unpublished = Catalogwell_Fetcher::unpublished_sentence( $page['url'] );
				if ( '' !== $unpublished ) {
					$entry['kind']     = 'unpublished';
					$entry['sentence'] = $unpublished;
				}
			}
			$pages[] = $entry;
		}
		$meta              = Catalogwell_Environment::meta();
		$scratch['events'] = array(
			'pages'     => $pages,
			'rule'      => Catalogwell_Events::rule_text( $meta['version'] ),
			'purchases' => Catalogwell_Purchases::count(),
		);
		self::save_scratch( $scratch );
		return array( 'done' => true );
	}

	/**
	 * Finish the run: store the result, the rows, and count one completed check.
	 *
	 * @param bool $count_run Whether this run counts toward the review line (a run started by a person does).
	 * @return array The stored result.
	 */
	public static function finish( $count_run = true ) {
		$scratch = self::scratch();
		$results = array(
			'version'     => CATALOGWELL_VERSION,
			'time'        => time(),
			'product_url' => isset( $scratch['product_url'] ) ? $scratch['product_url'] : '',
			'connection'  => isset( $scratch['connection'] ) ? $scratch['connection'] : array(),
			'catalog'     => isset( $scratch['catalog'] ) ? $scratch['catalog'] : array(),
			'pixel'       => isset( $scratch['pixel'] ) ? $scratch['pixel'] : array(),
			'events'      => isset( $scratch['events'] ) && isset( $scratch['events']['pages'] ) ? $scratch['events'] : array(),
		);
		update_option( self::OPT_RESULTS, $results, false );
		update_option( self::OPT_ROWS, wp_json_encode( isset( $scratch['rows'] ) ? $scratch['rows'] : array() ), false );
		if ( $count_run ) {
			update_option( self::OPT_RUNS, (int) get_option( self::OPT_RUNS, 0 ) + 1, false );
		}
		delete_option( self::OPT_SCRATCH );
		self::release();
		return $results;
	}

	/**
	 * Run every check in one go.
	 *
	 * @param string $product_url Product page chosen (may be empty).
	 * @param bool   $count_run   Whether this run counts toward the review line.
	 * @param int    $user        User ID the run is for (0: a scheduled check).
	 * @return array|WP_Error The stored result; an error, with nothing changed, when another run holds the lock.
	 */
	public static function run_all( $product_url = '', $count_run = true, $user = 0 ) {
		$started = self::start( $product_url, $user );
		if ( is_wp_error( $started ) ) {
			return $started;
		}
		self::step_connection();
		$after = 0;
		do {
			$page  = self::step_catalog( $after );
			$after = $page['last_id'];
		} while ( ! $page['done'] );
		self::step_catalog_finish();
		self::step_pixel();
		foreach ( self::page_plan() as $page_plan ) {
			for ( $n = 1; $n <= Catalogwell_Events::LOADS; $n++ ) {
				self::step_events_load( $page_plan['key'], $n );
			}
		}
		self::step_events_finish();
		return self::finish( $count_run );
	}

	/**
	 * The stored result of the last finished run.
	 *
	 * @return array Empty when there is none.
	 */
	public static function results() {
		$results = get_option( self::OPT_RESULTS, array() );
		return is_array( $results ) ? $results : array();
	}

	/**
	 * The rows of the last finished run: [id, visibility, reason].
	 *
	 * @return array[]
	 */
	public static function rows() {
		$rows = json_decode( (string) get_option( self::OPT_ROWS, '[]' ), true );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Whether the review line should show: after the third finished run, until dismissed.
	 *
	 * @return bool
	 */
	public static function review_due() {
		return (int) get_option( self::OPT_RUNS, 0 ) >= 3 && ! get_option( self::OPT_DISMISSED );
	}

	/**
	 * Delete everything Catalogwell stores.
	 *
	 * @return void
	 */
	public static function delete_all() {
		foreach ( array( self::OPT_RESULTS, self::OPT_ROWS, self::OPT_SCRATCH, self::OPT_RUNS, self::OPT_DISMISSED, self::OPT_LOCK ) as $name ) {
			delete_option( $name );
		}
	}
}
