<?php
/**
 * Check 2 for Google for WooCommerce: product counts by its stored sync status and its most common stored errors.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads the _wc_gla_sync_status and _wc_gla_errors product records. Writes nothing.
 */
class Catalogwell_Google {

	const STATUSES = array( 'synced', 'not-synced', 'has-errors', 'pending' );
	const TOP      = 5;

	/**
	 * Counts by stored sync status and the most common stored error messages.
	 *
	 * @return array{has_data:bool,statuses:array<string,int>,other:int,errors:array[]}
	 */
	public static function summary() {
		global $wpdb;

		$statuses = array_fill_keys( self::STATUSES, 0 );
		$other    = 0;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only counts of Google for WooCommerce's own records.
		$counts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT m.meta_value AS status, COUNT(*) AS n FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND p.post_status = 'publish' AND p.post_type IN ('product','product_variation') GROUP BY m.meta_value",
				'_wc_gla_sync_status'
			)
		);
		// phpcs:enable

		$has_data = false;
		foreach ( (array) $counts as $row ) {
			$has_data = true;
			if ( isset( $statuses[ $row->status ] ) ) {
				$statuses[ $row->status ] += (int) $row->n;
			} else {
				$other += (int) $row->n;
			}
		}

		$errors = self::top_errors();
		return array(
			'has_data' => $has_data || ! empty( $errors ),
			'statuses' => $statuses,
			'other'    => $other,
			'errors'   => $errors,
		);
	}

	/**
	 * The most common stored error messages and how many products carry each.
	 *
	 * @return array[] Each: message, products.
	 */
	private static function top_errors() {
		global $wpdb;
		$counts  = array();
		$after   = 0;
		$fetched = 0;
		do {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only paging of the stored error records.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT m.meta_id, m.meta_value FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND p.post_status = 'publish' AND p.post_type IN ('product','product_variation') AND m.meta_id > %d ORDER BY m.meta_id ASC LIMIT 1000",
					'_wc_gla_errors',
					$after
				)
			);
			// phpcs:enable
			$fetched = count( (array) $rows );
			foreach ( (array) $rows as $row ) {
				$after = (int) $row->meta_id;
				$value = maybe_unserialize( $row->meta_value );
				if ( ! is_array( $value ) ) {
					continue;
				}
				$seen = array();
				foreach ( $value as $message ) {
					if ( ! is_string( $message ) ) {
						continue; // A variable product also holds nested lists for its variations.
					}
					$message = trim( Catalogwell_Environment::scrub( wp_strip_all_tags( $message ) ) );
					if ( '' === $message || isset( $seen[ $message ] ) ) {
						continue;
					}
					$seen[ $message ] = true;
					if ( ! isset( $counts[ $message ] ) ) {
						$counts[ $message ] = 0;
					}
					++$counts[ $message ];
				}
			}
		} while ( 1000 === $fetched );

		$list = array();
		foreach ( $counts as $message => $products ) {
			$list[] = array(
				'message'  => (string) $message,
				'products' => $products,
			);
		}
		usort(
			$list,
			static function ( $a, $b ) {
				if ( $a['products'] === $b['products'] ) {
					return strcmp( $a['message'], $b['message'] );
				}
				return $b['products'] - $a['products'];
			}
		);
		return array_slice( $list, 0, self::TOP );
	}
}
