<?php
/**
 * Check 4: event IDs behind a page cache.
 *
 * Loads the same page several times as separate cookie-less visitors and compares the event IDs
 * that Meta for WooCommerce put in the HTML.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Event ID check.
 */
class Catalogwell_Events {

	const LOADS           = 5;
	const CACHE_THRESHOLD = 1800;

	/**
	 * Event IDs Meta for WooCommerce put in a page's HTML.
	 *
	 * @param string $html Page markup.
	 * @return array[] Each: name, id, path (inline, queued, isolated).
	 */
	public static function parse_events( $html ) {
		$events = array();

		// Queueing path (used while signals are held for consent): FacebookSignals.queueEvent({...}).
		if ( preg_match_all( '/FacebookSignals\.queueEvent\((\{.*\})\);/', $html, $m ) ) {
			foreach ( $m[1] as $json ) {
				$data = json_decode( $json, true );
				if ( is_array( $data ) && ! empty( $data['event_id'] ) && is_string( $data['event_id'] ) ) {
					$events[] = array(
						'name' => isset( $data['event_name'] ) ? (string) $data['event_name'] : '',
						'id'   => $data['event_id'],
						'path' => 'queued',
					);
				}
			}
		}

		// Isolated execution: wc_facebook_pixel_data = { eventQueue: [ { name, eventId } ] }.
		if ( preg_match_all( '/wc_facebook_pixel_data\s*=\s*(\{.*\});/', $html, $m ) ) {
			foreach ( $m[1] as $json ) {
				$data = json_decode( $json, true );
				if ( is_array( $data ) && ! empty( $data['eventQueue'] ) && is_array( $data['eventQueue'] ) ) {
					foreach ( $data['eventQueue'] as $item ) {
						if ( is_array( $item ) && ! empty( $item['eventId'] ) && is_string( $item['eventId'] ) ) {
							$events[] = array(
								'name' => isset( $item['name'] ) ? (string) $item['name'] : '',
								'id'   => $item['eventId'],
								'path' => 'isolated',
							);
						}
					}
				}
			}
		}

		// Inline path: the plugin's trackEvent call carries the event name first and the event ID last.
		$rest = $html;
		if ( preg_match_all( '/trackEvent\(\s*\'([A-Za-z]+)\'\s*,.*?isStale \? null : ("(?:[^"\\\\]|\\\\.)*")\s*\)/s', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $call ) {
				$id = json_decode( $call[2] );
				if ( is_string( $id ) && '' !== $id ) {
					$events[] = array(
						'name' => $call[1],
						'id'   => $id,
						'path' => 'inline',
					);
				}
			}
			$rest = str_replace( wp_list_pluck( $m, 0 ), '', $html );
		}

		// Older code: an fbq track call with the event ID in its last argument, outside the block above.
		if ( preg_match_all( '/fbq\(\s*\'(?:track|trackCustom)\'\s*,\s*\'([A-Za-z]+)\'\s*,.*?"eventID"\s*:\s*"([^"]+)"/s', $rest, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $call ) {
				$already = false;
				foreach ( $events as $event ) {
					if ( $event['id'] === $call[2] ) {
						$already = true;
						break;
					}
				}
				if ( ! $already ) {
					$events[] = array(
						'name' => $call[1],
						'id'   => $call[2],
						'path' => 'inline',
					);
				}
			}
		}
		return $events;
	}

	/**
	 * Time Meta for WooCommerce stamped on the page (window.__wc_fb_page_generated).
	 *
	 * @param string $html Page markup.
	 * @return int 0 when the page has no marker.
	 */
	public static function generated( $html ) {
		if ( preg_match( '/window\.__wc_fb_page_generated\s*=\s*(\d{9,11})/', $html, $m ) ) {
			return (int) $m[1];
		}
		return 0;
	}

	/**
	 * Caches that answered, named from the headers or markup that name them.
	 *
	 * @param array<string,string> $headers Lower-case response headers.
	 * @param string               $html    Page markup.
	 * @return string[] Names, empty when none is named.
	 */
	public static function caches( $headers, $html ) {
		$names = array();
		$tail  = substr( $html, -6000 );
		$head  = substr( $html, 0, 6000 );
		$all   = $head . $tail;

		if ( false !== stripos( $all, 'WP-Super-Cache' ) || false !== stripos( $all, 'super cache' ) ) {
			$names[] = 'WP Super Cache';
		}
		$powered = isset( $headers['x-powered-by'] ) ? $headers['x-powered-by'] : '';
		if ( false !== stripos( $all, 'W3 Total Cache' ) || false !== stripos( $powered, 'W3 Total Cache' ) ) {
			$names[] = 'W3 Total Cache';
		}
		if ( isset( $headers['x-litespeed-cache'] ) || isset( $headers['x-litespeed-cache-control'] ) || false !== stripos( $all, 'LiteSpeed Cache' ) ) {
			$names[] = 'LiteSpeed Cache';
		}
		if ( false !== stripos( $all, 'WP Rocket' ) || isset( $headers['x-rocket-nginx-serving-content'] ) || isset( $headers['x-wp-rocket'] ) ) {
			$names[] = 'WP Rocket';
		}
		$server = isset( $headers['server'] ) ? $headers['server'] : '';
		if ( isset( $headers['cf-cache-status'] ) || isset( $headers['cf-ray'] ) || false !== stripos( $server, 'cloudflare' ) ) {
			$names[] = 'Cloudflare';
		}
		$via = isset( $headers['via'] ) ? $headers['via'] : '';
		if ( isset( $headers['x-varnish'] ) || false !== stripos( $via, 'varnish' ) ) {
			$names[] = 'Varnish';
		}
		return $names;
	}

	/**
	 * One load of a page.
	 *
	 * @param string $url Address.
	 * @return array{kind:string,sentence:string,events:array[],generated:int,caches:string[],at:int}
	 */
	public static function load_once( $url ) {
		$fetch = Catalogwell_Fetcher::get( $url );
		$load  = array(
			'kind'      => $fetch['kind'],
			'sentence'  => $fetch['sentence'],
			'events'    => array(),
			'generated' => 0,
			'caches'    => array(),
			'at'        => time(),
		);
		if ( 'ok' === $fetch['kind'] ) {
			$load['events']    = self::parse_events( $fetch['body'] );
			$load['generated'] = self::generated( $fetch['body'] );
			$load['caches']    = self::caches( $fetch['headers'], $fetch['body'] );
		}
		return $load;
	}

	/**
	 * Compare the loads of one page.
	 *
	 * @param array   $page  Entry from Catalogwell_Pixel::pages().
	 * @param array[] $loads Results of load_once().
	 * @param int     $now   Unix time to measure the age at (tests pass one).
	 * @return array
	 */
	public static function analyse( $page, $loads, $now = null ) {
		$now    = null === $now ? time() : (int) $now;
		$result = array(
			'key'         => $page['key'],
			'label'       => $page['label'],
			'url'         => $page['url'],
			'kind'        => 'skipped',
			'sentence'    => $page['note'],
			'loads'       => count( $loads ),
			'ok_loads'    => 0,
			'per_load'    => array(),
			'repeated'    => array(),
			'dropped'     => array(),
			'generated'   => 0,
			'age'         => 0,
			'caches'      => array(),
			'queued_path' => false,
			'no_events'   => false,
		);
		if ( empty( $loads ) ) {
			return $result;
		}

		$ok       = array();
		$sentence = '';
		$kind     = 'ok';
		foreach ( $loads as $load ) {
			if ( 'ok' !== $load['kind'] ) {
				$kind     = $load['kind'];
				$sentence = $load['sentence'];
				continue;
			}
			$ok[] = $load;
		}
		$result['ok_loads'] = count( $ok );
		if ( empty( $ok ) ) {
			$result['kind']     = $kind;
			$result['sentence'] = $sentence;
			return $result;
		}
		$result['kind']     = 'ok';
		$result['sentence'] = count( $ok ) < count( $loads ) ? $sentence : '';

		$by_id    = array();
		$gen_last = 0;
		$caches   = array();
		foreach ( $ok as $number => $load ) {
			$ids = array();
			foreach ( $load['events'] as $event ) {
				$ids[] = array(
					'name' => $event['name'],
					'id'   => $event['id'],
					'path' => $event['path'],
				);
				if ( 'queued' === $event['path'] ) {
					$result['queued_path'] = true;
				}
				$key = $event['id'];
				if ( ! isset( $by_id[ $key ] ) ) {
					$by_id[ $key ] = array(
						'id'    => $event['id'],
						'name'  => $event['name'],
						'path'  => $event['path'],
						'loads' => array(),
					);
				}
				if ( ! in_array( $number + 1, $by_id[ $key ]['loads'], true ) ) {
					$by_id[ $key ]['loads'][] = $number + 1;
				}
			}
			$result['per_load'][] = array(
				'load'   => $number + 1,
				'events' => $ids,
			);
			if ( $load['generated'] ) {
				$gen_last = $load['generated'];
			}
			$caches = array_values( array_unique( array_merge( $caches, $load['caches'] ) ) );
		}

		$result['generated'] = $gen_last;
		$result['age']       = $gen_last ? max( 0, $now - $gen_last ) : 0;

		// The same ID in two or more loads. Whether a visitor would send it depends on the age of the copy: in a
		// copy more than 30 minutes old Meta for WooCommerce's script drops the eventID (inline and isolated paths;
		// the path that queues events for consent has no such check), so the visitor sends the event with none.
		foreach ( $by_id as $entry ) {
			if ( count( $entry['loads'] ) >= 2 ) {
				$item = array(
					'id'    => $entry['id'],
					'name'  => $entry['name'],
					'path'  => $entry['path'],
					'count' => count( $entry['loads'] ),
				);
				if ( 'queued' !== $entry['path'] && $gen_last && $result['age'] > self::CACHE_THRESHOLD ) {
					$result['dropped'][] = $item;
				} else {
					$result['repeated'][] = $item;
				}
			}
		}
		$result['caches']    = $caches;
		$result['no_events'] = empty( $by_id );
		return $result;
	}

	/**
	 * The plain rule from Meta for WooCommerce's own code, stated for the version it was read from.
	 *
	 * @param string $installed Installed Meta for WooCommerce version (may be empty).
	 * @return string
	 */
	public static function rule_text( $installed ) {
		$text = sprintf(
			/* translators: 1: Meta for WooCommerce version the rule was read from, 2: minutes. */
			__( 'Meta for WooCommerce %1$s: when a page is more than %2$d minutes old, the browser sends its events without the eventID. The path that queues events while signals are held for consent has no such check.', 'catalogwell' ),
			CATALOGWELL_META_REFERENCE,
			self::CACHE_THRESHOLD / 60
		);
		if ( '' !== $installed && CATALOGWELL_META_REFERENCE !== $installed ) {
			$text .= ' ' . sprintf(
				/* translators: %s: installed version. */
				__( 'Your site runs version %s, which Catalogwell has not been checked against, so this rule may differ there.', 'catalogwell' ),
				$installed
			);
		}
		return $text;
	}
}
