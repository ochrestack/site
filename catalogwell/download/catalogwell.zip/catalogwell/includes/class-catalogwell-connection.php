<?php
/**
 * Check 1: what Meta for WooCommerce and Google for WooCommerce have stored.
 *
 * Reads options only. The access token is never read into a result: only whether one is stored.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Connection check.
 */
class Catalogwell_Connection {

	const LABEL_SITE   = 'site';
	const LABEL_META   = 'meta';
	const LABEL_GOOGLE = 'google';

	/**
	 * Whether a stored value counts as empty (nothing, 0 or "0").
	 *
	 * @param mixed $value Stored value.
	 * @return bool
	 */
	public static function is_empty_id( $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			return true;
		}
		$value = trim( (string) $value );
		return '' === $value || '0' === $value;
	}

	/**
	 * Stored ID as text.
	 *
	 * @param mixed $value Stored value.
	 * @return string
	 */
	private static function id_text( $value ) {
		return self::is_empty_id( $value ) ? '' : trim( (string) $value );
	}

	/**
	 * Truthiness of a stored flag.
	 *
	 * @param mixed $value Stored value.
	 * @return bool
	 */
	private static function flag( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'yes', 'true', 'on' ), true );
	}

	/**
	 * The two Pixel IDs Meta for WooCommerce keeps.
	 *
	 * @return array{setting:string,config:string}
	 */
	public static function stored_pixel_ids() {
		$config = get_option( 'facebook_config', array() );
		$config = is_array( $config ) ? $config : array();
		return array(
			'setting' => self::id_text( get_option( 'wc_facebook_pixel_id', '' ) ),
			'config'  => self::id_text( isset( $config['pixel_id'] ) ? $config['pixel_id'] : '' ),
		);
	}

	/**
	 * Whether Meta for WooCommerce has an access token stored. The token itself is not returned.
	 *
	 * @return bool
	 */
	public static function token_stored() {
		return '' !== trim( (string) get_option( 'wc_facebook_access_token', '' ) );
	}

	/**
	 * When Meta for WooCommerce marked its connection invalid, as a Unix time; 0 when it has not.
	 *
	 * Meta for WooCommerce sets this transient for a day when Meta answers a request with an authorization error
	 * (for example error 190, subcode 464) and stops sending events until the store is reconnected.
	 *
	 * @return int
	 */
	public static function connection_invalid_since() {
		return (int) get_transient( 'wc_facebook_connection_invalid' );
	}

	/**
	 * What "token rejected" means, with the time Meta for WooCommerce noted it when the transient holds one.
	 *
	 * @param int $since Value of the transient.
	 * @return string
	 */
	private static function token_rejected_text( $since ) {
		$when = $since > 1000000000
			? sprintf(
				/* translators: %s: date and time. */
				__( ' (Meta for WooCommerce noted it on %s)', 'catalogwell' ),
				Catalogwell_Environment::format_time( $since )
			)
			: '';
		return sprintf(
			/* translators: %s: an optional phrase with the date the plugin noted the rejection, or nothing. */
			__( 'Meta for WooCommerce is active and has an access token stored, but Meta answered that the token is no longer valid%s. The plugin has stopped sending events and shows its own “connection error” notice on the Plugins screen and on its own screen. This can happen when the system user was unconfirmed, the password was changed or the app was deauthorized.', 'catalogwell' ),
			$when
		);
	}

	/**
	 * Run the Meta for WooCommerce part.
	 *
	 * @return array
	 */
	public static function meta() {
		$plugin = Catalogwell_Environment::meta();
		$pixels = self::stored_pixel_ids();
		$token  = self::token_stored();

		$data = array(
			'plugin'              => $plugin,
			'token_stored'        => $token,
			'pixel_setting'       => $pixels['setting'],
			'pixel_config'        => $pixels['config'],
			'catalog_id'          => self::id_text( get_option( 'wc_facebook_product_catalog_id', '' ) ),
			'business_manager_id' => self::id_text( get_option( 'wc_facebook_business_manager_id', '' ) ),
			'external_business'   => self::id_text( get_option( 'wc_facebook_external_business_id', '' ) ),
			'commerce_account_id' => self::id_text( get_option( 'wc_facebook_commerce_merchant_settings_id', '' ) ),
			'log_lines'           => Catalogwell_Logs::missing_token_lines( 7 ),
			'invalid_since'       => $token ? self::connection_invalid_since() : 0,
		);

		// The external business ID is a name Meta for WooCommerce makes up for the shop the first time its own
		// screen is opened; it is not an ID from Meta, so on its own it is not a connection that was started.
		$ids_stored = '' !== $data['pixel_setting'] || '' !== $data['pixel_config'] || '' !== $data['catalog_id']
			|| '' !== $data['business_manager_id'] || '' !== $data['commerce_account_id'];

		$data['anything_stored'] = $token || $ids_stored;
		$data['pixel_agreement'] = self::pixel_agreement( $pixels['setting'], $pixels['config'] );
		$data['states']          = self::meta_states( $data, $ids_stored );
		return $data;
	}

	/**
	 * How the two Pixel IDs relate.
	 *
	 * @param string $setting wc_facebook_pixel_id.
	 * @param string $config  facebook_config pixel_id.
	 * @return string agree, differ, config_empty, setting_empty or both_empty.
	 */
	public static function pixel_agreement( $setting, $config ) {
		if ( '' === $setting && '' === $config ) {
			return 'both_empty';
		}
		if ( '' === $config ) {
			return 'config_empty';
		}
		if ( '' === $setting ) {
			return 'setting_empty';
		}
		return $setting === $config ? 'agree' : 'differ';
	}

	/**
	 * Build the named states for Meta for WooCommerce. Each has one next step and one label.
	 *
	 * @param array $data       Stored data.
	 * @param bool  $ids_stored Whether any ID is stored.
	 * @return array[]
	 */
	private static function meta_states( $data, $ids_stored ) {
		$state    = $data['plugin']['state'];
		$token    = $data['token_stored'];
		$states   = array();
		$settings = __( 'Meta for WooCommerce’s own screen (Marketing > Facebook, or WooCommerce > Facebook)', 'catalogwell' );

		if ( 'active' !== $state && $data['anything_stored'] ) {
			$plain = 'inactive' === $state
				? __( 'Meta for WooCommerce is deactivated, but its access token or IDs are still stored in this site’s database. Deactivating the plugin does not remove them.', 'catalogwell' )
				: __( 'Meta for WooCommerce has been deleted, but its access token or IDs are still stored in this site’s database. Deleting the plugin does not remove them.', 'catalogwell' );
			if ( ! $token ) {
				$plain .= ' ' . __( 'No token is stored, so the plugin’s Disconnect cannot ask Meta to remove the link; that is done in Meta Business Settings, on Meta’s side.', 'catalogwell' );
			}
			$states[] = self::state(
				'left_behind',
				__( 'Left behind', 'catalogwell' ),
				$plain,
				__( 'If Meta still shows this site’s shop as managed by WooCommerce: install and activate Meta for WooCommerce again and, while it is connected, use its own Disconnect, which asks Meta to remove the link and then clears this data.', 'catalogwell' ),
				self::LABEL_SITE,
				$settings
			);
		} elseif ( 'active' !== $state ) {
			if ( 'deleted' === $state ) {
				$states[] = self::state(
					'not_installed',
					__( 'Not installed', 'catalogwell' ),
					__( 'Meta for WooCommerce is not installed on this site and nothing of it is stored. There is nothing to check here.', 'catalogwell' ),
					__( 'Install Meta for WooCommerce only if you want to sell through Facebook and Instagram.', 'catalogwell' ),
					self::LABEL_SITE,
					__( 'Plugins > Add Plugin', 'catalogwell' )
				);
			} else {
				$states[] = self::state(
					'never_connected',
					__( 'Never connected', 'catalogwell' ),
					__( 'Meta for WooCommerce is deactivated and no access token or ID from Meta is stored. It has not been connected on this site.', 'catalogwell' ),
					__( 'Activate Meta for WooCommerce, then complete its setup.', 'catalogwell' ),
					self::LABEL_SITE,
					$settings
				);
			}
		} elseif ( $token && $data['invalid_since'] > 0 ) {
			$states[] = self::state(
				'token_rejected',
				__( 'Token rejected by Meta', 'catalogwell' ),
				self::token_rejected_text( $data['invalid_since'] ),
				__( 'Reconnect the store in Meta for WooCommerce’s own screen (Marketing > Facebook), then run Catalogwell again.', 'catalogwell' ),
				self::LABEL_SITE,
				$settings
			);
		} elseif ( $token ) {
			$states[] = self::state(
				'connected',
				__( 'Connected', 'catalogwell' ),
				__( 'Meta for WooCommerce is active and has an access token stored.', 'catalogwell' ),
				__( 'Nothing to change on this site. If Meta still shows a problem, look in Meta Business Settings and Commerce Manager.', 'catalogwell' ),
				self::LABEL_META,
				__( 'Meta Business Settings and Commerce Manager', 'catalogwell' )
			);
		} elseif ( $ids_stored ) {
			$states[] = self::state(
				'token_missing',
				__( 'Access token missing', 'catalogwell' ),
				__( 'Meta for WooCommerce is active and has IDs stored but no access token, so it cannot call Meta. Its log then says “Cannot create the API instance because the access token is missing.”', 'catalogwell' ),
				__( 'Run Meta for WooCommerce’s setup again until it finishes, then run Catalogwell again to see whether a token is stored.', 'catalogwell' ),
				self::LABEL_SITE,
				$settings
			);
		} else {
			$states[] = self::state(
				'never_connected',
				__( 'Never connected', 'catalogwell' ),
				'' === $data['external_business']
					? __( 'Meta for WooCommerce is active, but no access token and no ID is stored. It has not been connected on this site.', 'catalogwell' )
					: __( 'Meta for WooCommerce is active and has stored a name for this shop (its external business ID, which it makes up when its own screen is first opened), but no access token and no ID from Meta. The setup was started and has not been finished on this site.', 'catalogwell' ),
				__( 'Open Meta for WooCommerce and complete its setup.', 'catalogwell' ),
				self::LABEL_SITE,
				$settings
			);
		}

		if ( 'active' === $state || $data['anything_stored'] ) {
			$pixel_state = self::pixel_state( $data, $token );
			if ( $pixel_state ) {
				$states[] = $pixel_state;
			}
		}
		return $states;
	}

	/**
	 * The finding for the two Pixel IDs, when they are not simply the same ID.
	 *
	 * @param array $data  Stored data.
	 * @param bool  $token Whether a token is stored.
	 * @return array|null
	 */
	private static function pixel_state( $data, $token ) {
		$setting = $data['pixel_setting'];
		$config  = $data['pixel_config'];
		$label   = __( 'Meta for WooCommerce’s own setup', 'catalogwell' );
		switch ( $data['pixel_agreement'] ) {
			case 'config_empty':
				return self::state(
					'pixel_config_empty',
					__( 'Pixel ID missing where the pages read it', 'catalogwell' ),
					__( 'wc_facebook_pixel_id holds a Pixel ID, but facebook_config holds none (empty or 0). Meta for WooCommerce prints the Pixel on pages from facebook_config, so pages print no Pixel.', 'catalogwell' ),
					__( 'Run Meta for WooCommerce’s setup again, then run Catalogwell again: both places should hold the same Pixel ID.', 'catalogwell' ),
					self::LABEL_SITE,
					$label
				);
			case 'setting_empty':
				return self::state(
					'pixel_setting_empty',
					__( 'Pixel ID missing in one of the two places', 'catalogwell' ),
					__( 'facebook_config holds a Pixel ID, which is what pages print, but wc_facebook_pixel_id, the other place the plugin keeps it, is empty or 0.', 'catalogwell' ),
					__( 'Run Meta for WooCommerce’s setup again, then run Catalogwell again: both places should hold the same Pixel ID.', 'catalogwell' ),
					self::LABEL_SITE,
					$label
				);
			case 'differ':
				return self::state(
					'pixel_differ',
					__( 'Two different Pixel IDs stored', 'catalogwell' ),
					__( 'wc_facebook_pixel_id and facebook_config hold different Pixel IDs. Pages print the one in facebook_config.', 'catalogwell' ),
					__( 'Run Meta for WooCommerce’s setup again, then run Catalogwell again: both places should hold the same Pixel ID.', 'catalogwell' ),
					self::LABEL_SITE,
					$label
				);
			case 'both_empty':
				if ( $token ) {
					return self::state(
						'pixel_none',
						__( 'No Pixel ID stored', 'catalogwell' ),
						__( 'A token is stored but neither wc_facebook_pixel_id nor facebook_config holds a Pixel ID, so pages print no Pixel.', 'catalogwell' ),
						__( 'Run Meta for WooCommerce’s setup again and attach a Pixel when it asks.', 'catalogwell' ),
						self::LABEL_SITE,
						$label
					);
				}
				return null;
			default:
				return null;
		}
	}

	/**
	 * The Pixel and catalog pairing as stored, with the label that Meta decides it.
	 *
	 * @param array $meta Result of meta().
	 * @return array
	 */
	public static function pairing( $meta ) {
		return array(
			'pixel_id'   => '' !== $meta['pixel_config'] ? $meta['pixel_config'] : $meta['pixel_setting'],
			'catalog_id' => $meta['catalog_id'],
			'label'      => self::LABEL_META,
		);
	}

	/**
	 * Run the Google for WooCommerce part.
	 *
	 * @return array
	 */
	public static function google() {
		$plugin = Catalogwell_Environment::google();
		$mc_at  = get_option( 'gla_mc_setup_completed_at', '' );

		$data = array(
			'plugin'          => $plugin,
			'merchant_id'     => self::id_text( get_option( 'gla_merchant_id', '' ) ),
			'ads_id'          => self::id_text( get_option( 'gla_ads_id', '' ) ),
			'google_account'  => self::flag( get_option( 'gla_google_connected', '' ) ),
			'wordpress_com'   => self::flag( get_option( 'gla_jetpack_connected', '' ) ),
			'setup_completed' => ! self::is_empty_id( $mc_at ),
			'data_left'       => self::google_data_left(),
		);

		$stored                  = '' !== $data['merchant_id'] || '' !== $data['ads_id'] || $data['google_account'] || $data['wordpress_com'] || $data['setup_completed'];
		$data['anything_stored'] = $stored;
		$data['states']          = self::google_states( $data, $stored );
		return $data;
	}

	/**
	 * What Google for WooCommerce leaves in the database: its options and product records.
	 *
	 * @return array{options:int,products:int}
	 */
	private static function google_data_left() {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read-only counts of Google for WooCommerce's own rows.
		$options  = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'gla_' ) . '%' )
		);
		$products = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $wpdb->esc_like( '_wc_gla_' ) . '%' )
		);
		// phpcs:enable
		return array(
			'options'  => $options,
			'products' => $products,
		);
	}

	/**
	 * Build the named states for Google for WooCommerce.
	 *
	 * @param array $data   Stored data.
	 * @param bool  $stored Whether any connection data is stored.
	 * @return array[]
	 */
	private static function google_states( $data, $stored ) {
		$state    = $data['plugin']['state'];
		$settings = __( 'Google for WooCommerce’s own screen (Marketing > Google for WooCommerce)', 'catalogwell' );
		$label    = self::LABEL_GOOGLE;

		if ( 'active' !== $state && ( $stored || $data['data_left']['options'] > 0 ) ) {
			$plain  = 'inactive' === $state
				? __( 'Google for WooCommerce is deactivated, but its connection data is still stored in this site’s database.', 'catalogwell' )
				: __( 'Google for WooCommerce has been deleted, but its connection data is still stored in this site’s database.', 'catalogwell' );
			$plain .= ' ' . __( 'Its uninstall removes the data only when WC_GLA_REMOVE_ALL_DATA is set to true in wp-config.php.', 'catalogwell' );
			return array(
				self::state(
					'left_behind',
					__( 'Left behind', 'catalogwell' ),
					$plain,
					__( 'To clear it, install and activate Google for WooCommerce, disconnect it, set WC_GLA_REMOVE_ALL_DATA to true in wp-config.php and delete the plugin again.', 'catalogwell' ),
					self::LABEL_SITE,
					$settings
				),
			);
		}
		if ( 'active' !== $state ) {
			if ( 'deleted' === $state ) {
				return array(
					self::state(
						'not_installed',
						__( 'Not installed', 'catalogwell' ),
						__( 'Google for WooCommerce is not installed on this site and nothing of it is stored. There is nothing to check here.', 'catalogwell' ),
						__( 'Install Google for WooCommerce only if you want your products in Google Merchant Center.', 'catalogwell' ),
						self::LABEL_SITE,
						__( 'Plugins > Add Plugin', 'catalogwell' )
					),
				);
			}
			return array(
				self::state(
					'never_connected',
					__( 'Never connected', 'catalogwell' ),
					__( 'Google for WooCommerce is deactivated and no connection data is stored.', 'catalogwell' ),
					__( 'Activate Google for WooCommerce, then complete its setup.', 'catalogwell' ),
					self::LABEL_SITE,
					$settings
				),
			);
		}
		if ( ! $stored ) {
			return array(
				self::state(
					'never_connected',
					__( 'Never connected', 'catalogwell' ),
					__( 'Google for WooCommerce is active, but no connection data is stored. It has not been connected on this site.', 'catalogwell' ),
					__( 'Open Google for WooCommerce and complete its setup.', 'catalogwell' ),
					self::LABEL_SITE,
					$settings
				),
			);
		}
		if ( $data['google_account'] && '' !== $data['merchant_id'] && $data['setup_completed'] ) {
			return array(
				self::state(
					'connected',
					__( 'Connected', 'catalogwell' ),
					__( 'Google for WooCommerce is active, a Google account and a Merchant Center account are connected, and its setup is completed.', 'catalogwell' ),
					__( 'Nothing to change on this site. If Merchant Center shows a problem, it is fixed in Merchant Center.', 'catalogwell' ),
					$label,
					__( 'Google Merchant Center', 'catalogwell' )
				),
			);
		}
		return array(
			self::state(
				'setup_incomplete',
				__( 'Setup not finished', 'catalogwell' ),
				__( 'Google for WooCommerce is active and stores some connection data, but not a connected Google account, a Merchant Center ID and a completed setup together.', 'catalogwell' ),
				__( 'Finish Google for WooCommerce’s setup, then run Catalogwell again.', 'catalogwell' ),
				self::LABEL_SITE,
				$settings
			),
		);
	}

	/**
	 * One state record.
	 *
	 * @param string $key   Machine key.
	 * @param string $name  State name shown to the person.
	 * @param string $plain What it means.
	 * @param string $step  The one next step.
	 * @param string $label One of the LABEL_ constants.
	 * @param string $where Where it is fixed.
	 * @return array
	 */
	private static function state( $key, $name, $plain, $step, $label, $where ) {
		return array(
			'key'   => $key,
			'name'  => $name,
			'plain' => $plain,
			'step'  => $step,
			'label' => $label,
			'where' => $where,
		);
	}

	/**
	 * Text of a label.
	 *
	 * @param string $label One of the LABEL_ constants.
	 * @return string
	 */
	public static function label_text( $label ) {
		switch ( $label ) {
			case self::LABEL_META:
				return __( 'Meta’s side: Catalogwell only reports this', 'catalogwell' );
			case self::LABEL_GOOGLE:
				return __( 'Google’s side: Catalogwell only reports this', 'catalogwell' );
			default:
				return __( 'Fix on this site', 'catalogwell' );
		}
	}
}
