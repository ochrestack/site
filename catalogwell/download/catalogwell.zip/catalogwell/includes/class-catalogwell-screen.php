<?php
/**
 * The Catalogwell screen: page, result sections and the product list.
 *
 * Every value is escaped where it is printed.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Screen renderer.
 */
class Catalogwell_Screen {

	const LIST_PER_PAGE = 25;

	/**
	 * Tie a number to the word after it, so a line does not end on "7" with "(ID 64)" or "MB" on the next one.
	 * Only text between tags is changed; the text of the report box is left alone (it is copied to a forum).
	 *
	 * @param string $html HTML whose values were escaped where they were printed.
	 * @return string
	 */
	public static function tidy_html( $html ) {
		$parts  = preg_split( '/(<[^>]*>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$skip   = 0;
		$result = '';
		foreach ( (array) $parts as $part ) {
			if ( '' !== $part && '<' === $part[0] ) {
				if ( preg_match( '#^<(textarea|script|style)\b#i', $part ) ) {
					++$skip;
				} elseif ( preg_match( '#^</(textarea|script|style)\b#i', $part ) ) {
					$skip = max( 0, $skip - 1 );
				}
				$result .= $part;
				continue;
			}
			$result .= $skip ? $part : preg_replace( array( '/(\d[\d,.]*%?) (?=[\p{L}(])/u', '/\bID (?=\d)/' ), array( "$1\xC2\xA0", "ID\xC2\xA0" ), $part );
		}
		return $result;
	}

	/**
	 * Print the screen.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! Catalogwell_Access::allowed() ) {
			wp_die( esc_html__( 'You are not allowed to open Catalogwell. It needs the WooCommerce manager or administrator role.', 'catalogwell' ), '', array( 'response' => 403 ) );
		}
		ob_start();
		self::print_screen();
		echo self::tidy_html( (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every value was escaped where it was printed.
	}

	/**
	 * Print the screen (untidied).
	 *
	 * @return void
	 */
	private static function print_screen() {
		$results     = Catalogwell_Runner::results();
		$product_url = isset( $results['product_url'] ) ? $results['product_url'] : '';
		?>
		<div class="wrap catalogwell" id="catalogwell-app">
			<h1><?php esc_html_e( 'Catalogwell', 'catalogwell' ); ?></h1>
			<p class="catalogwell-lead">
				<?php esc_html_e( 'See what Meta for WooCommerce and Google for WooCommerce have stored, which products go to Meta as hidden and why, which Pixel your pages carry, and whether your page cache repeats event IDs. Catalogwell only reads. It changes none of your products, orders or settings and nothing in any account, and it contacts no outside server.', 'catalogwell' ); ?>
			</p>

			<form id="catalogwell-form" class="catalogwell-controls" method="post" action="#">
				<p class="catalogwell-field">
					<label for="catalogwell-product-url"><?php esc_html_e( 'Product page to check (optional)', 'catalogwell' ); ?></label>
					<input type="url" id="catalogwell-product-url" class="regular-text" value="<?php echo esc_attr( $product_url ); ?>" placeholder="<?php echo esc_attr( home_url( '/product/' ) ); ?>" />
					<span class="description"><?php esc_html_e( 'Leave it empty and Catalogwell picks the newest published product shown in the shop.', 'catalogwell' ); ?></span>
				</p>
				<p class="catalogwell-actions">
					<button type="submit" class="button button-primary" id="catalogwell-run"><?php esc_html_e( 'Run the checks', 'catalogwell' ); ?></button>
					<span id="catalogwell-progress" class="catalogwell-progress" role="status" aria-live="polite"></span>
				</p>
			</form>
			<div id="catalogwell-error" class="notice notice-error inline" role="alert" hidden><p></p></div>

			<div id="catalogwell-results">
				<?php self::render_results( $results ); ?>
			</div>

			<?php self::render_pro_line(); ?>
		</div>
		<?php
	}

	/**
	 * Print the one line about Pro, unless Pro is active.
	 *
	 * @return void
	 */
	private static function render_pro_line() {
		if ( defined( 'CATALOGWELL_PRO_VERSION' ) ) {
			return;
		}
		?>
		<p class="catalogwell-pro-line description">
			<?php esc_html_e( 'Every check on this screen is free. Catalogwell Pro, a separate add-on at ochrestack.com ($19 once, no renewal), runs them every day and emails you when something changes.', 'catalogwell' ); ?>
		</p>
		<?php
	}

	/**
	 * Print the result sections, or the empty state when no check has finished.
	 *
	 * @param array $results Stored result.
	 * @return void
	 */
	public static function render_results( $results ) {
		ob_start();
		self::print_results( $results );
		echo self::tidy_html( (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every value was escaped where it was printed.
	}

	/**
	 * Print the result sections (untidied).
	 *
	 * @param array $results Stored result.
	 * @return void
	 */
	private static function print_results( $results ) {
		if ( empty( $results ) || empty( $results['connection'] ) ) {
			?>
			<p class="catalogwell-empty" id="catalogwell-empty"><?php esc_html_e( 'No check has finished yet. Press “Run the checks”; the result stays here until the next run.', 'catalogwell' ); ?></p>
			<?php
			return;
		}
		?>
		<p class="catalogwell-when" id="catalogwell-when">
			<?php
			/* translators: %s: date and time of the last finished run. */
			echo esc_html( sprintf( __( 'Result of the check that finished on %s.', 'catalogwell' ), Catalogwell_Environment::format_time( $results['time'] ) ) );
			?>
		</p>
		<?php
		self::render_connection( $results['connection'] );
		self::render_catalog( $results['catalog'], Catalogwell_Runner::meta_is_off( $results ) );
		self::render_pixel( $results['pixel'] );
		self::render_events( $results['events'] );
		self::render_copy( $results );
	}

	/**
	 * Escape a long address or file name for printing, with a break opportunity after / ? & @ - and _ so a
	 * narrow screen breaks it at those places and not in the middle of a word.
	 *
	 * @param string $text Text.
	 * @return string HTML.
	 */
	public static function breakable( $text ) {
		$out = '';
		foreach ( (array) preg_split( '/([\/?&@_-])/', $text, -1, PREG_SPLIT_DELIM_CAPTURE ) as $index => $piece ) {
			$out .= esc_html( $piece );
			if ( 1 === $index % 2 ) {
				$out .= '<wbr>';
			}
		}
		return $out;
	}

	/**
	 * Print a label pill.
	 *
	 * @param string $label Label constant of Catalogwell_Connection.
	 * @return void
	 */
	private static function label( $label ) {
		$classes = array(
			Catalogwell_Connection::LABEL_SITE => 'is-site',
			Catalogwell_Connection::LABEL_NONE => 'is-none',
		);
		$class   = isset( $classes[ $label ] ) ? $classes[ $label ] : 'is-other';
		echo '<span class="catalogwell-label ' . esc_attr( $class ) . '">' . esc_html( Catalogwell_Connection::label_text( $label ) ) . '</span>';
	}

	/**
	 * Print state boxes.
	 *
	 * @param array[] $states States.
	 * @return void
	 */
	private static function render_states( $states ) {
		foreach ( $states as $state ) {
			?>
			<div class="catalogwell-state catalogwell-state-<?php echo esc_attr( $state['key'] ); ?>">
				<p class="catalogwell-state-name"><strong><?php echo esc_html( $state['name'] ); ?></strong> <?php self::label( $state['label'] ); ?></p>
				<p><?php echo esc_html( $state['plain'] ); ?></p>
				<p><strong><?php esc_html_e( 'Next step:', 'catalogwell' ); ?></strong> <?php echo esc_html( $state['step'] ); ?></p>
				<p class="description">
					<?php
					/* translators: %s: where the thing is fixed. */
					echo esc_html( sprintf( __( 'Where: %s', 'catalogwell' ), $state['where'] ) );
					?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Print one row of a facts table.
	 *
	 * @param string $name  Row name.
	 * @param string $value Row value.
	 * @return void
	 */
	private static function fact_row( $name, $value ) {
		echo '<tr><th scope="row">' . esc_html( $name ) . '</th><td>' . esc_html( $value ) . '</td></tr>';
	}

	/**
	 * ID or "empty" text.
	 *
	 * @param string $id Stored ID.
	 * @return string
	 */
	private static function id_or_empty( $id ) {
		return '' === $id ? __( 'empty or 0', 'catalogwell' ) : $id;
	}

	/**
	 * Plugin line, such as "Active, version 3.7.9".
	 *
	 * @param array $plugin Plugin state.
	 * @return string
	 */
	private static function plugin_line( $plugin ) {
		$version = $plugin['version'];
		switch ( $plugin['state'] ) {
			case 'active':
				/* translators: %s: plugin version. */
				return sprintf( __( 'Active, version %s', 'catalogwell' ), $version );
			case 'inactive':
				/* translators: %s: plugin version. */
				return sprintf( __( 'Installed but deactivated, version %s', 'catalogwell' ), $version );
			default:
				return __( 'Not installed (deleted or never installed)', 'catalogwell' );
		}
	}

	/**
	 * Section 1: connection.
	 *
	 * @param array $connection Stored connection result.
	 * @return void
	 */
	private static function render_connection( $connection ) {
		$meta   = $connection['meta'];
		$google = $connection['google'];
		?>
		<section class="catalogwell-section" id="catalogwell-connection">
			<h2><?php esc_html_e( 'Connection: what each plugin has stored', 'catalogwell' ); ?></h2>

			<h3><?php esc_html_e( 'Meta for WooCommerce', 'catalogwell' ); ?></h3>
			<?php self::render_states( $meta['states'] ); ?>
			<div class="catalogwell-table-wrap">
				<table class="widefat striped catalogwell-table catalogwell-facts">
					<tbody>
					<?php
					self::fact_row( __( 'Plugin', 'catalogwell' ), self::plugin_line( $meta['plugin'] ) );
					self::fact_row( __( 'Access token stored', 'catalogwell' ), $meta['token_stored'] ? __( 'Yes (never shown)', 'catalogwell' ) : __( 'No', 'catalogwell' ) );
					self::fact_row( __( 'Pixel ID in wc_facebook_pixel_id', 'catalogwell' ), self::id_or_empty( $meta['pixel_setting'] ) );
					self::fact_row( __( 'Pixel ID in facebook_config', 'catalogwell' ), self::id_or_empty( $meta['pixel_config'] ) );
					self::fact_row( __( 'The two Pixel IDs', 'catalogwell' ), self::agreement_text( $meta['pixel_agreement'] ) );
					self::fact_row( __( 'Catalog ID', 'catalogwell' ), self::id_or_empty( $meta['catalog_id'] ) );
					self::fact_row( __( 'Business Manager ID', 'catalogwell' ), self::id_or_empty( $meta['business_manager_id'] ) );
					self::fact_row( __( 'External business ID', 'catalogwell' ), self::id_or_empty( $meta['external_business'] ) );
					self::fact_row( __( 'Commerce account ID', 'catalogwell' ), self::id_or_empty( $meta['commerce_account_id'] ) );
					self::fact_row(
						__( '“Access token is missing” lines in WooCommerce > Status > Logs, last 7 days', 'catalogwell' ),
						Catalogwell_Logs::count_text( $meta['log_lines'], true )
					);
					?>
					</tbody>
				</table>
			</div>

			<h3><?php esc_html_e( 'Google for WooCommerce', 'catalogwell' ); ?></h3>
			<?php self::render_states( $google['states'] ); ?>
			<div class="catalogwell-table-wrap">
				<table class="widefat striped catalogwell-table catalogwell-facts">
					<tbody>
					<?php
					self::fact_row( __( 'Plugin', 'catalogwell' ), self::plugin_line( $google['plugin'] ) );
					self::fact_row( __( 'Merchant Center ID', 'catalogwell' ), self::id_or_empty( $google['merchant_id'] ) );
					self::fact_row( __( 'Google Ads ID', 'catalogwell' ), self::id_or_empty( $google['ads_id'] ) );
					self::fact_row( __( 'Google account connected', 'catalogwell' ), $google['google_account'] ? __( 'Yes', 'catalogwell' ) : __( 'No', 'catalogwell' ) );
					self::fact_row( __( 'WordPress.com connection', 'catalogwell' ), $google['wordpress_com'] ? __( 'Yes', 'catalogwell' ) : __( 'No', 'catalogwell' ) );
					self::fact_row( __( 'Setup completed', 'catalogwell' ), $google['setup_completed'] ? __( 'Yes', 'catalogwell' ) : __( 'No', 'catalogwell' ) );
					self::fact_row(
						__( 'Data stored by the plugin', 'catalogwell' ),
						sprintf(
							/* translators: 1: text such as "1 option" or "2 options", 2: text such as "1 product with records" or "2 products with records". */
							__( '%1$s, %2$s', 'catalogwell' ),
							sprintf(
								/* translators: %d: number of options. */
								_n( '%d option', '%d options', (int) $google['data_left']['options'], 'catalogwell' ),
								(int) $google['data_left']['options']
							),
							sprintf(
								/* translators: %d: number of products. */
								_n( '%d product with records', '%d products with records', (int) $google['data_left']['products'], 'catalogwell' ),
								(int) $google['data_left']['products']
							)
						)
					);
					?>
					</tbody>
				</table>
			</div>
		</section>
		<?php
	}

	/**
	 * Words for how the two Pixel IDs relate.
	 *
	 * @param string $agreement Agreement key.
	 * @return string
	 */
	private static function agreement_text( $agreement ) {
		switch ( $agreement ) {
			case 'agree':
				return __( 'They agree', 'catalogwell' );
			case 'differ':
				return __( 'They differ', 'catalogwell' );
			case 'config_empty':
				return __( 'facebook_config is empty or 0, wc_facebook_pixel_id is not', 'catalogwell' );
			case 'setting_empty':
				return __( 'wc_facebook_pixel_id is empty or 0, facebook_config is not', 'catalogwell' );
			default:
				return __( 'Both are empty or 0', 'catalogwell' );
		}
	}

	/**
	 * Section 2: catalog.
	 *
	 * @param array $catalog Stored catalog result.
	 * @param bool  $off     Whether Meta for WooCommerce was switched off (deactivated or deleted) at the check.
	 * @return void
	 */
	private static function render_catalog( $catalog, $off ) {
		$summary = $catalog['summary'];
		?>
		<section class="catalogwell-section" id="catalogwell-catalog">
			<h2><?php esc_html_e( 'Catalog: which products go to Meta as hidden, and why', 'catalogwell' ); ?></h2>
			<?php if ( 0 === $catalog['items'] ) : ?>
				<p class="catalogwell-count"><strong><?php esc_html_e( 'No published product or variation was found, so there is nothing to list.', 'catalogwell' ); ?></strong></p>
			<?php else : ?>
				<?php $unread = ! empty( $catalog['language_unread'] ); ?>
				<p class="catalogwell-count">
					<?php if ( $off ) : ?>
						<strong><?php echo esc_html( Catalogwell_Catalog::off_text() ); ?></strong>
					<?php endif; ?>
					<?php if ( $unread ) : ?>
						<strong><?php echo esc_html( Catalogwell_Catalog::language_unread_text() ); ?></strong>
					<?php else : ?>
						<strong>
							<?php
							echo esc_html( Catalogwell_Catalog::count_text( $summary, $off ) );
							?>
						</strong>
						<?php echo esc_html( Catalogwell_Catalog::not_synced_text( $summary, $off ) ); ?>
					<?php endif; ?>
				</p>
				<p class="description">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: Meta for WooCommerce version the rules were read from, 2: seconds, 3: memory in MB. */
							__( 'The rules are read from Meta for WooCommerce %1$s. This scan took %2$s seconds and peaked at %3$s MB of memory.', 'catalogwell' ),
							CATALOGWELL_META_REFERENCE,
							number_format_i18n( $catalog['seconds'], 1 ),
							number_format_i18n( $catalog['peak_mb'], 1 )
						)
					);
					?>
				</p>
				<?php if ( ! $unread && '' !== Catalogwell_Catalog::items_text( $catalog ) ) : ?>
					<p class="description catalogwell-variations"><?php echo esc_html( Catalogwell_Catalog::items_text( $catalog ) ); ?></p>
				<?php endif; ?>
				<?php if ( ! $unread ) : ?>
					<div class="catalogwell-table-wrap">
						<table class="widefat striped catalogwell-table">
							<thead><tr><th scope="col"><?php esc_html_e( 'Reason', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Products', 'catalogwell' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( $summary['by_reason'] as $key => $count ) : ?>
								<tr><td><?php echo esc_html( Catalogwell_Catalog::reason_title( $key ) ); ?></td><td><?php echo esc_html( number_format_i18n( $count ) ); ?></td></tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<?php self::render_list_shell(); ?>
				<?php endif; ?>
			<?php endif; ?>

			<?php self::render_feed( $catalog['feed'], $catalog['job'] ); ?>
			<?php self::render_google_summary( $catalog['google'] ); ?>
		</section>
		<?php
	}

	/**
	 * The product list box that the script fills from the list endpoint.
	 *
	 * @return void
	 */
	private static function render_list_shell() {
		?>
		<div class="catalogwell-list" id="catalogwell-list" data-per-page="<?php echo esc_attr( (string) self::LIST_PER_PAGE ); ?>">
			<h3><?php esc_html_e( 'The products and the reason for each', 'catalogwell' ); ?></h3>
			<p>
				<label for="catalogwell-list-filter"><?php esc_html_e( 'Show', 'catalogwell' ); ?></label>
				<select id="catalogwell-list-filter">
					<option value="hidden"><?php esc_html_e( 'Hidden products', 'catalogwell' ); ?></option>
					<option value="published"><?php esc_html_e( 'Published products', 'catalogwell' ); ?></option>
					<option value="not_synced"><?php esc_html_e( 'Products not synced', 'catalogwell' ); ?></option>
					<option value="all"><?php esc_html_e( 'All products', 'catalogwell' ); ?></option>
				</select>
			</p>
			<div id="catalogwell-list-body" aria-live="polite"><?php self::print_list( 'hidden', 1 ); ?></div>
		</div>
		<?php
	}

	/**
	 * Print one page of the product list, from the stored rows.
	 *
	 * @param string $filter hidden, published, not_synced or all.
	 * @param int    $page   Page number from 1.
	 * @return void
	 */
	public static function render_list( $filter, $page ) {
		ob_start();
		self::print_list( $filter, $page );
		echo self::tidy_html( (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every value was escaped where it was printed.
	}

	/**
	 * Print one page of the product list (untidied).
	 *
	 * @param string $filter hidden, published, not_synced or all.
	 * @param int    $page   Page number from 1.
	 * @return void
	 */
	private static function print_list( $filter, $page ) {
		$rows = Catalogwell_Runner::rows();
		$keep = array();
		foreach ( $rows as $row ) {
			$vis = $row[1];
			if ( 'hidden' === $filter && Catalogwell_Catalog::VIS_HIDDEN !== $vis ) {
				continue;
			}
			if ( 'published' === $filter && Catalogwell_Catalog::VIS_PUBLISHED !== $vis ) {
				continue;
			}
			if ( 'not_synced' === $filter && Catalogwell_Catalog::VIS_NOT_SYNCED !== $vis ) {
				continue;
			}
			$keep[] = $row;
		}
		$goes  = self::goes_to_meta_as_text();
		$total = count( $keep );
		$pages = max( 1, (int) ceil( $total / self::LIST_PER_PAGE ) );
		$page  = min( max( 1, (int) $page ), $pages );
		$slice = array_slice( $keep, ( $page - 1 ) * self::LIST_PER_PAGE, self::LIST_PER_PAGE );

		if ( 0 === $total ) {
			echo '<p class="catalogwell-list-empty">' . esc_html( self::empty_list_text( $filter ) ) . '</p>';
			return;
		}

		echo '<p class="description">' . esc_html(
			sprintf(
				/* translators: 1: number of products in this list, 2: page number, 3: number of pages. */
				_n( '%1$s product in this list. Page %2$d of %3$d.', '%1$s products in this list. Page %2$d of %3$d.', $total, 'catalogwell' ),
				number_format_i18n( $total ),
				$page,
				$pages
			)
		) . '</p>';
		?>
		<div class="catalogwell-table-wrap">
			<table class="widefat striped catalogwell-table catalogwell-products catalogwell-stack">
				<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Product', 'catalogwell' ); ?></th>
					<th scope="col"><?php echo esc_html( $goes ); ?></th>
					<th scope="col"><?php esc_html_e( 'Reason', 'catalogwell' ); ?></th>
				</tr>
				</thead>
				<tbody>
				<?php foreach ( $slice as $row ) : ?>
					<tr>
						<td data-label="<?php esc_attr_e( 'Product', 'catalogwell' ); ?>"><?php self::product_name( (int) $row[0] ); ?></td>
						<td data-label="<?php echo esc_attr( $goes ); ?>"><?php echo esc_html( self::visibility_text( $row[1] ) ); ?></td>
						<td data-label="<?php esc_attr_e( 'Reason', 'catalogwell' ); ?>"><?php echo esc_html( Catalogwell_Catalog::reason_text( $row[2] ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="catalogwell-pager">
			<button type="button" class="button" data-catalogwell-page="<?php echo esc_attr( (string) ( $page - 1 ) ); ?>" <?php disabled( $page <= 1 ); ?> title="<?php echo esc_attr( $page <= 1 ? __( 'This is the first page of the list.', 'catalogwell' ) : '' ); ?>"><?php esc_html_e( 'Previous page', 'catalogwell' ); ?></button>
			<button type="button" class="button" data-catalogwell-page="<?php echo esc_attr( (string) ( $page + 1 ) ); ?>" <?php disabled( $page >= $pages ); ?> title="<?php echo esc_attr( $page >= $pages ? __( 'This is the last page of the list.', 'catalogwell' ) : '' ); ?>"><?php esc_html_e( 'Next page', 'catalogwell' ); ?></button>
		</p>
		<?php
	}

	/**
	 * Heading of the visibility column: "Goes to Meta as", or "Would go to Meta as" while Meta for WooCommerce is off.
	 *
	 * @return string
	 */
	public static function goes_to_meta_as_text() {
		return Catalogwell_Runner::meta_is_off() ? __( 'Would go to Meta as', 'catalogwell' ) : __( 'Goes to Meta as', 'catalogwell' );
	}

	/**
	 * What to say when a filtered list is empty.
	 *
	 * @param string $filter List filter.
	 * @return string
	 */
	private static function empty_list_text( $filter ) {
		switch ( $filter ) {
			case 'hidden':
				return __( 'No product goes to Meta as hidden.', 'catalogwell' );
			case 'published':
				return __( 'No product goes to Meta as published.', 'catalogwell' );
			case 'not_synced':
				return __( 'Every published product is synced.', 'catalogwell' );
			default:
				return __( 'No published product or variation was found.', 'catalogwell' );
		}
	}

	/**
	 * Words for a visibility code.
	 *
	 * @param string $vis Visibility code.
	 * @return string
	 */
	public static function visibility_text( $vis ) {
		switch ( $vis ) {
			case Catalogwell_Catalog::VIS_HIDDEN:
				return __( 'hidden', 'catalogwell' );
			case Catalogwell_Catalog::VIS_PUBLISHED:
				return __( 'published', 'catalogwell' );
			default:
				return __( 'not synced', 'catalogwell' );
		}
	}

	/**
	 * Print the title of a product or variation, linked to its edit screen (a variation's is its parent's) when the
	 * person may edit it and the product still exists.
	 *
	 * @param int $id Post ID.
	 * @return void
	 */
	private static function product_name( $id ) {
		$title   = self::product_title( $id );
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
		$edit_id = $product && $product->get_parent_id() ? (int) $product->get_parent_id() : $id;
		$link    = $product ? get_edit_post_link( $edit_id, 'raw' ) : '';
		if ( $link ) {
			echo '<a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a>';
			return;
		}
		echo esc_html( $title );
	}

	/**
	 * Title of a product or variation for a list row.
	 *
	 * @param int $id Post ID.
	 * @return string
	 */
	public static function product_title( $id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
		if ( ! $product ) {
			/* translators: %d: product ID. */
			return sprintf( __( 'Product %d (no longer exists)', 'catalogwell' ), $id );
		}
		$name = wp_strip_all_tags( $product->get_name() );
		if ( 'variation' === $product->get_type() ) {
			$name   = wp_strip_all_tags( wc_get_formatted_variation( $product, true, false, false ) );
			$parent = wc_get_product( $product->get_parent_id() );
			$name   = ( $parent ? wp_strip_all_tags( $parent->get_name() ) : '' ) . ( '' !== $name ? ' – ' . $name : '' );
		}
		/* translators: 1: product name, 2: product ID. */
		return sprintf( __( '%1$s (ID %2$d)', 'catalogwell' ), $name, $id );
	}

	/**
	 * Feed file and feed job block.
	 *
	 * @param array $feed Feed comparison.
	 * @param array $job  Feed job result.
	 * @return void
	 */
	private static function render_feed( $feed, $job ) {
		?>
		<h3><?php esc_html_e( 'Feed file and feed job', 'catalogwell' ); ?></h3>
		<?php if ( 'compared' !== $feed['state'] ) : ?>
			<p class="catalogwell-feed-line"><?php echo esc_html( $feed['message'] ); ?></p>
		<?php else : ?>
			<p class="catalogwell-feed-line">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: file name, 2: date and time, 3: number of rows read. */
						_n( 'The latest catalog feed file is %1$s, written on %2$s. Catalogwell read %3$s row.', 'The latest catalog feed file is %1$s, written on %2$s. Catalogwell read %3$s rows.', (int) $feed['checked'], 'catalogwell' ),
						$feed['file'],
						Catalogwell_Environment::format_time( $feed['date'] ),
						number_format_i18n( $feed['checked'] )
					)
				);
				?>
			</p>
			<?php if ( 0 === $feed['difference_count'] ) : ?>
				<p><?php esc_html_e( 'Every row’s visibility in the file is what the rules give today.', 'catalogwell' ); ?></p>
			<?php else : ?>
				<p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: number of rows. */
							_n( '%s row has a visibility in the file that differs from what the rules give today:', '%s rows have a visibility in the file that differs from what the rules give today:', (int) $feed['difference_count'], 'catalogwell' ),
							number_format_i18n( $feed['difference_count'] )
						)
					);
					?>
				</p>
				<div class="catalogwell-table-wrap">
					<table class="widefat striped catalogwell-table catalogwell-stack">
						<thead><tr><th scope="col"><?php esc_html_e( 'Product', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'The file says', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'The rules say today', 'catalogwell' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $feed['differences'] as $difference ) : ?>
							<tr>
								<td data-label="<?php esc_attr_e( 'Product', 'catalogwell' ); ?>"><?php self::product_name( (int) $difference['id'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'The file says', 'catalogwell' ); ?>"><?php echo esc_html( $difference['file'] ); ?></td>
								<td data-label="<?php esc_attr_e( 'The rules say today', 'catalogwell' ); ?>"><?php echo esc_html( $difference['rules'] ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<?php if ( $feed['difference_count'] > count( $feed['differences'] ) ) : ?>
					<p class="description">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: number of rows shown. */
								__( 'The first %s are listed.', 'catalogwell' ),
								number_format_i18n( count( $feed['differences'] ) )
							)
						);
						?>
					</p>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( $feed['not_listed'] > 0 ) : ?>
				<p class="description">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: number of rows. */
							_n( '%s row in the file is for a product that is not in the list above (deleted, unpublished or no longer synced).', '%s rows in the file are for products that are not in the list above (deleted, unpublished or no longer synced).', (int) $feed['not_listed'], 'catalogwell' ),
							number_format_i18n( $feed['not_listed'] )
						)
					);
					?>
				</p>
			<?php endif; ?>
		<?php endif; ?>
		<p class="catalogwell-job-line"><?php echo esc_html( Catalogwell_Feed::job_text( $job ) ); ?></p>
		<?php
	}

	/**
	 * Google for WooCommerce summary.
	 *
	 * @param array $google Summary.
	 * @return void
	 */
	private static function render_google_summary( $google ) {
		?>
		<h3><?php esc_html_e( 'Google for WooCommerce: stored sync status', 'catalogwell' ); ?></h3>
		<?php if ( ! $google['has_data'] ) : ?>
			<p><?php esc_html_e( 'Google for WooCommerce has stored no product sync records on this site.', 'catalogwell' ); ?></p>
		<?php else : ?>
			<div class="catalogwell-table-wrap">
				<table class="widefat striped catalogwell-table">
					<thead><tr><th scope="col"><?php esc_html_e( 'Stored sync status', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Products', 'catalogwell' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Synced', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $google['statuses']['synced'] ) ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Not synced', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $google['statuses']['not-synced'] ) ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Has errors', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $google['statuses']['has-errors'] ) ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Pending', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $google['statuses']['pending'] ) ); ?></td></tr>
						<?php if ( $google['other'] > 0 ) : ?>
							<tr><td><?php esc_html_e( 'Another stored value', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $google['other'] ) ); ?></td></tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<?php if ( empty( $google['errors'] ) ) : ?>
				<p><?php esc_html_e( 'No product carries a stored error message.', 'catalogwell' ); ?></p>
			<?php else : ?>
				<div class="catalogwell-table-wrap">
					<table class="widefat striped catalogwell-table">
						<thead><tr><th scope="col"><?php esc_html_e( 'Most common stored error', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Products', 'catalogwell' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $google['errors'] as $error ) : ?>
							<tr><td><?php echo esc_html( $error['message'] ); ?></td><td><?php echo esc_html( number_format_i18n( $error['products'] ) ); ?></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<p class="description"><?php esc_html_e( 'Google’s side: Catalogwell only reports what Google for WooCommerce stored. Whether Merchant Center accepts a product is shown in Merchant Center.', 'catalogwell' ); ?></p>
		<?php
	}

	/**
	 * Section 3: Pixel.
	 *
	 * @param array $pixel Stored pixel result.
	 * @return void
	 */
	private static function render_pixel( $pixel ) {
		?>
		<section class="catalogwell-section" id="catalogwell-pixel">
			<h2><?php esc_html_e( 'Pixel: what the pages really carry', 'catalogwell' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Catalogwell loaded each page as a visitor who is not logged in, with no cookies, and read the page’s own markup. A Pixel started only by a script file or a tag manager is not in the markup and is not listed.', 'catalogwell' ); ?></p>
			<?php foreach ( $pixel['pages'] as $page ) : ?>
				<h3><?php echo esc_html( $page['label'] ); ?></h3>
				<?php if ( '' !== $page['url'] ) : ?>
					<p class="catalogwell-url"><?php echo wp_kses( self::breakable( $page['url'] ), array( 'wbr' => array() ) ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $page['sentence'] ) : ?>
					<p class="catalogwell-fetch-sentence<?php echo 'ok' === $page['kind'] ? '' : ' is-problem'; ?>"><?php echo esc_html( $page['sentence'] ); ?></p>
				<?php endif; ?>
				<?php if ( 'ok' === $page['kind'] ) : ?>
					<?php if ( empty( $page['pixels'] ) ) : ?>
						<p><?php esc_html_e( 'No Meta Pixel ID is started in this page’s markup.', 'catalogwell' ); ?></p>
					<?php else : ?>
						<div class="catalogwell-table-wrap">
							<table class="widefat striped catalogwell-table catalogwell-stack">
								<thead><tr><th scope="col"><?php esc_html_e( 'Pixel ID', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Printed by', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Where its markup shows it', 'catalogwell' ); ?></th></tr></thead>
								<tbody>
								<?php foreach ( $page['pixels'] as $pixel_row ) : ?>
									<tr>
										<td data-label="<?php esc_attr_e( 'Pixel ID', 'catalogwell' ); ?>"><?php echo esc_html( $pixel_row['id'] ); ?></td>
										<td data-label="<?php esc_attr_e( 'Printed by', 'catalogwell' ); ?>"><?php echo esc_html( implode( ', ', array_map( array( 'Catalogwell_Pixel', 'plugin_name' ), $pixel_row['plugins'] ) ) ); ?></td>
										<td data-label="<?php esc_attr_e( 'Where its markup shows it', 'catalogwell' ); ?>"><?php echo esc_html( implode( '; ', $pixel_row['via'] ) ); ?></td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					<?php endif; ?>
					<?php if ( empty( $page['flags'] ) ) : ?>
						<p class="catalogwell-noflag"><?php esc_html_e( 'No flag for this page: no Pixel ID that is not the stored one, no second Pixel and no double start in the markup.', 'catalogwell' ); ?></p>
					<?php else : ?>
						<ul class="catalogwell-flags">
							<?php foreach ( $page['flags'] as $flag ) : ?>
								<li><span class="catalogwell-label is-site"><?php esc_html_e( 'Flag', 'catalogwell' ); ?></span> <?php echo esc_html( $flag['text'] ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; ?>

			<h3><?php esc_html_e( 'Pixel and catalog pairing, as stored', 'catalogwell' ); ?></h3>
			<?php $pair = $pixel['pairing']; ?>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: Pixel ID, 2: catalog ID. */
						__( 'Pixel ID %1$s, catalog ID %2$s.', 'catalogwell' ),
						self::id_or_empty( $pair['pixel_id'] ),
						self::id_or_empty( $pair['catalog_id'] )
					)
				);
				?>
				<?php self::label( $pair['label'] ); ?>
			</p>
			<p><?php esc_html_e( 'Whether Meta lets you attach this Pixel to this catalog depends on the business portfolio and on the access of the Facebook profile used in setup. Catalogwell cannot see either.', 'catalogwell' ); ?></p>
			<ol>
				<?php foreach ( Catalogwell_Pixel::pairing_steps() as $step ) : ?>
					<li><?php echo esc_html( $step ); ?></li>
				<?php endforeach; ?>
			</ol>
		</section>
		<?php
	}

	/**
	 * Section 4: event IDs and Purchase pairs.
	 *
	 * @param array $events Stored events result.
	 * @return void
	 */
	private static function render_events( $events ) {
		?>
		<section class="catalogwell-section" id="catalogwell-events">
			<h2><?php esc_html_e( 'Event IDs behind a page cache, and Purchase pairs', 'catalogwell' ); ?></h2>
			<p class="description">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of loads. */
						__( 'Catalogwell loaded each page %d times as separate visitors with no cookies and listed the eventIDs that Meta for WooCommerce put in the HTML.', 'catalogwell' ),
						Catalogwell_Events::LOADS
					)
				);
				?>
			</p>
			<p class="catalogwell-rule"><?php echo esc_html( $events['rule'] ); ?></p>

			<?php foreach ( $events['pages'] as $page ) : ?>
				<h3><?php echo esc_html( $page['label'] ); ?></h3>
				<?php if ( '' !== $page['url'] ) : ?>
					<p class="catalogwell-url"><?php echo wp_kses( self::breakable( $page['url'] ), array( 'wbr' => array() ) ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $page['sentence'] ) : ?>
					<p class="catalogwell-fetch-sentence is-problem"><?php echo esc_html( $page['sentence'] ); ?></p>
				<?php endif; ?>
				<?php if ( 'ok' === $page['kind'] ) : ?>
					<?php self::render_event_page( $page ); ?>
				<?php endif; ?>
			<?php endforeach; ?>

			<h3><?php esc_html_e( 'Purchase pairs on the last 50 orders', 'catalogwell' ); ?></h3>
			<?php self::render_purchases( $events['purchases'] ); ?>
		</section>
		<?php
	}

	/**
	 * Event ID details for one page.
	 *
	 * @param array $page Analysed page.
	 * @return void
	 */
	private static function render_event_page( $page ) {
		if ( $page['no_events'] ) {
			echo '<p>' . esc_html__( 'No eventID from Meta for WooCommerce was found in this page’s HTML.', 'catalogwell' ) . '</p>';
		} elseif ( empty( $page['repeated'] ) && empty( $page['dropped'] ) ) {
			echo '<p class="catalogwell-noflag">' . esc_html(
				sprintf(
					/* translators: %d: number of loads. */
					__( 'No eventID repeated across the %d loads: each visitor got its own.', 'catalogwell' ),
					(int) $page['ok_loads']
				)
			) . '</p>';
		} else {
			echo '<ul class="catalogwell-flags">';
			foreach ( $page['repeated'] as $repeat ) {
				echo '<li><span class="catalogwell-label is-site">' . esc_html__( 'Repeated', 'catalogwell' ) . '</span> ' . esc_html(
					sprintf(
						/* translators: 1: event name, 2: event ID, 3: number of loads that showed it, 4: number of loads. */
						__( 'Different visitors would send the same event ID. %1$s event %2$s was in %3$d of %4$d loads.', 'catalogwell' ),
						'' !== $repeat['name'] ? $repeat['name'] : __( 'An', 'catalogwell' ),
						$repeat['id'],
						$repeat['count'],
						(int) $page['ok_loads']
					)
				) . '</li>';
			}
			foreach ( $page['dropped'] as $dropped ) {
				echo '<li><span class="catalogwell-label is-site">' . esc_html__( 'No event ID sent', 'catalogwell' ) . '</span> ' . esc_html(
					sprintf(
						/* translators: 1: event name, 2: event ID, 3: number of loads that showed it, 4: number of loads. */
						__( '%1$s event %2$s is the same in %3$d of %4$d loads, but this copy of the page is more than 30 minutes old, so a browser drops the eventID from it: visitors send this event with no event ID, and Meta cannot use it to match the browser event with the server event.', 'catalogwell' ),
						'' !== $dropped['name'] ? $dropped['name'] : __( 'An', 'catalogwell' ),
						$dropped['id'],
						$dropped['count'],
						(int) $page['ok_loads']
					)
				) . '</li>';
			}
			echo '</ul>';
		}

		if ( $page['queued_path'] ) {
			echo '<p>' . esc_html__( 'Some of these events were printed by the path that queues events while signals are held for consent.', 'catalogwell' ) . '</p>';
		}

		if ( $page['generated'] ) {
			echo '<p>' . esc_html(
				sprintf(
					/* translators: 1: date and time the page was generated, 2: age in minutes. */
					__( 'The page was generated at %1$s (its own window.__wc_fb_page_generated marker), %2$s minutes before the last load.', 'catalogwell' ),
					Catalogwell_Environment::format_time( $page['generated'] ),
					number_format_i18n( $page['age'] / 60, 1 )
				)
			) . ' ';
			if ( $page['age'] > Catalogwell_Events::CACHE_THRESHOLD ) {
				echo esc_html__( 'That is more than 30 minutes, so the rule above applies to this copy.', 'catalogwell' );
			} else {
				echo esc_html__( 'That is less than 30 minutes, so the rule above does not drop the eventID from this copy yet.', 'catalogwell' );
			}
			echo '</p>';
		} else {
			echo '<p>' . esc_html__( 'The page carries no window.__wc_fb_page_generated marker, so its age is not known.', 'catalogwell' ) . '</p>';
		}

		if ( empty( $page['caches'] ) ) {
			echo '<p>' . esc_html__( 'Page cache: not named. No header or markup of this page names one.', 'catalogwell' ) . '</p>';
		} else {
			echo '<p>' . esc_html(
				sprintf(
					/* translators: %s: cache names. */
					__( 'Page cache named by the page’s headers or markup: %s.', 'catalogwell' ),
					implode( ', ', $page['caches'] )
				)
			) . '</p>';
		}

		?>
		<div class="catalogwell-table-wrap">
			<table class="widefat striped catalogwell-table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Load', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Event IDs in the HTML', 'catalogwell' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $page['per_load'] as $load ) : ?>
					<tr>
						<td><?php echo esc_html( (string) $load['load'] ); ?></td>
						<td>
							<?php
							if ( empty( $load['events'] ) ) {
								esc_html_e( 'none', 'catalogwell' );
							} else {
								$parts = array();
								foreach ( $load['events'] as $event ) {
									$parts[] = ( '' !== $event['name'] ? $event['name'] . ': ' : '' ) . $event['id'];
								}
								echo esc_html( implode( '; ', $parts ) );
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Purchase pair counts.
	 *
	 * @param array $p Purchase counts.
	 * @return void
	 */
	private static function render_purchases( $p ) {
		if ( ! $p['available'] ) {
			echo '<p>' . esc_html__( 'WooCommerce is not active, so there are no orders to count.', 'catalogwell' ) . '</p>';
			return;
		}
		if ( 0 === $p['total'] ) {
			echo '<p>' . esc_html__( 'There are no orders in a status where Meta for WooCommerce records a Purchase (pending, on-hold, processing, completed), so there is nothing to count.', 'catalogwell' ) . '</p>';
			return;
		}
		echo '<p>' . esc_html(
			sprintf(
				/* translators: %d: number of orders. */
				_n( 'Counted on the last %d order in a status where Meta for WooCommerce records a Purchase (pending, on-hold, processing, completed). This is what Meta for WooCommerce recorded on each order.', 'Counted on the last %d orders in a status where Meta for WooCommerce records a Purchase (pending, on-hold, processing, completed). This is what Meta for WooCommerce recorded on each order.', (int) $p['total'], 'catalogwell' ),
				(int) $p['total']
			)
		) . '</p>';
		?>
		<div class="catalogwell-table-wrap">
			<table class="widefat striped catalogwell-table">
				<thead><tr><th scope="col"><?php esc_html_e( 'What Meta for WooCommerce recorded', 'catalogwell' ); ?></th><th scope="col"><?php esc_html_e( 'Orders', 'catalogwell' ); ?></th></tr></thead>
				<tbody>
					<tr><td><?php esc_html_e( 'Server Purchase and browser Purchase code (placed on the thank-you page), with one shared event ID', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $p['both_shared'] ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'Server Purchase and browser Purchase code, but no event ID stored on the order', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $p['both_no_id'] ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'Server Purchase only', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $p['server_only'] ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'Browser Purchase code only (placed on the thank-you page)', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $p['browser_only'] ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'Neither recorded by Meta for WooCommerce', 'catalogwell' ); ?></td><td><?php echo esc_html( number_format_i18n( $p['neither'] ) ); ?></td></tr>
				</tbody>
			</table>
		</div>
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: text such as "1 order" or "2 orders" with a server Purchase recorded, 2: the same for a browser Purchase code. */
					__( 'In all: %1$s with a server Purchase recorded and %2$s with a browser Purchase code recorded.', 'catalogwell' ),
					sprintf(
						/* translators: %s: number of orders. */
						_n( '%s order', '%s orders', (int) $p['server_total'], 'catalogwell' ),
						number_format_i18n( $p['server_total'] )
					),
					sprintf(
						/* translators: %s: number of orders. */
						_n( '%s order', '%s orders', (int) $p['browser_total'], 'catalogwell' ),
						number_format_i18n( $p['browser_total'] )
					)
				)
			);
			?>
		</p>
		<?php if ( $p['pys_marked'] > 0 ) : ?>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: number of orders. */
						__( 'PixelYourSite marked %s of these orders as having its own Purchase sent. This check does not read PixelYourSite’s records, so “neither recorded” above does not mean no Purchase was tracked.', 'catalogwell' ),
						number_format_i18n( $p['pys_marked'] )
					)
				);
				?>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * The Copy as text box.
	 *
	 * @param array $results Stored result.
	 * @return void
	 */
	private static function render_copy( $results ) {
		?>
		<section class="catalogwell-section" id="catalogwell-copy">
			<h2><?php esc_html_e( 'Copy as text', 'catalogwell' ); ?></h2>
			<p class="description"><?php esc_html_e( 'A plain report to send to support@ochrestack.com or paste in a support thread. It holds no access token, no customer data and no e-mail address.', 'catalogwell' ); ?></p>
			<p>
				<button type="button" class="button" id="catalogwell-copy-button"><?php esc_html_e( 'Copy as text', 'catalogwell' ); ?></button>
				<span id="catalogwell-copy-status" class="catalogwell-progress" role="status" aria-live="polite"></span>
			</p>
			<label for="catalogwell-report" class="screen-reader-text"><?php esc_html_e( 'Report as plain text', 'catalogwell' ); ?></label>
			<textarea id="catalogwell-report" class="large-text code" rows="14" readonly="readonly"><?php echo esc_textarea( Catalogwell_Report::build( $results ) ); ?></textarea>
		</section>
		<?php
	}
}
