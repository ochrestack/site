<?php
/**
 * Check 3: which Meta Pixel IDs the site's pages really carry, and which plugin printed each.
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pixel check.
 */
class Catalogwell_Pixel {

	const PLUGIN_META  = 'meta';
	const PLUGIN_PYS   = 'pys';
	const PLUGIN_OFP   = 'ofp';
	const PLUGIN_OTHER = 'other';

	/**
	 * Name of a printing plugin.
	 *
	 * @param string $key One of the PLUGIN_ constants.
	 * @return string
	 */
	public static function plugin_name( $key ) {
		switch ( $key ) {
			case self::PLUGIN_META:
				return __( 'Meta for WooCommerce', 'catalogwell' );
			case self::PLUGIN_PYS:
				return __( 'PixelYourSite', 'catalogwell' );
			case self::PLUGIN_OFP:
				return __( 'Meta pixel for WordPress', 'catalogwell' );
			default:
				return __( 'theme or another plugin', 'catalogwell' );
		}
	}

	/**
	 * Pixel IDs started in a page's markup, with the plugin that printed each.
	 *
	 * @param string $html Page markup.
	 * @return array[] Each: id, plugin, via, starts (how many times the markup starts it), noscript_only.
	 */
	public static function parse( $html ) {
		$found = array(); // Key "plugin|id".
		$html  = self::without_comments( $html );

		$add = static function ( $plugin, $id, $via, $starts = 1 ) use ( &$found ) {
			$key = $plugin . '|' . $id;
			if ( ! isset( $found[ $key ] ) ) {
				$found[ $key ] = array(
					'id'            => $id,
					'plugin'        => $plugin,
					'via'           => array(),
					'starts'        => 0,
					'noscript_only' => false,
				);
			}
			$found[ $key ]['starts'] += $starts;
			if ( ! in_array( $via, $found[ $key ]['via'], true ) ) {
				$found[ $key ]['via'][] = $via;
			}
		};

		// Meta for WooCommerce 3.x.
		if ( preg_match_all( '/FacebookSignals\.initPixel\(\s*["\']?(\d{5,20})/', $html, $m ) ) {
			foreach ( $m[1] as $id ) {
				$add( self::PLUGIN_META, $id, __( 'a FacebookSignals.initPixel call in the page', 'catalogwell' ) );
			}
		}
		// Meta pixel for WordPress.
		if ( preg_match_all( '/FacebookSignal\.initPixel\(\s*["\']?(\d{5,20})/', $html, $m ) ) {
			foreach ( $m[1] as $id ) {
				$add( self::PLUGIN_OFP, $id, __( 'a FacebookSignal.initPixel call in the page', 'catalogwell' ) );
			}
		}
		// PixelYourSite.
		foreach ( self::pys_ids( $html ) as $id ) {
			$add( self::PLUGIN_PYS, $id, __( 'its pysOptions data in the page', 'catalogwell' ) );
		}

		// Any other fbq('init', ID) call, named by its agent string when it has one.
		if ( preg_match_all( '/fbq\(\s*[\'"]init[\'"]\s*,\s*[\'"]?(\d{5,20})[\'"]?(.{0,400})/s', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $call ) {
				$id     = $call[1];
				$after  = $call[2];
				$plugin = self::PLUGIN_OTHER;
				if ( false !== strpos( $after, '__wc_fb_page_generated' ) || preg_match( '/agent[\'"]?\s*:\s*[\'"]woocommerce/i', $after ) ) {
					$plugin = self::PLUGIN_META;
				} elseif ( preg_match( '/agent[\'"]?\s*:\s*[\'"]wordpress/i', $after ) ) {
					$plugin = self::PLUGIN_OFP;
				}
				$add( $plugin, $id, __( 'an fbq init call in the page', 'catalogwell' ) );
			}
		}

		// The noscript image: it names an ID, but a browser with scripts on does not start a Pixel from it.
		$script_ids = array();
		foreach ( $found as $entry ) {
			$script_ids[ $entry['id'] ] = true;
		}
		if ( preg_match_all( '#facebook\.com/tr\?[^"\'>\s]*?\bid=(\d{5,20})([^"\'>\s]*)#i', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $img ) {
				if ( isset( $script_ids[ $img[1] ] ) ) {
					continue;
				}
				$plugin = false !== stripos( rawurldecode( html_entity_decode( $img[2] ) ), 'PixelYourSite' ) ? self::PLUGIN_PYS : self::PLUGIN_OTHER;
				$add( $plugin, $img[1], __( 'a noscript image', 'catalogwell' ) );
				$found[ $plugin . '|' . $img[1] ]['noscript_only'] = true;
			}
		}

		return array_values( $found );
	}

	/**
	 * Markup without HTML comments, JavaScript block comments and lines that are only a JavaScript comment.
	 * A Pixel kept in a comment (old code left in a header-snippets plugin) is not started on the page.
	 *
	 * @param string $html Page markup.
	 * @return string
	 */
	private static function without_comments( $html ) {
		$clean = preg_replace( array( '/<!--.*?-->/s', '#/\*.{0,5000}?\*/#s' ), '', $html );
		$clean = is_string( $clean ) ? $clean : $html;
		$lines = preg_replace( '#(^|[;{}>])[ \t]*//[^\r\n]*#m', '$1', $clean );
		return is_string( $lines ) ? $lines : $clean;
	}

	/**
	 * Pixel IDs in PixelYourSite's pysOptions data.
	 *
	 * @param string $html Page markup.
	 * @return string[]
	 */
	private static function pys_ids( $html ) {
		if ( false === strpos( $html, 'pysOptions' ) ) {
			return array();
		}
		if ( ! preg_match( '/var\s+pysOptions\s*=\s*(\{.*?\});\s*(?:\r?\n|<\/script>)/s', $html, $m ) ) {
			return array();
		}
		$data = json_decode( $m[1], true );
		if ( ! is_array( $data ) ) {
			return array();
		}
		$ids = array();
		self::collect_pixel_ids( $data, false, $ids );
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Walk decoded pysOptions and collect pixelIds under a "facebook" key.
	 *
	 * @param array    $node       Decoded data.
	 * @param bool     $in_facebook Whether the walk is below a facebook key.
	 * @param string[] $ids        Found IDs.
	 * @return void
	 */
	private static function collect_pixel_ids( $node, $in_facebook, &$ids ) {
		foreach ( $node as $key => $value ) {
			$below = $in_facebook || 'facebook' === $key;
			if ( $below && 'pixelIds' === $key && is_array( $value ) ) {
				foreach ( $value as $id ) {
					if ( is_scalar( $id ) && preg_match( '/^\d{5,20}$/', (string) $id ) ) {
						$ids[] = (string) $id;
					}
				}
			} elseif ( is_array( $value ) ) {
				self::collect_pixel_ids( $value, $below, $ids );
			}
		}
	}

	/**
	 * Group parsed entries by Pixel ID.
	 *
	 * @param array[] $entries Result of parse().
	 * @return array[] Each: id, plugins (keys), via, starts, noscript_only.
	 */
	public static function group( $entries ) {
		$by_id = array();
		foreach ( $entries as $entry ) {
			$id = $entry['id'];
			if ( ! isset( $by_id[ $id ] ) ) {
				$by_id[ $id ] = array(
					'id'            => $id,
					'plugins'       => array(),
					'via'           => array(),
					'starts'        => 0,
					'noscript_only' => true,
				);
			}
			if ( ! in_array( $entry['plugin'], $by_id[ $id ]['plugins'], true ) ) {
				$by_id[ $id ]['plugins'][] = $entry['plugin'];
			}
			$by_id[ $id ]['via']     = array_values( array_unique( array_merge( $by_id[ $id ]['via'], $entry['via'] ) ) );
			$by_id[ $id ]['starts'] += $entry['starts'];
			if ( ! $entry['noscript_only'] ) {
				$by_id[ $id ]['noscript_only'] = false;
			}
		}
		return array_values( $by_id );
	}

	/**
	 * Flags for one page, against the Pixel IDs Meta for WooCommerce has stored.
	 *
	 * @param array[] $pixels       Grouped Pixels found on the page.
	 * @param array   $stored       Stored IDs: setting, config.
	 * @param bool    $meta_active  Whether Meta for WooCommerce is active.
	 * @return array[] Each: key, text.
	 */
	public static function flags( $pixels, $stored, $meta_active ) {
		$flags        = array();
		$stored_ids   = array_values( array_filter( array_unique( array( $stored['config'], $stored['setting'] ) ) ) );
		$script_found = array_values(
			array_filter(
				$pixels,
				static function ( $p ) {
					return ! $p['noscript_only'];
				}
			)
		);

		if ( $stored_ids && $meta_active && ! $script_found ) {
			$flags[] = array(
				'key'  => 'no_pixel',
				'text' => sprintf(
					/* translators: %s: Pixel ID stored by Meta for WooCommerce. */
					__( 'No Pixel is started on this page, while Meta for WooCommerce has Pixel %s stored.', 'catalogwell' ),
					implode( ', ', $stored_ids )
				),
			);
		}

		if ( $stored_ids ) {
			foreach ( $script_found as $pixel ) {
				if ( ! in_array( $pixel['id'], $stored_ids, true ) ) {
					$names   = array_map( array( __CLASS__, 'plugin_name' ), $pixel['plugins'] );
					$flags[] = array(
						'key'  => 'different_pixel',
						'text' => sprintf(
							/* translators: 1: Pixel ID on the page, 2: plugin names, 3: Pixel ID stored. */
							__( 'Pixel %1$s on this page (printed by %2$s) is not the Pixel stored by Meta for WooCommerce (%3$s).', 'catalogwell' ),
							$pixel['id'],
							implode( ', ', $names ),
							implode( ', ', $stored_ids )
						),
					);
				}
			}
		}

		if ( count( $script_found ) >= 2 ) {
			$flags[] = array(
				'key'  => 'two_pixels',
				'text' => sprintf(
					/* translators: %s: Pixel IDs. */
					__( 'Two different Pixel IDs are started on this page (%s). Each event can be sent once for each Pixel.', 'catalogwell' ),
					implode( ', ', wp_list_pluck( $script_found, 'id' ) )
				),
			);
		}

		foreach ( $script_found as $pixel ) {
			if ( count( $pixel['plugins'] ) >= 2 || $pixel['starts'] >= 2 ) {
				$names   = array_map( array( __CLASS__, 'plugin_name' ), $pixel['plugins'] );
				$flags[] = array(
					'key'  => 'double_start',
					'text' => sprintf(
						/* translators: 1: Pixel ID, 2: how many times the markup starts it, 3: plugin names. */
						__( 'Pixel %1$s is started %2$d times on this page (by %3$s). Two starts of one Pixel can send each event twice from the browser.', 'catalogwell' ),
						$pixel['id'],
						$pixel['starts'],
						implode( ' and ', $names )
					),
				);
			}
		}
		return $flags;
	}

	/**
	 * Pages to check: the home page and one product page.
	 *
	 * @param string $product_url Address the person chose (may be empty).
	 * @return array[] Each: key, label, url, note.
	 */
	public static function pages( $product_url = '' ) {
		$pages   = array();
		$pages[] = array(
			'key'   => 'home',
			'label' => __( 'Home page', 'catalogwell' ),
			'url'   => home_url( '/' ),
			'note'  => '',
		);

		$product_url = trim( (string) $product_url );
		if ( '' !== $product_url ) {
			$pages[] = array(
				'key'   => 'product',
				'label' => __( 'Product page', 'catalogwell' ),
				'url'   => $product_url,
				'note'  => '',
			);
			return $pages;
		}
		if ( ! Catalogwell_Environment::woocommerce_active() ) {
			$pages[] = array(
				'key'   => 'product',
				'label' => __( 'Product page', 'catalogwell' ),
				'url'   => '',
				'note'  => __( 'WooCommerce is not active, so there is no product page to check.', 'catalogwell' ),
			);
			return $pages;
		}
		$ids = wc_get_products(
			array(
				'status'     => 'publish',
				'visibility' => 'visible',
				'limit'      => 1,
				'orderby'    => 'ID',
				'order'      => 'DESC',
				'return'     => 'ids',
			)
		);
		if ( empty( $ids ) ) {
			$pages[] = array(
				'key'   => 'product',
				'label' => __( 'Product page', 'catalogwell' ),
				'url'   => '',
				'note'  => __( 'There is no published product shown in the shop, so there is no product page to check.', 'catalogwell' ),
			);
			return $pages;
		}
		$pages[] = array(
			'key'   => 'product',
			'label' => __( 'Product page', 'catalogwell' ),
			'url'   => get_permalink( (int) $ids[0] ),
			'note'  => '',
		);
		return $pages;
	}

	/**
	 * Check one page.
	 *
	 * @param array $page Entry from pages().
	 * @return array Result for the screen.
	 */
	public static function check_page( $page ) {
		$result = array(
			'key'      => $page['key'],
			'label'    => $page['label'],
			'url'      => $page['url'],
			'kind'     => 'skipped',
			'sentence' => $page['note'],
			'pixels'   => array(),
			'flags'    => array(),
		);
		if ( '' === $page['url'] ) {
			return $result;
		}
		if ( ! Catalogwell_Fetcher::is_own( $page['url'] ) ) {
			$result['kind']     = 'foreign_host';
			$result['sentence'] = sprintf(
				/* translators: %s: address. */
				__( 'The address %s is not on this site’s own host, so Catalogwell did not load it.', 'catalogwell' ),
				$page['url']
			);
			return $result;
		}

		$fetch              = Catalogwell_Fetcher::get( $page['url'] );
		$result['kind']     = $fetch['kind'];
		$result['sentence'] = $fetch['sentence'];
		if ( 'ok' !== $fetch['kind'] ) {
			if ( 'not_found' === $fetch['kind'] ) {
				$unpublished = Catalogwell_Fetcher::unpublished_sentence( $page['url'] );
				if ( '' !== $unpublished ) {
					$result['sentence'] = $unpublished;
					$result['kind']     = 'unpublished';
				}
			}
			return $result;
		}

		$meta   = Catalogwell_Environment::meta();
		$stored = Catalogwell_Connection::stored_pixel_ids();

		$result['pixels'] = self::group( self::parse( $fetch['body'] ) );
		$result['flags']  = self::flags( $result['pixels'], $stored, 'active' === $meta['state'] );
		return $result;
	}

	/**
	 * Run the whole check.
	 *
	 * @param string       $product_url Address chosen by the person (may be empty).
	 * @param array[]|null $pages       The pages the run chose when it started (null: choose now).
	 * @return array
	 */
	public static function run( $product_url = '', $pages = null ) {
		$meta    = Catalogwell_Connection::meta();
		$results = array();
		foreach ( null === $pages ? self::pages( $product_url ) : $pages as $page ) {
			$results[] = self::check_page( $page );
		}
		return array(
			'pages'   => $results,
			'stored'  => array(
				'setting' => $meta['pixel_setting'],
				'config'  => $meta['pixel_config'],
			),
			'pairing' => Catalogwell_Connection::pairing( $meta ),
		);
	}

	/**
	 * The steps to check access, for the pairing line.
	 *
	 * @return string[]
	 */
	public static function pairing_steps() {
		return array(
			__( 'In Meta Business Settings, open the business portfolio that owns the Pixel and the catalog.', 'catalogwell' ),
			__( 'Check that the Facebook profile you used in Meta for WooCommerce’s setup is a person in that portfolio and has access to both assets.', 'catalogwell' ),
			__( 'Then run Meta for WooCommerce’s setup again.', 'catalogwell' ),
		);
	}
}
