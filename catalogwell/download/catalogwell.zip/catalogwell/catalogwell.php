<?php
/**
 * Plugin Name:       Catalogwell – Catalog and Pixel Checker for WooCommerce
 * Description:       See what Meta for WooCommerce hides, and why, and what it has stored. Open it from WooCommerce > Catalogwell (Tools > Catalogwell while WooCommerce is inactive).
 * Version:           1.0.4
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       catalogwell
 * Domain Path:       /languages
 *
 * @package Catalogwell
 */

defined( 'ABSPATH' ) || exit;

define( 'CATALOGWELL_VERSION', '1.0.4' );
define( 'CATALOGWELL_FILE', __FILE__ );
define( 'CATALOGWELL_DIR', plugin_dir_path( __FILE__ ) );
define( 'CATALOGWELL_URL', plugin_dir_url( __FILE__ ) );

/**
 * The versions of the two plugins whose code the rules were read from.
 * A different installed version is named on the screen.
 */
define( 'CATALOGWELL_META_REFERENCE', '3.7.9' );
define( 'CATALOGWELL_GOOGLE_REFERENCE', '3.10.1' );

require_once CATALOGWELL_DIR . 'includes/class-catalogwell-access.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-environment.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-logs.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-connection.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-catalog.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-feed.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-google.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-fetcher.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-pixel.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-events.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-purchases.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-runner.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-report.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-screen.php';
require_once CATALOGWELL_DIR . 'includes/class-catalogwell-plugin.php';

Catalogwell_Plugin::init();
