=== Catalogwell – Catalog and Pixel Checker for WooCommerce ===
Contributors: ochrestack
Tags: pixel, catalog, diagnostics, deduplication, product-feed
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Products hidden in Meta Commerce Manager? Access token missing? See what Meta for WooCommerce hides, and why, and what it has stored.

== Description ==

“Many products in my catalog are marked as hidden in Meta Commerce Manager.” “My WooCommerce logs repeatedly show: Cannot create the API instance because the access token is missing.” Catalogwell shows which of your products Meta for WooCommerce marks hidden for your catalog, and why, what connection data it has stored, and whether your page cache repeats event IDs.

On WooCommerce's own sample store, Meta for WooCommerce marks 2 of 22 products hidden. (WordPress 7.1.5, WooCommerce 11.3.1 with its own sample_products.csv imported unchanged, default settings, Meta for WooCommerce 3.7.9.)

Catalogwell is free, with no account and no locked button. It only reads: it changes none of your products, orders or settings or any account, and contacts no outside server.

= What it shows =

* **Connection.** Whether Meta for WooCommerce is active, deactivated or deleted; whether a token is stored (never the token); its stored IDs; and its "access token is missing" log lines of the last 7 days. The state is named (Connected, Token rejected by Meta, Access token missing, Left behind, Never connected) with one next step.
* **Catalog.** Every published product and variation that Meta for WooCommerce sends, as "published" or "hidden", with the reason and the setting or field it comes from, including the WPML and Polylang language rule. Beside it: the newest feed file (rows that differ) and the last run of the daily feed job.
* **Google for WooCommerce.** Its stored IDs and setup state, counts by sync status and the five most common errors.
* **Pixel.** The Pixel IDs your home page and a product page carry, and which plugin printed each, with flags for no Pixel, a Pixel other than the stored one, two Pixels and one started twice.
* **Event IDs and Purchase pairs.** The same page loaded five times as separate visitors; an event ID seen twice is reported as repeated (on a copy over 30 minutes old, as dropped by the browser), with the page's age and the cache named. For your last 50 orders: the Purchase records Meta for WooCommerce saved (both with one event ID, server only, browser only, neither).

Each state is labelled "Fix on this site", "Meta's side" ("Google's side") or "Nothing to fix"; Catalogwell only reports the second kind. "Copy as text" makes a plain report for a support forum, with no token, customer data or e-mail address.

= What it does not do =

* Meta for WooCommerce's "Synced to Meta catalog" column already says whether each product syncs and why not. Catalogwell adds which synced products go as hidden, and why.
* Google for WooCommerce's Product Feed page already lists each product's status. Catalogwell adds only a summary.
* Developer tools and Meta's Test Events show one visit at a time; Catalogwell compares five.
* It cannot see or change Meta's or Google's accounts, and does not reconnect, repair, delete, edit visibility or regenerate feeds.
* No multisite network runs, payment-gateway Purchase timing or consent checks. One check runs at a time. A CDN in front of your site may cache differently.
* Checked against Meta for WooCommerce 3.7.9 and Google for WooCommerce 3.10.1, on Linux web servers and in Chromium; Windows and macOS web servers and other browsers were not run.

Not affiliated with or endorsed by Meta, Google or WooCommerce.

= Catalogwell Pro =

A separate add-on: $19 once, unlimited sites, every Pro update, no renewal. It re-runs the checks daily, e-mails you when a state changes, keeps 30 checks and exports the product list as CSV.

== External services ==

Neither Catalogwell nor Catalogwell Pro contacts any outside server (Pro's e-mail leaves through your site's own mail setup). The Pixel and event-ID checks request your own site's pages (home page and one product page, five times each) as a visitor who is not logged in, with no cookies; no script in them runs. Your site's code runs for each load as for a visitor: Catalogwell tells Meta for WooCommerce to treat its loads as a crawler, so it sends no Conversions API event for them (checked with 3.7.9); another plugin that records visits on the server may count them.

== Installation ==

1. Go to Plugins > Add Plugin > Upload Plugin, choose catalogwell.zip, press Install Now, then Activate Plugin.
2. Open WooCommerce > Catalogwell (under Tools when WooCommerce is not active) and press "Run the checks".

== Frequently Asked Questions ==

= My logs say the access token is missing. What does that mean? =

Meta for WooCommerce found no access token stored, so it cannot call Meta. Catalogwell shows whether a token is stored, the IDs stored and the count of those log lines. IDs without a token are named "Access token missing": run Meta for WooCommerce's setup again. A token Meta rejected is named "Token rejected by Meta": reconnect the store.

= I removed the plugin but Meta still shows it managing my shop. What is left? =

Deactivating or deleting Meta for WooCommerce 3.7.9 leaves its token and IDs in your database: "Left behind". Its own Disconnect, used while it is active and connected, asks Meta to remove the link and clears the data; Catalogwell cannot.

= Why are my products hidden in Commerce Manager when they are set to Sync and show? =

Meta for WooCommerce sends as hidden an out-of-stock item, a virtual product (bundles excepted), a product whose Facebook Sync is "Sync and hide in catalog", a variable product with no visible variation, and, on a Polylang or WPML site, a product that has no language (fix it on the product) or is not in the default language (Meta's rule). Catalogwell lists each product with its reason, and each feed-file row whose visibility differs.

= Setup only offers to create a new Pixel and catalog. Why? =

What setup offers depends on your business portfolio and the access of the Facebook profile used, which Catalogwell cannot see. It shows the IDs stored, the Pixel your pages print, and the steps to check access.

= Does my page cache make visitors share one event ID? =

It can. Meta for WooCommerce prints an event ID into the page, so a cache that serves one copy to everyone serves one ID to everyone; Catalogwell reports an ID seen in two loads as repeated. In 3.7.9 a browser drops the ID when the copy is over 30 minutes old (Catalogwell then says "No event ID sent"), but not on the consent-hold path.

= Are my Purchase events counted twice? =

On your last 50 orders, Catalogwell counts server Purchases, browser Purchase codes on the thank-you page, both with one event ID, or neither: what Meta for WooCommerce recorded on each order, not what Meta received.

= Does it change my store or my Meta account? =

No. It reads options, products, orders, files and your own pages, and stores only its own result (options named catalogwell_*), removed when you delete the plugin.

= Does it send anything anywhere? =

Catalogwell contacts no outside server: it requests only your own site's pages. Meta for WooCommerce is told to send no event for those loads (3.7.9); other server-side trackers are not, and may count them.

= Can it fix problems on Meta's or Google's side? =

No. Each finding is labelled "Fix on this site" or "Meta's side" ("Google's side"), with where it is fixed; the second kind is only reported.

= Where do I get help? =

support@ochrestack.com

== Screenshots ==

1. The catalog result on WooCommerce's sample store: how many products go to Meta as hidden, each reason, and the product list.
2. Connection: what Meta for WooCommerce has stored. The IDs shown are the demo store's.
3. A stored connection with the access token missing, with its next step and label. The IDs shown are the demo store's.
4. Event IDs behind WP Super Cache: the same event ID in five separate loads.
5. Pixel check: a second Pixel on the home page, and which plugin printed each. The Pixel IDs shown are the demo store's.

== Changelog ==

= 1.0.2 =
* Meta for WooCommerce no longer writes a "Blocked CAPI event for crawler" line to its log for each page a check loads (it did while the store was not connected or its debug mode was on).
* The review line is gone until the plugin is in the WordPress.org directory.
* Products in the lists link to their edit screens; a product with no language and a product in another language have separate reasons.
* Purchase pairs say what Meta for WooCommerce recorded and name orders that carry PixelYourSite's marker; "Left behind" with no token has one next step, on Meta's side.

= 1.0.1 =
* The language rule of Meta for WooCommerce (Polylang and WPML) is read, so a Polylang store no longer shows hidden products as published.
* A check makes Meta for WooCommerce send no events for its page loads.
* "Token rejected by Meta" is its own state; opening Meta's setup screen once no longer reads as "Access token missing".
* One check runs at a time; a second one is told so and changes nothing.
* A cached copy more than 30 minutes old is reported as "No event ID sent", not as one ID for every visitor.

= 1.0.0 =
* First release: connection, catalog, Pixel and event-ID checks, Purchase pair counts, Copy as text.
