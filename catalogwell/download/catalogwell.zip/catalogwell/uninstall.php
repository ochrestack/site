<?php
/**
 * Removes what Catalogwell stored when the plugin is deleted.
 *
 * @package Catalogwell
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'catalogwell_results', 'catalogwell_rows', 'catalogwell_scratch', 'catalogwell_runs', 'catalogwell_review_dismissed', 'catalogwell_lock' ) as $catalogwell_option ) {
	delete_option( $catalogwell_option );
}
