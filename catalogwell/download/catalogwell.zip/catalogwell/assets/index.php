<?php
/**
 * Silence is golden.
 *
 * @package Catalogwell
 */
