/* Catalogwell admin screen. No external requests: every call goes to this site's admin-ajax.php. */
( function () {
	'use strict';

	var data = window.catalogwellData;
	if ( ! data ) {
		return;
	}
	var form = document.getElementById( 'catalogwell-form' );
	var button = document.getElementById( 'catalogwell-run' );
	var progress = document.getElementById( 'catalogwell-progress' );
	var errorBox = document.getElementById( 'catalogwell-error' );
	var results = document.getElementById( 'catalogwell-results' );
	var running = false;
	var runId = '';

	function post( payload ) {
		var body = new URLSearchParams();
		body.set( 'action', 'catalogwell_step' );
		body.set( 'nonce', data.nonce );
		if ( runId ) {
			body.set( 'run', runId );
		}
		Object.keys( payload ).forEach( function ( key ) {
			body.set( key, payload[ key ] );
		} );
		return window.fetch( data.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function ( response ) {
			return response.json().catch( function () {
				throw new Error( data.i18n.networkError );
			} );
		} ).then( function ( json ) {
			if ( ! json || ! json.success ) {
				var failure = new Error( json && json.data && json.data.message ? json.data.message : data.i18n.networkError );
				failure.refused = json && json.data && json.data.refused;
				throw failure;
			}
			return json.data;
		} );
	}

	// The window chooses the run's ID, so that a reload before the first answer arrives can still give the run up.
	function newRunId() {
		var bytes = new Uint8Array( 16 );
		window.crypto.getRandomValues( bytes );
		return Array.prototype.map.call( bytes, function ( b ) {
			return ( '0' + b.toString( 16 ) ).slice( -2 );
		} ).join( '' );
	}

	function say( text ) {
		progress.textContent = text;
	}

	function fill( template, values ) {
		var i = 0;
		return template.replace( /%(\d\$)?s/g, function () {
			var value = values[ i ];
			i += 1;
			return value;
		} );
	}

	function showError( message, refused ) {
		errorBox.querySelector( 'p' ).textContent = refused ? message : fill( data.i18n.failed, [ message ] );
		errorBox.hidden = false;
	}

	function catalogLoop( after, total ) {
		return post( { step: 'catalog', after: String( after ) } ).then( function ( out ) {
			say( fill( data.i18n.catalog, [ out.rows, total ] ) );
			if ( out.done ) {
				return out;
			}
			return catalogLoop( out.last_id, total );
		} );
	}

	function eventsLoop( pages ) {
		var keys = Object.keys( pages );
		var chain = Promise.resolve();
		keys.forEach( function ( key ) {
			for ( var n = 1; n <= data.loads; n += 1 ) {
				( function ( load ) {
					chain = chain.then( function () {
						say( fill( data.i18n.events, [ pages[ key ], load, data.loads ] ) );
						return post( { step: 'events', page: key, load: String( load ) } );
					} );
				}( n ) );
			}
		} );
		return chain;
	}

	function run() {
		if ( running ) {
			return;
		}
		running = true;
		runId = newRunId();
		button.disabled = true;
		errorBox.hidden = true;
		say( data.i18n.starting );
		var total = 0;
		var pages = {};
		post( { step: 'start', product_url: document.getElementById( 'catalogwell-product-url' ).value } )
			.then( function ( out ) {
				total = out.items;
				pages = out.pages;
				say( data.i18n.connection );
				return post( { step: 'connection' } );
			} )
			.then( function () {
				return catalogLoop( 0, total );
			} )
			.then( function () {
				say( data.i18n.catalogEnd );
				return post( { step: 'catalog_finish' } );
			} )
			.then( function () {
				say( data.i18n.pixel );
				return post( { step: 'pixel' } );
			} )
			.then( function () {
				return eventsLoop( pages );
			} )
			.then( function () {
				say( data.i18n.eventsEnd );
				return post( { step: 'events_finish' } );
			} )
			.then( function () {
				say( data.i18n.finishing );
				return post( { step: 'finish' } );
			} )
			.then( function ( out ) {
				results.innerHTML = out.html;
				say( data.i18n.done );
			} )
			.catch( function ( error ) {
				say( '' );
				showError( error.message, error.refused );
				if ( ! error.refused ) {
					giveUp(); // A run that stopped on an error must not make the next press wait.
				}
			} )
			.then( function () {
				running = false;
				runId = '';
				button.disabled = false;
			} );
	}

	// A run that stopped on an error, or whose window is closed or reloaded, gives its lock up, so the next press of
	// the button is not told to wait. (A reload can fail the request in flight before "pagehide" fires, so the run's
	// ID outlives the failed request until it has been given up.)
	function giveUp() {
		if ( ! runId || ! navigator.sendBeacon ) {
			return;
		}
		var body = new URLSearchParams();
		body.set( 'action', 'catalogwell_step' );
		body.set( 'nonce', data.nonce );
		body.set( 'step', 'release' );
		body.set( 'run', runId );
		navigator.sendBeacon( data.ajaxUrl, body );
		runId = '';
	}

	window.addEventListener( 'pagehide', function () {
		if ( running || runId ) {
			giveUp();
		}
	} );

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		run();
	} );

	function loadList( filter, page ) {
		var body = document.getElementById( 'catalogwell-list-body' );
		var payload = new URLSearchParams();
		payload.set( 'action', 'catalogwell_list' );
		payload.set( 'nonce', data.nonce );
		payload.set( 'filter', filter );
		payload.set( 'page', String( page ) );
		window.fetch( data.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: payload.toString()
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( json ) {
			if ( json && json.success ) {
				body.innerHTML = json.data.html;
			} else {
				body.textContent = data.i18n.listFailed;
			}
		} ).catch( function () {
			body.textContent = data.i18n.listFailed;
		} );
	}

	document.addEventListener( 'change', function ( event ) {
		if ( event.target && 'catalogwell-list-filter' === event.target.id ) {
			loadList( event.target.value, 1 );
		}
	} );

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( ! target || ! target.closest ) {
			return;
		}
		var pager = target.closest( '[data-catalogwell-page]' );
		if ( pager && ! pager.disabled ) {
			var filter = document.getElementById( 'catalogwell-list-filter' ).value;
			loadList( filter, parseInt( pager.getAttribute( 'data-catalogwell-page' ), 10 ) );
			return;
		}
		if ( target.closest( '#catalogwell-copy-button' ) ) {
			copyReport();
			return;
		}
	} );

	function copyReport() {
		var area = document.getElementById( 'catalogwell-report' );
		var status = document.getElementById( 'catalogwell-copy-status' );
		area.focus();
		area.select();
		var done = function () {
			status.textContent = data.i18n.copied;
		};
		var fail = function () {
			status.textContent = data.i18n.copyFailed;
		};
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( area.value ).then( done, function () {
				try {
					document.execCommand( 'copy' ) ? done() : fail();
				} catch ( e ) {
					fail();
				}
			} );
			return;
		}
		try {
			document.execCommand( 'copy' ) ? done() : fail();
		} catch ( e ) {
			fail();
		}
	}
}() );
