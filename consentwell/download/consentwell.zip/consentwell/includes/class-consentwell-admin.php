<?php
/**
 * The Tools > Consentwell screen.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin screen.
 */
class Consentwell_Admin {

	const SLUG = 'consentwell';

	const REVIEW_META = 'consentwell_review_dismissed';

	const REVIEW_URL = 'https://wordpress.org/support/plugin/consentwell/reviews/#new-post';

	const PRO_URL = 'https://ochrestack.com/consentwell';

	/**
	 * Screen hook suffix.
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Hook in.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CONSENTWELL_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Tools > Consentwell, administrators only.
	 */
	public static function menu() {
		self::$hook = (string) add_management_page(
			__( 'Consentwell', 'consentwell' ),
			__( 'Consentwell', 'consentwell' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Address of the screen.
	 *
	 * @return string
	 */
	public static function screen_url() {
		return admin_url( 'tools.php?page=' . self::SLUG );
	}

	/**
	 * "Check a page" link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::screen_url() ) . '">' . esc_html__( 'Check a page', 'consentwell' ) . '</a>' );
		return $links;
	}

	/**
	 * Register the check engine everywhere in admin (an add-on may reuse it), enqueue the screen's assets on the screen.
	 *
	 * @param string $hook Current screen hook.
	 */
	public static function assets( $hook ) {
		wp_register_script( 'consentwell-check', CONSENTWELL_URL . 'assets/js/check.js', array( 'wp-i18n' ), CONSENTWELL_VERSION, true );
		wp_localize_script(
			'consentwell-check',
			'consentwellCheckData',
			array(
				'rest'     => esc_url_raw( rest_url( Consentwell_Rest::NS . '/' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'siteHost' => Consentwell_Url::site_host(),
				'cookies'  => array(
					'consent'   => Consentwell_Services::data()['consent_cookies'],
					'wordpress' => Consentwell_Services::data()['wordpress_cookies'],
				),
			)
		);
		wp_register_style( 'consentwell-admin', CONSENTWELL_URL . 'assets/css/admin.css', array(), CONSENTWELL_VERSION );
		if ( $hook !== self::$hook || '' === self::$hook ) {
			return;
		}
		wp_enqueue_style( 'consentwell-admin' );
		wp_enqueue_script( 'consentwell-admin', CONSENTWELL_URL . 'assets/js/admin.js', array( 'consentwell-check', 'wp-i18n' ), CONSENTWELL_VERSION, true );
		wp_set_script_translations( 'consentwell-admin', 'consentwell' );
		wp_set_script_translations( 'consentwell-check', 'consentwell' );
	}

	/**
	 * Pages the admin can pick.
	 *
	 * @return array [ label => [ url => title ] ]
	 */
	private static function choices() {
		$groups = array(
			__( 'Home page', 'consentwell' ) => array( home_url( '/' ) => __( 'Home page', 'consentwell' ) ),
		);
		$pages  = get_pages(
			array(
				'post_status' => 'publish',
				'number'      => 300,
				'sort_column' => 'menu_order,post_title',
			)
		);
		foreach ( $pages as $page ) {
			$groups[ __( 'Pages', 'consentwell' ) ][ get_permalink( $page ) ] = get_the_title( $page ) ? get_the_title( $page ) : get_permalink( $page );
		}
		$posts = get_posts(
			array(
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'post_type'      => 'post',
			)
		);
		foreach ( $posts as $post ) {
			$groups[ __( 'Recent posts', 'consentwell' ) ][ get_permalink( $post ) ] = get_the_title( $post ) ? get_the_title( $post ) : get_permalink( $post );
		}
		return $groups;
	}

	/**
	 * The screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'consentwell' ), 403 );
		}
		$plugin = Consentwell_Consent_Plugins::active();
		?>
		<div class="wrap consentwell">
			<h1><?php esc_html_e( 'Consentwell', 'consentwell' ); ?></h1>
			<p class="consentwell-intro"><?php esc_html_e( 'Check any page of your site as a logged-out visitor: does the consent banner show, and what still loads after Reject.', 'consentwell' ); ?></p>
			<p class="consentwell-disclaimer"><?php esc_html_e( 'Results are technical facts about what one page loaded in this browser at the time of the check. They are not legal advice, and no plugin can make a site compliant.', 'consentwell' ); ?></p>

			<div class="consentwell-plugin">
				<?php if ( $plugin ) : ?>
					<p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: consent plugin name, 2: version. */
							__( 'Consent plugin: %1$s %2$s. Consentwell clicks its Reject button for you.', 'consentwell' ),
							$plugin['name'],
							$plugin['version']
						)
					);
					?>
					</p>
				<?php else : ?>
					<p><?php esc_html_e( 'No recognised consent plugin is active (Consentwell recognises Complianz and CookieYes by name). Another banner is found if it is visible and has buttons labelled like a choice (Accept, Reject); you then click its Reject button in the check window yourself.', 'consentwell' ); ?></p>
				<?php endif; ?>
			</div>

			<form class="consentwell-form" id="consentwell-form">
				<p>
					<label for="consentwell-page"><strong><?php esc_html_e( 'Page to check', 'consentwell' ); ?></strong></label><br>
					<select id="consentwell-page" name="page">
						<?php foreach ( self::choices() as $group => $options ) : ?>
							<optgroup label="<?php echo esc_attr( $group ); ?>">
								<?php foreach ( $options as $url => $title ) : ?>
									<option value="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></option>
								<?php endforeach; ?>
							</optgroup>
						<?php endforeach; ?>
					</select>
				</p>
				<p>
					<label for="consentwell-url"><?php esc_html_e( 'Or any address on this site', 'consentwell' ); ?></label><br>
					<input type="url" id="consentwell-url" class="regular-text" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>">
				</p>
				<p class="consentwell-buttons">
					<button type="submit" class="button button-primary" id="consentwell-run"><?php esc_html_e( 'Check this page', 'consentwell' ); ?></button>
					<button type="button" class="button" id="consentwell-run-server"><?php esc_html_e( 'Server-side check only', 'consentwell' ); ?></button>
				</p>
			</form>

			<div id="consentwell-status" class="consentwell-status" aria-live="polite" hidden></div>
			<div id="consentwell-manual" class="notice notice-info inline consentwell-manual" hidden>
				<p><strong><?php esc_html_e( 'Your turn: click Reject in the check window below.', 'consentwell' ); ?></strong> <?php esc_html_e( 'This banner is not one Consentwell recognises by name, so it does not click for you. Consentwell continues as soon as you click a Reject button in the window.', 'consentwell' ); ?></p>
				<p><button type="button" class="button" id="consentwell-manual-done"><?php esc_html_e( 'I clicked Reject, continue', 'consentwell' ); ?></button></p>
			</div>
			<div id="consentwell-window-wrap" class="consentwell-window-wrap" hidden>
				<p class="consentwell-window-caption"><?php esc_html_e( 'Check window: this page as a logged-out visitor with no consent stored', 'consentwell' ); ?></p>
				<div id="consentwell-window" class="consentwell-window"></div>
			</div>

			<div id="consentwell-review" class="consentwell-review" <?php echo self::show_review() ? '' : 'hidden'; ?>>
				<p>
					<?php esc_html_e( 'Is Consentwell useful? A review on WordPress.org helps other site owners find it.', 'consentwell' ); ?>
					<a href="<?php echo esc_url( self::REVIEW_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Write a review', 'consentwell' ); ?></a>
					<button type="button" class="button-link" id="consentwell-review-dismiss"><?php esc_html_e( 'Dismiss', 'consentwell' ); ?></button>
				</p>
			</div>

			<div id="consentwell-result" class="consentwell-result-wrap"></div>

			<h2><?php esc_html_e( 'Last 20 checks', 'consentwell' ); ?></h2>
			<div id="consentwell-table"><?php echo self::table_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts in table_html(). ?></div>

			<?php
			if ( ! defined( 'CONSENTWELL_PRO_VERSION' ) ) {
				echo self::pro_line(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts in pro_line().
			}
			?>
		</div>
		<?php
	}

	/**
	 * The one mention of the Pro add-on on this screen (shown only while Pro is not active).
	 *
	 * @return string HTML.
	 */
	public static function pro_line() {
		return '<p class="consentwell-pro-line">'
			. esc_html__( 'Every single-page check here is free. To check the pages in your sitemap (up to 5,000 addresses) in one run, with a CSV and a comparison with the previous run, there is a separate add-on, Consentwell Pro ($19 once):', 'consentwell' )
			. ' <a href="' . esc_url( self::PRO_URL ) . '" target="_blank" rel="noopener noreferrer">ochrestack.com/consentwell</a></p>';
	}

	/**
	 * Whether the review line shows for the current admin (after the third completed check, until dismissed).
	 *
	 * @return bool
	 */
	public static function show_review() {
		return Consentwell_Store::completed() >= 3 && ! get_user_meta( get_current_user_id(), self::REVIEW_META, true );
	}

	/**
	 * Display text for a "banner shown" cell.
	 *
	 * @param array $check Result.
	 * @return string
	 */
	public static function banner_cell( $check ) {
		$banner = $check['banner'];
		if ( 'server' === $check['mode'] ) {
			/* translators: %s: yes / no. */
			return sprintf( __( 'not checked (in HTML: %s)', 'consentwell' ), Consentwell_Report::yes_no( $banner['in_html'] ) );
		}
		if ( ! $banner['found'] && ! $banner['in_html'] ) {
			return __( 'no banner found', 'consentwell' );
		}
		if ( $banner['by_design'] ) {
			return __( 'no (hidden by design)', 'consentwell' );
		}
		return Consentwell_Report::yes_no( $banner['shown'] );
	}

	/**
	 * A count, or a dash when not measured.
	 *
	 * @param int|null $value Count.
	 * @return string
	 */
	private static function count_cell( $value ) {
		return null === $value ? '—' : (string) (int) $value;
	}

	/**
	 * The last-20 table.
	 *
	 * @return string HTML.
	 */
	public static function table_html() {
		$checks = Consentwell_Store::all();
		if ( ! $checks ) {
			return '<p class="consentwell-empty">' . esc_html__( 'No checks yet. Pick a page above and click Check this page.', 'consentwell' ) . '</p>';
		}
		$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		$html   = '<table class="widefat striped consentwell-table"><thead><tr>'
			. '<th scope="col">' . esc_html__( 'Page', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Checked', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Banner shown', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Reject visible', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Third-party requests before a choice', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Third-party requests after Reject', 'consentwell' ) . '</th>'
			. '<th scope="col">' . esc_html__( 'Cookies after Reject', 'consentwell' ) . '</th>'
			. '<th scope="col"><span class="screen-reader-text">' . esc_html__( 'Actions', 'consentwell' ) . '</span></th>'
			. '</tr></thead><tbody>';
		foreach ( $checks as $check ) {
			$html .= '<tr data-check-id="' . esc_attr( $check['id'] ) . '">'
				. '<td class="consentwell-col-page"><a href="' . esc_url( $check['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $check['url'] ) . '</a>' . ( 'server' === $check['mode'] ? ' <span class="consentwell-tag">' . esc_html__( 'server-side', 'consentwell' ) . '</span>' : '' ) . '</td>'
				. '<td class="consentwell-col-date">' . esc_html( wp_date( $format, (int) $check['time'] ) ) . '</td>'
				. '<td class="consentwell-col-banner">' . esc_html( self::banner_cell( $check ) ) . '</td>'
				. '<td class="consentwell-col-reject">' . esc_html( 'server' === $check['mode'] ? '—' : Consentwell_Report::yes_no( $check['banner']['reject_visible'] ) ) . '</td>'
				. '<td class="consentwell-col-before">' . esc_html( self::count_cell( $check['counts']['before'] ) ) . '</td>'
				. '<td class="consentwell-col-after">' . esc_html( self::count_cell( $check['counts']['after'] ) ) . '</td>'
				. '<td class="consentwell-col-cookies">' . esc_html( self::count_cell( $check['counts']['cookies_after'] ) ) . '</td>'
				. '<td class="consentwell-col-actions">'
				. '<button type="button" class="button button-small consentwell-view" data-id="' . esc_attr( $check['id'] ) . '">' . esc_html__( 'View', 'consentwell' ) . '</button> '
				. '<button type="button" class="button button-small consentwell-again" data-url="' . esc_url( $check['url'] ) . '" data-mode="' . esc_attr( $check['mode'] ) . '">' . esc_html__( 'Check again', 'consentwell' ) . '</button>'
				. '</td></tr>';
		}
		return $html . '</tbody></table>';
	}

	/**
	 * Detail view of one result.
	 *
	 * @param array $check Result.
	 * @return string HTML.
	 */
	public static function result_html( $check ) {
		$banner = $check['banner'];
		$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		$html   = '<div class="consentwell-result" data-check-id="' . esc_attr( $check['id'] ) . '">';
		$html  .= '<h2>' . esc_html__( 'Result', 'consentwell' ) . ': <a href="' . esc_url( $check['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $check['url'] ) . '</a></h2>';
		$html  .= '<p class="consentwell-meta">' . esc_html(
			sprintf(
				/* translators: 1: date, 2: WordPress version, 3: consent plugin. */
				__( 'Checked %1$s · WordPress %2$s · Consent plugin: %3$s', 'consentwell' ),
				wp_date( $format, (int) $check['time'] ),
				$check['wp_version'],
				Consentwell_Report::plugin_label( $check )
			)
		) . '</p>';

		$rows = array();
		if ( 'browser' === $check['mode'] && ! $banner['found'] && ! $banner['in_html'] ) {
			$rows[] = array( __( 'Consent banner', 'consentwell' ), __( 'No consent banner found on this page.', 'consentwell' ), 'neutral' );
		} else {
			$rows[] = array( __( 'Banner in the page HTML', 'consentwell' ), Consentwell_Report::yes_no( $banner['in_html'] ), $banner['in_html'] ? 'yes' : 'no' );
			if ( 'browser' === $check['mode'] ) {
				$text = Consentwell_Report::yes_no( $banner['shown'] );
				if ( $banner['hidden_by'] ) {
					$text .= ' — ' . implode( '; ', $banner['hidden_by'] );
				}
				$rows[] = array( __( 'Banner visible on screen', 'consentwell' ), $text, $banner['shown'] ? 'yes' : ( $banner['by_design'] ? 'neutral' : 'no' ) );
				$reject = Consentwell_Report::yes_no( $banner['reject_visible'] );
				if ( $banner['reject_hidden'] ) {
					$reject .= ' — ' . implode( '; ', $banner['reject_hidden'] );
				} elseif ( $banner['found'] && ! $banner['reject_found'] ) {
					$reject .= ' — ' . __( 'no Reject button found on the first layer', 'consentwell' );
				}
				$rows[] = array( __( 'Reject button visible on the first layer', 'consentwell' ), $reject, $banner['reject_visible'] ? 'yes' : 'no' );
			}
		}
		$html .= '<table class="widefat consentwell-facts"><tbody>';
		foreach ( $rows as $row ) {
			$html .= '<tr class="consentwell-fact-' . esc_attr( $row[2] ) . '"><th scope="row">' . esc_html( $row[0] ) . '</th><td>' . esc_html( $row[1] ) . '</td></tr>';
		}
		$html .= '</tbody></table>';

		if ( $check['causes'] ) {
			$by_design = 'dnt_gpc_by_design' === $check['causes'][0]['code'];
			$html     .= '<div class="notice inline ' . ( $by_design ? 'notice-info' : 'notice-warning' ) . ' consentwell-causes"><p><strong>' . esc_html__( 'Likely cause', 'consentwell' ) . '</strong></p><ul>';
			foreach ( $check['causes'] as $cause ) {
				$html .= '<li data-code="' . esc_attr( $cause['code'] ) . '">' . esc_html( $cause['text'] );
				if ( $cause['items'] ) {
					$html .= '<ul>';
					foreach ( $cause['items'] as $item ) {
						$html .= '<li><code>' . esc_html( $item ) . '</code></li>';
					}
					$html .= '</ul>';
				}
				$html .= '</li>';
			}
			$html .= '</ul></div>';
		}
		foreach ( $check['notes'] as $note ) {
			$html .= '<p class="consentwell-note">' . esc_html( $note ) . '</p>';
		}

		$html .= self::list_html(
			'server' === $check['mode'] ? __( 'Third-party script and frame tags in the HTML', 'consentwell' ) : __( 'Before any choice', 'consentwell' ),
			$check['before'],
			'before',
			'browser' === $check['mode'],
			Consentwell_Report::watch_text( $check, 'before' )
		);
		if ( null !== $check['after'] ) {
			$html .= self::list_html( __( 'After Reject (page reloaded)', 'consentwell' ), $check['after'], 'after', true, Consentwell_Report::watch_text( $check, 'after' ) );
		}

		if ( ! empty( $check['server']['cookies'] ) ) {
			$html .= '<h3>' . esc_html__( 'Cookies the page response sets (server-side fetch, HttpOnly included)', 'consentwell' ) . '</h3><ul class="consentwell-server-cookies">';
			foreach ( $check['server']['cookies'] as $cookie ) {
				$html .= '<li><code>' . esc_html( $cookie['name'] ) . '</code> ' . esc_html__( 'set', 'consentwell' ) . ( $cookie['httponly'] ? ' <span class="consentwell-tag">HttpOnly</span>' : '' ) . '</li>';
			}
			$html .= '</ul>';
		}

		$html .= '<p class="consentwell-note">' . esc_html__( 'Cookies that another domain stores for itself cannot be read by any page; those services appear in the lists above as requests.', 'consentwell' ) . '</p>';
		$html .= '<h3>' . esc_html__( 'Copy as text', 'consentwell' ) . '</h3>';
		$html .= '<p>' . esc_html__( 'A plain-text summary to paste into your consent plugin’s support forum. It contains the page address, the plugin versions and the findings, nothing about you or your visitors.', 'consentwell' ) . '</p>';
		$html .= '<p><button type="button" class="button consentwell-copy">' . esc_html__( 'Copy as text', 'consentwell' ) . '</button> <span class="consentwell-copied" aria-live="polite"></span></p>';
		$html .= '<textarea class="large-text code consentwell-text" rows="8" readonly>' . esc_textarea( Consentwell_Report::as_text( $check ) ) . '</textarea>';
		$html .= '</div>';
		return $html;
	}

	/**
	 * One request list.
	 *
	 * @param string $title        Title.
	 * @param array  $data         { requests, cookies }.
	 * @param string $key          'before' or 'after'.
	 * @param bool   $with_cookies Whether cookies were read for this list.
	 * @param string $watch        What the list covers, or ''.
	 * @return string HTML.
	 */
	private static function list_html( $title, $data, $key, $with_cookies, $watch = '' ) {
		$count = count( $data['requests'] );
		$html  = '<div class="consentwell-list consentwell-list-' . esc_attr( $key ) . '">';
		$html .= '<h3>' . esc_html( $title ) . ': ' . esc_html(
			sprintf(
				/* translators: %d: number of requests. */
				_n( '%d third-party request', '%d third-party requests', $count, 'consentwell' ),
				$count
			)
		) . '</h3>';
		if ( '' !== $watch ) {
			$html .= '<p class="consentwell-note consentwell-watch">' . esc_html( $watch ) . '</p>';
		}
		if ( $count ) {
			$html .= '<table class="widefat striped consentwell-requests"><thead><tr><th scope="col">' . esc_html__( 'Type', 'consentwell' ) . '</th><th scope="col">' . esc_html__( 'Address', 'consentwell' ) . '</th><th scope="col">' . esc_html__( 'Service', 'consentwell' ) . '</th></tr></thead><tbody>';
			foreach ( $data['requests'] as $request ) {
				$html .= '<tr><td>' . esc_html__( 'loaded', 'consentwell' ) . ' ' . esc_html( Consentwell_Report::type_label( $request['type'] ) ) . '</td><td class="consentwell-address"><code>' . esc_html( $request['url'] ) . '</code></td><td>' . esc_html( $request['service'] ) . '</td></tr>';
			}
			$html .= '</tbody></table>';
		}
		if ( $with_cookies ) {
			$html .= '<p class="consentwell-cookies"><strong>' . esc_html__( 'Cookies set (readable by the page):', 'consentwell' ) . '</strong> ';
			$html .= $data['cookies'] ? '<code>' . implode( '</code>, <code>', array_map( 'esc_html', $data['cookies'] ) ) . '</code>' : esc_html__( 'none', 'consentwell' );
			$html .= '</p>';
		}
		return $html . '</div>';
	}
}
