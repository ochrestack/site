<?php
/**
 * Server-side check: fetch a page of this site as a logged-out visitor and read the HTML and headers.
 *
 * Every request made here goes to the site's own address (see Consentwell_Server_Check::get_own()).
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Server-side check.
 */
class Consentwell_Server_Check {

	/**
	 * Response headers that show a page cache answered.
	 *
	 * @var string[]
	 */
	const CACHE_HEADERS = array( 'age', 'x-cache', 'x-cache-status', 'cf-cache-status', 'x-litespeed-cache', 'x-proxy-cache', 'x-varnish', 'x-sg-cache', 'x-kinsta-cache', 'x-wpe-cached', 'x-nginx-cache', 'x-fastcgi-cache', 'x-wp-cache', 'x-rocket-nginx-serving-static' );

	/**
	 * GET an address on this site. Refuses any other host.
	 *
	 * @param string $url  Address on this site.
	 * @param array  $args Extra wp_remote_get() arguments.
	 * @return array|WP_Error
	 */
	public static function get_own( $url, $args = array() ) {
		if ( ! Consentwell_Url::is_own( $url ) ) {
			return new WP_Error( 'consentwell_not_own', __( 'Consentwell only requests this site’s own pages.', 'consentwell' ) );
		}
		$defaults = array(
			'timeout'     => 20,
			'redirection' => 0,
			'cookies'     => array(),
			'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter used for loopback requests.
			'user-agent'  => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36 Consentwell/' . CONSENTWELL_VERSION,
			'headers'     => array( 'Accept' => 'text/html,application/xhtml+xml' ),
		);
		$args     = array_merge( $defaults, $args );
		// Redirects are followed by hand, and only while they stay on this site.
		for ( $hop = 0; $hop <= 3; $hop++ ) {
			$response = wp_remote_get( $url, $args );
			$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$location = $code >= 300 && $code < 400 ? (string) wp_remote_retrieve_header( $response, 'location' ) : '';
			if ( '' === $location ) {
				return $response;
			}
			$url = Consentwell_Url::absolute( $location, $url );
			if ( ! Consentwell_Url::is_own( $url ) ) {
				return new WP_Error( 'consentwell_redirect_away', __( 'The page redirects to another site, so Consentwell did not follow it.', 'consentwell' ) );
			}
		}
		return new WP_Error( 'consentwell_too_many_redirects', __( 'The page redirects too many times.', 'consentwell' ) );
	}

	/**
	 * HEAD an address on this site. Refuses any other host.
	 *
	 * @param string $url Address on this site.
	 * @return int HTTP status, 0 when the request failed or was refused.
	 */
	public static function status_of_own( $url ) {
		if ( ! Consentwell_Url::is_own( $url ) ) {
			return 0;
		}
		$response = wp_remote_head(
			$url,
			array(
				'timeout'     => 10,
				'redirection' => 0,
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter used for loopback requests.
			)
		);
		return is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
	}

	/**
	 * Run the server-side check of one page.
	 *
	 * @param string     $url     Page address on this site.
	 * @param array|null $plugin  Active consent plugin (Consentwell_Consent_Plugins::active()).
	 * @param int        $user_id Admin who runs the check.
	 * @return array
	 */
	public static function run( $url, $plugin, $user_id ) {
		$result = array(
			'fetched'                => false,
			'error'                  => '',
			'status'                 => 0,
			'scripts'                => array(),
			'frames'                 => array(),
			'cookies'                => array(),
			'banner_in_html'         => null,
			'banner_candidate'       => null,
			'config_in_html'         => null,
			'consent_assets'         => array(),
			'consent_script_in_html' => null,
			'asset_errors'           => array(),
			'frame_blocked'          => false,
			'frame_header'           => '',
			'head_marker'            => null,
			'footer_marker'          => null,
			'cache'                  => array(
				'headers'     => array(),
				'differs'     => false,
				'differences' => array(),
			),
		);

		$visitor = self::get_own( $url );
		if ( is_wp_error( $visitor ) ) {
			$result['error'] = $visitor->get_error_message();
			return $result;
		}
		$html                       = (string) wp_remote_retrieve_body( $visitor );
		$result['fetched']          = true;
		$result['status']           = (int) wp_remote_retrieve_response_code( $visitor );
		$tags                       = self::read_tags( $html, $url );
		$result['scripts']          = $tags['scripts'];
		$result['frames']           = $tags['frames'];
		$result['cookies']          = self::read_set_cookies( $visitor );
		$frame                      = self::frame_policy( $visitor );
		$result['frame_blocked']    = $frame['blocked'];
		$result['frame_header']     = $frame['header'];
		$result['cache']['headers'] = self::cache_headers( $visitor );

		$visitor_sig                      = self::signature( $html, $tags, $plugin );
		$result['banner_in_html']         = $visitor_sig['banner'];
		$result['config_in_html']         = $visitor_sig['config'];
		$result['consent_assets']         = $visitor_sig['assets'];
		$result['consent_script_in_html'] = $visitor_sig['script'];

		foreach ( array_slice( $visitor_sig['assets'], 0, 10 ) as $asset ) {
			if ( Consentwell_Url::is_own( $asset ) ) {
				$status = self::status_of_own( $asset );
				if ( $status >= 400 ) {
					$result['asset_errors'][] = array(
						'url'    => $asset,
						'status' => $status,
					);
				}
			}
		}

		// A fresh copy, rendered for this check only, bypassing page caches.
		$token = Consentwell_Token::issue( $user_id, Consentwell_Token::KIND_SERVER );
		$fresh = self::get_own(
			Consentwell_Token::url_with_token( $url, $token ),
			array(
				'headers' => array(
					'Accept'        => 'text/html,application/xhtml+xml',
					'Cache-Control' => 'no-cache',
					'Pragma'        => 'no-cache',
				),
			)
		);
		Consentwell_Token::spend( $token );
		$fresh_html = '';
		if ( ! is_wp_error( $fresh ) && 200 === (int) wp_remote_retrieve_response_code( $fresh ) ) {
			$fresh_html = (string) wp_remote_retrieve_body( $fresh );
			if ( false !== strpos( $fresh_html, 'consentwell-probe' ) ) {
				$result['head_marker']   = true;
				$result['footer_marker'] = false !== strpos( $fresh_html, 'consentwell-footer-marker' );
			}
			$fresh_sig   = self::signature( $fresh_html, self::read_tags( $fresh_html, $url ), $plugin );
			$differences = self::compare( $visitor_sig, $fresh_sig );
			if ( $differences ) {
				$result['cache']['differs']     = true;
				$result['cache']['differences'] = $differences;
			}
		}
		if ( ! $plugin ) {
			// No recognised consent plugin: is there a banner in the HTML at all (the browser may not show it)?
			$candidate = '' !== $fresh_html ? self::find_banner_markup( $fresh_html ) : null;
			if ( null === $candidate ) {
				$candidate = self::find_banner_markup( $html );
			}
			$result['banner_candidate'] = $candidate;
			$result['banner_in_html']   = null !== $candidate;
		}
		return $result;
	}

	/**
	 * A consent banner in the page's HTML that no recognised consent plugin put there: the outermost
	 * element whose id, class or label mentions cookies, consent or GDPR, whose text mentions cookies,
	 * consent or privacy, and that has a button or link labelled like a choice (Accept, Reject, Allow …).
	 * The same test the check window applies, without the visibility test, because a banner can be in the
	 * HTML and still not show in the check window (Cookie Notice & Compliance does not show in a frame).
	 *
	 * @param string $html Page HTML.
	 * @return array|null { element: string, name: string } or null when the HTML holds none.
	 */
	public static function find_banner_markup( $html ) {
		if ( '' === trim( $html ) ) {
			return null;
		}
		$doc      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		$xpath = new DOMXPath( $doc );
		// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property names (tagName, textContent).
		$skip = array( 'script', 'style', 'link', 'meta', 'noscript', 'head', 'html', 'body', 'title', 'form' );
		foreach ( $xpath->query( '//body//*[@id or @class or @aria-label]' ) as $node ) {
			if ( ! ( $node instanceof DOMElement ) || in_array( strtolower( $node->tagName ), $skip, true ) ) {
				continue;
			}
			$named = $node->getAttribute( 'id' ) . ' ' . $node->getAttribute( 'class' ) . ' ' . $node->getAttribute( 'aria-label' );
			if ( ! preg_match( '/cookie|consent|gdpr/i', $named ) ) {
				continue;
			}
			$text = trim( preg_replace( '/\s+/u', ' ', (string) $node->textContent ) );
			if ( strlen( $text ) < 20 || strlen( $text ) > 3000 || ! preg_match( '/cookie|consent|privacy|tracking|datenschutz|gdpr|rgpd|einwilligung/i', $text ) ) {
				continue;
			}
			$choice = false;
			foreach ( $xpath->query( './/button | .//a | .//*[@role="button"] | .//input[@type="button" or @type="submit"]', $node ) as $button ) {
				$label = trim( $button->textContent . ' ' . $button->getAttribute( 'value' ) . ' ' . $button->getAttribute( 'aria-label' ) );
				if ( preg_match( '/accept|agree|allow|\bok\b|got it|reject|decline|deny|refuse|necessary|akzept|zustimm|ablehnen|alle|accepter|aceptar|accetta/i', $label ) ) {
					$choice = true;
					break;
				}
			}
			if ( ! $choice ) {
				continue;
			}
			$element = strtolower( $node->tagName );
			if ( '' !== $node->getAttribute( 'id' ) ) {
				$element .= '#' . $node->getAttribute( 'id' );
			}
			$classes = array_slice( preg_split( '/\s+/', trim( $node->getAttribute( 'class' ) ), -1, PREG_SPLIT_NO_EMPTY ), 0, 3 );
			if ( $classes ) {
				$element .= '.' . implode( '.', $classes );
			}
			// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			return array(
				'element' => substr( $element, 0, 120 ),
				'name'    => Consentwell_Consent_Plugins::frame_shy_by_element_id( $node->getAttribute( 'id' ) ),
			);
		}
		// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		return null;
	}

	/**
	 * Third-party script and frame tags a browser would load from this HTML, plus every script and stylesheet address.
	 *
	 * @param string $html Page HTML.
	 * @param string $base Page address.
	 * @return array { scripts: [ {url, service} ], frames: [ {url, service, tag} ], all: [ urls ] }
	 */
	public static function read_tags( $html, $base ) {
		$out = array(
			'scripts' => array(),
			'frames'  => array(),
			'all'     => array(),
		);
		if ( '' === trim( $html ) ) {
			return $out;
		}
		$doc      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		$seen = array();
		foreach ( $doc->getElementsByTagName( 'script' ) as $node ) {
			$src = $node->getAttribute( 'src' );
			if ( '' === $src || ! self::is_executable_script( $node->getAttribute( 'type' ) ) ) {
				continue;
			}
			$abs = Consentwell_Url::absolute( $src, $base );
			if ( '' === $abs ) {
				continue;
			}
			$out['all'][] = $abs;
			if ( Consentwell_Url::is_third_party( $abs ) && empty( $seen[ 's' . $abs ] ) ) {
				$seen[ 's' . $abs ] = true;
				$out['scripts'][]   = array(
					'url'     => $abs,
					'service' => Consentwell_Services::name_for( $abs ),
				);
			}
		}
		foreach ( $doc->getElementsByTagName( 'link' ) as $node ) {
			$rel = strtolower( $node->getAttribute( 'rel' ) );
			if ( false !== strpos( $rel, 'stylesheet' ) ) {
				$abs = Consentwell_Url::absolute( $node->getAttribute( 'href' ), $base );
				if ( '' !== $abs ) {
					$out['all'][] = $abs;
				}
			}
		}
		$frame_tags = array(
			'iframe' => 'src',
			'embed'  => 'src',
			'object' => 'data',
		);
		foreach ( $frame_tags as $tag => $attr ) {
			foreach ( $doc->getElementsByTagName( $tag ) as $node ) {
				$abs = Consentwell_Url::absolute( $node->getAttribute( $attr ), $base );
				if ( '' === $abs || ! Consentwell_Url::is_third_party( $abs ) || ! empty( $seen[ 'f' . $abs ] ) ) {
					continue;
				}
				$seen[ 'f' . $abs ] = true;
				$out['frames'][]    = array(
					'url'     => $abs,
					'service' => Consentwell_Services::name_for( $abs ),
					'tag'     => $tag,
				);
			}
		}
		return $out;
	}

	/**
	 * Whether a script type attribute means the browser runs (and so downloads) the script.
	 * Consent plugins hold scripts back by changing the type, for example to text/plain.
	 *
	 * @param string $type Value of the type attribute.
	 * @return bool
	 */
	private static function is_executable_script( $type ) {
		$type = strtolower( trim( (string) $type ) );
		if ( '' === $type || 'module' === $type ) {
			return true;
		}
		$type = trim( explode( ';', $type )[0] );
		return in_array( $type, array( 'text/javascript', 'application/javascript', 'application/ecmascript', 'text/ecmascript', 'application/x-javascript', 'text/jscript' ), true );
	}

	/**
	 * Every Set-Cookie header of a response, HttpOnly cookies included.
	 *
	 * @param array $response wp_remote_get() response.
	 * @return array [ { name, httponly, secure, samesite, domain, path } ]
	 */
	public static function read_set_cookies( $response ) {
		$raw = wp_remote_retrieve_header( $response, 'set-cookie' );
		if ( '' === $raw || array() === $raw ) {
			return array();
		}
		$lines   = is_array( $raw ) ? $raw : array( $raw );
		$cookies = array();
		foreach ( $lines as $line ) {
			$parts = array_map( 'trim', explode( ';', (string) $line ) );
			$pair  = array_shift( $parts );
			if ( false === strpos( $pair, '=' ) ) {
				continue;
			}
			$name = trim( substr( $pair, 0, strpos( $pair, '=' ) ) );
			if ( '' === $name ) {
				continue;
			}
			$cookie = array(
				'name'     => $name,
				'httponly' => false,
				'secure'   => false,
				'samesite' => '',
				'domain'   => '',
				'path'     => '',
			);
			foreach ( $parts as $attr ) {
				$key   = strtolower( trim( strtok( $attr, '=' ) ) );
				$value = false !== strpos( $attr, '=' ) ? trim( substr( $attr, strpos( $attr, '=' ) + 1 ) ) : '';
				if ( 'httponly' === $key ) {
					$cookie['httponly'] = true;
				} elseif ( 'secure' === $key ) {
					$cookie['secure'] = true;
				} elseif ( in_array( $key, array( 'samesite', 'domain', 'path' ), true ) ) {
					$cookie[ $key ] = $value;
				}
			}
			$cookies[] = $cookie;
		}
		return $cookies;
	}

	/**
	 * Whether the response forbids showing the page in a frame on the site's own admin screen.
	 *
	 * @param array $response wp_remote_get() response.
	 * @return array { blocked: bool, header: string }
	 */
	public static function frame_policy( $response ) {
		$xfo = wp_remote_retrieve_header( $response, 'x-frame-options' );
		$xfo = is_array( $xfo ) ? implode( ', ', $xfo ) : (string) $xfo;
		if ( '' !== $xfo && false !== stripos( $xfo, 'deny' ) ) {
			return array(
				'blocked' => true,
				'header'  => 'X-Frame-Options: ' . $xfo,
			);
		}
		$csp = wp_remote_retrieve_header( $response, 'content-security-policy' );
		$csp = is_array( $csp ) ? implode( '; ', $csp ) : (string) $csp;
		if ( preg_match( "/frame-ancestors\s+'none'/i", $csp ) ) {
			return array(
				'blocked' => true,
				'header'  => "Content-Security-Policy: frame-ancestors 'none'",
			);
		}
		return array(
			'blocked' => false,
			'header'  => '' !== $xfo ? 'X-Frame-Options: ' . $xfo : '',
		);
	}

	/**
	 * Cache-related response headers.
	 *
	 * @param array $response wp_remote_get() response.
	 * @return array name => value
	 */
	private static function cache_headers( $response ) {
		$found = array();
		foreach ( self::CACHE_HEADERS as $name ) {
			$value = wp_remote_retrieve_header( $response, $name );
			if ( '' !== $value && array() !== $value ) {
				$found[ $name ] = sanitize_text_field( is_array( $value ) ? implode( ', ', $value ) : (string) $value );
			}
		}
		return $found;
	}

	/**
	 * What matters about the consent banner in a copy of the page.
	 *
	 * @param string     $html   HTML.
	 * @param array      $tags   read_tags() result for the HTML.
	 * @param array|null $plugin Active consent plugin.
	 * @return array { banner, config, script, assets }
	 */
	private static function signature( $html, $tags, $plugin ) {
		$sig = array(
			'banner' => null,
			'config' => null,
			'script' => null,
			'assets' => array(),
		);
		if ( ! $plugin ) {
			return $sig;
		}
		$def           = Consentwell_Consent_Plugins::definition( $plugin['slug'] );
		$sig['banner'] = (bool) preg_match( $def['html_marker'], $html );
		$sig['config'] = false !== strpos( $html, $def['config_mark'] );
		$sig['script'] = false;
		foreach ( array_unique( $tags['all'] ) as $asset ) {
			if ( Consentwell_Consent_Plugins::is_plugin_asset( $asset, $plugin['slug'] ) ) {
				$sig['assets'][] = $asset;
				if ( false !== strpos( $asset, $def['script_path'] ) ) {
					$sig['script'] = true;
				}
			}
		}
		sort( $sig['assets'] );
		return $sig;
	}

	/**
	 * Differences between the copy a visitor gets and a fresh render.
	 *
	 * @param array $visitor Signature of the visitor copy.
	 * @param array $fresh   Signature of the fresh copy.
	 * @return array [ { code, detail } ]
	 */
	private static function compare( $visitor, $fresh ) {
		$diff = array();
		if ( null === $visitor['banner'] || null === $fresh['banner'] ) {
			return $diff;
		}
		if ( $fresh['banner'] && ! $visitor['banner'] ) {
			$diff[] = array(
				'code'   => 'banner_missing',
				'detail' => '',
			);
		}
		if ( $fresh['config'] && ! $visitor['config'] ) {
			$diff[] = array(
				'code'   => 'config_missing',
				'detail' => '',
			);
		}
		$only_visitor = array_values( array_diff( $visitor['assets'], $fresh['assets'] ) );
		$only_fresh   = array_values( array_diff( $fresh['assets'], $visitor['assets'] ) );
		foreach ( $only_visitor as $asset ) {
			$diff[] = array(
				'code'   => 'asset_only_cached',
				'detail' => $asset,
			);
		}
		foreach ( $only_fresh as $asset ) {
			$diff[] = array(
				'code'   => 'asset_only_fresh',
				'detail' => $asset,
			);
		}
		return $diff;
	}
}
