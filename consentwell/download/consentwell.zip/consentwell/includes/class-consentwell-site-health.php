<?php
/**
 * Site Health test "Consent banner check (Consentwell)": the last stored check of the home page.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Site Health.
 */
class Consentwell_Site_Health {

	const TEST = 'consentwell_banner';

	/**
	 * Hook in.
	 */
	public static function init() {
		add_filter( 'site_status_tests', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register the direct test.
	 *
	 * @param array $tests Tests.
	 * @return array
	 */
	public static function register( $tests ) {
		$tests['direct'][ self::TEST ] = array(
			'label' => __( 'Consent banner check (Consentwell)', 'consentwell' ),
			'test'  => array( __CLASS__, 'run' ),
		);
		return $tests;
	}

	/**
	 * The test result.
	 *
	 * @return array
	 */
	public static function run() {
		$check  = Consentwell_Store::latest_for( home_url( '/' ) );
		$result = array(
			'label'       => '',
			'status'      => 'recommended',
			'badge'       => array(
				'label' => __( 'Privacy', 'consentwell' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => self::TEST,
		);

		if ( ! $check ) {
			// Nothing was found, so nothing is recommended: the item is "good" until a check says otherwise.
			$result['status']      = 'good';
			$result['label']       = __( 'No Consentwell check of the home page is stored yet', 'consentwell' );
			$result['description'] = '<p>' . esc_html__( 'Consentwell opens a page as a logged-out visitor and reports whether the consent banner shows and what still loads after Reject. No check of the home page is stored yet.', 'consentwell' ) . '</p>';
			$result['actions']     = self::action( __( 'Check the home page', 'consentwell' ) );
			return $result;
		}

		$when   = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $check['time'] );
		$banner = $check['banner'];
		$after  = $check['counts']['after'];
		$facts  = '<p>' . esc_html(
			sprintf(
				/* translators: 1: date, 2: consent plugin. */
				__( 'Last check of the home page: %1$s. Consent plugin: %2$s.', 'consentwell' ),
				$when,
				Consentwell_Report::plugin_label( $check )
			)
		) . '</p>';

		if ( 'server' === $check['mode'] ) {
			if ( $check['plugin'] && ! $banner['in_html'] ) {
				$result['status'] = 'critical';
				$result['label']  = __( 'The consent banner is not in the home page HTML', 'consentwell' );
			} elseif ( $check['counts']['before'] > 0 ) {
				$result['label'] = sprintf(
					/* translators: %d: number of tags. */
					_n( 'The home page HTML has %d third-party script or frame tag', 'The home page HTML has %d third-party script or frame tags', $check['counts']['before'], 'consentwell' ),
					$check['counts']['before']
				);
			} else {
				$result['status'] = 'good';
				$result['label']  = __( 'The home page HTML has no third-party script or frame tags', 'consentwell' );
			}
			$facts .= '<p>' . esc_html__( 'This was a server-side check (no browser). A check in the browser also shows whether the banner is visible and what loads after Reject.', 'consentwell' ) . '</p>';
		} elseif ( $banner['by_design'] ) {
			$result['status'] = 'good';
			$result['label']  = __( 'The consent banner was hidden by design in the last check of the home page', 'consentwell' );
			$facts           .= '<p>' . esc_html( $check['causes'][0]['text'] ) . '</p>';
		} elseif ( ! $banner['found'] && ! $banner['in_html'] ) {
			$result['status'] = $check['plugin'] ? 'critical' : 'recommended';
			$result['label']  = __( 'No consent banner was found on the home page in the last check', 'consentwell' );
		} elseif ( ! empty( $banner['not_in_window'] ) ) {
			$result['status'] = 'recommended';
			$result['label']  = __( 'A consent banner is in the home page HTML but did not show in the check window', 'consentwell' );
		} elseif ( ! $banner['shown'] ) {
			$result['status'] = 'critical';
			$result['label']  = __( 'The consent banner did not show on the home page in the last check', 'consentwell' );
		} elseif ( ! $banner['reject_visible'] ) {
			$result['label'] = __( 'The consent banner showed on the home page without a visible Reject button', 'consentwell' );
		} elseif ( $after ) {
			$result['label'] = sprintf(
				/* translators: %d: number of addresses. */
				_n( '%d third-party address requested on the home page after Reject', '%d third-party addresses requested on the home page after Reject', $after, 'consentwell' ),
				$after
			);
		} else {
			$result['status'] = 'good';
			$seconds          = isset( $check['watch']['after'] ) ? (int) $check['watch']['after'] : 0;
			$result['label']  = $seconds
				? sprintf(
					/* translators: %d: number of seconds. */
					__( 'The consent banner showed on the home page, and no request to another domain was seen after Reject in the %d seconds Consentwell watched', 'consentwell' ),
					$seconds
				)
				: __( 'The consent banner showed on the home page, and no request to another domain was seen after Reject', 'consentwell' );
			$facts .= '<p>' . esc_html( Consentwell_Report::watch_text( $check, 'after' ) ) . '</p>';
		}

		if ( $check['causes'] && ! $banner['by_design'] ) {
			$facts .= '<p>' . esc_html( $check['causes'][0]['text'] ) . '</p>';
		}
		$facts .= '<p>' . esc_html__( 'This reports technical facts from one check, not legal advice.', 'consentwell' ) . '</p>';

		$result['description'] = $facts;
		$result['actions']     = self::action( __( 'Open Consentwell', 'consentwell' ) );
		return $result;
	}

	/**
	 * Link to the screen.
	 *
	 * @param string $label Link text.
	 * @return string
	 */
	private static function action( $label ) {
		return '<p><a href="' . esc_url( Consentwell_Admin::screen_url() ) . '">' . esc_html( $label ) . '</a></p>';
	}
}
