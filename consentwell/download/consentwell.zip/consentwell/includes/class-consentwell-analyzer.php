<?php
/**
 * Turns the facts collected in the check window and by the server-side check into one stored result.
 *
 * Everything that arrives from the browser is treated as untrusted input and is sanitised here.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Result builder.
 */
class Consentwell_Analyzer {

	const MAX_ITEMS = 500;

	const MAX_SCROLL_STEPS = 40;

	const REQUEST_TYPES = array( 'script', 'frame', 'image', 'stylesheet', 'font', 'media', 'fetch', 'other' );

	/**
	 * Build a result from a browser check.
	 *
	 * @param string     $url     Page address.
	 * @param array|null $plugin  Active consent plugin.
	 * @param array      $server  Consentwell_Server_Check::run() result.
	 * @param array      $browser Facts from the check window (untrusted).
	 * @return array
	 */
	public static function from_browser( $url, $plugin, $server, $browser ) {
		$browser = is_array( $browser ) ? $browser : array();
		$env     = self::arr( $browser, 'env' );
		$probe   = self::arr( $browser, 'probe' );
		$banner  = self::arr( $browser, 'banner' );
		$reject  = self::arr( $browser, 'reject' );
		$cfg     = self::arr( self::arr( $browser, 'plugin_js' ), $plugin ? $plugin['slug'] : '' );
		$before  = self::lists( self::arr( $browser, 'before' ) );
		$after   = isset( $browser['after'] ) && is_array( $browser['after'] ) ? self::lists( $browser['after'] ) : null;

		$found          = ! empty( $banner['found'] );
		$visible        = $found && ! empty( $banner['visible'] );
		$reject_info    = self::arr( $banner, 'reject' );
		$reject_found   = $found && ! empty( $reject_info['found'] );
		$reject_visible = $visible && $reject_found && ! empty( $reject_info['visible'] );
		$dnt            = ! empty( $env['dnt'] );
		$gpc            = ! empty( $env['gpc'] );
		$respects       = false;
		if ( $plugin && 'complianz' === $plugin['slug'] ) {
			$respects = isset( $cfg['do_not_track_enabled'] ) ? (bool) $cfg['do_not_track_enabled'] : ! empty( $plugin['settings']['respect_dnt'] );
		}
		$by_design = ! $visible && ( $dnt || $gpc ) && $respects;

		$result = self::base( $url, $plugin, 'browser' );

		$cache_hides          = false;
		$cache_banner_missing = false;
		if ( ! empty( $server['cache']['differs'] ) ) {
			foreach ( $server['cache']['differences'] as $difference ) {
				if ( in_array( $difference['code'], array( 'banner_missing', 'config_missing' ), true ) ) {
					$cache_hides = true;
				}
				if ( 'banner_missing' === $difference['code'] ) {
					$cache_banner_missing = true;
				}
			}
		}

		// A banner in the HTML that no recognised plugin put there and that the check window did not show:
		// visitors may still see it (some banners do not show inside a frame), so it is not "did not show".
		$candidate     = ( ! $plugin && ! $found && ! empty( $server['banner_candidate'] ) && is_array( $server['banner_candidate'] ) ) ? $server['banner_candidate'] : null;
		$not_in_window = null !== $candidate;
		// CookieYes builds its banner from a template in the HTML; the template counts as "in the HTML".
		$in_html   = $found || ( $plugin && ! empty( $server['banner_in_html'] ) ) || $not_in_window;
		$hidden_by = array();
		if ( $found && ! $visible ) {
			$hidden_by = self::hidden_texts( self::arr( $banner, 'hidden_by' ) );
		} elseif ( ! $found && $in_html && ! $not_in_window ) {
			$hidden_by[] = __( 'the banner is in the page HTML, but the consent plugin’s script never put it on screen', 'consentwell' );
		}
		if ( $visible && $cache_hides ) {
			$hidden_by[] = __( 'the copy of this page that visitors get from the cache does not show it (see the likely cause)', 'consentwell' );
		}

		$shown = $not_in_window ? null : ( $visible && ! $cache_hides );
		if ( ! $shown ) {
			// Visitors who do not see the banner do not see its Reject button either.
			$reject_visible = false;
		}
		$result['banner'] = array(
			'found'                => $found,
			'source'               => self::text( isset( $banner['source'] ) ? $banner['source'] : '', 20 ),
			'element'              => self::text( isset( $banner['element'] ) ? $banner['element'] : '', 120 ),
			'in_html'              => $in_html,
			'cache_banner_missing' => $cache_banner_missing,
			'visible'              => $visible,
			'shown'                => $shown,
			'not_in_window'        => $not_in_window,
			'candidate'            => $not_in_window ? self::text( isset( $candidate['element'] ) ? $candidate['element'] : '', 120 ) : '',
			'named'                => $not_in_window ? self::text( isset( $candidate['name'] ) ? $candidate['name'] : '', 60 ) : '',
			'by_design'            => $by_design,
			'hidden_by'            => $hidden_by,
			'reject_found'         => $reject_found,
			'reject_visible'       => ( $in_html && ! $not_in_window ) ? $reject_visible : null,
			'reject_hidden'        => ( $reject_found && ! $reject_visible && $visible ) ? self::hidden_texts( self::arr( $reject_info, 'hidden_by' ) ) : array(),
			'shown_after'          => ( $visible && isset( $banner['shown_after'] ) && is_numeric( $banner['shown_after'] ) ) ? round( max( 0, min( 600, (float) $banner['shown_after'] ) ), 1 ) : null,
			'seen_then_hidden'     => $found && ! $visible && ! empty( $banner['visible_at_settle'] ),
		);

		$result['before'] = $before;
		$result['after']  = $after;
		$result['watch']  = self::watch_part( self::arr( $browser, 'watch' ) );

		$result['cookie_mode'] = ( isset( $browser['cookie_mode'] ) && 'consent-only' === $browser['cookie_mode'] ) ? 'consent-only' : 'all';

		$mode             = isset( $reject['mode'] ) && in_array( $reject['mode'], array( 'auto', 'manual', 'none' ), true ) ? $reject['mode'] : 'none';
		$clicked          = ! empty( $reject['clicked'] );
		$result['reject'] = array(
			'mode'    => $mode,
			'clicked' => $clicked,
		);
		if ( ! empty( $reject['early_click'] ) ) {
			$result['reject']['early_click'] = true;
		}
		$label = 'auto' === $mode ? self::text( isset( $reject['label'] ) ? $reject['label'] : '', 60 ) : '';
		if ( '' !== $label ) {
			$result['reject']['label'] = $label;
		}

		$result['server'] = self::server_part( $server );
		$result['causes'] = self::causes( $plugin, $server, $probe, $browser, $result, $cfg, $dnt, $gpc, $by_design );
		$result['notes']  = self::notes( $result, $probe, $dnt, $gpc );
		$result['counts'] = self::counts( $result );
		return $result;
	}

	/**
	 * Build a result from the server-side check only (no browser, or the page refuses to be framed).
	 *
	 * @param string     $url    Page address.
	 * @param array|null $plugin Active consent plugin.
	 * @param array      $server Consentwell_Server_Check::run() result.
	 * @param string     $why    'server' (asked for) or 'frame_blocked'.
	 * @return array
	 */
	public static function from_server( $url, $plugin, $server, $why = 'server' ) {
		$result = self::base( $url, $plugin, 'server' );
		$in     = ! empty( $server['banner_in_html'] );

		$result['banner'] = array(
			'found'            => $plugin ? $in : false,
			'source'           => $plugin ? $plugin['slug'] : '',
			'element'          => '',
			'in_html'          => ( $plugin || ! empty( $server['fetched'] ) ) ? $in : null,
			'visible'          => null,
			'shown'            => null,
			'not_in_window'    => false,
			'candidate'        => '',
			'named'            => '',
			'by_design'        => false,
			'hidden_by'        => array(),
			'reject_found'     => false,
			'reject_visible'   => null,
			'reject_hidden'    => array(),
			'shown_after'      => null,
			'seen_then_hidden' => false,
		);
		$result['watch']  = null;
		$requests         = array();
		foreach ( array_merge( $server['scripts'], $server['frames'] ) as $item ) {
			$requests[] = array(
				'url'     => $item['url'],
				'type'    => isset( $item['tag'] ) ? 'frame' : 'script',
				'service' => $item['service'],
			);
		}
		$result['before'] = array(
			'requests' => $requests,
			'cookies'  => array(),
		);
		$result['after']  = null;
		$result['reject'] = array(
			'mode'    => 'none',
			'clicked' => false,
		);
		$result['server'] = self::server_part( $server );
		$result['causes'] = self::causes( $plugin, $server, array(), array(), $result, array(), false, false, false );
		$notes            = array();
		if ( 'frame_blocked' === $why ) {
			$notes[] = sprintf(
				/* translators: %s: the response header, for example "X-Frame-Options: DENY". */
				__( 'This page cannot open in the check window: the site sends “%s”, which forbids showing its pages in a frame (often set by a security plugin or the server). This is the server-side result instead: what the HTML contains, without a browser and without Reject.', 'consentwell' ),
				$server['frame_header']
			);
			if ( 0 === stripos( (string) $server['frame_header'], 'X-Frame-Options' ) ) {
				$notes[] = __( 'The header “X-Frame-Options: SAMEORIGIN” allows the full check, because the check window is on your own site.', 'consentwell' );
			}
		} else {
			$notes[] = __( 'Server-side check: the page was fetched without a browser, so scripts did not run and Reject was not clicked. It lists the third-party script and frame tags in the HTML and every cookie the response sets.', 'consentwell' );
		}
		if ( ! $plugin && ! empty( $server['fetched'] ) && ! $in ) {
			$notes[] = __( 'No banner markup is in the HTML. A banner that a script builds is not in the HTML, so this check cannot see it; the check in the browser can.', 'consentwell' );
		}
		if ( ! $server['fetched'] ) {
			$notes[] = sprintf(
				/* translators: %s: error message. */
				__( 'The site could not fetch its own page: %s', 'consentwell' ),
				$server['error']
			);
		}
		$result['notes']  = $notes;
		$result['counts'] = self::counts( $result );
		return $result;
	}

	/**
	 * Fields every result has.
	 *
	 * @param string     $url    Page address.
	 * @param array|null $plugin Consent plugin.
	 * @param string     $mode   'browser' or 'server'.
	 * @return array
	 */
	private static function base( $url, $plugin, $mode ) {
		$shy = $plugin ? null : Consentwell_Consent_Plugins::active_frame_shy();
		return array(
			'id'           => wp_generate_uuid4(),
			'url'          => esc_url_raw( $url ),
			'time'         => time(),
			'mode'         => $mode,
			'wp_version'   => get_bloginfo( 'version' ),
			'plugin'       => $plugin ? array(
				'slug'    => $plugin['slug'],
				'name'    => $plugin['name'],
				'version' => $plugin['version'],
			) : null,
			'other_plugin' => $shy,
		);
	}

	/**
	 * The parts of the server-side check that are kept with the result.
	 *
	 * @param array $server Server check result.
	 * @return array
	 */
	private static function server_part( $server ) {
		return array(
			'fetched'       => ! empty( $server['fetched'] ),
			'status'        => isset( $server['status'] ) ? (int) $server['status'] : 0,
			'scripts'       => isset( $server['scripts'] ) ? $server['scripts'] : array(),
			'frames'        => isset( $server['frames'] ) ? $server['frames'] : array(),
			'cookies'       => isset( $server['cookies'] ) ? $server['cookies'] : array(),
			'frame_blocked' => ! empty( $server['frame_blocked'] ),
			'frame_header'  => isset( $server['frame_header'] ) ? $server['frame_header'] : '',
		);
	}

	/**
	 * Likely causes, in plain words.
	 *
	 * @param array|null $plugin    Consent plugin.
	 * @param array      $server    Server check result.
	 * @param array      $probe     Probe facts from the check window.
	 * @param array      $browser   All browser facts.
	 * @param array      $result    Result so far.
	 * @param array      $cfg       Consent plugin's own script settings seen in the window.
	 * @param bool       $dnt       Browser sends Do Not Track.
	 * @param bool       $gpc       Browser sends Global Privacy Control.
	 * @param bool       $by_design Banner hidden by the consent plugin's DNT/GPC setting.
	 * @return array [ { code, text, items } ]
	 */
	private static function causes( $plugin, $server, $probe, $browser, $result, $cfg, $dnt, $gpc, $by_design ) {
		$causes       = array();
		$banner       = $result['banner'];
		$browser_mode = 'browser' === $result['mode'];
		$problem      = $browser_mode
			? ( ! $banner['shown'] || ( $banner['found'] && ! $banner['reject_visible'] ) || ( $plugin && ! $banner['found'] ) )
			: ( $plugin && ! $banner['found'] );
		$name         = $plugin ? $plugin['name'] : __( 'The consent plugin', 'consentwell' );
		$signals      = array();
		if ( $gpc ) {
			$signals[] = __( 'Global Privacy Control', 'consentwell' );
		}
		if ( $dnt ) {
			$signals[] = __( 'Do Not Track', 'consentwell' );
		}

		if ( $by_design ) {
			$causes[] = array(
				'code'  => 'dnt_gpc_by_design',
				'text'  => sprintf(
					/* translators: %s: "Global Privacy Control" and/or "Do Not Track". */
					__( 'Hidden by design, nothing is broken: the browser running this check sends %s, and Complianz’s “Respect Do Not Track and Global Privacy Control?” setting is on, so Complianz does not show the banner to this browser. Visitors whose browsers do not send these signals see the banner.', 'consentwell' ),
					implode( __( ' and ', 'consentwell' ), $signals )
				),
				'items' => array(),
			);
			return $causes;
		}
		if ( $browser_mode && ! empty( $banner['not_in_window'] ) ) {
			$causes[] = array(
				'code'  => 'banner_not_in_window',
				'text'  => '' !== $banner['named']
					? sprintf(
						/* translators: 1: consent plugin name, 2: the banner element, such as "div#cookie-notice". */
						__( '%1$s does not show its banner inside a frame (its own script stops when the page is in one), and the check window is a frame. The banner is in the page HTML (%2$s) but cannot show here; visitors who have not chosen yet should see it. Open the page in a private window to confirm.', 'consentwell' ),
						$banner['named'],
						$banner['candidate']
					)
					: sprintf(
						/* translators: %s: the banner element, such as "div#cookie-banner". */
						__( 'A banner is in the page HTML (%s) but did not appear in the check window. Some banners do not show inside a frame, and the check window is one. Open the page in a private window to see what visitors see.', 'consentwell' ),
						$banner['candidate']
					),
				'items' => array(),
			);
		}
		// Failed consent-plugin files and a cache that serves another copy are reported even when the
		// banner shows; everything else only explains a banner that does not show.
		if ( $problem && $browser_mode && ! $banner['visible'] && $signals ) {
			$causes[] = array(
				'code'  => 'dnt_gpc_signal',
				'text'  => sprintf(
					/* translators: %s: "Global Privacy Control" and/or "Do Not Track". */
					__( 'The browser running this check sends %s. Some consent plugins hide their banner from browsers that send it; visitors without the signal may see a different result.', 'consentwell' ),
					implode( __( ' and ', 'consentwell' ), $signals )
				),
				'items' => array(),
			);
		}

		$head   = $browser_mode ? ! empty( $probe['head'] ) : ( true === $server['head_marker'] );
		$footer = $browser_mode ? ! empty( $probe['footer'] ) : ( true === $server['footer_marker'] );
		$known  = $browser_mode || null !== $server['head_marker'];
		if ( $problem && $known && ! $head ) {
			$causes[] = array(
				'code'  => 'no_wp_head',
				'text'  => __( 'This page has no wp_head and no wp_footer output: the theme’s template does not call wp_head() and wp_footer(), so plugins cannot add their scripts or their banner to it.', 'consentwell' ),
				'items' => array(),
			);
		} elseif ( $problem && $known && ! $footer ) {
			$causes[] = array(
				'code'  => 'no_wp_footer',
				'text'  => sprintf(
					/* translators: %s: consent plugin name. */
					__( 'This page has no wp_footer output: the theme’s template does not call wp_footer(). %s adds its banner there, so the banner cannot appear on this page.', 'consentwell' ),
					$name
				),
				'items' => array(),
			);
		}

		if ( $plugin ) {
			$errors = array();
			foreach ( self::arr( $probe, 'resource_errors' ) as $error ) {
				$url = isset( $error['url'] ) ? esc_url_raw( $error['url'] ) : '';
				if ( $url && Consentwell_Consent_Plugins::is_plugin_asset( $url, $plugin['slug'] ) ) {
					$status         = isset( $error['status'] ) ? (int) $error['status'] : 0;
					$errors[ $url ] = $status > 0
						/* translators: 1: address, 2: HTTP status code. */
						? sprintf( __( '%1$s answered %2$d', 'consentwell' ), $url, $status )
						/* translators: %s: address. */
						: sprintf( __( '%s failed to load', 'consentwell' ), $url );
				}
			}
			foreach ( isset( $server['asset_errors'] ) ? $server['asset_errors'] : array() as $error ) {
				if ( ! isset( $errors[ $error['url'] ] ) ) {
					/* translators: 1: address, 2: HTTP status code. */
					$errors[ $error['url'] ] = sprintf( __( '%1$s answered %2$d', 'consentwell' ), $error['url'], (int) $error['status'] );
				}
			}
			if ( $errors ) {
				$causes[] = array(
					'code'  => 'consent_asset_error',
					'text'  => sprintf(
						/* translators: %s: consent plugin name. */
						__( '%s’s own files did not load:', 'consentwell' ),
						$name
					),
					'items' => array_values( $errors ),
				);
			}

			$script_loaded = $browser_mode ? ! empty( $browser['consent_script_loaded'] ) : ( true === $server['consent_script_in_html'] );
			if ( $problem && $banner['found'] && ! $script_loaded ) {
				// One cause for one fact: when the banner also kept its hiding class, the class is part of the same sentence.
				$class_here = $browser_mode && ! $banner['visible'] ? self::hiding_class( self::arr( self::arr( $browser, 'banner' ), 'hidden_by' ) ) : '';
				$looks      = self::script_missing_looks();
				$causes[]   = array(
					'code'  => 'consent_script_missing',
					'text'  => '' !== $class_here
						? sprintf(
							/* translators: 1: consent plugin name, 2: CSS class name such as "cmplz-hidden", 3: things to look for. */
							__( '%1$s’s banner is in the page with its hiding class “%2$s” still on it, and its script is not: something removed or delayed the script, so nothing shows the banner. Look for: %3$s.', 'consentwell' ),
							$name,
							$class_here,
							$looks
						)
						: sprintf(
							/* translators: 1: consent plugin name, 2: things to look for. */
							__( '%1$s’s banner is in the page, but its script is not: something removed or delayed the script, so nothing shows the banner. Look for: %2$s.', 'consentwell' ),
							$name,
							$looks
						),
					'items' => array(),
				);
			}

			if ( $problem && $browser_mode && $script_loaded && isset( $cfg['present'] ) && ! $cfg['present'] ) {
				$def      = Consentwell_Consent_Plugins::definition( $plugin['slug'] );
				$causes[] = array(
					'code'  => 'consent_config_missing',
					'text'  => sprintf(
						/* translators: 1: consent plugin name, 2: name of its inline settings script, such as "var complianz". */
						__( '%1$s’s script is on the page, but its settings (the inline “%2$s” script) did not run, so the script cannot show the banner. An error in an inline script, or an optimisation layer that changes inline scripts, causes this.', 'consentwell' ),
						$name,
						$def ? $def['config_mark'] : ''
					),
					'items' => array(),
				);
			}
			if ( $problem && $browser_mode && 'complianz' === $plugin['slug'] && ! empty( $cfg['disable_cookiebanner'] ) ) {
				$causes[] = array(
					'code'  => 'disabled_here',
					'text'  => __( 'Complianz turned its banner off on this page (it does this, for example, in previews and page-builder editors).', 'consentwell' ),
					'items' => array(),
				);
			}
		}

		$css_hides = $browser_mode && $banner['found'] && ! $banner['visible'] && self::style_rule_hides( self::arr( self::arr( $browser, 'banner' ), 'hidden_by' ) );
		if ( $css_hides ) {
			$causes[] = array(
				'code'  => 'style_rule_hides',
				'text'  => sprintf(
					/* translators: %s: the rule and the element it hides, such as "display: none on div#cookie-banner". */
					__( 'A style rule hides the banner: %s. Look for that rule in the theme, in Additional CSS and in other plugins’ stylesheets.', 'consentwell' ),
					implode( '; ', $banner['hidden_by'] )
				),
				'items' => array(),
			);
		}

		$hiding_class = $browser_mode && $banner['found'] && ! $banner['visible'] ? self::hiding_class( self::arr( self::arr( $browser, 'banner' ), 'hidden_by' ) ) : '';
		if ( '' !== $hiding_class && ! in_array( 'consent_script_missing', array_column( $causes, 'code' ), true ) ) {
			$causes[] = array(
				'code'  => 'hiding_class',
				'text'  => sprintf(
					/* translators: %s: CSS class name, such as "cmplz-hidden". */
					__( 'The banner is in the page, but its hiding class “%s” is still on it. A consent plugin keeps its banner hidden with a class like this until its own script shows it, so that script may not have run on this page. Look for: a script error on the page, an optimisation or script-delay plugin, a cached copy of the page.', 'consentwell' ),
					$hiding_class
				),
				'items' => array(),
			);
		}

		$script_errors = self::script_error_items( $probe );
		if ( $problem && $script_errors && ! $css_hides ) {
			$causes[] = array(
				'code'  => 'script_errors',
				'text'  => __( 'Scripts on this page stopped with an error. An error before the consent plugin’s script runs can stop the banner from appearing:', 'consentwell' ),
				'items' => $script_errors,
			);
		}

		if ( ! empty( $server['cache']['differs'] ) ) {
			$items = array();
			foreach ( $server['cache']['differences'] as $difference ) {
				switch ( $difference['code'] ) {
					case 'banner_missing':
						$items[] = __( 'The visitor copy has no consent banner; the fresh page has one.', 'consentwell' );
						break;
					case 'config_missing':
						$items[] = __( 'The visitor copy is missing the consent plugin’s settings script; the fresh page has it.', 'consentwell' );
						break;
					case 'asset_only_cached':
						/* translators: %s: address. */
						$items[] = sprintf( __( 'Only in the visitor copy: %s', 'consentwell' ), $difference['detail'] );
						break;
					case 'asset_only_fresh':
						/* translators: %s: address. */
						$items[] = sprintf( __( 'Only in the fresh page: %s', 'consentwell' ), $difference['detail'] );
						break;
				}
			}
			foreach ( $server['cache']['headers'] as $header => $value ) {
				/* translators: 1: header name, 2: header value. */
				$items[] = sprintf( __( 'Cache header on the visitor copy: %1$s: %2$s', 'consentwell' ), $header, $value );
			}
			$causes[] = array(
				'code'  => 'cache_differs',
				'text'  => __( 'The HTML a logged-out visitor gets differs from a fresh page: a page cache or optimisation plugin is serving an older or changed copy. Clearing that cache after changing consent settings usually fixes this.', 'consentwell' ),
				'items' => $items,
			);
		}

		if ( $browser_mode && $banner['visible'] && null !== $banner['shown_after'] ) {
			$causes[] = array(
				'code'  => 'banner_late',
				'text'  => sprintf(
					/* translators: 1: number of seconds, such as "5.4". 2: what may hold the banner back (a sentence about optimisation plugins). */
					__( 'The banner only appeared %1$s seconds after the page loaded, after the page had settled. Something holds back the consent plugin’s script until a timeout or the first visitor input; a visitor who leaves sooner never sees a banner. %2$s', 'consentwell' ),
					number_format_i18n( $banner['shown_after'], 1 ),
					self::delay_hint( $plugin )
				),
				'items' => array(),
			);
		}

		$excluded = ( $problem && $plugin && 'complianz' === $plugin['slug'] && ! $banner['found'] ) ? self::complianz_exclusion( isset( $result['url'] ) ? $result['url'] : '' ) : '';
		if ( '' !== $excluded ) {
			$causes[] = array(
				'code'  => 'excluded_page',
				'text'  => sprintf(
					/* translators: %s: the word in the address that Complianz has on its list of excluded pages. */
					__( 'Complianz is switched off for this address: “%s” is on its list of excluded pages (the “Disable Complianz on this page” box in the Cookiebanner box of the page editor).', 'consentwell' ),
					$excluded
				),
				'items' => array(),
			);
		}
		if ( $problem && $plugin && ! $banner['found'] && ! $causes ) {
			$causes[] = array(
				'code'  => 'banner_missing',
				'text'  => sprintf(
					/* translators: %s: consent plugin name. */
					__( '%s is active but did not add a banner to this page. Consentwell found no setting or error that explains it.', 'consentwell' ),
					$name
				),
				'items' => array(),
			);
		}
		return $causes;
	}

	/**
	 * What may hold the consent plugin's script or banner back, in plain words.
	 *
	 * @param array|null $plugin Consent plugin.
	 * @return string
	 */
	private static function delay_hint( $plugin ) {
		$optimisers = Consentwell_Consent_Plugins::active_optimisers();
		if ( $optimisers ) {
			return sprintf(
				/* translators: %s: names of the active optimisation plugins. */
				__( 'Optimisation plugins active here: %s. Check their script-delay and optimisation settings.', 'consentwell' ),
				implode( ', ', $optimisers )
			);
		}
		return sprintf(
			/* translators: %s: consent plugin name, or “The consent plugin”. */
			__( 'No optimisation or script-delay plugin that Consentwell knows by name is active here, so %s itself, or a setting at your host or CDN, may be delaying it.', 'consentwell' ),
			$plugin ? $plugin['name'] : __( 'the consent plugin', 'consentwell' )
		);
	}

	/**
	 * What to look for when a consent plugin's script is missing from the page, as one list in a sentence. The optimisation
	 * plugins named are the ones active here; nothing blames the consent plugin itself, because the page's own template or
	 * settings can remove its script as well.
	 *
	 * @return string
	 */
	private static function script_missing_looks() {
		$optimisers = Consentwell_Consent_Plugins::active_optimisers();
		$first      = $optimisers
			/* translators: %s: names of the active optimisation plugins. */
			? sprintf( __( 'the script-delay and optimisation settings of %s (active here)', 'consentwell' ), implode( ', ', $optimisers ) )
			: __( 'a script-delay or optimisation setting (no plugin that Consentwell knows by name is active here)', 'consentwell' );
		return $first . __( ', a template or page setting that does not load the script on this page, or a script-delay or cache setting at your host or CDN', 'consentwell' );
	}

	/**
	 * Whether the browser's hiding facts say a style rule (and not a hiding class) hides the banner.
	 *
	 * @param array $facts [ { kind } ] untrusted.
	 * @return bool
	 */
	private static function style_rule_hides( $facts ) {
		$rule = false;
		foreach ( array_slice( $facts, 0, 10 ) as $fact ) {
			$kind = is_array( $fact ) && isset( $fact['kind'] ) ? (string) $fact['kind'] : '';
			if ( 'class' === $kind ) {
				return false;
			}
			if ( in_array( $kind, array( 'display', 'visibility', 'opacity', 'size', 'offscreen' ), true ) ) {
				$rule = true;
			}
		}
		return $rule;
	}

	/**
	 * The entry of Complianz's list of excluded pages that matches an address. Complianz keeps the slugs of pages whose
	 * "Disable Complianz on this page" box is ticked in the option cmplz_excluded_posts_array and shows no banner on a request
	 * whose address contains one of them.
	 *
	 * @param string $url Address that was checked.
	 * @return string The matching entry, or ''.
	 */
	private static function complianz_exclusion( $url ) {
		$list = get_option( 'cmplz_excluded_posts_array', array() );
		if ( ! is_array( $list ) || '' === $url ) {
			return '';
		}
		$request = (string) wp_parse_url( $url, PHP_URL_PATH ) . ( wp_parse_url( $url, PHP_URL_QUERY ) ? '?' . wp_parse_url( $url, PHP_URL_QUERY ) : '' );
		foreach ( $list as $slug ) {
			if ( is_string( $slug ) && '' !== $slug && false !== strpos( $request, $slug ) ) {
				return $slug;
			}
		}
		return '';
	}

	/**
	 * The name of the hiding class among the browser's hiding facts, or ''.
	 *
	 * @param array $facts [ { kind, detail } ] untrusted.
	 * @return string
	 */
	private static function hiding_class( $facts ) {
		foreach ( array_slice( $facts, 0, 10 ) as $fact ) {
			if ( is_array( $fact ) && isset( $fact['kind'], $fact['detail'] ) && 'class' === $fact['kind'] ) {
				return self::text( $fact['detail'], 60 );
			}
		}
		return '';
	}

	/**
	 * The page's script errors as "message (file:line)", at most 20, without repeats.
	 *
	 * @param array $probe Probe facts (untrusted).
	 * @return string[]
	 */
	private static function script_error_items( $probe ) {
		$items = array();
		foreach ( array_slice( self::arr( $probe, 'errors' ), 0, 20 ) as $error ) {
			if ( ! is_array( $error ) ) {
				continue;
			}
			$message = self::text( isset( $error['message'] ) ? $error['message'] : '', 300 );
			$source  = isset( $error['source'] ) ? esc_url_raw( remove_query_arg( array( Consentwell_Token::QUERY_ARG, 'consentwell_blank' ), (string) $error['source'] ) ) : '';
			$line    = isset( $error['line'] ) ? (int) $error['line'] : 0;
			$items[] = $source ? sprintf( '%s (%s%s)', $message, $source, $line ? ':' . $line : '' ) : $message;
		}
		return array_values( array_unique( $items ) );
	}

	/**
	 * Notes shown with every result.
	 *
	 * @param array $result Result.
	 * @param array $probe  Probe facts.
	 * @param bool  $dnt    DNT.
	 * @param bool  $gpc    GPC.
	 * @return string[]
	 */
	private static function notes( $result, $probe, $dnt, $gpc ) {
		$notes  = array();
		$reject = $result['reject'];
		if ( ! empty( $result['banner']['not_in_window'] ) ) {
			$notes[] = __( 'The banner did not appear in the check window, so Reject could not be clicked. The list shows what loads before any choice.', 'consentwell' );
		} elseif ( ! $result['banner']['found'] && $result['banner']['in_html'] ) {
			$notes[] = __( 'The banner never appeared on screen, so Reject could not be clicked. The list shows what loads before any choice.', 'consentwell' );
		} elseif ( ! $result['banner']['found'] ) {
			$notes[] = __( 'No consent banner found on this page, so Reject was not clicked. The list shows what loads before any choice.', 'consentwell' );
			if ( empty( $result['plugin'] ) ) {
				$notes[] = __( 'A banner that a script builds only for top-level windows, or that does not show inside a frame, is not found by this check. If visitors see a banner on this page, open it in a private window to confirm.', 'consentwell' );
			}
		} elseif ( 'auto' === $reject['mode'] && $reject['clicked'] ) {
			$button = empty( $reject['label'] )
				? __( 'the banner’s Reject button', 'consentwell' )
				/* translators: %s: the text on the button, for example "Deny". */
				: sprintf( __( 'the banner’s Reject button (labelled “%s”)', 'consentwell' ), $reject['label'] );
			$notes[] = $result['banner']['reject_visible']
				/* translators: %s: "the banner’s Reject button" with its label. */
				? sprintf( __( 'Consentwell clicked %s, then reloaded the page.', 'consentwell' ), $button )
				/* translators: %s: "the banner’s Reject button" with its label. */
				: sprintf( __( 'Consentwell clicked %s although visitors could not see it, then reloaded the page, so the After Reject list is still available.', 'consentwell' ), $button );
		} elseif ( 'manual' === $reject['mode'] && $reject['clicked'] ) {
			$notes[] = __( 'You clicked Reject in the check window; Consentwell then reloaded the page.', 'consentwell' );
		} elseif ( ! empty( $reject['early_click'] ) ) {
			$notes[] = __( 'You clicked in the check window before Consentwell asked you to, so Reject was not counted and the page may have recorded a choice before the lists were read. Run the check again and wait for “Your turn” before you click.', 'consentwell' );
		} else {
			$notes[] = __( 'Reject was not clicked, so there is no After Reject list for this check.', 'consentwell' );
		}
		if ( ! empty( $reject['early_click'] ) && $reject['clicked'] ) {
			$notes[] = __( 'You also clicked in the check window before Consentwell asked you to, so the page may have recorded a choice before the Before any choice list was read.', 'consentwell' );
		}
		if ( ! empty( $result['banner']['seen_then_hidden'] ) ) {
			$notes[] = __( 'The banner was on screen when the page had loaded and was hidden again by the end of the check.', 'consentwell' );
		}
		if ( ! empty( $result['watch']['scroll_limit'] ) ) {
			$notes[] = sprintf(
				/* translators: %d: number of scroll steps. */
				__( 'The page is longer than the %d scroll steps Consentwell makes, so content further down was not scrolled into view.', 'consentwell' ),
				self::MAX_SCROLL_STEPS
			);
		}
		if ( isset( $result['cookie_mode'] ) && 'consent-only' === $result['cookie_mode'] ) {
			$notes[] = __( 'This browser cannot tell a page its cookies’ expiry dates (it has no Cookie Store API, or this admin screen is on plain http), so only cookies named like a consent record were cleared before the check. Cookies the browser already had are not listed.', 'consentwell' );
		}
		if ( ! $result['banner']['by_design'] && ( $dnt || $gpc ) && $result['banner']['visible'] ) {
			$notes[] = __( 'The browser running this check sends Do Not Track or Global Privacy Control.', 'consentwell' );
		}
		$errors = 'browser' === $result['mode'] ? self::script_error_items( $probe ) : array();
		if ( $errors && ! in_array( 'script_errors', wp_list_pluck( $result['causes'], 'code' ), true ) ) {
			$shown = array_slice( $errors, 0, 3 );
			$more  = count( $errors ) - count( $shown );
			$list  = implode( '; ', $shown ) . ( $more > 0 ? sprintf( /* translators: %d: number of further errors. */ _n( ' and %d more', ' and %d more', $more, 'consentwell' ), $more ) : '' );
			if ( $result['banner']['shown'] ) {
				$notes[] = sprintf(
					/* translators: 1: number of script errors, 2: the errors. */
					_n( '%1$d script error happened on this page; it did not stop the banner: %2$s', '%1$d script errors happened on this page; they did not stop the banner: %2$s', count( $errors ), 'consentwell' ),
					count( $errors ),
					$list
				);
			} else {
				$notes[] = sprintf(
					/* translators: 1: number of script errors, 2: the errors. */
					_n( '%1$d script error happened on this page as well: %2$s', '%1$d script errors happened on this page as well: %2$s', count( $errors ), 'consentwell' ),
					count( $errors ),
					$list
				);
			}
		}
		return $notes;
	}

	/**
	 * The four numbers shown in the table.
	 *
	 * @param array $result Result.
	 * @return array
	 */
	private static function counts( $result ) {
		return array(
			'before'        => count( $result['before']['requests'] ),
			'after'         => null === $result['after'] ? null : count( $result['after']['requests'] ),
			'cookies_after' => null === $result['after'] ? null : count( $result['after']['cookies'] ),
		);
	}

	/**
	 * How long each page load was watched (seconds since the page loaded), from the browser.
	 *
	 * @param array $raw Untrusted.
	 * @return array { before: int|null, after: int|null, scroll_limit: bool }
	 */
	private static function watch_part( $raw ) {
		$seconds = static function ( $key ) use ( $raw ) {
			return ( isset( $raw[ $key ] ) && is_numeric( $raw[ $key ] ) ) ? max( 0, min( 600, (int) $raw[ $key ] ) ) : null;
		};
		return array(
			'before'       => $seconds( 'before' ),
			'after'        => $seconds( 'after' ),
			'scroll_limit' => ! empty( $raw['scroll_limit'] ),
		);
	}

	/**
	 * Sanitise a { requests, cookies } list pair from the browser.
	 *
	 * @param array $raw Untrusted.
	 * @return array
	 */
	private static function lists( $raw ) {
		$requests = array();
		$seen     = array();
		foreach ( array_slice( self::arr( $raw, 'requests' ), 0, self::MAX_ITEMS ) as $item ) {
			if ( ! is_array( $item ) || empty( $item['url'] ) ) {
				continue;
			}
			$url = esc_url_raw( substr( (string) $item['url'], 0, 2048 ), array( 'http', 'https' ) );
			if ( '' === $url || ! Consentwell_Url::is_third_party( $url ) || isset( $seen[ $url ] ) ) {
				continue;
			}
			$seen[ $url ] = true;
			$type         = isset( $item['type'] ) && in_array( $item['type'], self::REQUEST_TYPES, true ) ? $item['type'] : 'other';
			$requests[]   = array(
				'url'     => $url,
				'type'    => $type,
				'service' => Consentwell_Services::name_for( $url ),
				'failed'  => ! empty( $item['failed'] ),
			);
		}
		$cookies = array();
		$omitted = array();
		foreach ( array_slice( self::arr( $raw, 'cookies' ), 0, self::MAX_ITEMS ) as $name ) {
			$name = is_string( $name ) ? substr( preg_replace( '/[^A-Za-z0-9!#$%&\'*+\-.^_`|~]/', '', $name ), 0, 200 ) : '';
			if ( '' === $name ) {
				continue;
			}
			if ( Consentwell_Services::cookie_in_list( $name, 'consent_cookies' ) ) {
				$omitted[ $name ] = $name;
				continue;
			}
			if ( Consentwell_Services::cookie_in_list( $name, 'wordpress_cookies' ) ) {
				continue;
			}
			$cookies[ $name ] = $name;
		}
		return array(
			'requests' => $requests,
			'cookies'  => array_values( $cookies ),
			'omitted'  => array_values( $omitted ),
		);
	}

	/**
	 * Plain-words reasons from the browser's hiding facts.
	 *
	 * @param array $facts [ { kind, detail, element } ] untrusted.
	 * @return string[]
	 */
	private static function hidden_texts( $facts ) {
		$texts = array();
		foreach ( array_slice( $facts, 0, 10 ) as $fact ) {
			if ( ! is_array( $fact ) ) {
				continue;
			}
			$kind    = isset( $fact['kind'] ) ? (string) $fact['kind'] : '';
			$element = self::text( isset( $fact['element'] ) ? $fact['element'] : '', 120 );
			$detail  = self::text( isset( $fact['detail'] ) ? $fact['detail'] : '', 120 );
			switch ( $kind ) {
				case 'class':
					/* translators: 1: CSS class name, 2: element description. */
					$texts[] = sprintf( __( 'hiding class “%1$s” on %2$s', 'consentwell' ), $detail, $element );
					break;
				case 'display':
					/* translators: %s: element description. */
					$texts[] = sprintf( __( 'display: none on %s', 'consentwell' ), $element );
					break;
				case 'visibility':
					/* translators: %s: element description. */
					$texts[] = sprintf( __( 'visibility: hidden on %s', 'consentwell' ), $element );
					break;
				case 'opacity':
					/* translators: %s: element description. */
					$texts[] = sprintf( __( 'opacity: 0 on %s', 'consentwell' ), $element );
					break;
				case 'size':
					/* translators: 1: element description, 2: size such as "0 × 0". */
					$texts[] = sprintf( __( 'zero size (%2$s px) on %1$s', 'consentwell' ), $element, $detail );
					break;
				case 'offscreen':
					/* translators: 1: element description, 2: position. */
					$texts[] = sprintf( __( 'off screen (%2$s) on %1$s', 'consentwell' ), $element, $detail );
					break;
				case 'hidden-attr':
					/* translators: %s: element description. */
					$texts[] = sprintf( __( 'the hidden attribute on %s', 'consentwell' ), $element );
					break;
			}
		}
		return array_values( array_unique( $texts ) );
	}

	/**
	 * Array member or empty array.
	 *
	 * @param mixed  $source Array.
	 * @param string $key    Key.
	 * @return array
	 */
	private static function arr( $source, $key ) {
		return ( is_array( $source ) && '' !== $key && isset( $source[ $key ] ) && is_array( $source[ $key ] ) ) ? $source[ $key ] : array();
	}

	/**
	 * Sanitised, length-limited text.
	 *
	 * @param mixed $value Value.
	 * @param int   $max   Maximum length.
	 * @return string
	 */
	private static function text( $value, $max ) {
		return is_scalar( $value ) ? mb_substr( sanitize_text_field( (string) $value ), 0, $max ) : '';
	}
}
