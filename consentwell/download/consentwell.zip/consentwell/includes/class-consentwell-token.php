<?php
/**
 * Short-lived, single-use tokens that let a check render a page as a logged-out visitor.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check tokens.
 *
 * A token is created by an administrator through the REST API, is stored as a transient keyed by a
 * keyed hash of the token (the token itself is never stored), lives for two minutes, and is spent
 * by the first page it renders. A token never grants anything: it only makes the request render
 * as a logged-out visitor.
 */
class Consentwell_Token {

	const QUERY_ARG = 'consentwell_check';

	const TTL = 120;

	/**
	 * Kind for the check window: only valid with the issuing admin's own login cookie.
	 */
	const KIND_FRAME = 'frame';

	/**
	 * Kind for the server-side fetch: only valid without any login cookie.
	 */
	const KIND_SERVER = 'server';

	/**
	 * Create a token for the given user.
	 *
	 * @param int    $user_id User who starts the check.
	 * @param string $kind    KIND_FRAME or KIND_SERVER.
	 * @return string Token.
	 */
	public static function issue( $user_id, $kind = self::KIND_FRAME ) {
		$token = wp_generate_password( 32, false, false );
		set_transient(
			self::key( $token ),
			array(
				'user'    => (int) $user_id,
				'kind'    => self::KIND_SERVER === $kind ? self::KIND_SERVER : self::KIND_FRAME,
				'expires' => time() + self::TTL,
			),
			self::TTL
		);
		return $token;
	}

	/**
	 * Check a token without spending it.
	 *
	 * @param string $token          Token from the address.
	 * @param int    $cookie_user_id User identified by the request's login cookie (0 when none).
	 * @return bool
	 */
	public static function is_valid( $token, $cookie_user_id ) {
		if ( ! is_string( $token ) || ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			return false;
		}
		$record = get_transient( self::key( $token ) );
		if ( ! is_array( $record ) || empty( $record['expires'] ) || (int) $record['expires'] < time() ) {
			return false;
		}
		$cookie_user_id = (int) $cookie_user_id;
		if ( self::KIND_SERVER === $record['kind'] ) {
			return 0 === $cookie_user_id;
		}
		return $cookie_user_id > 0 && (int) $record['user'] === $cookie_user_id && user_can( $cookie_user_id, 'manage_options' );
	}

	/**
	 * Spend a token so it cannot be used again.
	 *
	 * @param string $token Token.
	 */
	public static function spend( $token ) {
		if ( is_string( $token ) && preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) {
			delete_transient( self::key( $token ) );
		}
	}

	/**
	 * Transient name for a token.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	private static function key( $token ) {
		return 'consentwell_t_' . substr( hash_hmac( 'sha256', $token, wp_salt( 'nonce' ) ), 0, 40 );
	}

	/**
	 * Address of a page with a token attached.
	 *
	 * @param string $url   Page address.
	 * @param string $token Token.
	 * @return string
	 */
	public static function url_with_token( $url, $token ) {
		return add_query_arg( self::QUERY_ARG, rawurlencode( $token ), $url );
	}
}
