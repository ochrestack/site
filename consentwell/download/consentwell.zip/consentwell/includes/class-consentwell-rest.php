<?php
/**
 * REST endpoints used by the Tools > Consentwell screen. Administrators only, with a nonce.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST API.
 */
class Consentwell_Rest {

	const NS = 'consentwell/v1';

	const PENDING_TTL = 900;

	/**
	 * Hook in.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Register routes.
	 */
	public static function routes() {
		$url_arg      = array(
			'url' => array(
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => 'esc_url_raw',
			),
		);
		$check_id_arg = array(
			'type'              => 'string',
			'required'          => true,
			'sanitize_callback' => 'sanitize_text_field',
		);
		$store_arg    = array(
			'type'    => 'boolean',
			'default' => true,
		);

		register_rest_route(
			self::NS,
			'/prepare',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'prepare' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array_merge( $url_arg, array( 'store' => $store_arg ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/token',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'token' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array( 'check_id' => $check_id_arg ),
			)
		);
		register_rest_route(
			self::NS,
			'/results',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'results' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array(
					'check_id' => $check_id_arg,
					'browser'  => array(
						'type'     => 'object',
						'required' => true,
					),
					'store'    => $store_arg,
				),
			)
		);
		register_rest_route(
			self::NS,
			'/server-check',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'server_check' ),
				'permission_callback' => array( __CLASS__, 'can' ),
				'args'                => array_merge( $url_arg, array( 'store' => $store_arg ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/checks/(?P<id>[a-f0-9-]{36})',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_check' ),
				'permission_callback' => array( __CLASS__, 'can' ),
			)
		);
		register_rest_route(
			self::NS,
			'/review/dismiss',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'dismiss_review' ),
				'permission_callback' => array( __CLASS__, 'can' ),
			)
		);
	}

	/**
	 * Administrators only, and only with a valid REST nonce from the screen.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public static function can( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'consentwell_forbidden', __( 'Only administrators can run Consentwell checks.', 'consentwell' ), array( 'status' => rest_authorization_required_code() ) );
		}
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error( 'consentwell_bad_nonce', __( 'The security check failed. Reload the Consentwell screen and try again.', 'consentwell' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Start a browser check: server-side check, then a token for the check window.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function prepare( $request ) {
		$url = Consentwell_Url::validate_check_url( $request['url'] );
		if ( is_wp_error( $url ) ) {
			return $url;
		}
		$user_id = get_current_user_id();
		$plugin  = Consentwell_Consent_Plugins::active();
		$server  = Consentwell_Server_Check::run( $url, $plugin, $user_id );

		if ( $server['frame_blocked'] ) {
			$check = Consentwell_Analyzer::from_server( $url, $plugin, $server, 'frame_blocked' );
			return rest_ensure_response( array_merge( array( 'frame_blocked' => true ), self::finish( $check, (bool) $request['store'] ) ) );
		}

		$check_id = wp_generate_uuid4();
		set_transient(
			self::pending_key( $user_id, $check_id ),
			array(
				'url'    => $url,
				'plugin' => $plugin,
				'server' => $server,
			),
			self::PENDING_TTL
		);
		return rest_ensure_response(
			array(
				'frame_blocked' => false,
				'check_id'      => $check_id,
				'url'           => $url,
				'frame_url'     => Consentwell_Token::url_with_token( $url, Consentwell_Token::issue( $user_id ) ),
				'blank_url'     => Consentwell_Token::url_with_token( add_query_arg( 'consentwell_blank', '1', $url ), Consentwell_Token::issue( $user_id ) ),
				'plugin'        => $plugin ? array(
					'slug'    => $plugin['slug'],
					'name'    => $plugin['name'],
					'version' => $plugin['version'],
				) : null,
			)
		);
	}

	/**
	 * A fresh token for reloading the check window after Reject.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function token( $request ) {
		$user_id = get_current_user_id();
		$pending = get_transient( self::pending_key( $user_id, $request['check_id'] ) );
		if ( ! is_array( $pending ) ) {
			return self::expired();
		}
		return rest_ensure_response(
			array(
				'frame_url' => Consentwell_Token::url_with_token( $pending['url'], Consentwell_Token::issue( $user_id ) ),
			)
		);
	}

	/**
	 * Receive the facts from the check window and store the result.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function results( $request ) {
		$user_id = get_current_user_id();
		$key     = self::pending_key( $user_id, $request['check_id'] );
		$pending = get_transient( $key );
		if ( ! is_array( $pending ) ) {
			return self::expired();
		}
		delete_transient( $key );
		$browser = $request['browser'];
		if ( ! empty( $browser['frame'] ) && is_array( $browser['frame'] ) && ! empty( $browser['frame']['blocked'] ) ) {
			$check = Consentwell_Analyzer::from_server( $pending['url'], $pending['plugin'], $pending['server'], 'frame_blocked' );
			if ( empty( $pending['server']['frame_header'] ) ) {
				$check['notes'][0] = __( 'This page could not open in the check window (the browser did not allow Consentwell to read it). This is the server-side result instead: what the HTML contains, without a browser and without Reject.', 'consentwell' );
			}
		} else {
			$check = Consentwell_Analyzer::from_browser( $pending['url'], $pending['plugin'], $pending['server'], $browser );
		}
		return rest_ensure_response( self::finish( $check, (bool) $request['store'] ) );
	}

	/**
	 * Server-side check only.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function server_check( $request ) {
		$url = Consentwell_Url::validate_check_url( $request['url'] );
		if ( is_wp_error( $url ) ) {
			return $url;
		}
		$plugin = Consentwell_Consent_Plugins::active();
		$server = Consentwell_Server_Check::run( $url, $plugin, get_current_user_id() );
		$check  = Consentwell_Analyzer::from_server( $url, $plugin, $server, $server['frame_blocked'] ? 'frame_blocked' : 'server' );
		return rest_ensure_response( self::finish( $check, (bool) $request['store'] ) );
	}

	/**
	 * One stored result.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_check( $request ) {
		$check = Consentwell_Store::get( $request['id'] );
		if ( ! $check ) {
			return new WP_Error( 'consentwell_not_found', __( 'That check is no longer kept (Consentwell keeps the last 20).', 'consentwell' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response( self::payload( $check ) );
	}

	/**
	 * Hide the review line for this administrator.
	 *
	 * @return WP_REST_Response
	 */
	public static function dismiss_review() {
		update_user_meta( get_current_user_id(), Consentwell_Admin::REVIEW_META, 1 );
		return rest_ensure_response( array( 'dismissed' => true ) );
	}

	/**
	 * Store (when asked) and build the response.
	 *
	 * @param array $check Result.
	 * @param bool  $store Whether to keep it in the last-20 list.
	 * @return array
	 */
	private static function finish( $check, $store ) {
		if ( $store ) {
			Consentwell_Store::add( $check );
		}
		$payload = self::payload( $check );
		if ( $store ) {
			$payload['table_html']  = Consentwell_Admin::table_html();
			$payload['show_review'] = Consentwell_Admin::show_review();
		}
		return $payload;
	}

	/**
	 * Result, its text and its HTML.
	 *
	 * @param array $check Result.
	 * @return array
	 */
	private static function payload( $check ) {
		return array(
			'check' => $check,
			'text'  => Consentwell_Report::as_text( $check ),
			'html'  => Consentwell_Admin::result_html( $check ),
		);
	}

	/**
	 * Transient name for a check in progress.
	 *
	 * @param int    $user_id  User.
	 * @param string $check_id Check id.
	 * @return string
	 */
	private static function pending_key( $user_id, $check_id ) {
		return 'consentwell_p_' . md5( (int) $user_id . '|' . (string) $check_id );
	}

	/**
	 * Error for a check that took too long.
	 *
	 * @return WP_Error
	 */
	private static function expired() {
		return new WP_Error( 'consentwell_expired', __( 'This check took too long and expired. Start it again.', 'consentwell' ), array( 'status' => 410 ) );
	}
}
