<?php
/**
 * Well-known service names for third-party addresses, and cookie name lists.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Service and cookie lists, read from assets/services.json (shared with the browser script).
 */
class Consentwell_Services {

	/**
	 * Cached list.
	 *
	 * @var array|null
	 */
	private static $data = null;

	/**
	 * The decoded services.json.
	 *
	 * @return array
	 */
	public static function data() {
		if ( null === self::$data ) {
			$data       = wp_json_file_decode( CONSENTWELL_DIR . 'assets/services.json', array( 'associative' => true ) );
			self::$data = is_array( $data ) ? $data : array(
				'services'          => array(),
				'consent_cookies'   => array(
					'prefixes' => array(),
					'names'    => array(),
				),
				'wordpress_cookies' => array(
					'prefixes' => array(),
					'names'    => array(),
				),
			);
		}
		return self::$data;
	}

	/**
	 * Name of the well-known service an address belongs to, or '' when it is not a known one.
	 * A service can match by host, by a fragment of host and path, or by a regular expression over host, path and query.
	 *
	 * @param string $url Absolute address.
	 * @return string
	 */
	public static function name_for( $url ) {
		$parts = wp_parse_url( (string) $url );
		if ( empty( $parts['host'] ) ) {
			return '';
		}
		$host     = strtolower( $parts['host'] );
		$hostpath = $host . ( isset( $parts['path'] ) ? $parts['path'] : '' );
		$bare     = Consentwell_Url::host_key( $host ) . ( isset( $parts['path'] ) ? $parts['path'] : '' );
		$full     = $hostpath . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' );
		foreach ( self::data()['services'] as $service ) {
			foreach ( $service['match'] as $fragment ) {
				if ( false !== strpos( $hostpath, $fragment ) || false !== strpos( $bare, $fragment ) ) {
					return $service['name'];
				}
			}
			// Services told apart by the address's query string (gtag.js?id=G-… is Analytics, id=AW-… is Ads).
			foreach ( isset( $service['regex'] ) ? $service['regex'] : array() as $pattern ) {
				if ( 1 === preg_match( $pattern, $full ) ) {
					return $service['name'];
				}
			}
			foreach ( $service['hosts'] as $service_host ) {
				if ( $host === $service_host || substr( $host, -strlen( '.' . $service_host ) ) === '.' . $service_host ) {
					return $service['name'];
				}
			}
		}
		return '';
	}

	/**
	 * Whether a cookie name matches one of the lists in services.json.
	 *
	 * @param string $name Cookie name.
	 * @param string $which 'consent_cookies' or 'wordpress_cookies'.
	 * @return bool
	 */
	public static function cookie_in_list( $name, $which ) {
		$data = self::data();
		if ( empty( $data[ $which ] ) ) {
			return false;
		}
		if ( in_array( $name, $data[ $which ]['names'], true ) ) {
			return true;
		}
		foreach ( $data[ $which ]['prefixes'] as $prefix ) {
			if ( 0 === strpos( $name, $prefix ) ) {
				return true;
			}
		}
		return false;
	}
}
