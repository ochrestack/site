<?php
/**
 * Renders a checked page as a logged-out visitor when, and only when, a valid check token is present.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check rendering.
 */
class Consentwell_Render {

	/**
	 * 'none' (no token in the request), 'valid' or 'refused'.
	 *
	 * @var string
	 */
	private static $state = 'none';

	/**
	 * The token of this request.
	 *
	 * @var string
	 */
	private static $token = '';

	/**
	 * Hook in.
	 */
	public static function init() {
		add_filter( 'determine_current_user', array( __CLASS__, 'filter_current_user' ), 100 );
		add_action( 'template_redirect', array( __CLASS__, 'refuse_invalid' ), 0 );
		add_action( 'template_redirect', array( __CLASS__, 'start_render' ), 1000 );
	}

	/**
	 * Reset the per-request state (used by tests that simulate several requests in one process).
	 */
	public static function reset() {
		self::$state = 'none';
		self::$token = '';
	}

	/**
	 * Current state.
	 *
	 * @return string
	 */
	public static function state() {
		return self::$state;
	}

	/**
	 * The token in this request's address; null when the request has none.
	 *
	 * @return string|null
	 */
	private static function request_token() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The token is its own short-lived, single-use, user-bound credential (see Consentwell_Token).
		if ( ! isset( $_GET[ Consentwell_Token::QUERY_ARG ] ) ) {
			return null;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- As above.
		$token = is_string( $_GET[ Consentwell_Token::QUERY_ARG ] ) ? sanitize_text_field( wp_unslash( $_GET[ Consentwell_Token::QUERY_ARG ] ) ) : '';
		// Anything that is not exactly 32 letters and digits is kept as '' and refused.
		return is_string( $token ) && preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ? $token : '';
	}

	/**
	 * On a front-end request that carries a check token: validate it against the login cookie's
	 * user and render as a logged-out visitor. A token never raises privileges: every outcome of
	 * this filter is either the unchanged user or user 0.
	 *
	 * @param int|false $user_id User identified by the login cookie so far.
	 * @return int|false
	 */
	public static function filter_current_user( $user_id ) {
		if ( 'valid' === self::$state || 'refused' === self::$state ) {
			return 0;
		}
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $user_id;
		}
		$token = self::request_token();
		if ( null === $token ) {
			return $user_id;
		}
		self::$token = $token;
		self::$state = Consentwell_Token::is_valid( $token, (int) $user_id ) ? 'valid' : 'refused';
		return 0;
	}

	/**
	 * Stop a request whose token is missing, forged, spent, expired or belongs to someone else.
	 */
	public static function refuse_invalid() {
		if ( 'none' === self::$state && null !== self::request_token() ) {
			// The user was determined before this plugin could look (or not at all): treat it as refused.
			self::$state = 'refused';
		}
		if ( 'refused' !== self::$state ) {
			return;
		}
		nocache_headers();
		wp_die(
			esc_html__( 'This check link is not valid any more. Start the check again from Tools > Consentwell.', 'consentwell' ),
			esc_html__( 'Check link expired', 'consentwell' ),
			array( 'response' => 403 )
		);
	}

	/**
	 * The page is about to render for a valid token: spend the token, keep the page out of caches,
	 * and add the head probe and footer marker that the check reads.
	 */
	public static function start_render() {
		if ( 'valid' !== self::$state ) {
			return;
		}
		Consentwell_Token::spend( self::$token );
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Shared constant that page-cache plugins read.
		}
		nocache_headers();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only reached with a valid check token.
		if ( isset( $_GET['consentwell_blank'] ) ) {
			// An empty document at the page's own address, so the check can read and clear
			// cookies that are scoped to this path before the page itself loads.
			header( 'Content-Type: text/html; charset=utf-8' );
			echo '<!doctype html><html><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Consentwell</title></head><body></body></html>';
			exit;
		}
		add_action( 'wp_head', array( __CLASS__, 'print_probe' ), -1000 );
		add_action( 'wp_footer', array( __CLASS__, 'print_footer_marker' ), PHP_INT_MAX );
	}

	/**
	 * The probe records script errors and failed resources on the checked page, from the top of
	 * the head, so that errors in later scripts are seen.
	 */
	public static function print_probe() {
		$js = '(function(){var p=window.__consentwellProbe={head:true,footer:false,errors:[],resourceErrors:[]};'
			. 'try{performance.setResourceTimingBufferSize(5000);}catch(e){}'
			. 'window.addEventListener("error",function(e){var t=e.target;'
			. 'if(t&&t!==window&&t.tagName){var u=t.currentSrc||t.src||t.href||"";if(u){p.resourceErrors.push({url:String(u),tag:String(t.tagName).toLowerCase()});}return;}'
			. 'if(p.errors.length<50){p.errors.push({message:String(e.message||"Script error"),source:String(e.filename||""),line:e.lineno||0});}},true);'
			. '})();';
		wp_print_inline_script_tag( $js, array( 'id' => 'consentwell-probe' ) );
	}

	/**
	 * Marker that proves wp_footer() ran on this page.
	 */
	public static function print_footer_marker() {
		echo '<template id="consentwell-footer-marker"></template>';
		wp_print_inline_script_tag( 'if(window.__consentwellProbe){window.__consentwellProbe.footer=true;}', array( 'id' => 'consentwell-footer-js' ) );
	}
}
