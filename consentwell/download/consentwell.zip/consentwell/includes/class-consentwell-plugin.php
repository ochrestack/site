<?php
/**
 * Bootstrap.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin bootstrap.
 */
class Consentwell_Plugin {

	/**
	 * Hook everything in.
	 */
	public static function init() {
		Consentwell_Render::init();
		Consentwell_Rest::init();
		Consentwell_Site_Health::init();
		if ( is_admin() ) {
			Consentwell_Admin::init();
		}
	}
}
