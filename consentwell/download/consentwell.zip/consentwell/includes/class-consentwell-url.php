<?php
/**
 * Address helpers: which addresses belong to this site, and which are on other domains.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Address helpers.
 */
class Consentwell_Url {

	/**
	 * Host of the site's front end, lower case, without a leading "www.".
	 *
	 * @return string
	 */
	public static function site_host() {
		return self::host_key( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	}

	/**
	 * Normalise a host for comparison: lower case, no leading "www.".
	 *
	 * @param string $host Host name.
	 * @return string
	 */
	public static function host_key( $host ) {
		$host = strtolower( trim( (string) $host, " \t\n\r\0\x0B." ) );
		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}
		return $host;
	}

	/**
	 * Whether an absolute http(s) address is on this site.
	 *
	 * @param string $url Address.
	 * @return bool
	 */
	public static function is_own( $url ) {
		$parts = wp_parse_url( (string) $url );
		if ( empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
			return false;
		}
		if ( ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return false;
		}
		// Same host and same port as the site: a check never reaches another service on the server.
		$site_port = wp_parse_url( home_url( '/' ), PHP_URL_PORT );
		$port      = isset( $parts['port'] ) ? (int) $parts['port'] : null;
		if ( ( $site_port ? (int) $site_port : null ) !== $port && ! ( null === $site_port && in_array( $port, array( 80, 443 ), true ) ) ) {
			return false;
		}
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return false;
		}
		return self::host_key( $parts['host'] ) === self::site_host();
	}

	/**
	 * Whether an address is on another domain than the site.
	 *
	 * @param string $url Absolute address.
	 * @return bool
	 */
	public static function is_third_party( $url ) {
		$host = wp_parse_url( (string) $url, PHP_URL_HOST );
		if ( empty( $host ) ) {
			return false;
		}
		return self::host_key( $host ) !== self::site_host();
	}

	/**
	 * Turn an address found in a page into an absolute address.
	 *
	 * @param string $src  Address as written in the HTML.
	 * @param string $base Address of the page.
	 * @return string Absolute address, or '' when it cannot be loaded (data:, javascript:, empty).
	 */
	public static function absolute( $src, $base ) {
		$src = trim( html_entity_decode( (string) $src, ENT_QUOTES, 'UTF-8' ) );
		if ( '' === $src || '#' === $src[0] ) {
			return '';
		}
		if ( preg_match( '#^[a-z][a-z0-9+.-]*:#i', $src ) ) {
			return preg_match( '#^https?://#i', $src ) ? $src : '';
		}
		$base_parts = wp_parse_url( $base );
		$scheme     = isset( $base_parts['scheme'] ) ? $base_parts['scheme'] : 'https';
		if ( 0 === strpos( $src, '//' ) ) {
			return $scheme . ':' . $src;
		}
		$origin = $scheme . '://' . ( isset( $base_parts['host'] ) ? $base_parts['host'] : '' ) . ( isset( $base_parts['port'] ) ? ':' . $base_parts['port'] : '' );
		if ( '/' === $src[0] ) {
			return $origin . $src;
		}
		$path = isset( $base_parts['path'] ) ? $base_parts['path'] : '/';
		$dir  = substr( $path, 0, strrpos( $path, '/' ) + 1 );
		return $origin . $dir . $src;
	}

	/**
	 * A path typed without the site's address ("/about/") becomes an address on this site. A path that already starts
	 * with the site's own folder (a site in /blog/) is kept as it is. Anything else is returned unchanged.
	 *
	 * @param string $input What was typed.
	 * @return string
	 */
	public static function from_path( $input ) {
		if ( ! preg_match( '#^/(?!/)#', $input ) ) {
			return $input;
		}
		$home = home_url( '/' );
		$base = rtrim( (string) wp_parse_url( $home, PHP_URL_PATH ), '/' );
		if ( '' !== $base && ( $input === $base || 0 === strpos( $input, $base . '/' ) ) ) {
			return substr( $home, 0, strlen( $home ) - strlen( $base ) - 1 ) . $input;
		}
		return $home . ltrim( $input, '/' );
	}

	/**
	 * Validate an address the admin asked to check. Returns the cleaned address or a WP_Error.
	 *
	 * @param string $url Address.
	 * @return string|WP_Error
	 */
	public static function validate_check_url( $url ) {
		$url = self::from_path( trim( (string) $url ) );
		$url = esc_url_raw( $url, array( 'http', 'https' ) );
		if ( '' === $url || ! self::is_own( $url ) ) {
			return new WP_Error(
				'consentwell_not_own',
				__( 'Consentwell only checks pages of this site. Enter an address that starts with this site’s address.', 'consentwell' ),
				array( 'status' => 400 )
			);
		}
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$base = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$rel  = '' !== $base && 0 === strpos( $path, $base . '/' ) ? substr( $path, strlen( $base ) ) : $path;
		if ( preg_match( '#^/(wp-login\.php|wp-admin(/|$)|wp-json(/|$))#', $rel ) ) {
			return new WP_Error(
				'consentwell_not_a_page',
				__( 'This address is a WordPress login, admin or REST screen, not a page your visitors see. Enter the address of a page.', 'consentwell' ),
				array( 'status' => 422 )
			);
		}
		$url = remove_query_arg( array( Consentwell_Token::QUERY_ARG, 'consentwell_blank' ), $url );
		$url = preg_replace( '/#.*$/', '', $url );
		return $url;
	}

	/**
	 * Whether two page addresses point at the same page (ignores a trailing slash and the fragment).
	 *
	 * @param string $a Address.
	 * @param string $b Address.
	 * @return bool
	 */
	public static function same_page( $a, $b ) {
		$norm = static function ( $u ) {
			$u     = preg_replace( '/#.*$/', '', (string) $u );
			$parts = wp_parse_url( $u );
			$host  = isset( $parts['host'] ) ? self::host_key( $parts['host'] ) : '';
			$path  = isset( $parts['path'] ) ? rtrim( $parts['path'], '/' ) : '';
			$query = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
			return $host . $path . $query;
		};
		return $norm( $a ) === $norm( $b );
	}
}
