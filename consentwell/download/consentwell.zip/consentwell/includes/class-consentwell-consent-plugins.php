<?php
/**
 * Which recognised consent plugin is active, its version, and the settings that change what a check means.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Recognised consent plugins.
 */
class Consentwell_Consent_Plugins {

	/**
	 * Recognised plugins: slug => definition.
	 *
	 * @return array
	 */
	public static function known() {
		return array(
			'complianz' => array(
				'name'        => 'Complianz',
				'files'       => array( 'complianz-gdpr/complianz-gpdr.php', 'complianz-gdpr-premium/complianz-gpdr-premium.php' ),
				'asset_paths' => array( '/plugins/complianz-gdpr/', '/plugins/complianz-gdpr-premium/', '/uploads/complianz/' ),
				'script_path' => 'cookiebanner/js/complianz',
				'html_marker' => '/id=["\']cmplz-cookiebanner-container["\']|class=["\'][^"\']*\bcmplz-cookiebanner\b/',
				'config_mark' => 'var complianz',
			),
			'cookieyes' => array(
				'name'        => 'CookieYes',
				'files'       => array( 'cookie-law-info/cookie-law-info.php' ),
				'asset_paths' => array( '/plugins/cookie-law-info/', 'cdn-cookieyes.com/' ),
				'script_path' => 'frontend/js/script',
				'html_marker' => '/id=["\']ckyBannerTemplate["\']|class=["\'][^"\']*\bcky-consent-container\b/',
				'config_mark' => '_ckyConfig',
			),
		);
	}

	/**
	 * The active recognised consent plugin, or null.
	 *
	 * @return array|null { slug, name, version, settings }
	 */
	public static function active() {
		if ( ! function_exists( 'is_plugin_active' ) || ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( self::known() as $slug => $def ) {
			foreach ( $def['files'] as $file ) {
				if ( is_plugin_active( $file ) ) {
					$data = get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false );
					return array(
						'slug'     => $slug,
						'name'     => $def['name'],
						'version'  => isset( $data['Version'] ) ? (string) $data['Version'] : '',
						'settings' => self::settings( $slug ),
					);
				}
			}
		}
		return null;
	}

	/**
	 * Settings of the consent plugin that change how a result reads.
	 *
	 * @param string $slug Plugin slug.
	 * @return array
	 */
	public static function settings( $slug ) {
		$settings = array();
		if ( 'complianz' === $slug ) {
			if ( function_exists( 'cmplz_get_option' ) ) {
				$respect = cmplz_get_option( 'respect_dnt' );
			} else {
				$options = get_option( 'cmplz_options', array() );
				$respect = is_array( $options ) && isset( $options['respect_dnt'] ) ? $options['respect_dnt'] : 'no';
			}
			// Same expression Complianz uses for do_not_track_enabled in its banner script.
			$settings['respect_dnt'] = ( 'no' !== $respect );
		}
		return $settings;
	}

	/**
	 * Definition for a slug.
	 *
	 * @param string $slug Slug.
	 * @return array|null
	 */
	public static function definition( $slug ) {
		$known = self::known();
		return isset( $known[ $slug ] ) ? $known[ $slug ] : null;
	}

	/**
	 * Whether an address is one of the consent plugin's own files.
	 *
	 * @param string $url  Address.
	 * @param string $slug Plugin slug.
	 * @return bool
	 */
	public static function is_plugin_asset( $url, $slug ) {
		$def = self::definition( $slug );
		if ( ! $def ) {
			return false;
		}
		$path = (string) wp_parse_url( $url, PHP_URL_HOST ) . (string) wp_parse_url( $url, PHP_URL_PATH );
		foreach ( $def['asset_paths'] as $fragment ) {
			if ( false !== strpos( $path, $fragment ) ) {
				return true;
			}
		}
		return false;
	}
}
