<?php
/**
 * Keeps the last 20 check results in the site's own database.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Result store.
 */
class Consentwell_Store {

	const OPTION = 'consentwell_checks';

	const KEEP = 20;

	/**
	 * All kept results, newest first.
	 *
	 * @return array
	 */
	public static function all() {
		$checks = get_option( self::OPTION, array() );
		return is_array( $checks ) ? array_values( $checks ) : array();
	}

	/**
	 * Add a result; the oldest beyond 20 is removed.
	 *
	 * @param array $check Result.
	 * @return array The stored result.
	 */
	public static function add( $check ) {
		$checks = self::all();
		array_unshift( $checks, $check );
		$checks = array_slice( $checks, 0, self::KEEP );
		update_option( self::OPTION, $checks, false );
		return $check;
	}

	/**
	 * One result by id.
	 *
	 * @param string $id Result id.
	 * @return array|null
	 */
	public static function get( $id ) {
		foreach ( self::all() as $check ) {
			if ( isset( $check['id'] ) && $check['id'] === $id ) {
				return $check;
			}
		}
		return null;
	}

	/**
	 * The newest result for a page, or null.
	 *
	 * @param string $url Page address.
	 * @return array|null
	 */
	public static function latest_for( $url ) {
		foreach ( self::all() as $check ) {
			if ( Consentwell_Url::same_page( $check['url'], $url ) ) {
				return $check;
			}
		}
		return null;
	}
}
