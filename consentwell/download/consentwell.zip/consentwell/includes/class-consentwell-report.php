<?php
/**
 * Plain-text summary of a result, sized to paste into a support forum.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Text report.
 */
class Consentwell_Report {

	/**
	 * Human label for a request type.
	 *
	 * @param string $type Type key.
	 * @return string
	 */
	public static function type_label( $type ) {
		$labels = array(
			'script'     => __( 'script', 'consentwell' ),
			'frame'      => __( 'frame or embed', 'consentwell' ),
			'image'      => __( 'image or pixel', 'consentwell' ),
			'stylesheet' => __( 'stylesheet', 'consentwell' ),
			'font'       => __( 'font', 'consentwell' ),
			'media'      => __( 'media', 'consentwell' ),
			'fetch'      => __( 'data request', 'consentwell' ),
			'other'      => __( 'other', 'consentwell' ),
		);
		return isset( $labels[ $type ] ) ? $labels[ $type ] : $labels['other'];
	}

	/**
	 * What a list row says about its request: "requested script", "requested script (failed)" when the
	 * browser reported that the file did not load (a network or ad-blocker failure, or an error status),
	 * or "script tag" for a tag in the HTML of a server-side check, where nothing was requested.
	 *
	 * @param array $request { type, failed? }.
	 * @param bool  $browser Whether the list comes from a browser check.
	 * @return string
	 */
	public static function request_label( $request, $browser ) {
		$type = self::type_label( isset( $request['type'] ) ? $request['type'] : 'other' );
		if ( ! $browser ) {
			/* translators: %s: type of request, such as "script". */
			return sprintf( __( '%s tag', 'consentwell' ), $type );
		}
		if ( ! empty( $request['failed'] ) ) {
			/* translators: %s: type of request, such as "script". */
			return sprintf( __( 'requested %s (failed)', 'consentwell' ), $type );
		}
		/* translators: %s: type of request, such as "script". */
		return sprintf( __( 'requested %s', 'consentwell' ), $type );
	}

	/**
	 * The "banner visible" text for a banner in the HTML that the check window did not show.
	 *
	 * @return string
	 */
	public static function not_in_window_text() {
		return __( 'not shown in the check window (visitors may see it: open the page in a private window to confirm)', 'consentwell' );
	}

	/**
	 * Yes / no / not checked.
	 *
	 * @param bool|null $value Value.
	 * @return string
	 */
	public static function yes_no( $value ) {
		if ( null === $value ) {
			return __( 'not checked', 'consentwell' );
		}
		return $value ? __( 'yes', 'consentwell' ) : __( 'no', 'consentwell' );
	}

	/**
	 * What one list covers: how long the page was watched, and with what input.
	 *
	 * @param array  $check Result.
	 * @param string $key   'before' or 'after'.
	 * @return string Empty when the result has no watch data (a server-side check, or a result stored by an earlier version).
	 */
	public static function watch_text( $check, $key ) {
		if ( empty( $check['watch'][ $key ] ) ) {
			return '';
		}
		return sprintf(
			/* translators: %d: number of seconds. */
			__( 'Watched about %d seconds after the page loaded, with simulated mouse, key, touch and scroll input and the page scrolled to the bottom. A request that starts later than that, or only after a real click, is not listed.', 'consentwell' ),
			(int) $check['watch'][ $key ]
		);
	}

	/**
	 * Says which cookies the list leaves out because they are the consent plugin's own record.
	 *
	 * @param array $data { requests, cookies, omitted }.
	 * @return string Empty when nothing was left out (or the result was stored by an earlier version).
	 */
	public static function omitted_text( $data ) {
		if ( empty( $data['omitted'] ) ) {
			return '';
		}
		$shown = array_slice( $data['omitted'], 0, 4 );
		$more  = count( $data['omitted'] ) - count( $shown );
		$names = implode( ', ', $shown ) . ( $more > 0 ? sprintf( /* translators: %d: number of further cookie names. */ __( ' and %d more', 'consentwell' ), $more ) : '' );
		return sprintf(
			/* translators: %s: cookie names. */
			__( '(the consent plugin’s own record, %s, is not listed)', 'consentwell' ),
			$names
		);
	}

	/**
	 * The consent plugin as "Name version", or a plain phrase.
	 *
	 * @param array $check Result.
	 * @return string
	 */
	public static function plugin_label( $check ) {
		if ( empty( $check['plugin'] ) ) {
			if ( ! empty( $check['other_plugin']['name'] ) ) {
				return sprintf(
					/* translators: %s: consent plugin name and version. */
					__( 'none recognised (Consentwell recognises Complianz and CookieYes by name); %s is active', 'consentwell' ),
					trim( $check['other_plugin']['name'] . ' ' . $check['other_plugin']['version'] )
				);
			}
			return __( 'none recognised (Consentwell recognises Complianz and CookieYes by name)', 'consentwell' );
		}
		return trim( $check['plugin']['name'] . ' ' . $check['plugin']['version'] );
	}

	/**
	 * The text.
	 *
	 * @param array $check Result.
	 * @return string
	 */
	public static function as_text( $check ) {
		$lines   = array();
		$lines[] = __( 'Consentwell check', 'consentwell' );
		/* translators: %s: page address. */
		$lines[] = sprintf( __( 'Page: %s', 'consentwell' ), $check['url'] );
		/* translators: %s: date and time in UTC. */
		$lines[] = sprintf( __( 'Checked: %s UTC', 'consentwell' ), gmdate( 'Y-m-d H:i', (int) $check['time'] ) );
		/* translators: %s: WordPress version. */
		$lines[] = sprintf( __( 'WordPress: %s', 'consentwell' ), $check['wp_version'] );
		/* translators: %s: consent plugin name and version. */
		$lines[] = sprintf( __( 'Consent plugin: %s', 'consentwell' ), self::plugin_label( $check ) );
		$lines[] = 'server' === $check['mode']
			? __( 'Method: server-side fetch as a logged-out visitor (no browser, Reject not clicked)', 'consentwell' )
			: __( 'Method: page opened in a browser as a logged-out visitor with no consent stored', 'consentwell' );
		$lines[] = '';

		$banner = $check['banner'];
		if ( 'browser' === $check['mode'] && ! $banner['found'] && ! $banner['in_html'] ) {
			$lines[] = __( 'Consent banner: no consent banner found on this page', 'consentwell' );
		} else {
			/* translators: %s: yes / no. */
			$lines[] = sprintf( __( 'Banner in the page HTML: %s', 'consentwell' ), self::yes_no( $banner['in_html'] ) );
			if ( 'browser' === $check['mode'] ) {
				$visible = ! empty( $banner['not_in_window'] ) ? self::not_in_window_text() : self::yes_no( $banner['shown'] );
				if ( $banner['hidden_by'] ) {
					$visible .= ' (' . implode( '; ', $banner['hidden_by'] ) . ')';
				}
				/* translators: %s: yes / no and the reason. */
				$lines[] = sprintf( __( 'Banner visible on screen: %s', 'consentwell' ), $visible );
				$reject  = self::yes_no( $banner['reject_visible'] );
				if ( $banner['reject_hidden'] ) {
					$reject .= ' (' . implode( '; ', $banner['reject_hidden'] ) . ')';
				} elseif ( $banner['found'] && ! $banner['reject_found'] ) {
					$reject .= ' (' . __( 'no Reject button found on the first layer', 'consentwell' ) . ')';
				}
				/* translators: %s: yes / no and the reason. */
				$lines[] = sprintf( __( 'Reject button visible on the first layer: %s', 'consentwell' ), $reject );
			}
		}

		if ( $check['causes'] ) {
			$lines[] = '';
			$lines[] = __( 'Likely cause:', 'consentwell' );
			foreach ( $check['causes'] as $cause ) {
				$lines[] = '- ' . $cause['text'];
				foreach ( $cause['items'] as $item ) {
					$lines[] = '    ' . $item;
				}
			}
		}

		$lines[] = '';
		$lines   = array_merge( $lines, self::list_lines( 'server' === $check['mode'] ? __( 'Third-party script and frame tags in the HTML', 'consentwell' ) : __( 'Before any choice', 'consentwell' ), $check['before'], 'browser' === $check['mode'], self::watch_text( $check, 'before' ) ) );
		if ( null !== $check['after'] ) {
			$lines[] = '';
			$lines   = array_merge( $lines, self::list_lines( __( 'After Reject (page reloaded)', 'consentwell' ), $check['after'], true, self::watch_text( $check, 'after' ) ) );
		}

		if ( ! empty( $check['server']['cookies'] ) ) {
			$lines[] = '';
			$lines[] = __( 'Cookies the page response sets (server-side fetch, HttpOnly included):', 'consentwell' );
			foreach ( $check['server']['cookies'] as $cookie ) {
				$lines[] = '- ' . $cookie['name'] . ( $cookie['httponly'] ? ' (HttpOnly)' : '' );
			}
		}

		if ( $check['notes'] ) {
			$lines[] = '';
			foreach ( $check['notes'] as $note ) {
				$lines[] = $note;
			}
		}
		$lines[] = '';
		$lines[] = __( 'Cookies that another domain stores for itself cannot be read by any page; those services appear above as requests.', 'consentwell' );
		$lines[] = __( 'These are technical facts from one check, not legal advice.', 'consentwell' );
		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * Lines for a requests + cookies list.
	 *
	 * @param string $title Section title.
	 * @param array  $data  { requests, cookies }.
	 * @param bool   $with_cookies Whether cookies were read in the browser for this list.
	 * @param string $watch        What the list covers (see watch_text()), or ''.
	 * @return string[]
	 */
	private static function list_lines( $title, $data, $with_cookies = true, $watch = '' ) {
		$lines = array();
		$count = count( $data['requests'] );
		/* translators: 1: section title, 2: number of requests. */
		$lines[] = sprintf( _n( '%1$s: %2$d third-party request', '%1$s: %2$d third-party requests', $count, 'consentwell' ), $title, $count );
		foreach ( $data['requests'] as $request ) {
			$lines[] = '- ' . self::request_label( $request, $with_cookies ) . ': ' . $request['url'] . ( $request['service'] ? ' (' . $request['service'] . ')' : '' );
		}
		if ( '' !== $watch ) {
			$lines[] = $watch;
		}
		if ( ! $with_cookies ) {
			return $lines;
		}
		if ( $data['cookies'] ) {
			/* translators: %s: comma-separated cookie names. */
			$line = sprintf( __( 'Cookies set (readable by the page): %s', 'consentwell' ), implode( ', ', $data['cookies'] ) );
		} else {
			$line = __( 'Cookies set (readable by the page): none', 'consentwell' );
		}
		$omitted = self::omitted_text( $data );
		$lines[] = '' === $omitted ? $line : $line . ' ' . $omitted;
		return $lines;
	}
}
