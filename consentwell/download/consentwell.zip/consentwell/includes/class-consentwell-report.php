<?php
/**
 * Plain-text summary of a result, sized to paste into a support forum.
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

/**
 * Text report.
 */
class Consentwell_Report {

	/**
	 * Human label for a request type.
	 *
	 * @param string $type Type key.
	 * @return string
	 */
	public static function type_label( $type ) {
		$labels = array(
			'script'     => __( 'script', 'consentwell' ),
			'frame'      => __( 'frame or embed', 'consentwell' ),
			'image'      => __( 'image or pixel', 'consentwell' ),
			'stylesheet' => __( 'stylesheet', 'consentwell' ),
			'font'       => __( 'font', 'consentwell' ),
			'media'      => __( 'media', 'consentwell' ),
			'fetch'      => __( 'data request', 'consentwell' ),
			'other'      => __( 'other', 'consentwell' ),
		);
		return isset( $labels[ $type ] ) ? $labels[ $type ] : $labels['other'];
	}

	/**
	 * Yes / no / not checked.
	 *
	 * @param bool|null $value Value.
	 * @return string
	 */
	public static function yes_no( $value ) {
		if ( null === $value ) {
			return __( 'not checked', 'consentwell' );
		}
		return $value ? __( 'yes', 'consentwell' ) : __( 'no', 'consentwell' );
	}

	/**
	 * What one list covers: how long the page was watched, and with what input.
	 *
	 * @param array  $check Result.
	 * @param string $key   'before' or 'after'.
	 * @return string Empty when the result has no watch data (a server-side check, or a result stored by an earlier version).
	 */
	public static function watch_text( $check, $key ) {
		if ( empty( $check['watch'][ $key ] ) ) {
			return '';
		}
		return sprintf(
			/* translators: %d: number of seconds. */
			__( 'Watched about %d seconds after the page loaded, with simulated mouse, key, touch and scroll input and the page scrolled to the bottom. A request that starts later than that, or only after a real click, is not listed.', 'consentwell' ),
			(int) $check['watch'][ $key ]
		);
	}

	/**
	 * The consent plugin as "Name version", or a plain phrase.
	 *
	 * @param array $check Result.
	 * @return string
	 */
	public static function plugin_label( $check ) {
		if ( empty( $check['plugin'] ) ) {
			return __( 'none recognised (Consentwell recognises Complianz and CookieYes by name)', 'consentwell' );
		}
		return trim( $check['plugin']['name'] . ' ' . $check['plugin']['version'] );
	}

	/**
	 * The text.
	 *
	 * @param array $check Result.
	 * @return string
	 */
	public static function as_text( $check ) {
		$lines   = array();
		$lines[] = __( 'Consentwell check', 'consentwell' );
		/* translators: %s: page address. */
		$lines[] = sprintf( __( 'Page: %s', 'consentwell' ), $check['url'] );
		/* translators: %s: date and time in UTC. */
		$lines[] = sprintf( __( 'Checked: %s UTC', 'consentwell' ), gmdate( 'Y-m-d H:i', (int) $check['time'] ) );
		/* translators: %s: WordPress version. */
		$lines[] = sprintf( __( 'WordPress: %s', 'consentwell' ), $check['wp_version'] );
		/* translators: %s: consent plugin name and version. */
		$lines[] = sprintf( __( 'Consent plugin: %s', 'consentwell' ), self::plugin_label( $check ) );
		$lines[] = 'server' === $check['mode']
			? __( 'Method: server-side fetch as a logged-out visitor (no browser, Reject not clicked)', 'consentwell' )
			: __( 'Method: page opened in a browser as a logged-out visitor with no consent stored', 'consentwell' );
		$lines[] = '';

		$banner = $check['banner'];
		if ( 'browser' === $check['mode'] && ! $banner['found'] && ! $banner['in_html'] ) {
			$lines[] = __( 'Consent banner: no consent banner found on this page', 'consentwell' );
		} else {
			/* translators: %s: yes / no. */
			$lines[] = sprintf( __( 'Banner in the page HTML: %s', 'consentwell' ), self::yes_no( $banner['in_html'] ) );
			if ( 'browser' === $check['mode'] ) {
				$visible = self::yes_no( $banner['shown'] );
				if ( $banner['hidden_by'] ) {
					$visible .= ' (' . implode( '; ', $banner['hidden_by'] ) . ')';
				}
				/* translators: %s: yes / no and the reason. */
				$lines[] = sprintf( __( 'Banner visible on screen: %s', 'consentwell' ), $visible );
				$reject  = self::yes_no( $banner['reject_visible'] );
				if ( $banner['reject_hidden'] ) {
					$reject .= ' (' . implode( '; ', $banner['reject_hidden'] ) . ')';
				} elseif ( $banner['found'] && ! $banner['reject_found'] ) {
					$reject .= ' (' . __( 'no Reject button found on the first layer', 'consentwell' ) . ')';
				}
				/* translators: %s: yes / no and the reason. */
				$lines[] = sprintf( __( 'Reject button visible on the first layer: %s', 'consentwell' ), $reject );
			}
		}

		if ( $check['causes'] ) {
			$lines[] = '';
			$lines[] = __( 'Likely cause:', 'consentwell' );
			foreach ( $check['causes'] as $cause ) {
				$lines[] = '- ' . $cause['text'];
				foreach ( $cause['items'] as $item ) {
					$lines[] = '    ' . $item;
				}
			}
		}

		$lines[] = '';
		$lines   = array_merge( $lines, self::list_lines( 'server' === $check['mode'] ? __( 'Third-party script and frame tags in the HTML', 'consentwell' ) : __( 'Before any choice', 'consentwell' ), $check['before'], 'browser' === $check['mode'], self::watch_text( $check, 'before' ) ) );
		if ( null !== $check['after'] ) {
			$lines[] = '';
			$lines   = array_merge( $lines, self::list_lines( __( 'After Reject (page reloaded)', 'consentwell' ), $check['after'], true, self::watch_text( $check, 'after' ) ) );
		}

		if ( ! empty( $check['server']['cookies'] ) ) {
			$lines[] = '';
			$lines[] = __( 'Cookies the page response sets (server-side fetch, HttpOnly included):', 'consentwell' );
			foreach ( $check['server']['cookies'] as $cookie ) {
				$lines[] = '- ' . $cookie['name'] . ( $cookie['httponly'] ? ' (HttpOnly)' : '' );
			}
		}

		if ( $check['notes'] ) {
			$lines[] = '';
			foreach ( $check['notes'] as $note ) {
				$lines[] = $note;
			}
		}
		$lines[] = '';
		$lines[] = __( 'Cookies that another domain stores for itself cannot be read by any page; those services appear above as requests.', 'consentwell' );
		$lines[] = __( 'These are technical facts from one check, not legal advice.', 'consentwell' );
		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * Lines for a requests + cookies list.
	 *
	 * @param string $title Section title.
	 * @param array  $data  { requests, cookies }.
	 * @param bool   $with_cookies Whether cookies were read in the browser for this list.
	 * @param string $watch        What the list covers (see watch_text()), or ''.
	 * @return string[]
	 */
	private static function list_lines( $title, $data, $with_cookies = true, $watch = '' ) {
		$lines = array();
		$count = count( $data['requests'] );
		/* translators: 1: section title, 2: number of requests. */
		$lines[] = sprintf( _n( '%1$s: %2$d third-party request', '%1$s: %2$d third-party requests', $count, 'consentwell' ), $title, $count );
		foreach ( $data['requests'] as $request ) {
			$lines[] = '- ' . __( 'loaded', 'consentwell' ) . ' ' . self::type_label( $request['type'] ) . ': ' . $request['url'] . ( $request['service'] ? ' (' . $request['service'] . ')' : '' );
		}
		if ( '' !== $watch ) {
			$lines[] = $watch;
		}
		if ( ! $with_cookies ) {
			return $lines;
		}
		if ( $data['cookies'] ) {
			/* translators: %s: comma-separated cookie names. */
			$lines[] = sprintf( __( 'Cookies set (readable by the page): %s', 'consentwell' ), implode( ', ', $data['cookies'] ) );
		} else {
			$lines[] = __( 'Cookies set (readable by the page): none', 'consentwell' );
		}
		return $lines;
	}
}
