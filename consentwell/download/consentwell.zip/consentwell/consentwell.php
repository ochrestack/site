<?php
/**
 * Plugin Name:       Consentwell – Check What Loads After Reject
 * Plugin URI:        https://ochrestack.com/consentwell
 * Description:       Checks any page of your site as a logged-out visitor: does the consent banner show, and what still loads after Reject. Reports technical facts, not legal advice.
 * Version:           1.0.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       consentwell
 *
 * @package Consentwell
 */

defined( 'ABSPATH' ) || exit;

define( 'CONSENTWELL_VERSION', '1.0.2' );
define( 'CONSENTWELL_FILE', __FILE__ );
define( 'CONSENTWELL_DIR', plugin_dir_path( __FILE__ ) );
define( 'CONSENTWELL_URL', plugin_dir_url( __FILE__ ) );

require_once CONSENTWELL_DIR . 'includes/class-consentwell-url.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-services.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-token.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-render.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-consent-plugins.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-server-check.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-analyzer.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-store.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-report.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-rest.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-admin.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-site-health.php';
require_once CONSENTWELL_DIR . 'includes/class-consentwell-plugin.php';

Consentwell_Plugin::init();
