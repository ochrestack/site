/**
 * Consentwell check engine.
 *
 * Opens a page of this site in a same-origin check window as a logged-out visitor with no consent
 * stored, reads what the page shows and loads, clicks Reject (or waits for the admin's click),
 * reloads, reads again, and sends the facts to the site's own REST endpoint. It makes no request
 * to any other server; the checked page itself loads whatever third-party content it normally loads.
 *
 * @package Consentwell
 */
( function () {
	'use strict';

	var data = window.consentwellCheckData || {};
	var i18n = window.wp && window.wp.i18n ? window.wp.i18n : null;
	function __( text ) {
		return i18n ? i18n.__( text, 'consentwell' ) : text;
	}

	var REJECT_TEXT = /\b(reject|decline|deny|refuse|disagree)\b|necessary only|only necessary|essential only|only essential|ablehnen|verweigern|nur notwendige|nur essenzielle|refuser|tout refuser|rechazar|rifiuta|weiger|afwijzen|odrzu/i;
	var BANNER_WORDS = /cookie|consent|privacy|tracking|datenschutz|gdpr|rgpd|einwilligung/i;
	var CHOICE_WORDS = /accept|agree|allow|\bok\b|got it|reject|decline|deny|refuse|necessary|akzept|zustimm|ablehnen|alle|accepter|aceptar|accetta/i;
	var GENERIC_HIDE_CLASSES = [ 'hidden', 'hide', 'is-hidden', 'd-none', 'invisible' ];
	// Words that make a banner out of an element with no cookie or consent in its id, class or label.
	var STRONG_BANNER_WORDS = /cookie|consent|gdpr|rgpd|einwilligung|tracking/i;
	// A name that looks like a consent record; used only when the browser cannot read cookie attributes.
	var CONSENT_COOKIE_NAME = /consent|cookie|gdpr|cmplz|cky|optin|privacy|borlabs|usercentrics|complianz|euconsent/i;

	/**
	 * How long a page is watched, in milliseconds. After the page has settled, Consentwell sends the
	 * input a visitor makes (mouse, key, touch, wheel, scrolling down in steps) and keeps watching
	 * until this much time has passed since the last input with no new request. Script-delay plugins
	 * load their scripts after a timeout of about five seconds or on the first input.
	 */
	var TIMING = {
		settleMin: 1500,
		settleQuiet: 800,
		settleMax: 8000,
		scrollStep: 150,
		maxScrollSteps: 40,
		afterInput: 6000,
		quiet: 1500,
		cap: 25000,
		bannerPoll: 400,
	};
	// Test hook (docs/decisions.md): the 120-page run test shortens the watch so it finishes in minutes.
	if ( window.consentwellTiming && typeof window.consentwellTiming === 'object' ) {
		Object.keys( TIMING ).forEach( function ( key ) {
			if ( typeof window.consentwellTiming[ key ] === 'number' ) {
				TIMING[ key ] = window.consentwellTiming[ key ];
			}
		} );
	}

	var PLUGINS = {
		complianz: {
			hideClasses: [ 'cmplz-hidden' ],
			find: function ( doc, win ) {
				var cfg = win.complianz;
				var el = null;
				if ( cfg && typeof cfg === 'object' && cfg.user_banner_id && cfg.consenttype ) {
					el = doc.querySelector( '.cmplz-cookiebanner.banner-' + cfg.user_banner_id + '.' + cfg.consenttype );
				}
				if ( ! el ) {
					el = doc.querySelector( '.cmplz-cookiebanner.optin' ) || doc.querySelector( '.cmplz-cookiebanner' );
				}
				return el;
			},
			reject: function ( el ) {
				return el.querySelector( '.cmplz-btn.cmplz-deny' ) || el.querySelector( '.cmplz-deny' );
			},
			scriptLoaded: function ( doc ) {
				return !! doc.querySelector( 'script[src*="cookiebanner/js/complianz"]' );
			},
			config: function ( win ) {
				var cfg = win.complianz;
				if ( ! cfg || typeof cfg !== 'object' ) {
					return { present: false };
				}
				return {
					present: true,
					do_not_track_enabled: !! cfg.do_not_track_enabled,
					consenttype: String( cfg.consenttype || '' ),
					disable_cookiebanner: !! cfg.disable_cookiebanner,
				};
			},
		},
		cookieyes: {
			hideClasses: [ 'cky-hide' ],
			find: function ( doc ) {
				return doc.querySelector( '.cky-consent-container' ) || doc.querySelector( '[data-cky-tag="notice"]' );
			},
			reject: function ( el ) {
				return el.querySelector( '[data-cky-tag="reject-button"]' ) || el.querySelector( '.cky-btn-reject' );
			},
			scriptLoaded: function ( doc ) {
				return !! doc.querySelector( 'script#cookieyes, script[src*="cookie-law-info"][src*="script"], script[src*="cdn-cookieyes.com"]' );
			},
			config: function ( win ) {
				return { present: !! win._ckyConfig };
			},
		},
	};

	function sleep( ms ) {
		return new Promise( function ( resolve ) {
			setTimeout( resolve, ms );
		} );
	}

	function api( path, body, keepalive ) {
		return fetch( data.rest + path, {
			method: body ? 'POST' : 'GET',
			credentials: 'same-origin',
			// keepalive lets a request finish even if the admin leaves the screen right away.
			keepalive: !! keepalive,
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': data.nonce },
			body: body ? JSON.stringify( body ) : undefined,
		} ).then( function ( response ) {
			return response.json().catch( function () {
				return {};
			} ).then( function ( json ) {
				if ( ! response.ok ) {
					throw new Error( json && json.message ? json.message : 'HTTP ' + response.status );
				}
				return json;
			} );
		} );
	}

	function hostKey( host ) {
		host = String( host || '' ).toLowerCase().replace( /\.$/, '' );
		return host.indexOf( 'www.' ) === 0 ? host.slice( 4 ) : host;
	}

	function isThirdParty( url ) {
		try {
			var u = new URL( url );
			if ( u.protocol !== 'http:' && u.protocol !== 'https:' ) {
				return false;
			}
			return hostKey( u.hostname ) !== data.siteHost;
		} catch ( e ) {
			return false;
		}
	}

	/* Cookies ------------------------------------------------------------------------------- */

	function inList( name, list ) {
		if ( ! list ) {
			return false;
		}
		if ( list.names.indexOf( name ) !== -1 ) {
			return true;
		}
		return list.prefixes.some( function ( prefix ) {
			return name.indexOf( prefix ) === 0;
		} );
	}

	function readCookies( doc ) {
		return String( doc.cookie || '' ).split( ';' ).map( function ( part ) {
			return part.trim();
		} ).filter( Boolean ).map( function ( part ) {
			var i = part.indexOf( '=' );
			return { name: i < 0 ? part : part.slice( 0, i ), value: i < 0 ? '' : part.slice( i + 1 ) };
		} );
	}

	/** Every path a cookie readable at this address can have: /, /a, /a/, /a/b, /a/b/ … */
	function pathVariants( pathname ) {
		var out = [ '/' ];
		var acc = '';
		String( pathname || '/' ).split( '/' ).filter( Boolean ).forEach( function ( part ) {
			acc += '/' + part;
			out.push( acc, acc + '/' );
		} );
		return out;
	}

	/** The path a cookie set without a path attribute gets on this address. */
	function defaultPath( pathname ) {
		var i = String( pathname || '/' ).lastIndexOf( '/' );
		return i > 0 ? pathname.slice( 0, i ) : '/';
	}

	function expireCookie( name, paths ) {
		var parts = location.hostname.split( '.' );
		var domains = [ '' ];
		for ( var i = 0; i < parts.length - 1; i++ ) {
			domains.push( parts.slice( i ).join( '.' ) );
			domains.push( '.' + parts.slice( i ).join( '.' ) );
		}
		domains.forEach( function ( domain ) {
			paths.forEach( function ( path ) {
				document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=' + path + ( domain ? '; domain=' + domain : '' );
			} );
		} );
	}

	function cookieStoreOf( win ) {
		try {
			return win && win.cookieStore && typeof win.cookieStore.getAll === 'function' ? win.cookieStore : null;
		} catch ( e ) {
			return null;
		}
	}

	/** True when this browser can tell us a cookie's expiry, path, domain and SameSite (Cookie Store API). */
	function canReadCookieAttributes() {
		return !! cookieStoreOf( window );
	}

	/**
	 * The cookies a document can read, with their attributes where the browser tells them
	 * (expiry, path, domain, SameSite, Secure), WordPress's own cookies left out.
	 *
	 * @param {Document} doc The admin screen, or the check window at the checked page's address.
	 * @param {Window}   win Window of that document.
	 */
	async function snapshotCookies( doc, win ) {
		var pathname = doc.location.pathname;
		var store = cookieStoreOf( win );
		var list = null;
		if ( store ) {
			try {
				list = ( await store.getAll() ).map( function ( c ) {
					return {
						name: c.name,
						value: c.value,
						path: c.path || '/',
						domain: c.domain || '',
						expires: typeof c.expires === 'number' ? c.expires : 0,
						sameSite: c.sameSite || '',
						secure: !! c.secure,
					};
				} );
			} catch ( e ) {
				list = null;
			}
		}
		if ( ! list ) {
			list = readCookies( doc ).map( function ( c ) {
				return { name: c.name, value: c.value, path: doc === document ? '/' : defaultPath( pathname ), domain: '', expires: 0, sameSite: 'lax', secure: false };
			} );
		}
		return list.filter( function ( c ) {
			return ! inList( c.name, data.cookies.wordpress );
		} );
	}

	/** The document.cookie string that puts a snapshot cookie back exactly as it was. */
	function cookieString( c ) {
		var text = c.name + '=' + c.value + '; path=' + ( c.path || '/' );
		if ( c.domain ) {
			text += '; domain=' + c.domain;
		}
		if ( c.expires ) {
			text += '; expires=' + new Date( c.expires ).toUTCString();
		}
		if ( c.sameSite ) {
			text += '; SameSite=' + c.sameSite.charAt( 0 ).toUpperCase() + c.sameSite.slice( 1 );
		}
		if ( c.secure || c.sameSite === 'none' ) {
			text += '; Secure';
		}
		return text;
	}

	/**
	 * Remove the cookies a document can read so the check starts as a visitor with no consent stored.
	 * When the browser can tell us each cookie's attributes, every cookie except WordPress's own is
	 * removed (a cookie left from an earlier visit, such as a tracker's, would hide what the page sets
	 * after Reject) and put back exactly as it was after the check. When it cannot, only cookies named
	 * like a consent record are removed, and the names of the others are kept out of the lists.
	 * Returns what was removed, to put back after.
	 *
	 * @param {Document} doc   Document whose cookies to read.
	 * @param {Window}   win   Its window.
	 * @param {Object}   state { saved: [], untouched: [] } collected so far.
	 */
	async function clearCookies( doc, win, state ) {
		var full = canReadCookieAttributes();
		var keyOf = function ( c ) {
			return full ? c.name + '\n' + c.path : c.name;
		};
		var seen = state.saved.map( keyOf );
		var pathname = doc.location.pathname;
		var paths = pathVariants( pathname ).concat( [ location.pathname.replace( /[^/]*$/, '' ) ] );
		( await snapshotCookies( doc, win ) ).forEach( function ( c ) {
			if ( seen.indexOf( keyOf( c ) ) !== -1 ) {
				return;
			}
			if ( ! full && ! inList( c.name, data.cookies.consent ) && ! CONSENT_COOKIE_NAME.test( c.name ) ) {
				if ( state.untouched.indexOf( c.name ) === -1 ) {
					state.untouched.push( c.name );
				}
				return;
			}
			state.saved.push( c );
			expireCookie( c.name, full ? [ c.path ].concat( paths ) : paths );
		} );
	}

	/** Remove what the check set, and put back the admin's own cookies as they were. */
	function restoreCookies( state, lastDoc ) {
		if ( ! state || state.restored ) {
			return;
		}
		state.restored = true;
		[ document, lastDoc ].forEach( function ( doc ) {
			if ( ! doc ) {
				return;
			}
			try {
				var paths = pathVariants( doc.location.pathname ).concat( [ location.pathname.replace( /[^/]*$/, '' ) ] );
				readCookies( doc ).forEach( function ( c ) {
					if ( ! inList( c.name, data.cookies.wordpress ) && state.untouched.indexOf( c.name ) === -1 ) {
						expireCookie( c.name, paths );
					}
				} );
			} catch ( e ) {}
		} );
		state.saved.forEach( function ( c ) {
			document.cookie = cookieString( c );
		} );
	}

	/* Check window ---------------------------------------------------------------------------- */

	function openWindow( container, url ) {
		return new Promise( function ( resolve ) {
			var frame = document.createElement( 'iframe' );
			var done = false;
			frame.className = 'consentwell-frame';
			frame.setAttribute( 'title', __( 'Check window' ) );
			// No top navigation: a checked page cannot navigate the admin screen away.
			frame.setAttribute( 'sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-modals' );
			frame.addEventListener( 'load', function () {
				var href = '';
				try {
					href = frame.contentWindow.location.href;
				} catch ( e ) {}
				if ( href === 'about:blank' ) {
					return;
				}
				if ( ! done ) {
					done = true;
					resolve( { frame: frame, timedOut: false, loadedAt: Date.now() } );
				}
			} );
			setTimeout( function () {
				if ( ! done ) {
					done = true;
					resolve( { frame: frame, timedOut: true, loadedAt: Date.now() } );
				}
			}, 30000 );
			frame.src = url;
			container.innerHTML = '';
			container.appendChild( frame );
		} );
	}

	function frameAccess( frame ) {
		try {
			var doc = frame.contentDocument;
			var win = frame.contentWindow;
			if ( ! doc || ! win || ! doc.documentElement || doc.location.href === 'about:blank' ) {
				return null;
			}
			return { doc: doc, win: win };
		} catch ( e ) {
			return null;
		}
	}

	function resourceCount( win ) {
		try {
			return win.performance.getEntriesByType( 'resource' ).length;
		} catch ( e ) {
			return 0;
		}
	}

	/** Wait until the page has been quiet (no new requests, no DOM changes) for a moment. */
	function settle( win, doc, minMs, maxMs ) {
		return new Promise( function ( resolve ) {
			var start = Date.now();
			var last = start;
			var count = resourceCount( win );
			var observer = null;
			try {
				observer = new win.MutationObserver( function () {
					last = Date.now();
				} );
				observer.observe( doc.documentElement, { subtree: true, childList: true, attributes: true } );
			} catch ( e ) {}
			var timer = setInterval( function () {
				var c = resourceCount( win );
				var now = Date.now();
				if ( c !== count ) {
					count = c;
					last = now;
				}
				if ( ( now - start >= minMs && now - last >= TIMING.settleQuiet ) || now - start >= maxMs ) {
					clearInterval( timer );
					if ( observer ) {
						observer.disconnect();
					}
					resolve();
				}
			}, 200 );
		} );
	}

	/* Reading the page ------------------------------------------------------------------------- */

	function describe( el ) {
		if ( ! el || ! el.tagName ) {
			return '';
		}
		var text = el.tagName.toLowerCase();
		if ( el.id ) {
			text += '#' + el.id;
		}
		var classes = String( el.getAttribute( 'class' ) || '' ).trim().split( /\s+/ ).filter( Boolean ).slice( 0, 3 );
		if ( classes.length ) {
			text += '.' + classes.join( '.' );
		}
		return text.slice( 0, 120 );
	}

	/** The parent element, crossing from an open shadow root to its host. */
	function parentOf( node ) {
		return node.parentElement || ( node.parentNode && node.parentNode.host ) || null;
	}

	function hideClassOn( node, hideClasses ) {
		var list = hideClasses.concat( GENERIC_HIDE_CLASSES );
		for ( var i = 0; i < list.length; i++ ) {
			if ( node.classList && node.classList.contains( list[ i ] ) ) {
				return list[ i ];
			}
		}
		return '';
	}

	function visibleRect( el ) {
		var rect = el.getBoundingClientRect();
		if ( rect.width >= 2 && rect.height >= 2 ) {
			return rect;
		}
		// A wrapper can have no size of its own while its fixed-position content does.
		var children = el.querySelectorAll( '*' );
		for ( var i = 0; i < children.length && i < 200; i++ ) {
			var r = children[ i ].getBoundingClientRect();
			if ( r.width >= 2 && r.height >= 2 ) {
				return r;
			}
		}
		return rect;
	}

	/** Why an element is not visible on screen; an empty list means it is visible. */
	function hiddenBy( el, win, doc, hideClasses ) {
		var facts = [];
		for ( var node = el; node && node.nodeType === 1 && node !== doc.documentElement; node = parentOf( node ) ) {
			var cs = win.getComputedStyle( node );
			var cls = hideClassOn( node, hideClasses );
			if ( cs.display === 'none' ) {
				if ( cls ) {
					facts.push( { kind: 'class', detail: cls, element: describe( node ) } );
				} else if ( node.hidden ) {
					facts.push( { kind: 'hidden-attr', element: describe( node ) } );
				} else {
					facts.push( { kind: 'display', element: describe( node ) } );
				}
				return facts;
			}
			if ( cs.visibility === 'hidden' || cs.visibility === 'collapse' ) {
				var parent = parentOf( node );
				var parentHidden = parent && parent !== doc.documentElement && win.getComputedStyle( parent ).visibility === 'hidden';
				if ( ! parentHidden ) {
					facts.push( cls ? { kind: 'class', detail: cls, element: describe( node ) } : { kind: 'visibility', element: describe( node ) } );
					return facts;
				}
			}
			if ( parseFloat( cs.opacity ) < 0.05 ) {
				facts.push( cls ? { kind: 'class', detail: cls, element: describe( node ) } : { kind: 'opacity', element: describe( node ) } );
				return facts;
			}
		}
		var rect = visibleRect( el );
		if ( rect.width < 2 || rect.height < 2 ) {
			facts.push( { kind: 'size', detail: Math.round( rect.width ) + ' × ' + Math.round( rect.height ), element: describe( el ) } );
			return facts;
		}
		var vw = win.innerWidth;
		var vh = win.innerHeight;
		if ( rect.bottom <= 0 || rect.right <= 0 || rect.top >= vh || rect.left >= vw ) {
			facts.push( {
				kind: 'offscreen',
				detail: 'top ' + Math.round( rect.top ) + ' px, left ' + Math.round( rect.left ) + ' px; window ' + vw + ' × ' + vh,
				element: describe( el ),
			} );
		}
		return facts;
	}

	/** Elements in the page and inside every open shadow root (closed shadow roots cannot be read). */
	function allElements( doc ) {
		var out = [];
		var roots = [ doc ];
		for ( var r = 0; r < roots.length && r < 100; r++ ) {
			var all = roots[ r ].querySelectorAll( '*' );
			for ( var i = 0; i < all.length && i < 6000; i++ ) {
				out.push( all[ i ] );
				if ( all[ i ].shadowRoot ) {
					roots.push( all[ i ].shadowRoot );
					// The top-level elements of a shadow root are candidates too.
					for ( var c = 0; c < all[ i ].shadowRoot.children.length; c++ ) {
						out.push( all[ i ].shadowRoot.children[ c ] );
					}
				}
			}
		}
		return out;
	}

	/**
	 * A banner that no consent plugin Consentwell knows by name put on the page: an element, in the
	 * page or in an open shadow root, whose id, class or label mentions cookies, consent or GDPR, or
	 * that is fixed or sticky on screen or a dialog, whose text mentions cookies or consent, and
	 * that has buttons labelled like a choice (Accept, Reject, Allow …). Only visible ones count.
	 */
	function findGenericBanner( doc, win ) {
		var keyword = /cookie|consent|gdpr/i;
		var viewport = win.innerWidth * win.innerHeight;
		var nodes = allElements( doc );
		var best = null;
		var bestArea = 0;
		for ( var i = 0; i < nodes.length; i++ ) {
			var el = nodes[ i ];
			if ( el === doc.body || el === doc.documentElement || /^(script|style|link|meta|template|noscript|head|html|body)$/i.test( el.tagName ) ) {
				continue;
			}
			var byName = el.id === 'CybotCookiebotDialog' || keyword.test( el.id || '' ) || keyword.test( String( el.getAttribute( 'class' ) || '' ) ) || keyword.test( el.getAttribute( 'aria-label' ) || '' );
			var byPlace = false;
			if ( ! byName ) {
				var role = el.getAttribute( 'role' );
				var position = '';
				try {
					position = win.getComputedStyle( el ).position;
				} catch ( e ) {}
				byPlace = role === 'dialog' || role === 'alertdialog' || el.getAttribute( 'aria-modal' ) === 'true' || el.tagName === 'DIALOG' || position === 'fixed' || position === 'sticky';
			}
			if ( ! byName && ! byPlace ) {
				continue;
			}
			var text = ( el.innerText || el.textContent || '' ).slice( 0, 3000 );
			if ( text.length < 20 || ! ( byName ? BANNER_WORDS : STRONG_BANNER_WORDS ).test( text ) ) {
				continue;
			}
			var buttons = el.querySelectorAll( 'button, a, [role="button"], input[type="button"], input[type="submit"]' );
			var hasChoice = false;
			for ( var b = 0; b < buttons.length; b++ ) {
				if ( CHOICE_WORDS.test( buttons[ b ].innerText || buttons[ b ].value || '' ) ) {
					hasChoice = true;
					break;
				}
			}
			if ( ! hasChoice || hiddenBy( el, win, doc, [] ).length ) {
				continue;
			}
			var rect = visibleRect( el );
			var area = rect.width * rect.height;
			if ( area > bestArea && area < viewport * 1.01 && ( byName || area <= viewport * 0.6 ) ) {
				best = el;
				bestArea = area;
			}
		}
		// Prefer the outermost element that still has the same banner in it.
		while ( best && best.parentElement && best.parentElement !== doc.body && best.parentElement !== doc.documentElement && ( best.parentElement.innerText || '' ).length < ( best.innerText || '' ).length + 40 && ! hiddenBy( best.parentElement, win, doc, [] ).length && visibleRect( best.parentElement ).width * visibleRect( best.parentElement ).height <= viewport * 1.01 ) {
			best = best.parentElement;
		}
		return best;
	}

	function findRejectByText( el, win, doc ) {
		var buttons = el.querySelectorAll( 'button, a, [role="button"], input[type="button"], input[type="submit"]' );
		var fallback = null;
		for ( var i = 0; i < buttons.length; i++ ) {
			var label = ( buttons[ i ].innerText || buttons[ i ].value || buttons[ i ].getAttribute( 'aria-label' ) || '' ).trim();
			if ( REJECT_TEXT.test( label ) ) {
				if ( ! hiddenBy( buttons[ i ], win, doc, [] ).length ) {
					return buttons[ i ];
				}
				fallback = fallback || buttons[ i ];
			}
		}
		return fallback;
	}

	function inspectBanner( doc, win, slug ) {
		var def = PLUGINS[ slug ];
		var el = def ? def.find( doc, win ) : findGenericBanner( doc, win );
		if ( ! el ) {
			return { info: { found: false, source: def ? slug : 'generic' }, el: null, reject: null };
		}
		var hideClasses = def ? def.hideClasses : [];
		var facts = hiddenBy( el, win, doc, hideClasses );
		var rejectEl = def ? def.reject( el ) : findRejectByText( el, win, doc );
		var rejectFacts = rejectEl ? hiddenBy( rejectEl, win, doc, hideClasses ) : [];
		return {
			info: {
				found: true,
				source: def ? slug : 'generic',
				element: describe( el ),
				visible: facts.length === 0,
				hidden_by: facts,
				reject: {
					found: !! rejectEl,
					visible: !! rejectEl && rejectFacts.length === 0,
					hidden_by: rejectFacts,
				},
			},
			el: el,
			reject: rejectEl,
		};
	}

	function typeOf( entry ) {
		var it = String( entry.initiatorType || '' ).toLowerCase();
		var path = '';
		try {
			path = new URL( entry.name ).pathname.toLowerCase();
		} catch ( e ) {}
		if ( /\.(woff2?|ttf|otf|eot)$/.test( path ) ) {
			return 'font';
		}
		if ( it === 'script' ) {
			return 'script';
		}
		if ( it === 'iframe' || it === 'frame' || it === 'embed' || it === 'object' ) {
			return 'frame';
		}
		if ( it === 'img' || it === 'image' || it === 'input' || it === 'beacon' || it === 'ping' ) {
			return 'image';
		}
		if ( it === 'video' || it === 'audio' || it === 'track' ) {
			return 'media';
		}
		if ( it === 'fetch' || it === 'xmlhttprequest' || it === 'eventsource' ) {
			return 'fetch';
		}
		if ( /\.css$/.test( path ) || /fonts\.googleapis\.com$/.test( ( function () {
			try {
				return new URL( entry.name ).hostname;
			} catch ( e ) {
				return '';
			}
		} )() ) ) {
			return 'stylesheet';
		}
		if ( /\.(png|jpe?g|gif|webp|svg|ico|avif|bmp)$/.test( path ) ) {
			return 'image';
		}
		if ( /\.m?js$/.test( path ) ) {
			return 'script';
		}
		if ( it === 'link' ) {
			return 'stylesheet';
		}
		return 'other';
	}

	function collect( win, doc, ignoreCookies ) {
		var requests = [];
		var errors = [];
		var seen = {};
		var entries = [];
		try {
			entries = win.performance.getEntriesByType( 'resource' );
		} catch ( e ) {}
		entries.forEach( function ( entry ) {
			var url = String( entry.name || '' );
			if ( ! /^https?:/i.test( url ) ) {
				return;
			}
			if ( typeof entry.responseStatus === 'number' && entry.responseStatus >= 400 ) {
				errors.push( { url: url, status: entry.responseStatus } );
			}
			if ( ! isThirdParty( url ) || seen[ url ] ) {
				return;
			}
			seen[ url ] = true;
			requests.push( { url: url, type: typeOf( entry ) } );
		} );
		return {
			requests: requests,
			cookies: readCookies( doc ).map( function ( c ) {
				return c.name;
			} ).filter( function ( name ) {
				return ( ignoreCookies || [] ).indexOf( name ) === -1;
			} ),
			errors: errors,
		};
	}

	function readProbe( win, statusErrors ) {
		var probe = win.__consentwellProbe || null;
		var resourceErrors = statusErrors.slice();
		if ( probe ) {
			probe.resourceErrors.forEach( function ( e ) {
				var known = resourceErrors.some( function ( r ) {
					return r.url === e.url;
				} );
				if ( ! known ) {
					resourceErrors.push( { url: e.url, status: 0 } );
				}
			} );
		}
		return {
			head: !! probe,
			footer: !! ( probe && probe.footer ) || !! win.document.getElementById( 'consentwell-footer-marker' ),
			errors: probe ? probe.errors.slice( 0, 50 ) : [],
			resource_errors: resourceErrors.slice( 0, 50 ),
		};
	}

	function waitForManualReject( access, bannerEl, opts ) {
		return new Promise( function ( resolve ) {
			var finished = false;
			function finish() {
				if ( finished ) {
					return;
				}
				finished = true;
				access.doc.removeEventListener( 'click', onClick, true );
				resolve( true );
			}
			function onClick( event ) {
				// A click inside a shadow root is retargeted to the host; the composed path has the real element.
				var path = event.composedPath ? event.composedPath() : [];
				var origin = path[ 0 ] || event.target;
				var target = origin && origin.closest ? origin.closest( 'button, a, [role="button"], input' ) : null;
				if ( ! target ) {
					return;
				}
				var label = ( target.innerText || target.value || target.getAttribute( 'aria-label' ) || '' ).trim();
				var inBanner = !! bannerEl && ( bannerEl.contains( target ) || path.indexOf( bannerEl ) !== -1 );
				if ( REJECT_TEXT.test( label ) || ( inBanner && ! /accept|agree|allow|akzept|zustimm|accepter|aceptar|accetta/i.test( label ) ) ) {
					setTimeout( finish, 300 );
				}
			}
			access.doc.addEventListener( 'click', onClick, true );
			if ( opts.manualReject ) {
				opts.manualReject().then( finish );
			}
		} );
	}

	/* Watching like a visitor ------------------------------------------------------------------ */

	function fire( win, doc, type, make ) {
		try {
			( doc.body || doc.documentElement ).dispatchEvent( make( win, type ) );
		} catch ( e ) {}
	}

	/** The input a visitor makes: the events script-delay plugins and lazy loaders wait for. */
	function simulateInput( win, doc ) {
		var mouse = function ( w, type ) {
			return new w.MouseEvent( type, { bubbles: true, cancelable: true, clientX: 240, clientY: 220, view: w } );
		};
		fire( win, doc, 'mouseover', mouse );
		fire( win, doc, 'mousemove', mouse );
		fire( win, doc, 'keydown', function ( w, type ) {
			return new w.KeyboardEvent( type, { bubbles: true, cancelable: true, key: 'Shift', code: 'ShiftLeft' } );
		} );
		var touch = function ( w, type ) {
			return typeof w.TouchEvent === 'function' ? new w.TouchEvent( type, { bubbles: true, cancelable: true } ) : new w.Event( type, { bubbles: true, cancelable: true } );
		};
		fire( win, doc, 'touchstart', touch );
		fire( win, doc, 'touchmove', touch );
		fire( win, doc, 'wheel', function ( w, type ) {
			return new w.WheelEvent( type, { bubbles: true, cancelable: true, deltaY: 120 } );
		} );
	}

	function pageHeight( doc ) {
		return Math.max( doc.documentElement ? doc.documentElement.scrollHeight : 0, doc.body ? doc.body.scrollHeight : 0 );
	}

	/** Scroll to the bottom in steps (lazy-loaded content starts when it comes near the screen), then back to the top. */
	async function scrollThrough( win, doc ) {
		var view = win.innerHeight || 600;
		var step = Math.max( 200, Math.round( view * 0.8 ) );
		var position = 0;
		var steps = 0;
		while ( steps < TIMING.maxScrollSteps && position + view < pageHeight( doc ) ) {
			position += step;
			win.scrollTo( 0, position );
			steps++;
			await sleep( TIMING.scrollStep );
		}
		var limit = position + view < pageHeight( doc );
		win.scrollTo( 0, pageHeight( doc ) );
		await sleep( TIMING.scrollStep );
		win.scrollTo( 0, 0 );
		return { steps: steps, limit: limit };
	}

	/**
	 * Watch a loaded page the way a visitor uses it: wait for it to settle, send input, scroll to the
	 * bottom, then keep watching until a fixed time has passed since the last input with no new request.
	 *
	 * @param {Object}   access   { doc, win }.
	 * @param {number}   loadedAt Time the page finished loading.
	 * @param {Function} onSettled Called once the page has settled, before any input is sent.
	 * @return {Promise<Object>} { seconds, scrollLimit } seconds watched since the page loaded.
	 */
	async function watchPage( access, loadedAt, onSettled ) {
		var win = access.win;
		var doc = access.doc;
		await settle( win, doc, TIMING.settleMin, TIMING.settleMax );
		if ( onSettled ) {
			onSettled();
		}
		var count = resourceCount( win );
		var lastNew = Date.now();
		var tick = function () {
			var c = resourceCount( win );
			if ( c !== count ) {
				count = c;
				lastNew = Date.now();
			}
		};
		var poller = setInterval( tick, 200 );
		try {
			simulateInput( win, doc );
			var scroll = await scrollThrough( win, doc );
			var lastInput = Date.now();
			simulateInput( win, doc );
			var started = Date.now();
			while ( true ) {
				await sleep( 200 );
				var now = Date.now();
				if ( ( now - lastInput >= TIMING.afterInput && now - lastNew >= TIMING.quiet ) || now - started >= TIMING.cap ) {
					break;
				}
			}
			tick();
			return { seconds: Math.round( ( Date.now() - loadedAt ) / 1000 ), scrollLimit: scroll.limit };
		} finally {
			clearInterval( poller );
		}
	}

	function loggedInPage( doc ) {
		return !! ( doc.getElementById( 'wpadminbar' ) || ( doc.body && doc.body.classList.contains( 'logged-in' ) ) );
	}

	function refusedPage( doc ) {
		return !! ( doc.body && doc.body.id === 'error-page' && doc.title && /expired|not valid/i.test( doc.body.innerText || '' ) );
	}

	/* The check --------------------------------------------------------------------------------- */

	/**
	 * Run one check.
	 *
	 * @param {Object}   opts
	 * @param {string}   opts.url          Page address on this site.
	 * @param {Element}  opts.container    Element the check window goes in.
	 * @param {boolean}  opts.store        Keep the result in the last-20 list (default true).
	 * @param {boolean}  opts.batch        No manual Reject (unrecognised banners are not clicked).
	 * @param {Function} opts.onStep       Progress messages.
	 * @param {Function} opts.manualReject Called when the admin must click Reject; returns a Promise
	 *                                     that resolves if the admin confirms by another way.
	 * @param {Function} opts.onManual     Called with true/false when manual waiting starts/ends.
	 * @return {Promise<Object>} REST payload { check, text, html, table_html? }.
	 */
	async function run( opts ) {
		var step = opts.onStep || function () {};
		var store = opts.store !== false;

		step( __( 'Fetching the page as a logged-out visitor (server side)…' ) );
		var prep = await api( 'prepare', { url: opts.url, store: store } );
		if ( prep.frame_blocked ) {
			return prep;
		}
		var slug = prep.plugin ? prep.plugin.slug : '';
		var cookies = { saved: [], untouched: [], restored: false };
		var lastDoc = null;
		var browser = { env: {}, probe: {}, plugin_js: {}, reject: { mode: 'none', clicked: false }, watch: {} };
		// Leaving the screen (another menu item, closing the tab) must not leave the admin's cookies deleted.
		var onLeave = function () {
			restoreCookies( cookies, lastDoc );
		};
		window.addEventListener( 'pagehide', onLeave );
		try {
			await clearCookies( document, window, cookies );
			// An empty document at the page's own address first, to clear cookies scoped to that path.
			var blank = frameAccess( ( await openWindow( opts.container, prep.blank_url ) ).frame );
			if ( blank ) {
				await clearCookies( blank.doc, blank.win, cookies );
			}
			browser.cookie_mode = canReadCookieAttributes() ? 'all' : 'consent-only';

			step( __( 'Opening the page in the check window, before any choice…' ) );
			var opened = await openWindow( opts.container, prep.frame_url );
			var access = frameAccess( opened.frame );
			if ( ! access ) {
				browser.frame = { blocked: true };
				return await api( 'results', { check_id: prep.check_id, browser: browser, store: store } );
			}
			lastDoc = access.doc;
			if ( refusedPage( access.doc ) ) {
				throw new Error( __( 'The site refused the check link. Start the check again.' ) );
			}
			if ( loggedInPage( access.doc ) ) {
				throw new Error( __( 'The page redirected to an address without the check token, so it opened as you (logged in) instead of as a visitor. Check the final address of the page instead.' ) );
			}

			// Look for the banner from the moment the page has loaded until the watching ends. The result is
			// the state at the end; when the banner only became visible later (a script delay holds
			// back the consent plugin's script) the time is kept, instead of reporting "did not show".
			var banner = null;
			var visibleSince = null;
			var visibleAtSettle = false;
			var look = function () {
				try {
					var found = inspectBanner( access.doc, access.win, slug );
					if ( found.info.found || ! banner ) {
						banner = found;
					}
					if ( found.info.found && found.info.visible ) {
						visibleSince = visibleSince === null ? Date.now() : visibleSince;
					} else {
						visibleSince = null;
					}
				} catch ( e ) {}
			};
			look();
			var looker = setInterval( look, TIMING.bannerPoll );
			var watched;
			try {
				step( __( 'Scrolling the page and watching for late requests…' ) );
				watched = await watchPage( access, opened.loadedAt, function () {
					look();
					visibleAtSettle = visibleSince !== null;
				} );
			} finally {
				clearInterval( looker );
			}
			look();
			browser.watch.before = watched.seconds;
			browser.watch.scroll_limit = watched.scrollLimit;
			if ( banner.info.found && banner.info.visible && visibleSince !== null && ! visibleAtSettle ) {
				banner.info.shown_after = Math.round( ( visibleSince - opened.loadedAt ) / 100 ) / 10;
			}
			if ( banner.info.found && ! banner.info.visible && visibleAtSettle ) {
				banner.info.visible_at_settle = true;
			}

			var nav = access.win.navigator;
			browser.env = {
				dnt: nav.doNotTrack === '1' || nav.doNotTrack === 'yes' || access.win.doNotTrack === '1',
				gpc: nav.globalPrivacyControl === true,
			};
			var before = collect( access.win, access.doc, cookies.untouched );
			browser.probe = readProbe( access.win, before.errors );
			if ( slug && PLUGINS[ slug ] ) {
				browser.plugin_js[ slug ] = PLUGINS[ slug ].config( access.win );
				browser.consent_script_loaded = PLUGINS[ slug ].scriptLoaded( access.doc );
			}
			browser.banner = banner.info;
			browser.before = { requests: before.requests, cookies: before.cookies };

			if ( banner.info.found ) {
				if ( ! banner.el.isConnected ) {
					banner = inspectBanner( access.doc, access.win, slug );
				}
				if ( PLUGINS[ slug ] && banner.reject ) {
					step( __( 'Clicking Reject in the banner…' ) );
					banner.reject.click();
					browser.reject = { mode: 'auto', clicked: true };
				} else if ( ! PLUGINS[ slug ] && ! opts.batch && banner.el ) {
					step( __( 'Waiting for you to click Reject in the check window…' ) );
					if ( opts.onManual ) {
						opts.onManual( true );
					}
					await waitForManualReject( access, banner.el, opts );
					if ( opts.onManual ) {
						opts.onManual( false );
					}
					browser.reject = { mode: 'manual', clicked: true };
				}
			}

			if ( browser.reject.clicked ) {
				await sleep( 1500 );
				step( __( 'Reloading the page after Reject…' ) );
				var fresh = await api( 'token', { check_id: prep.check_id } );
				var reopened = await openWindow( opts.container, fresh.frame_url );
				var access2 = frameAccess( reopened.frame );
				if ( access2 ) {
					lastDoc = access2.doc;
					step( __( 'Scrolling the page and watching for late requests…' ) );
					var watchedAfter = await watchPage( access2, reopened.loadedAt );
					var after = collect( access2.win, access2.doc, cookies.untouched );
					browser.after = { requests: after.requests, cookies: after.cookies };
					browser.watch.after = watchedAfter.seconds;
					browser.watch.scroll_limit = browser.watch.scroll_limit || watchedAfter.scrollLimit;
				}
			}
			step( __( 'Writing up the result…' ) );
			return await api( 'results', { check_id: prep.check_id, browser: browser, store: store } );
		} finally {
			window.removeEventListener( 'pagehide', onLeave );
			restoreCookies( cookies, lastDoc );
		}
	}

	window.consentwellCheck = { run: run, api: api };
} )();
