/**
 * Tools > Consentwell screen.
 *
 * @package Consentwell
 */
( function () {
	'use strict';

	var __ = window.wp.i18n.__;
	var engine = window.consentwellCheck;
	var $ = function ( id ) {
		return document.getElementById( id );
	};

	var form = $( 'consentwell-form' );
	var runButton = $( 'consentwell-run' );
	var serverButton = $( 'consentwell-run-server' );
	var status = $( 'consentwell-status' );
	var manual = $( 'consentwell-manual' );
	var manualDone = $( 'consentwell-manual-done' );
	var windowWrap = $( 'consentwell-window-wrap' );
	var windowBox = $( 'consentwell-window' );
	var resultBox = $( 'consentwell-result' );
	var tableBox = $( 'consentwell-table' );
	var busy = false;
	var manualResolve = null;

	function chosenUrl() {
		var typed = $( 'consentwell-url' ).value.trim();
		return typed || $( 'consentwell-page' ).value;
	}

	function setStatus( text, kind ) {
		status.hidden = false;
		status.className = 'consentwell-status' + ( kind ? ' consentwell-status-' + kind : '' );
		status.textContent = text;
	}

	function setBusy( value ) {
		busy = value;
		runButton.disabled = value;
		serverButton.disabled = value;
		document.querySelectorAll( '.consentwell-again' ).forEach( function ( b ) {
			b.disabled = value;
		} );
	}

	function show( payload ) {
		resultBox.innerHTML = payload.html;
		if ( payload.table_html ) {
			tableBox.innerHTML = payload.table_html;
		}
		resultBox.scrollIntoView( { behavior: 'smooth', block: 'start' } );
	}

	async function check( url, mode ) {
		if ( busy ) {
			return;
		}
		setBusy( true );
		resultBox.innerHTML = '';
		try {
			var payload;
			if ( mode === 'server' ) {
				windowWrap.hidden = true;
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				payload = await engine.api( 'server-check', { url: url, store: true } );
			} else {
				windowWrap.hidden = false;
				// The status line and the whole check window share one screen: the banner appears at the window's bottom edge.
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				status.scrollIntoView( { block: 'start' } );
				payload = await engine.run( {
					url: url,
					container: windowBox,
					store: true,
					onStep: function ( text ) {
						setStatus( text );
					},
					onManual: function ( waiting ) {
						manual.hidden = ! waiting;
						// The prompt says it all: the status line would repeat it.
						status.hidden = waiting;
						if ( waiting ) {
							// Show the prompt and the whole check window, where the banner is.
							manual.scrollIntoView( { block: 'start' } );
						}
					},
					manualReject: function () {
						return new Promise( function ( resolve ) {
							manualResolve = resolve;
						} );
					},
				} );
			}
			if ( payload.frame_blocked ) {
				windowWrap.hidden = true;
				setStatus( __( 'This page cannot open in the check window, so the server-side result is shown instead.', 'consentwell' ), 'warning' );
			} else {
				setStatus( __( 'Check finished.', 'consentwell' ), 'done' );
			}
			show( payload );
		} catch ( error ) {
			setStatus( __( 'The check could not finish:', 'consentwell' ) + ' ' + error.message, 'error' );
		} finally {
			manual.hidden = true;
			manualResolve = null;
			setBusy( false );
		}
	}

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		check( chosenUrl(), 'browser' );
	} );
	serverButton.addEventListener( 'click', function () {
		check( chosenUrl(), 'server' );
	} );
	manualDone.addEventListener( 'click', function () {
		if ( manualResolve ) {
			manualResolve( true );
		}
	} );

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( target.classList.contains( 'consentwell-again' ) ) {
			check( target.getAttribute( 'data-url' ), target.getAttribute( 'data-mode' ) );
		} else if ( target.classList.contains( 'consentwell-view' ) ) {
			engine.api( 'checks/' + target.getAttribute( 'data-id' ) ).then( show ).catch( function ( error ) {
				setStatus( error.message, 'error' );
			} );
		} else if ( target.classList.contains( 'consentwell-copy' ) ) {
			var box = target.closest( '.consentwell-result' );
			var area = box.querySelector( '.consentwell-text' );
			var done = box.querySelector( '.consentwell-copied' );
			var text = area.value;
			var fallback = function () {
				area.focus();
				area.select();
				var ok = false;
				try {
					ok = document.execCommand( 'copy' );
				} catch ( e ) {}
				done.textContent = ok ? __( 'Copied.', 'consentwell' ) : __( 'Selected: press Ctrl+C (Cmd+C on a Mac) to copy.', 'consentwell' );
			};
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( text ).then( function () {
					done.textContent = __( 'Copied.', 'consentwell' );
				}, fallback );
			} else {
				fallback();
			}
		}
	} );
} )();
