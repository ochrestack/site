/**
 * Tools > Consentwell screen.
 *
 * @package Consentwell
 */
( function () {
	'use strict';

	var __ = window.wp.i18n.__;
	var engine = window.consentwellCheck;
	var $ = function ( id ) {
		return document.getElementById( id );
	};

	var form = $( 'consentwell-form' );
	var runButton = $( 'consentwell-run' );
	var serverButton = $( 'consentwell-run-server' );
	var status = $( 'consentwell-status' );
	var manual = $( 'consentwell-manual' );
	var manualDone = $( 'consentwell-manual-done' );
	var windowWrap = $( 'consentwell-window-wrap' );
	var windowBox = $( 'consentwell-window' );
	var resultBox = $( 'consentwell-result' );
	var tableBox = $( 'consentwell-table' );
	var busy = false;
	var manualResolve = null;

	function chosenUrl() {
		var typed = $( 'consentwell-url' ).value.trim();
		return typed || $( 'consentwell-page' ).value;
	}

	function setStatus( text, kind ) {
		status.hidden = false;
		status.className = 'consentwell-status' + ( kind ? ' consentwell-status-' + kind : '' );
		status.textContent = text;
	}

	var running = false;

	/**
	 * While a check runs, the window takes the room left on the screen under the status line (at least 240 px, at most
	 * 640 px), so the whole window, the banner at its bottom edge included, is in view on a screen from 1024x600 up.
	 * Nothing above the window moves and the page is not scrolled: the button stays where it was pressed. On a screen
	 * too short for 240 px under the form (a phone), the window is longer than the screen and the reader scrolls to it.
	 */
	function fitWindow() {
		if ( windowWrap.hidden || ! running ) {
			return;
		}
		windowBox.style.height = '';
		var top = windowBox.getBoundingClientRect().top;
		windowBox.style.height = Math.max( 240, Math.min( 640, window.innerHeight - top - 12 ) ) + 'px';
	}

	function setRunning( value ) {
		running = value;
		if ( value ) {
			fitWindow();
		} else {
			windowBox.style.height = '';
		}
	}

	function setBusy( value ) {
		busy = value;
		runButton.disabled = value;
		serverButton.disabled = value;
		document.querySelectorAll( '.consentwell-again' ).forEach( function ( b ) {
			b.disabled = value;
		} );
	}

	/**
	 * Whether the top of an element is on the screen, with room to read a line under it.
	 *
	 * @param {Element} el Element.
	 * @return {boolean}
	 */
	function topInView( el ) {
		var top = el.getBoundingClientRect().top;
		return top >= 0 && top < window.innerHeight - 60;
	}

	/**
	 * Show a result. The page moves only when the top of the result is not already on the screen (View on a row of Last 20
	 * checks); a check started with the button at the top shows its result under the status line without moving anything.
	 *
	 * @param {Object} payload Result.
	 */
	function show( payload ) {
		resultBox.innerHTML = payload.html;
		if ( payload.table_html ) {
			tableBox.innerHTML = payload.table_html;
		}
		if ( ! topInView( resultBox ) ) {
			resultBox.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
	}

	async function check( url, mode ) {
		if ( busy ) {
			return;
		}
		// Check again on a row of Last 20 checks: the status line and the window are above the screen, so go to them (measured
		// before the old result is emptied, which shortens the page). A check started with the button at the top does not move the page.
		var fromBelow = runButton.getBoundingClientRect().bottom < 0;
		setBusy( true );
		resultBox.innerHTML = '';
		if ( fromBelow ) {
			window.scrollTo( 0, 0 );
		}
		try {
			var payload;
			if ( mode === 'server' ) {
				windowWrap.hidden = true;
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				payload = await engine.api( 'server-check', { url: url, store: true } );
			} else {
				windowWrap.hidden = false;
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				setRunning( true );
				payload = await engine.run( {
					url: url,
					container: windowBox,
					store: true,
					onStep: function ( text ) {
						setStatus( text );
						fitWindow();
					},
					onManual: function ( waiting ) {
						manual.hidden = ! waiting;
						// The prompt says it all: the status line would repeat it.
						status.hidden = waiting;
						fitWindow();
					},
					manualReject: function () {
						return new Promise( function ( resolve ) {
							manualResolve = resolve;
						} );
					},
				} );
			}
			// The window has done its work: the result takes its place under the status line, in view, and the form above does not move.
			setRunning( false );
			windowWrap.hidden = true;
			if ( payload.frame_blocked ) {
				setStatus( __( 'This page cannot open in the check window, so the server-side result is shown instead.', 'consentwell' ), 'warning' );
			} else {
				setStatus( __( 'Check finished.', 'consentwell' ), 'done' );
			}
			show( payload );
		} catch ( error ) {
			setStatus( __( 'The check could not finish:', 'consentwell' ) + ' ' + error.message, 'error' );
		} finally {
			setRunning( false );
			manual.hidden = true;
			manualResolve = null;
			setBusy( false );
		}
	}

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		check( chosenUrl(), 'browser' );
	} );
	serverButton.addEventListener( 'click', function () {
		check( chosenUrl(), 'server' );
	} );
	manualDone.addEventListener( 'click', function () {
		if ( manualResolve ) {
			manualResolve( true );
		}
	} );

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( target.classList.contains( 'consentwell-again' ) ) {
			check( target.getAttribute( 'data-url' ), target.getAttribute( 'data-mode' ) );
		} else if ( target.classList.contains( 'consentwell-view' ) ) {
			engine.api( 'checks/' + target.getAttribute( 'data-id' ) ).then( show ).catch( function ( error ) {
				setStatus( error.message, 'error' );
			} );
		} else if ( target.classList.contains( 'consentwell-copy' ) ) {
			var box = target.closest( '.consentwell-result' );
			var area = box.querySelector( '.consentwell-text' );
			var done = box.querySelector( '.consentwell-copied' );
			var text = area.value;
			var fallback = function () {
				area.focus();
				area.select();
				var ok = false;
				try {
					ok = document.execCommand( 'copy' );
				} catch ( e ) {}
				done.textContent = ok ? __( 'Copied.', 'consentwell' ) : __( 'Selected: press Ctrl+C (Cmd+C on a Mac) to copy.', 'consentwell' );
			};
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( text ).then( function () {
					done.textContent = __( 'Copied.', 'consentwell' );
				}, fallback );
			} else {
				fallback();
			}
		}
	} );
} )();
