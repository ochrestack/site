/**
 * Tools > Consentwell screen.
 *
 * @package Consentwell
 */
( function () {
	'use strict';

	var __ = window.wp.i18n.__;
	var engine = window.consentwellCheck;
	var $ = function ( id ) {
		return document.getElementById( id );
	};

	var form = $( 'consentwell-form' );
	var runButton = $( 'consentwell-run' );
	var serverButton = $( 'consentwell-run-server' );
	var status = $( 'consentwell-status' );
	var manual = $( 'consentwell-manual' );
	var manualDone = $( 'consentwell-manual-done' );
	var windowWrap = $( 'consentwell-window-wrap' );
	var windowBox = $( 'consentwell-window' );
	var resultBox = $( 'consentwell-result' );
	var tableBox = $( 'consentwell-table' );
	var busy = false;
	var manualResolve = null;

	function chosenUrl() {
		var typed = $( 'consentwell-url' ).value.trim();
		return typed || $( 'consentwell-page' ).value;
	}

	function setStatus( text, kind ) {
		status.hidden = false;
		status.className = 'consentwell-status' + ( kind ? ' consentwell-status-' + kind : '' );
		status.textContent = text;
	}

	var running = false;
	var fitTimer = 0;

	// The picker's hint says which of the two ways of naming a page counts.
	var pageHint = $( 'consentwell-page-hint' );
	var urlField = $( 'consentwell-url' );
	function showWhichPageCounts() {
		pageHint.textContent = urlField.value.trim() ? pageHint.getAttribute( 'data-typed' ) : pageHint.getAttribute( 'data-idle' );
	}
	urlField.addEventListener( 'input', showWhichPageCounts );
	showWhichPageCounts();

	/**
	 * While a check runs, the window takes the room left on the screen under the status line, measured from where the
	 * window really starts (a WordPress notice or two above the heading push it down), at least 180 px (240 px on a phone) and at most 640 px,
	 * so the whole window, the banner at its bottom edge included, is in view. It is measured again when the screen is
	 * resized and twice a second while the check runs, because a notice can be dismissed or added meanwhile. Nothing above
	 * the window moves and the page is not scrolled while it fits, so the button stays where it was pressed. Only when
	 * the least does not fit (a phone, or three notices on a short screen) the window is longer than the room and the
	 * reader scrolls to it.
	 */
	function fitWindow() {
		if ( windowWrap.hidden || ! running ) {
			return;
		}
		var top = windowBox.getBoundingClientRect().top;
		// On a phone the page in the window is laid out for a narrow screen and its banner is taller: keep 240 px there.
		var least = window.innerWidth <= 782 ? 240 : 180;
		var height = Math.max( least, Math.min( 640, Math.floor( window.innerHeight - top - 12 ) ) ) + 'px';
		if ( windowBox.style.height !== height ) {
			windowBox.style.height = height;
		}
	}

	function setRunning( value ) {
		running = value;
		clearInterval( fitTimer );
		if ( value ) {
			fitWindow();
			fitTimer = setInterval( fitWindow, 500 );
		} else {
			windowBox.style.height = '';
		}
	}
	window.addEventListener( 'resize', fitWindow );

	function setBusy( value ) {
		busy = value;
		runButton.disabled = value;
		serverButton.disabled = value;
		document.querySelectorAll( '.consentwell-again' ).forEach( function ( b ) {
			b.disabled = value;
		} );
	}

	/**
	 * Whether the top of an element is on the screen, with room to read a line under it.
	 *
	 * @param {Element} el Element.
	 * @return {boolean}
	 */
	function topInView( el ) {
		var top = el.getBoundingClientRect().top;
		return top >= 0 && top < window.innerHeight - 60;
	}

	/**
	 * Show a result. The page moves only when the top of the result is not already on the screen (View on a row of Last 20
	 * checks); a check started with the button at the top shows its result under the status line without moving anything.
	 *
	 * @param {Object} payload Result.
	 */
	function show( payload ) {
		resultBox.innerHTML = payload.html;
		if ( payload.table_html ) {
			tableBox.innerHTML = payload.table_html;
		}
		if ( ! topInView( resultBox ) ) {
			resultBox.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
	}

	async function check( url, mode ) {
		if ( busy ) {
			return;
		}
		// Check again on a row of Last 20 checks: the status line and the window are above the screen, so go to them (measured
		// before the old result is emptied, which shortens the page). A check started with the button at the top does not move the page.
		var fromBelow = runButton.getBoundingClientRect().bottom < 0;
		setBusy( true );
		resultBox.innerHTML = '';
		if ( fromBelow ) {
			window.scrollTo( 0, 0 );
		}
		try {
			var payload;
			if ( mode === 'server' ) {
				windowWrap.hidden = true;
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				payload = await engine.api( 'server-check', { url: url, store: true } );
			} else {
				windowWrap.hidden = false;
				setStatus( __( 'Fetching the page as a logged-out visitor (server side)…', 'consentwell' ) );
				setRunning( true );
				payload = await engine.run( {
					url: url,
					container: windowBox,
					store: true,
					onStep: function ( text ) {
						setStatus( text );
						fitWindow();
					},
					onManual: function ( waiting ) {
						manual.hidden = ! waiting;
						// The prompt says it all: the status line would repeat it.
						status.hidden = waiting;
						fitWindow();
					},
					manualReject: function () {
						return new Promise( function ( resolve ) {
							manualResolve = resolve;
						} );
					},
				} );
			}
			// The window has done its work: the result takes its place under the status line, in view, and the form above does not move.
			setRunning( false );
			windowWrap.hidden = true;
			if ( payload.frame_blocked ) {
				setStatus( __( 'This page cannot open in the check window, so the server-side result is shown instead.', 'consentwell' ), 'warning' );
			} else {
				setStatus( __( 'Check finished.', 'consentwell' ), 'done' );
			}
			show( payload );
		} catch ( error ) {
			// A refusal never held a page: the window and its label go, and the status line is the only change.
			windowWrap.hidden = true;
			setStatus( __( 'The check could not finish:', 'consentwell' ) + ' ' + error.message, 'error' );
		} finally {
			setRunning( false );
			manual.hidden = true;
			manualResolve = null;
			setBusy( false );
		}
	}

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		check( chosenUrl(), 'browser' );
	} );
	serverButton.addEventListener( 'click', function () {
		check( chosenUrl(), 'server' );
	} );
	manualDone.addEventListener( 'click', function () {
		if ( manualResolve ) {
			manualResolve( true );
		}
	} );

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( target.classList.contains( 'consentwell-again' ) ) {
			check( target.getAttribute( 'data-url' ), target.getAttribute( 'data-mode' ) );
		} else if ( target.classList.contains( 'consentwell-view' ) ) {
			engine.api( 'checks/' + target.getAttribute( 'data-id' ) ).then( show ).catch( function ( error ) {
				setStatus( error.message, 'error' );
			} );
		} else if ( target.classList.contains( 'consentwell-copy' ) ) {
			var box = target.closest( '.consentwell-result' );
			var area = box.querySelector( '.consentwell-text' );
			var done = box.querySelector( '.consentwell-copied' );
			var text = area.value;
			var fallback = function () {
				area.focus();
				area.select();
				var ok = false;
				try {
					ok = document.execCommand( 'copy' );
				} catch ( e ) {}
				done.textContent = ok ? __( 'Copied.', 'consentwell' ) : __( 'Selected: press Ctrl+C (Cmd+C on a Mac) to copy.', 'consentwell' );
			};
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( text ).then( function () {
					done.textContent = __( 'Copied.', 'consentwell' );
				}, fallback );
			} else {
				fallback();
			}
		}
	} );
} )();
