=== Consentwell – Check What Loads After Reject ===
Contributors: ochrestack
Tags: cookie consent, cookie banner, gdpr, cookie scanner, consent
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Check any page as a logged-out visitor: does your consent banner show, and what still loads after Reject? Plain facts, nothing sent anywhere.

== Description ==

"The consent banner is enabled … but it doesn't appear for visitors."
"reCAPTCHA v2 loads on our homepage even when visitors reject optional cookies."

Consentwell checks any page of your site as a logged-out visitor: does the banner show, and what still loads after Reject.

Go to Tools > Consentwell, pick a page and click Check this page. The page opens in a check window on that screen as a visitor who is not logged in and has no consent stored. Consentwell reads the page, clicks the banner's Reject button, reloads the page and writes down what happened. A check takes about 20 seconds: each page load is watched while Consentwell moves the mouse, presses a key, touches and scrolls the page to the bottom, until 6 seconds after the last input with nothing new loading. The result says how many seconds it watched.

= What a check reports =

* Whether the consent banner is in the page HTML, whether it is visible on screen, and if not, what hides it: a hiding class (such as cmplz-hidden), display: none, zero size, or a position off screen.
* Whether a Reject button is visible on the first layer of the banner.
* The likely cause, where one is found: the theme does not call wp_footer(); a script error on the page; the consent plugin's own stylesheet or script answering an error; the browser sends Do Not Track or Global Privacy Control (with Complianz's "Respect Do Not Track and Global Privacy Control?" setting on, the banner is hidden by design and Consentwell says so); the copy visitors get from a page cache differs from a fresh page.
* Before any choice, and after Reject: the requests to other domains that the page made while Consentwell watched it (scripts, frames and embeds, images and pixels, stylesheets and fonts) with the full address, the type and the service name where it is a well-known one (Google reCAPTCHA, YouTube, Google Maps, Google Fonts, Meta Pixel and more), and the cookies the page can read.
* How long it watched, in seconds, under each list. A request that starts later than that, or only after a real click, is not listed.
* A server-side check that needs no browser: the third-party script and frame tags in the HTML, and every cookie the response sets, HttpOnly cookies included. Pages that forbid framing (X-Frame-Options: DENY) get this check instead.
* A Site Health test, "Consent banner check (Consentwell)", with the result of the last check of your home page.
* The last 20 checks with dates, Check again in one click, and Copy as text: a plain-text summary to paste into your consent plugin's support forum.

Every line is a fact ("loaded", "set") with the exact address, so you can confirm it in your own browser's developer tools. There is no score.

= Support =

Questions: support@ochrestack.com

= Which consent plugins =

Consentwell recognises Complianz and CookieYes by name and clicks their Reject button for you. Another banner is found when it is visible, has buttons labelled like a choice (Accept, Reject, Allow) and mentions cookies or consent in its text, in the page or in an open shadow root; you click its Reject button in the check window and Consentwell continues from there. A banner in a closed shadow root or inside a frame is not found. Cookiebot's dialog is looked for by its usual id but was not tested with a Cookiebot account. Consentwell is not affiliated with or endorsed by Complianz, CookieYes or Cookiebot.

= What it does not do =

Consentwell changes nothing on your site and does not fix your consent plugin's settings; it is a technical check, not legal advice, and no plugin can make a site compliant. It shows no banner of its own and reports technical facts about what one page loaded in your browser at the time of the check.

Your browser's developer tools can show the same requests for free, and they see more: they list requests made inside frames and requests that start long after the page loaded. Consentwell does the steps for you (a fresh visitor, Reject clicked, the page reloaded, the page scrolled) and writes the result in plain words, and names the likely reason when a banner is in the page but not on screen.

= Consentwell Pro =

Every single-page check in this plugin is free, with no limit and no account. A separate add-on, Consentwell Pro ($19 once, no renewal, from ochrestack.com), checks the pages in your sitemap (up to 5,000 addresses) in one run, with a CSV and a comparison with the previous run.

== External services ==

Neither Consentwell nor Consentwell Pro contacts any outside server: no account, no licence check, no telemetry, no calls to Ochrestack.

A check opens your site's own pages: in the check window in your browser, and through a request from your server to your own site. Those pages load whatever third-party content your site itself loads (for example Google reCAPTCHA, a YouTube embed or Google Fonts), as they do for any visitor. That is what the check measures. Results are stored in your site's own database (the last 20 checks).

== Installation ==

1. Plugins > Add Plugin (Add New Plugin in WordPress 6.5), search for "Consentwell", Install, Activate. Or upload the zip under Plugins > Add Plugin > Upload Plugin.
2. Go to Tools > Consentwell, pick a page, click Check this page.

Administrators only (manage_options).

== Frequently Asked Questions ==

= My banner is enabled but visitors don't see it. Why? =

Check the page with Consentwell. It tells you whether the banner is in the HTML, whether it is visible, and what hides it (for example the cmplz-hidden class), then names the likely cause it found: a theme without wp_footer(), a script error, the consent plugin's own file answering an error, a page cache serving an older copy, or your browser sending Global Privacy Control while the consent plugin is set to respect it, which hides the banner by design.

= My consent plugin's scan won't run. Can I still see what my site loads? =

Yes. Consentwell needs no outside scanner and no domain authentication: it opens the page in your own browser and lists the requests to other domains that the page makes, before any choice and after Reject. The server-side check lists the third-party tags and every cookie the page response sets.

= Something still loads after visitors reject. How do I find out what? =

Run a check on that page. The After Reject list shows each address that the page requested after Consentwell clicked Reject and reloaded the page, for example google.com/recaptcha/api.js, with its type and service, and says how many seconds it watched. Copy as text gives you a summary to paste into your consent plugin's support forum.

= Does it change my site? =

No. It reads pages and stores its results; it never changes settings, scripts or content. During a check, the checked page is shown as a logged-out visitor in the check window only; your own login is not touched. Your own cookies for this site are set aside during a check and put back as they were, with the same expiry, also if you leave the screen halfway.

= Does it send anything anywhere? =

No. See External services above.

= Is this legal advice? =

No. Consentwell reports technical facts about what a page loaded in your browser. It is not legal advice, and no plugin can make a site compliant.

= Why is a request from my browser's developer tools not listed? =

Consentwell lists what the page itself requested while it watched. Not listed: requests made inside frames (the frame's own address is listed), files another domain's stylesheet loads (such as fonts.gstatic.com font files; the stylesheet is listed), requests after the watching ended, and requests that need a real click.

= Does it see what visitors in other countries see? =

No. The check sees what a visitor from your own location sees, in your browser. Browser extensions (ad blockers, privacy tools) can change what loads; use a browser profile without them for checks.

== Screenshots ==

1. The After Reject result on a small-business site: the third-party addresses that loaded after Reject while Consentwell watched, with type, service and the seconds watched.
2. A page whose theme template never calls wp_footer(): no banner on the page, and the likely cause named.
3. Tools > Consentwell: pick a page, Check this page, and the last 20 checks.
4. Copy as text: a plain-text summary for your consent plugin's support forum.
5. The Site Health test "Consent banner check (Consentwell)".

== Changelog ==

= 1.0.1 =
* Lists now cover requests that start late: input, scrolling and a 6 second watch after the last input; each list says how many seconds it watched.
* A banner held back by a script-delay setting is reported as shown late, with the time.
* Other banners are also found in open shadow roots and without "cookie" in their id or class.
* Your own cookies come back as they were after a check, also if you leave the screen halfway.
* Site Health says what it watched instead of "nothing loaded".

= 1.0.0 =
* First release: the per-page check (banner visibility, Reject, likely cause, before-choice and after-Reject requests and cookies), the server-side check, the Site Health test, the last 20 checks and Copy as text.
