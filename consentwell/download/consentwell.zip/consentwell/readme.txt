=== Consentwell – Check What Loads After Reject ===
Contributors: ochrestack
Tags: cookie consent, cookie banner, gdpr, cookie scanner, consent
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Check a page as a logged-out visitor: does your consent banner show, and what still loads after Reject? Plain facts, nothing sent anywhere.

== Description ==

"The consent banner is enabled … but it doesn't appear for visitors."

Consentwell checks a page of your site as a logged-out visitor: does the banner show, and what still loads after Reject.

Go to Tools > Consentwell, pick a page and click Check this page. The page opens in a check window on that screen as a visitor who is not logged in and has no consent stored. Consentwell reads the page, clicks the banner's Reject button, reloads the page and writes down what happened. A check takes about 20 seconds: each page load is watched while Consentwell moves the mouse, presses a key, touches and scrolls the page to the bottom, until 6 seconds after the last input with nothing new loading. The result says how long it watched.

= What a check reports =

* Whether the consent banner is in the page HTML and visible on screen, and if not, what hides it: a hiding class (such as cmplz-hidden), display: none, zero size, or a position off screen.
* Whether a Reject button is visible on the first layer of the banner.
* The likely cause, where one is found: the theme does not call wp_footer(); a script error on the page; the consent plugin's own files answering an error; a style rule that hides the banner; Do Not Track or Global Privacy Control with a consent plugin set to respect it (hidden by design, and Consentwell says so); a page cache serving a different copy.
* Before any choice, and after Reject: the requests to other domains that the page made while Consentwell watched it, with the full address, the type, the service name where it is a well-known one (Google reCAPTCHA, YouTube, Google Maps, Google Fonts, Meta Pixel and more), and the cookies the page can read (the consent plugin's own record cookies are counted, not listed).
* How long it watched, in seconds, under each list. A request that starts later than that, or only after a real click, is not listed.
* A server-side check that needs no browser: the third-party script and frame tags in the HTML and every cookie the response sets, HttpOnly included. Pages that forbid framing (X-Frame-Options: DENY) get this check instead.
* A Site Health test, "Consent banner check (Consentwell)", for your home page, and the last 20 checks with Check again and Copy as text, a plain-text summary for your consent plugin's support forum.

Every line is a fact ("requested", "set") with the exact address, so you can confirm it in your browser's developer tools. A request the page reported as failed says "(failed)". There is no score.

= Support =

Questions: support@ochrestack.com

= Which consent plugins =

Run against: Complianz 7.5.7 and CookieYes 3.5.9 (Consentwell clicks Reject for you); GDPR Cookie Compliance 5.3.1, CookieAdmin 1.2.6, SureCookie 1.8.1 and Beautiful Cookie Consent Banner 4.10.0 (you click Reject in the check window when the screen says "Your turn"); Cookie Notice & Compliance 3.1.19 and WPConsent 1.2.1 (their banner does not appear in the check window, see the FAQ). Not run, they need an account: Real Cookie Banner, Cookiebot, iubenda, Termly.

Another banner is found when it is visible in the check window, has buttons labelled like a choice (Accept, Reject, Allow) and mentions cookies or consent. A banner in a closed shadow root is not found. Not affiliated with or endorsed by any consent plugin named here.

= What it does not do =

Consentwell changes nothing on your site and does not fix your consent plugin's settings; it is a technical check, not legal advice, and no plugin can make a site compliant. It shows no banner of its own.

Your browser's developer tools show the same requests for free, and more (requests made inside frames, whose own address Consentwell lists, and files another domain's stylesheet loads). Consentwell does the steps for you (a fresh visitor, Reject clicked, the page reloaded and scrolled), writes the result in plain words and names the likely reason a banner is in the page but not on screen.

= Consentwell Pro =

Every single-page check here is free, with no limit and no account. A separate add-on, Consentwell Pro ($19 once, no renewal, from ochrestack.com), checks the pages in your sitemap (up to 5,000 addresses) in one run, with a CSV and a comparison with the previous run. Pro clicks Reject on Complianz and CookieYes banners; on any other banner it lists what loads before any choice only.

== External services ==

Neither Consentwell nor Consentwell Pro contacts any outside server: no account, no licence check, no telemetry, no calls to Ochrestack.

A check opens your site's own pages: in the check window in your browser, and through a request from your server to your own site. Those pages load whatever third-party content your site itself loads (Google reCAPTCHA, a YouTube embed, Google Fonts), as for any visitor; that is what the check measures. Results are stored in your site's own database (the last 20 checks). A check never changes settings, scripts or content: the checked page is shown as a logged-out visitor in the check window only, and your own cookies for this site are set aside during a check and put back as they were, also if you leave the screen halfway.

== Installation ==

1. Plugins > Add Plugin (Add New Plugin in WordPress 6.5), search for "Consentwell", Install, Activate. Or upload the zip under Plugins > Add Plugin > Upload Plugin.
2. Go to Tools > Consentwell, pick a page, click Check this page.

Administrators only (manage_options).

== Frequently Asked Questions ==

= My banner is enabled but visitors don't see it. Why? =

Check the page with Consentwell. It tells you whether the banner is in the HTML, whether it is visible and what hides it, and names the likely cause it found (see "What a check reports").

= Why does the banner show to my visitors but not in the check? =

The check window is a frame, and some banners do not appear in a frame: Cookie Notice & Compliance stops its own script in one. Consentwell then says the banner is in the page HTML but not shown in the check window, lists what loads before any choice and does not click Reject. A private window shows what visitors see.

= My consent plugin's scan won't run. Can I still see what my site loads? =

Yes. Consentwell needs no outside scanner and no domain authentication: it opens the page in your own browser and lists the requests to other domains, before any choice and after Reject.

= Something still loads after visitors reject. How do I find out what? =

Run a check on that page. The After Reject list shows each address the page requested after Reject and a reload, with its type and service, and how many seconds it watched. Copy as text gives you a summary for your consent plugin's support forum.

= Does it see what visitors in other countries see? =

No. The check sees what a visitor from your own location sees, in your browser. Browser extensions (ad blockers, privacy tools) change what loads; use a profile without them.

== Screenshots ==

1. The After Reject result on a small-business site: the third-party addresses that loaded after Reject while Consentwell watched, with type, service and the seconds watched.
2. A page whose theme template never calls wp_footer(): no banner on the page, and the likely cause named.
3. Tools > Consentwell: pick a page, Check this page, and the last 20 checks.
4. Copy as text: a plain-text summary for your consent plugin's support forum.
5. The Site Health test "Consent banner check (Consentwell)".

== Changelog ==

= 1.0.7 =
* The check window ignores clicks until "Your turn". A refused address leaves no empty window.

= 1.0.6 =
* A draft or private page is told so, not "answered 404". The check window fits a small screen with a WordPress notice above it. View and Check again sit under each address.

= 1.0.5 =
* The Check this page button stays where it is while a check runs. One Likely cause paragraph for a banner that kept its hiding class. "Server-side check only" says what it does.

= 1.0.4 =
* A 404, a login screen or a JSON address stops with one plain sentence and is not stored; /about/ is accepted. Tables scroll.

= 1.0.3 =
* A banner in the HTML that does not appear in the check window (Cookie Notice & Compliance) is no longer "No consent banner found".

= 1.0.2 =
* Pro no longer shows "0 after Reject" for pages it did not click Reject on; it lists what loads before any choice there.

= 1.0.1 =
* Lists cover late requests (input, scrolling, 6 seconds after the last input) and say how long they watched; a banner held back by a script-delay setting is reported as shown late.

= 1.0.0 =
* First release.
