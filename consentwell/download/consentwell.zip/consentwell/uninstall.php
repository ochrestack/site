<?php
/**
 * Removes Consentwell's stored results when the plugin is deleted.
 *
 * @package Consentwell
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'consentwell_checks' );
delete_option( 'consentwell_completed_checks' );
delete_metadata( 'user', 0, 'consentwell_review_dismissed', '', true );
