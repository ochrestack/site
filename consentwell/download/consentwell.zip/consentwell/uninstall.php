<?php
/**
 * Removes Consentwell's stored results when the plugin is deleted.
 *
 * @package Consentwell
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'consentwell_checks' );
// Values 1.0.3 and earlier stored for a review line that no longer exists.
delete_option( 'consentwell_completed_checks' );
delete_metadata( 'user', 0, 'consentwell_review_dismissed', '', true );
