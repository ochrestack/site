<?php
/**
 * Plugin Name:       Rolemend – View Only and No-Upload Media Roles
 * Plugin URI:        https://ochrestack.com/rolemend/
 * Description:       Adds a View Only role that can look round wp-admin and change nothing, and a Media Library (no uploads) role that can edit media titles and alternative text without uploading files.
 * Version:           1.1.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rolemend
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

define( 'ROLEMEND_VERSION', '1.1.0' );
define( 'ROLEMEND_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-rolemend-roles.php';
require_once __DIR__ . '/includes/class-rolemend-caps.php';
require_once __DIR__ . '/includes/class-rolemend-guard.php';
require_once __DIR__ . '/includes/class-rolemend-writes.php';
require_once __DIR__ . '/includes/class-rolemend-view-only.php';
require_once __DIR__ . '/includes/class-rolemend-media.php';
require_once __DIR__ . '/includes/class-rolemend-screen.php';

register_activation_hook( __FILE__, array( 'Rolemend_Roles', 'activate' ) );

Rolemend_Roles::init();
Rolemend_Caps::init();
Rolemend_Guard::init();
Rolemend_Writes::init();
Rolemend_View_Only::init();
Rolemend_Media::init();
Rolemend_Screen::init();

/**
 * Whether a user holds the View Only or the Media Library (no uploads) role on this site.
 *
 * Other code (add-ons, themes, other plugins) can use this to keep its own
 * screens away from these accounts.
 *
 * @param int $user_id User ID. Defaults to the current user.
 * @return bool
 */
function rolemend_is_restricted_user( $user_id = 0 ) {
	$user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
	return Rolemend_Roles::is_view_only( $user ) || Rolemend_Roles::is_media_role( $user );
}
