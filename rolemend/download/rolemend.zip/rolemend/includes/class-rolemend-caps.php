<?php
/**
 * Capabilities granted and denied at run time.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Grants the capabilities WordPress asks for before it shows a screen, and denies
 * the capabilities it asks for before it changes something.
 *
 * WordPress ties seeing to editing (the Posts list needs edit_posts, every
 * Settings screen needs manage_options, the Media Library needs upload_files),
 * so the View Only role is given those capabilities while the plugin is active.
 * Every request that would change something is refused separately by
 * Rolemend_Guard; the denials below keep the editing links and buttons off the
 * screens and give a second line of defence.
 */
class Rolemend_Caps {

	/**
	 * Primitive capabilities the View Only role needs to open WordPress's own screens.
	 *
	 * @var string[]
	 */
	const VIEW_ONLY_GRANTS = array(
		'read',
		'edit_posts',
		'edit_others_posts',
		'edit_published_posts',
		'edit_private_posts',
		'read_private_posts',
		'edit_pages',
		'edit_others_pages',
		'edit_published_pages',
		'edit_private_pages',
		'read_private_pages',
		'upload_files',
		'moderate_comments',
		'manage_categories',
		'list_users',
		'activate_plugins',
		'switch_themes',
		'edit_theme_options',
		'manage_options',
	);

	/**
	 * Primitive capabilities the Media Library (no uploads) role needs to open the library.
	 * upload_files is what WordPress asks for before it shows the library at all;
	 * the uploads themselves are refused by Rolemend_Guard.
	 *
	 * @var string[]
	 */
	const MEDIA_GRANTS = array(
		'read',
		'upload_files',
	);

	/**
	 * Primitive capabilities that only ever change things. They are switched off for
	 * both roles even when a role editor has added them.
	 *
	 * @var string[]
	 */
	const NEVER = array(
		'unfiltered_html',
		'unfiltered_upload',
		'edit_files',
		'edit_plugins',
		'edit_themes',
		'install_plugins',
		'install_themes',
		'install_languages',
		'update_core',
		'update_plugins',
		'update_themes',
		'update_languages',
		'delete_plugins',
		'delete_themes',
		'import',
		'export',
		'create_users',
		'delete_users',
		'edit_users',
		'promote_users',
		'remove_users',
		'add_users',
		'publish_posts',
		'publish_pages',
		'delete_posts',
		'delete_pages',
		'delete_others_posts',
		'delete_others_pages',
		'delete_published_posts',
		'delete_published_pages',
		'delete_private_posts',
		'delete_private_pages',
		'edit_dashboard',
		'manage_links',
		'customize',
		'manage_network',
		'manage_sites',
		'manage_network_users',
		'manage_network_plugins',
		'manage_network_themes',
		'manage_network_options',
		'upgrade_network',
		'setup_network',
		'create_sites',
		'delete_sites',
	);

	/**
	 * Meta capabilities refused to both roles, whatever they map to.
	 *
	 * @var string[]
	 */
	const DENIED_META = array(
		'edit_post',
		'delete_post',
		'publish_post',
		'edit_page',
		'delete_page',
		'edit_comment',
		'delete_comment',
		'edit_term',
		'delete_term',
		'assign_term',
		'add_post_meta',
		'edit_post_meta',
		'delete_post_meta',
		'add_comment_meta',
		'edit_comment_meta',
		'delete_comment_meta',
		'add_term_meta',
		'edit_term_meta',
		'delete_term_meta',
		'add_user_meta',
		'edit_user_meta',
		'delete_user_meta',
		'delete_user',
		'remove_user',
		'promote_user',
		'activate_plugin',
		'deactivate_plugin',
		'deactivate_plugins',
		'resume_plugin',
		'resume_theme',
		'upload_plugins',
		'upload_themes',
		'update_php',
		'update_https',
		'export_others_personal_data',
		'erase_others_personal_data',
		'edit_css',
		'create_app_password',
		'edit_app_password',
		'delete_app_password',
		'delete_app_passwords',
		'delete_site',
		'edit_block_binding',
	);

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'user_has_cap', array( __CLASS__, 'filter_user_caps' ), 20, 4 );
		add_filter( 'map_meta_cap', array( __CLASS__, 'filter_meta_caps' ), 20, 4 );
	}

	/**
	 * Adds the view capabilities and removes the change-only ones.
	 *
	 * @param bool[]   $allcaps All the user's capabilities.
	 * @param string[] $caps    Required primitive capabilities.
	 * @param array    $args    Requested capability, user ID, object ID.
	 * @param WP_User  $user    The user.
	 * @return bool[]
	 */
	public static function filter_user_caps( $allcaps, $caps, $args, $user ) {
		if ( Rolemend_Roles::is_view_only( $user ) ) {
			$grants = self::VIEW_ONLY_GRANTS;
			if ( ! is_multisite() ) {
				// What an Administrator sees: Tools > Site Health (single sites only, as in core).
				$grants[] = 'view_site_health_checks';
			}
		} elseif ( Rolemend_Roles::is_media_role( $user ) ) {
			$grants = self::MEDIA_GRANTS;
		} else {
			return $allcaps;
		}
		foreach ( $grants as $cap ) {
			$allcaps[ $cap ] = true;
		}
		foreach ( self::NEVER as $cap ) {
			$allcaps[ $cap ] = false;
		}
		return $allcaps;
	}

	/**
	 * Refuses the meta capabilities that lead to a change.
	 *
	 * @param string[] $caps    Primitive capabilities required.
	 * @param string   $cap     Capability being checked.
	 * @param int      $user_id User ID.
	 * @param array    $args    Extra arguments, usually an object ID.
	 * @return string[]
	 */
	public static function filter_meta_caps( $caps, $cap, $user_id, $args ) {
		if ( ! $user_id ) {
			return $caps;
		}
		$user  = get_userdata( $user_id );
		$view  = Rolemend_Roles::is_view_only( $user );
		$media = ! $view && Rolemend_Roles::is_media_role( $user );
		if ( ! $view && ! $media ) {
			return $caps;
		}

		if ( 'edit_user' === $cap ) {
			// Their own profile only (password, and for the media role the rest of their own profile).
			$target = isset( $args[0] ) ? (int) $args[0] : 0;
			return $target === (int) $user_id ? $caps : array( 'do_not_allow' );
		}

		if ( in_array( $cap, array( 'add_user_meta', 'edit_user_meta', 'delete_user_meta' ), true ) ) {
			// Only their own block editor preferences (which panels are open, the welcome guide).
			$target = isset( $args[0] ) ? (int) $args[0] : 0;
			$key    = isset( $args[1] ) ? (string) $args[1] : '';
			$own    = $target === (int) $user_id && 'persisted_preferences' === substr( $key, -21 );
			return $own ? $caps : array( 'do_not_allow' );
		}

		if ( $media && 'edit_post' === $cap ) {
			$post = isset( $args[0] ) ? get_post( $args[0] ) : null;
			// The media text of any attachment; nothing else.
			return ( $post && 'attachment' === $post->post_type ) ? array( 'read' ) : array( 'do_not_allow' );
		}

		if ( in_array( $cap, self::DENIED_META, true ) || in_array( $cap, self::NEVER, true ) ) {
			return array( 'do_not_allow' );
		}
		return $caps;
	}
}
