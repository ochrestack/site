<?php
/**
 * Users > Rolemend: who holds each role, and in plain words what each role can do.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * The plugin's one screen.
 */
class Rolemend_Screen {

	const SLUG = 'rolemend';

	/**
	 * Holders listed before "Show the other n users".
	 */
	const HOLDERS_SHOWN = 10;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ROLEMEND_FILE ), array( __CLASS__, 'action_links' ) );
		add_filter( 'pre_option_default_role', array( __CLASS__, 'preselect_role' ) );
	}

	/**
	 * Users > Rolemend, for people who can change user roles.
	 */
	public static function add_page() {
		add_users_page(
			__( 'Rolemend', 'rolemend' ),
			__( 'Rolemend', 'rolemend' ),
			'promote_users',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Address of the screen.
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'users.php?page=' . self::SLUG );
	}

	/**
	 * "Roles" link on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( current_user_can( 'promote_users' ) ) {
			array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Roles', 'rolemend' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * "Add a user with this role" opens Users > Add User with the role already chosen.
	 * Only the form's default changes, for that one page load; nothing is saved.
	 *
	 * @param mixed $value Short-circuit value.
	 * @return mixed
	 */
	public static function preselect_role( $value ) {
		global $pagenow;
		if ( 'user-new.php' !== $pagenow || ! current_user_can( 'create_users' ) ) {
			return $value;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only preselects a form field.
		$role = isset( $_GET['rolemend_role'] ) ? sanitize_key( wp_unslash( $_GET['rolemend_role'] ) ) : '';
		return in_array( $role, Rolemend_Roles::keys(), true ) ? $role : $value;
	}

	/**
	 * What each role can do, cannot do, and what it does not lock.
	 *
	 * @return array
	 */
	public static function descriptions() {
		return array(
			Rolemend_Roles::VIEW_ONLY => array(
				'name'   => __( 'View Only', 'rolemend' ),
				'intro'  => __( 'For someone who should look round wp-admin and save nothing: an accountant, auditor, client, board member or new hire.', 'rolemend' ),
				'can'    => array(
					__( 'Open the screens an Administrator sees for WordPress itself: Dashboard, Posts, Pages, Media, Comments, Appearance (Themes, Editor or Design, Widgets, Fonts, Menus), Plugins, Users, Tools > Site Health and every Settings screen.', 'rolemend' ),
					__( 'See every post and page in the lists, drafts and private ones included, by title, author, date and status.', 'rolemend' ),
					__( 'Change their own password and their own screen options.', 'rolemend' ),
					__( 'Open other plugins\' screens that use WordPress\'s own Settings permission.', 'rolemend' ),
				),
				'cannot' => array(
					__( 'Save any Settings screen.', 'rolemend' ),
					__( 'Create, edit, publish, schedule, trash or delete posts, pages and drafts.', 'rolemend' ),
					__( 'Upload, edit or delete media.', 'rolemend' ),
					__( 'Approve, edit, mark as spam or delete comments.', 'rolemend' ),
					__( 'Add, edit, promote or delete users, or create application passwords.', 'rolemend' ),
					__( 'Install, activate, deactivate, update or delete plugins and themes.', 'rolemend' ),
					__( 'Save menus, widgets or the Customizer.', 'rolemend' ),
					__( 'Make any of these changes through the REST API.', 'rolemend' ),
					__( 'Save through other plugins\' own forms and screens, or use a link or button on them that WordPress protects with a hidden check code, such as Run on WooCommerce\'s Scheduled Actions.', 'rolemend' ),
					__( 'Get any write into the database through other plugins\' code that runs on their requests, except caches and their own settings and sign-in.', 'rolemend' ),
					__( 'Open Tools > Export, Tools > Import, the theme and plugin file editors, or Network Admin.', 'rolemend' ),
					__( 'Open the text of a draft: drafts are listed by title, author, date and status, but WordPress shows a draft only to people who may edit it.', 'rolemend' ),
					__( 'Post comments or send other forms on the front end while signed in.', 'rolemend' ),
					__( 'See other plugins\' menu entries, toolbar items, Plugins-screen links, Dashboard widgets or admin notices, unless the plugin uses WordPress\'s own Settings permission.', 'rolemend' ),
				),
				'open'   => array(
					__( 'Some plugins can still send an email, save a file or call another service when this person opens one of their screens or clicks a plain link. Rolemend stops them saving to your site\'s database (caches and the person\'s own settings aside), but not what they do outside it.', 'rolemend' ),
					__( 'A plugin whose save was stopped may still say "Saved".', 'rolemend' ),
					__( 'A few plugins start work before WordPress checks who is signed in, or reach the database by a route of their own. Rolemend cannot stop those.', 'rolemend' ),
					__( 'What the account can read is readable: user email addresses, commenter details, settings, and anything other plugins show on their screens.', 'rolemend' ),
					__( 'Choose who gets this role as you would for any account that can read your site.', 'rolemend' ),
					__( 'A few of the other plugins\' screens that do open may load empty.', 'rolemend' ),
					__( 'On other plugins\' screens, a link or button that WordPress protects with a hidden check code is refused for both roles, even one that only reads, such as a download link.', 'rolemend' ),
					__( 'Appearance > Editor (called Design with a classic theme) opens, but its previews of posts, pages and navigation show nothing, because WordPress lists those only for people who may edit them.', 'rolemend' ),
				),
			),
			Rolemend_Roles::MEDIA     => array(
				'name'   => __( 'Media Library (no uploads)', 'rolemend' ),
				'intro'  => __( 'For an SEO or accessibility contractor who should fix titles and alternative text without adding files.', 'rolemend' ),
				'can'    => array(
					__( 'Open Dashboard, Media > Library (grid and list views, search and filters) and their own Profile.', 'rolemend' ),
					__( 'Open any item\'s Attachment details and Edit Media screen and save its Title, Alternative Text, Caption and Description.', 'rolemend' ),
					__( 'Sign in at wp-login.php straight to Media > Library, unless the sign-in asks for another page.', 'rolemend' ),
				),
				'cannot' => array(
					__( 'Upload in any way: there is no "Add Media File"; drag and drop, the upload button, the REST API and files fetched from a URL are all refused.', 'rolemend' ),
					__( 'Delete or trash media.', 'rolemend' ),
					__( 'Use Edit Image (crop, rotate, scale, restore).', 'rolemend' ),
					__( 'Change "Uploaded to", or anything else.', 'rolemend' ),
					__( 'Delete or change media through another plugin\'s tool: the database takes no write from other plugins\' code on their requests, except caches and their own settings and sign-in.', 'rolemend' ),
					__( 'Upload even if a role editor later gives this role upload rights.', 'rolemend' ),
					__( 'Post comments or send other forms on the front end while signed in.', 'rolemend' ),
				),
				'open'   => array(
					__( 'New alternative text in the library does not change images already placed in posts and pages: they keep the text they were inserted with. Featured images, galleries and shop images that the theme reads from the library do show the new text.', 'rolemend' ),
					__( 'On a WooCommerce shop the role reaches wp-admin like any other account: WooCommerce\'s redirect to My account is switched off for these two roles. Other shop and membership plugins that send people without the Edit Posts permission to an account page are not handled.', 'rolemend' ),
				),
			),
		);
	}

	/**
	 * Renders the screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'promote_users' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'rolemend' ), 403 );
		}
		$descriptions = self::descriptions();
		$total        = 0;
		echo '<div class="wrap rolemend-screen">';
		echo '<style>.rolemend-roles{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(360px,100%),1fr));gap:0 20px;align-items:start}.rolemend-roles .card{margin-top:20px;min-width:0}ul.rolemend-holders{margin:.5em 0 1em;padding:0;list-style:none}.rolemend-holders li{margin:0;padding:6px 0;border-top:1px solid #dcdcde;overflow-wrap:anywhere}.rolemend-holders li:first-child{border-top:0}.rolemend-holders .rolemend-name{font-weight:600}.rolemend-holders .rolemend-email{display:block;color:#646970}.rolemend-more>summary{cursor:pointer;color:#2271b1;padding:.3em 0}.rolemend-role details{margin:.6em 0 0}.rolemend-role summary{cursor:pointer;font-weight:600;padding:.3em 0}.rolemend-role summary .count{font-weight:400;color:#646970}.rolemend-more>summary{font-weight:400}</style>';
		echo '<h1>' . esc_html__( 'Rolemend', 'rolemend' ) . '</h1>';
		echo '<p>' . esc_html__( 'Two roles you can give from Users > Add User or from a user\'s profile. Nothing else on the site was changed when Rolemend was activated.', 'rolemend' ) . '</p>';
		echo '<div class="rolemend-roles">';

		foreach ( $descriptions as $role => $text ) {
			$holders = Rolemend_Roles::holders( $role );
			$total  += count( $holders );
			$add_url = add_query_arg( 'rolemend_role', $role, admin_url( 'user-new.php' ) );
			echo '<div class="card rolemend-role" id="' . esc_attr( 'rolemend-' . $role ) . '" style="max-width:none">';
			echo '<h2>' . esc_html( $text['name'] ) . '</h2>';
			echo '<p>' . esc_html( $text['intro'] ) . '</p>';

			echo '<h3>' . esc_html(
				sprintf(
					/* translators: %d: number of users. */
					_n( 'Who has this role (%d user)', 'Who has this role (%d users)', count( $holders ), 'rolemend' ),
					count( $holders )
				)
			) . '</h3>';
			if ( current_user_can( 'create_users' ) ) {
				echo '<p><a class="button button-primary" href="' . esc_url( $add_url ) . '">' . esc_html__( 'Add a user with this role', 'rolemend' ) . '</a></p>';
			}
			self::render_holders( $role, $holders );
			echo '<p class="description">' . esc_html__( 'To give the role to an existing user, open their profile (Users > All Users > Edit) and choose it under Role.', 'rolemend' ) . '</p>';

			self::render_list( __( 'What it can do', 'rolemend' ), $text['can'], 'rolemend-can' );
			self::render_list( __( 'What it cannot do', 'rolemend' ), $text['cannot'], 'rolemend-cannot' );
			self::render_list( __( 'What it does not lock', 'rolemend' ), $text['open'], 'rolemend-open' );
			echo '</div>';
		}
		echo '</div>';

		echo '<div class="card rolemend-removal" style="max-width:none">';
		echo '<h2>' . esc_html__( 'Deactivating and deleting Rolemend', 'rolemend' ) . '</h2>';
		echo '<p>' . esc_html__( 'Deactivating stops both roles at once: their users can no longer open wp-admin. Reactivating gives them back the same access.', 'rolemend' ) . '</p>';
		echo '<p class="rolemend-delete-warning"><strong>' . esc_html( self::deletion_sentence( $total ) ) . '</strong></p>';
		if ( is_multisite() ) {
			echo '<p>' . esc_html__( 'On a network, each site has its own two roles and its own list of users here.', 'rolemend' ) . '</p>';
		}
		echo '</div></div>';
	}

	/**
	 * What deleting the plugin does to the people who hold a role, with the count inside the sentence.
	 *
	 * @param int $total Users who hold either role.
	 * @return string
	 */
	public static function deletion_sentence( $total ) {
		if ( $total < 1 ) {
			return __( 'Deleting Rolemend removes both roles. Nobody has either role now, so no account is affected.', 'rolemend' );
		}
		return sprintf(
			/* translators: %d: number of users. */
			_n(
				'Deleting Rolemend removes both roles. Right now %d user has one of them and keeps their account, with no role on this site.',
				'Deleting Rolemend removes both roles. Right now %d users have one of them and keep their accounts, with no role on this site.',
				$total,
				'rolemend'
			),
			$total
		);
	}

	/**
	 * Who holds a role: one line each (name, username, then what an add-on says, such as an end date) with the address
	 * under it. The first ten show; the rest are one click away, so a site with many holders keeps the screen short and the
	 * buttons where they were (critique round 4, issue 2).
	 *
	 * @param string    $role    Role key.
	 * @param WP_User[] $holders Users.
	 */
	private static function render_holders( $role, $holders ) {
		if ( ! $holders ) {
			echo '<p class="rolemend-none"><em>' . esc_html__( 'Nobody yet.', 'rolemend' ) . '</em></p>';
			return;
		}
		/**
		 * The users who hold a role, in the order they are listed (add-ons may sort them).
		 *
		 * @param WP_User[] $holders Users.
		 * @param string    $role    Role key.
		 */
		$holders = array_values( (array) apply_filters( 'rolemend_holders', $holders, $role ) );
		$shown   = array_slice( $holders, 0, self::HOLDERS_SHOWN );
		$rest    = array_slice( $holders, self::HOLDERS_SHOWN );
		echo '<ul class="rolemend-holders">';
		foreach ( $shown as $user ) {
			self::render_holder( $user );
		}
		echo '</ul>';
		if ( $rest ) {
			echo '<details class="rolemend-more"><summary>' . esc_html(
				sprintf(
					/* translators: %d: number of users not shown yet. */
					_n( 'Show the other %d user', 'Show the other %d users', count( $rest ), 'rolemend' ),
					count( $rest )
				)
			) . '</summary><ul class="rolemend-holders">';
			foreach ( $rest as $user ) {
				self::render_holder( $user );
			}
			echo '</ul></details>';
		}
	}

	/**
	 * One holder: "Name · username · note", the address under it.
	 *
	 * @param WP_User $user User.
	 */
	private static function render_holder( $user ) {
		/**
		 * Short notes about a holder, shown after the username (an add-on may say when access ends).
		 *
		 * @param string[] $notes Plain text.
		 * @param WP_User  $user  User.
		 */
		$notes = array_filter( array_map( 'strval', (array) apply_filters( 'rolemend_holder_notes', array(), $user ) ) );
		if ( $user->user_login !== $user->display_name ) {
			array_unshift( $notes, $user->user_login );
		}
		echo '<li><span class="rolemend-name"><a href="' . esc_url( get_edit_user_link( $user->ID ) ) . '">' . esc_html( $user->display_name ) . '</a></span>';
		foreach ( $notes as $note ) {
			echo ' <span class="rolemend-note">&middot; ' . esc_html( $note ) . '</span>';
		}
		echo ' <span class="rolemend-email">' . esc_html( $user->user_email ) . '</span></li>';
	}

	/**
	 * A list the reader opens: closed until clicked, so the screen starts with who has each role and the button.
	 *
	 * @param string   $title Heading.
	 * @param string[] $items Items.
	 * @param string   $css   CSS class.
	 */
	private static function render_list( $title, $items, $css ) {
		echo '<details class="rolemend-details"><summary>' . esc_html( $title ) . ' <span class="count">(' . esc_html( (string) count( $items ) ) . ')</span></summary>';
		echo '<ul class="' . esc_attr( $css ) . '" style="list-style:disc;margin-left:2em">';
		foreach ( $items as $item ) {
			echo '<li>' . esc_html( $item ) . '</li>';
		}
		echo '</ul></details>';
	}
}
