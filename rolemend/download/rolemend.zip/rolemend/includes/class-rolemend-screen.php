<?php
/**
 * Users > Rolemend: who holds each role, and in plain words what each role can do.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * The plugin's one screen.
 */
class Rolemend_Screen {

	const SLUG = 'rolemend';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ROLEMEND_FILE ), array( __CLASS__, 'action_links' ) );
		add_filter( 'pre_option_default_role', array( __CLASS__, 'preselect_role' ) );
	}

	/**
	 * Users > Rolemend, for people who can change user roles.
	 */
	public static function add_page() {
		add_users_page(
			__( 'Rolemend', 'rolemend' ),
			__( 'Rolemend', 'rolemend' ),
			'promote_users',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Address of the screen.
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'users.php?page=' . self::SLUG );
	}

	/**
	 * "Roles" link on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( current_user_can( 'promote_users' ) ) {
			array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Roles', 'rolemend' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * "Add a user with this role" opens Users > Add User with the role already chosen.
	 * Only the form's default changes, for that one page load; nothing is saved.
	 *
	 * @param mixed $value Short-circuit value.
	 * @return mixed
	 */
	public static function preselect_role( $value ) {
		global $pagenow;
		if ( 'user-new.php' !== $pagenow || ! current_user_can( 'create_users' ) ) {
			return $value;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only preselects a form field.
		$role = isset( $_GET['rolemend_role'] ) ? sanitize_key( wp_unslash( $_GET['rolemend_role'] ) ) : '';
		return in_array( $role, Rolemend_Roles::keys(), true ) ? $role : $value;
	}

	/**
	 * What each role can do, cannot do, and what it does not lock.
	 *
	 * @return array
	 */
	public static function descriptions() {
		return array(
			Rolemend_Roles::VIEW_ONLY => array(
				'name'   => __( 'View Only', 'rolemend' ),
				'intro'  => __( 'For someone who should look round wp-admin and change nothing: an accountant, auditor, client, board member or new hire.', 'rolemend' ),
				'can'    => array(
					__( 'Open the screens an Administrator sees for WordPress itself: Dashboard, Posts, Pages, Media, Comments, Appearance (Themes, Editor or Menus, Widgets), Plugins, Users, Tools > Site Health and every Settings screen.', 'rolemend' ),
					__( 'See every post and page in the lists, drafts and private ones included, by title, author, date and status.', 'rolemend' ),
					__( 'Change their own password and their own screen options.', 'rolemend' ),
					__( 'Open other plugins\' screens that use WordPress\'s own Settings permission.', 'rolemend' ),
				),
				'cannot' => array(
					__( 'Save any Settings screen.', 'rolemend' ),
					__( 'Create, edit, publish, schedule, trash or delete posts, pages and drafts.', 'rolemend' ),
					__( 'Upload, edit or delete media.', 'rolemend' ),
					__( 'Approve, edit, mark as spam or delete comments.', 'rolemend' ),
					__( 'Add, edit, promote or delete users, or create application passwords.', 'rolemend' ),
					__( 'Install, activate, deactivate, update or delete plugins and themes.', 'rolemend' ),
					__( 'Save menus, widgets or the Customizer.', 'rolemend' ),
					__( 'Make any of these changes through the REST API.', 'rolemend' ),
					__( 'Save through other plugins\' own save handlers (admin-post.php, admin-ajax.php, the REST API, their own screens), or use a link or button on their screens that carries WordPress\'s security token.', 'rolemend' ),
					__( 'Get any write into the database through other plugins\' code that runs on their requests, except caches and their own settings and sign-in.', 'rolemend' ),
					__( 'Open Tools > Export, Tools > Import, the theme and plugin file editors, or Network Admin.', 'rolemend' ),
				),
				'open'   => array(
					__( 'Anything another plugin does outside the WordPress database when a plain link is clicked or a screen is read, such as sending an email, writing a file or calling another service. WordPress\'s own links, such as Trash or Activate, are refused, and database writes from other plugins\' links are stopped. A plugin whose save was stopped may still show its own "Saved" message.', 'rolemend' ),
					__( 'Code that runs while plugins are still loading, before WordPress knows who is signed in, and plugins that write to the database through their own connection instead of WordPress\'s.', 'rolemend' ),
					__( 'What the account can read is readable: user email addresses, commenter details, settings, and anything other plugins show on their screens. Choose who gets this role.', 'rolemend' ),
					__( 'Drafts are listed by title, author and date, but their text cannot be opened, because WordPress shows a draft only to people who may edit it.', 'rolemend' ),
					__( 'Tools > Export and the theme and plugin file editors are not available to the role.', 'rolemend' ),
					__( 'Other plugins\' screens appear only when they use WordPress\'s own Settings permission, and some of them may load empty when their reading also goes through a save handler.', 'rolemend' ),
					__( 'Other plugins\' menu entries, WooCommerce\'s Products and Yoast SEO\'s among them, are left out of the menu unless the plugin uses that Settings permission.', 'rolemend' ),
					__( 'Appearance > Editor opens, but its previews of posts, pages and navigation show nothing, because WordPress lists those only for people who may edit them.', 'rolemend' ),
				),
			),
			Rolemend_Roles::MEDIA     => array(
				'name'   => __( 'Media Library (no uploads)', 'rolemend' ),
				'intro'  => __( 'For an SEO or accessibility contractor who should fix titles and alternative text without adding files.', 'rolemend' ),
				'can'    => array(
					__( 'Open Dashboard, Media > Library (grid and list views, search and filters) and their own Profile.', 'rolemend' ),
					__( 'Open any item\'s Attachment details and Edit Media screen and save its Title, Alternative Text, Caption and Description.', 'rolemend' ),
				),
				'cannot' => array(
					__( 'Upload in any way: there is no "Add Media File"; drag and drop, the upload button, the REST API and files fetched from a URL are all refused.', 'rolemend' ),
					__( 'Delete or trash media.', 'rolemend' ),
					__( 'Use Edit Image (crop, rotate, scale, restore).', 'rolemend' ),
					__( 'Change "Uploaded to", or anything else.', 'rolemend' ),
					__( 'Delete or change media through another plugin\'s tool: the database takes no write from other plugins\' code on their requests, except caches and their own settings and sign-in.', 'rolemend' ),
					__( 'Upload even if a role editor later gives this role upload rights.', 'rolemend' ),
				),
				'open'   => array(
					__( 'New alternative text in the library does not change images already placed in posts and pages: they keep the text they were inserted with. Featured images, galleries and shop images that the theme reads from the library do show the new text.', 'rolemend' ),
					__( 'On a WooCommerce shop the role reaches wp-admin like any other account: WooCommerce\'s redirect to My account is switched off for these two roles. Other shop and membership plugins that send people without the Edit Posts permission to an account page are not handled.', 'rolemend' ),
				),
			),
		);
	}

	/**
	 * Renders the screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'promote_users' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'rolemend' ), 403 );
		}
		$descriptions = self::descriptions();
		$total        = 0;
		echo '<div class="wrap rolemend-screen">';
		echo '<h1>' . esc_html__( 'Rolemend', 'rolemend' ) . '</h1>';
		echo '<p>' . esc_html__( 'Two roles you can give from Users > Add User or from a user\'s profile. Nothing else on the site was changed when Rolemend was activated.', 'rolemend' ) . '</p>';

		foreach ( $descriptions as $role => $text ) {
			$holders = Rolemend_Roles::holders( $role );
			$total  += count( $holders );
			$add_url = add_query_arg( 'rolemend_role', $role, admin_url( 'user-new.php' ) );
			echo '<div class="card rolemend-role" id="' . esc_attr( 'rolemend-' . $role ) . '" style="max-width:none">';
			echo '<h2>' . esc_html( $text['name'] ) . '</h2>';
			echo '<p>' . esc_html( $text['intro'] ) . '</p>';

			echo '<h3>' . esc_html(
				sprintf(
					/* translators: %d: number of users. */
					_n( 'Who has this role (%d user)', 'Who has this role (%d users)', count( $holders ), 'rolemend' ),
					count( $holders )
				)
			) . '</h3>';
			self::render_holders( $role, $holders );
			if ( current_user_can( 'create_users' ) ) {
				echo '<p><a class="button button-primary" href="' . esc_url( $add_url ) . '">' . esc_html__( 'Add a user with this role', 'rolemend' ) . '</a></p>';
			}
			echo '<p class="description">' . esc_html__( 'To give the role to an existing user, open their profile (Users > All Users > Edit) and choose it under Role.', 'rolemend' ) . '</p>';

			self::render_list( __( 'What it can do', 'rolemend' ), $text['can'], 'rolemend-can' );
			self::render_list( __( 'What it cannot do', 'rolemend' ), $text['cannot'], 'rolemend-cannot' );
			self::render_list( __( 'What it does not lock', 'rolemend' ), $text['open'], 'rolemend-open' );
			echo '</div>';
		}

		echo '<div class="card rolemend-removal" style="max-width:none">';
		echo '<h2>' . esc_html__( 'Deactivating and deleting Rolemend', 'rolemend' ) . '</h2>';
		echo '<p>' . esc_html__( 'Deactivating stops both roles at once: their users can no longer open wp-admin. Reactivating gives them back the same access.', 'rolemend' ) . '</p>';
		echo '<p class="rolemend-delete-warning"><strong>' . esc_html(
			sprintf(
				/* translators: %d: number of users. */
				_n(
					'Deleting Rolemend removes both roles. The %d user who has one of them keeps their account, with no role on this site.',
					'Deleting Rolemend removes both roles. The %d users who have one of them keep their accounts, with no role on this site.',
					$total,
					'rolemend'
				),
				$total
			)
		) . '</strong></p>';
		if ( is_multisite() ) {
			echo '<p>' . esc_html__( 'On a network, each site has its own two roles and its own list of users here.', 'rolemend' ) . '</p>';
		}
		echo '</div></div>';
	}

	/**
	 * Table of users holding a role.
	 *
	 * @param string    $role    Role key.
	 * @param WP_User[] $holders Users.
	 */
	private static function render_holders( $role, $holders ) {
		if ( ! $holders ) {
			echo '<p class="rolemend-none"><em>' . esc_html__( 'Nobody yet.', 'rolemend' ) . '</em></p>';
			return;
		}
		/**
		 * Extra columns for the holders table, for add-ons.
		 *
		 * @param array  $columns Column key => label.
		 * @param string $role    Role key.
		 */
		$extra = (array) apply_filters( 'rolemend_holder_columns', array(), $role );
		echo '<table class="widefat striped rolemend-holders"><thead><tr>';
		echo '<th>' . esc_html__( 'Name', 'rolemend' ) . '</th><th>' . esc_html__( 'Username', 'rolemend' ) . '</th><th>' . esc_html__( 'Email', 'rolemend' ) . '</th>';
		foreach ( $extra as $label ) {
			echo '<th>' . esc_html( $label ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $holders as $user ) {
			echo '<tr><td><a href="' . esc_url( get_edit_user_link( $user->ID ) ) . '">' . esc_html( $user->display_name ) . '</a></td>';
			echo '<td>' . esc_html( $user->user_login ) . '</td><td>' . esc_html( $user->user_email ) . '</td>';
			foreach ( array_keys( $extra ) as $key ) {
				/**
				 * Value of an extra holders column.
				 *
				 * @param string  $value Plain text.
				 * @param string  $key   Column key.
				 * @param WP_User $user  User.
				 */
				echo '<td>' . esc_html( (string) apply_filters( 'rolemend_holder_column_value', '', $key, $user ) ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * A headed list.
	 *
	 * @param string   $title Heading.
	 * @param string[] $items Items.
	 * @param string   $css   CSS class.
	 */
	private static function render_list( $title, $items, $css ) {
		echo '<h3>' . esc_html( $title ) . '</h3><ul class="' . esc_attr( $css ) . '" style="list-style:disc;margin-left:2em">';
		foreach ( $items as $item ) {
			echo '<li>' . esc_html( $item ) . '</li>';
		}
		echo '</ul>';
	}
}
