<?php
/**
 * Refuses every request from the two roles that would change something.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Request-level refusals.
 *
 * Checks run on `init` (before other plugins' save handlers that listen on `init`,
 * `admin_init`, `admin_post_*` and `wp_ajax_*`), again on `admin_init`, on
 * `rest_pre_dispatch` for the REST API, and in WordPress's own upload handling.
 */
class Rolemend_Guard {

	/**
	 * WordPress screens neither role may open at all (they exist to change things,
	 * or, for Export and the file editors, the brief keeps them away from the roles).
	 *
	 * @var string[]
	 */
	const REFUSED_PAGES = array(
		'post-new.php',
		'comment.php',
		'user-new.php',
		'plugin-install.php',
		'plugin-editor.php',
		'theme-install.php',
		'theme-editor.php',
		'update.php',
		'update-core.php',
		'import.php',
		'export.php',
		'export-personal-data.php',
		'erase-personal-data.php',
		'customize.php',
		'options.php',
		'media-new.php',
		'async-upload.php',
		'media.php',
		'revision.php',
		'term.php',
		'link-add.php',
		'link.php',
		'link-manager.php',
		'edit-link.php',
		'authorize-application.php',
		'network.php',
		'ms-delete-site.php',
		'ms-edit.php',
		'ms-options.php',
		'ms-sites.php',
		'ms-themes.php',
		'ms-users.php',
		'admin-post.php',
		'press-this.php',
	);

	/**
	 * GET parameters that only ever ask WordPress to change something.
	 *
	 * @var string[]
	 */
	const CHANGE_PARAMS = array(
		'delete_all',
		'delete_all2',
		'changeit',
		'new_role',
		'new_role2',
		'doaction',
		'doaction2',
		'found_post_id',
	);

	/**
	 * The admin-ajax.php actions the View Only role may call: reading, and its own screen layout.
	 *
	 * @var string[]
	 */
	const VIEW_ONLY_AJAX = array(
		'heartbeat',
		'logged-in',
		'closed-postboxes',
		'hidden-columns',
		'meta-box-order',
		'update-welcome-panel',
		'dashboard-widgets',
		'get-community-events',
		'query-attachments',
		'get-attachment',
		'fetch-list',
		'search-plugins',
		'menu-get-metabox',
		'menu-quick-search',
		'generate-password',
	);

	/**
	 * The admin-ajax.php actions the Media Library (no uploads) role may call.
	 * save-attachment is checked further: only the four text fields.
	 *
	 * @var string[]
	 */
	const MEDIA_AJAX = array(
		'heartbeat',
		'logged-in',
		'closed-postboxes',
		'hidden-columns',
		'meta-box-order',
		'update-welcome-panel',
		'dashboard-widgets',
		'get-community-events',
		'query-attachments',
		'get-attachment',
		'fetch-list',
		'save-attachment',
		'wp-remove-post-lock',
		'generate-password',
		'destroy-sessions',
		'save-user-color-scheme',
	);

	/**
	 * Fields the media role may change through Attachment details.
	 *
	 * @var string[]
	 */
	const MEDIA_FIELDS = array( 'title', 'caption', 'description', 'alt' );

	/**
	 * WordPress's own list screens, whose filter forms send a nonce with _wp_http_referer and only read.
	 *
	 * @var string[]
	 */
	const LIST_SCREENS = array( 'edit.php', 'upload.php', 'users.php', 'edit-comments.php', 'edit-tags.php', 'plugins.php' );

	/**
	 * Whether a security token was taken off this request (another plugin's screen, GET).
	 *
	 * @var bool
	 */
	private static $nonce_removed = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'hold_back_customizer' ), 0 );
		add_action( 'init', array( __CLASS__, 'guard_request' ), -1000 );
		add_action( 'admin_init', array( __CLASS__, 'guard_request' ), -1000 );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'guard_rest' ), 0, 3 );
		add_filter( 'wp_handle_upload_prefilter', array( __CLASS__, 'refuse_upload' ), 0 );
		add_filter( 'wp_handle_sideload_prefilter', array( __CLASS__, 'refuse_upload' ), 0 );
		add_filter( 'wp_upload_bits', array( __CLASS__, 'refuse_upload_bits' ), 0 );
		add_filter( 'authenticate', array( __CLASS__, 'refuse_xmlrpc' ), 100 );
		add_action( 'login_form_confirm_admin_email', array( __CLASS__, 'skip_admin_email_check' ) );
		add_action( 'check_admin_referer', array( __CLASS__, 'refuse_removed_nonce' ), 0, 2 );
		add_action( 'check_ajax_referer', array( __CLASS__, 'refuse_removed_nonce' ), 0, 2 );
		// Last lines under the request checks, whatever code runs on the request of either role (WordPress
		// creates some posts lazily on reading screens; other plugins run their own handlers): no post is
		// written outside the media role's own four-field saves, none is deleted or trashed, no term is
		// created. Below these, Rolemend_Writes stops every other database write.
		add_filter( 'wp_insert_post_empty_content', array( __CLASS__, 'refuse_post_write' ), 1000 );
		add_filter( 'pre_delete_post', array( __CLASS__, 'refuse_post_delete' ), 1000 );
		add_filter( 'pre_trash_post', array( __CLASS__, 'refuse_post_delete' ), 1000 );
		add_filter( 'pre_insert_term', array( __CLASS__, 'refuse_term_write' ), 1000 );
	}

	/**
	 * Treats every post a restricted user's request would save as empty, so WordPress saves nothing.
	 * The media role's own saves of the four fields run inside Rolemend_Writes::allow() and pass.
	 *
	 * @param bool $maybe_empty Whether WordPress considers the post empty.
	 * @return bool
	 */
	public static function refuse_post_write( $maybe_empty ) {
		$role = Rolemend_Writes::role();
		if ( 'view' === $role || ( 'media' === $role && ! Rolemend_Writes::is_allowing() ) ) {
			return true;
		}
		return $maybe_empty;
	}

	/**
	 * Stops deleting or trashing a post on a restricted user's request.
	 *
	 * @param mixed $check Short-circuit value.
	 * @return mixed
	 */
	public static function refuse_post_delete( $check ) {
		return '' !== Rolemend_Writes::role() ? false : $check;
	}

	/**
	 * Stops creating a term on a restricted user's request.
	 *
	 * @param string|WP_Error $term Term name.
	 * @return string|WP_Error
	 */
	public static function refuse_term_write( $term ) {
		$role = Rolemend_Writes::role();
		return '' !== $role ? new WP_Error( 'rolemend_not_allowed', self::message( $role ) ) : $term;
	}

	/**
	 * A handler on another plugin's screen checked the security token Rolemend took off a link or GET form
	 * (see get_changes_something()): it is about to change something, so the plain refusal is shown.
	 *
	 * @param string    $action Nonce action.
	 * @param false|int $result Verification result.
	 */
	public static function refuse_removed_nonce( $action, $result ) {
		if ( self::$nonce_removed && false === $result ) {
			$role = self::role_of();
			if ( '' !== $role ) {
				self::refuse( $role );
			}
		}
	}

	/**
	 * Which restriction applies to the current user: 'view', 'media' or ''.
	 *
	 * @param WP_User|null $user User, default current.
	 * @return string
	 */
	public static function role_of( $user = null ) {
		$user = $user ? $user : wp_get_current_user();
		if ( Rolemend_Roles::is_view_only( $user ) ) {
			return 'view';
		}
		if ( Rolemend_Roles::is_media_role( $user ) ) {
			return 'media';
		}
		return '';
	}

	/**
	 * The plain refusal message.
	 *
	 * @param string $role 'view' or 'media'.
	 * @param string $kind 'change', 'upload' or 'read' (View Only asked to open an item in the editor).
	 * @return string
	 */
	public static function message( $role, $kind = 'change' ) {
		if ( 'view' === $role && 'read' === $kind ) {
			return __( 'This account is view only, so the editor does not open. Posts, pages and drafts are listed by title, author, date and status; the text of a draft cannot be opened.', 'rolemend' );
		}
		if ( 'view' === $role ) {
			return __( 'This account is view only, so nothing was changed. Ask an administrator if this change is needed.', 'rolemend' );
		}
		if ( 'upload' === $kind ) {
			return __( 'This account cannot upload files, so nothing was uploaded. Ask an administrator to add the file to the Media Library.', 'rolemend' );
		}
		return __( 'This account can change only the title, alternative text, caption and description of media, so nothing was changed. Ask an administrator if this change is needed.', 'rolemend' );
	}

	/**
	 * Main check, on init and again on admin_init.
	 *
	 * In wp-admin (admin pages, admin-ajax.php, admin-post.php, async-upload.php) for both roles.
	 * Outside wp-admin, both roles may send nothing but GET and HEAD requests (wp-login.php
	 * excepted, for signing in and resetting their own password, and the block editor's own
	 * preferences): no comments, no forms that write, no REST changes.
	 */
	public static function guard_request() {
		$role = self::role_of();
		if ( '' === $role ) {
			return;
		}
		if ( ! is_admin() ) {
			if ( self::is_write_method() && 'wp-login.php' !== self::page() ) {
				if ( self::is_rest_url() && ( 'OPTIONS' === self::method() || self::is_own_preferences_route() ) ) {
					// OPTIONS only describes a route; saving editor preferences is checked field by field in guard_rest().
					return;
				}
				if ( self::is_rest_url() ) {
					$kind = ( 'POST' === self::method() && '/wp/v2/media' === self::rest_route_from_url() ) ? 'upload' : 'change';
					wp_send_json(
						array(
							'code'    => 'rolemend_not_allowed',
							'message' => self::message( $role, $kind ),
							'data'    => array( 'status' => 403 ),
						),
						403
					);
				}
				self::refuse( $role );
			}
			return;
		}
		$page = self::page();

		if ( is_network_admin() ) {
			self::refuse( $role );
		}

		if ( 'admin-ajax.php' === $page ) {
			self::guard_ajax( $role );
			return;
		}

		if ( 'async-upload.php' === $page ) {
			self::refuse_upload_request( $role );
		}

		if ( 'post.php' === $page ) {
			self::guard_post_php( $role );
			return;
		}

		if ( in_array( $page, self::REFUSED_PAGES, true ) ) {
			self::refuse( $role, in_array( $page, array( 'media-new.php', 'media.php' ), true ) ? 'upload' : 'change' );
		}

		if ( 'user-edit.php' === $page && self::request_int( 'user_id' ) !== get_current_user_id() ) {
			self::refuse( $role );
		}

		if ( self::is_write_method() ) {
			self::guard_post( $role, $page );
			return;
		}

		if ( self::get_changes_something( $page ) ) {
			self::refuse( $role );
		}
	}

	/**
	 * The Customizer starts before init and refuses with its own words. For the two roles it is not
	 * started at all, so customize.php and its save request reach the checks above and get the plain message.
	 */
	public static function hold_back_customizer() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Presence only.
		$customizer = ( isset( $_REQUEST['wp_customize'] ) && 'on' === $_REQUEST['wp_customize'] ) || ( is_admin() && 'customize.php' === self::page() );
		if ( $customizer && '' !== self::role_of() ) {
			remove_action( 'plugins_loaded', '_wp_customize_include' );
		}
	}

	/**
	 * POST (or any method other than GET and HEAD) to an admin page.
	 *
	 * Allowed: own Profile (View Only: password only, saved by Rolemend_View_Only),
	 * and Screen Options, which WordPress saves and redirects before `admin_init`.
	 *
	 * @param string $role Role.
	 * @param string $page Admin file.
	 */
	private static function guard_post( $role, $page ) {
		if ( 'profile.php' === $page ) {
			if ( doing_action( 'admin_init' ) && 'view' === $role ) {
				Rolemend_View_Only::save_profile();
			}
			return;
		}
		if ( self::is_screen_options_post() && ! doing_action( 'admin_init' ) ) {
			// WordPress saves it in set_screen_options() and exits; anything still here at admin_init is refused.
			return;
		}
		self::refuse( $role );
	}

	/**
	 * Whether the POST is the Screen Options form and nothing else.
	 *
	 * @return bool
	 */
	private static function is_screen_options_post() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Only the field names are inspected; WordPress verifies the screen options nonce itself.
		if ( ! isset( $_POST['wp_screen_options'] ) || ! is_array( $_POST['wp_screen_options'] ) ) {
			return false;
		}
		$fields = array( 'wp_screen_options', 'screenoptionnonce', 'screen-options-apply', 'mode', 'screen_columns' );
		foreach ( array_keys( $_POST ) as $key ) {
			if ( ! in_array( $key, $fields, true ) && '-hide' !== substr( (string) $key, -5 ) ) {
				return false;
			}
		}
		// phpcs:enable
		return true;
	}

	/**
	 * Post editing screens. View Only: never. Media role: the Edit Media screen of an attachment.
	 *
	 * @param string $role Role.
	 */
	private static function guard_post_php( $role ) {
		if ( 'media' === $role ) {
			$action = self::request_string( 'action' );
			if ( self::is_write_method() ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce checked in Rolemend_Media::save_edit_media().
				$post_id = isset( $_POST['post_ID'] ) ? absint( $_POST['post_ID'] ) : 0;
				if ( 'editpost' === $action && self::is_attachment( $post_id ) ) {
					if ( doing_action( 'admin_init' ) ) {
						Rolemend_Media::save_edit_media( $post_id );
					}
					return;
				}
			} elseif ( 'edit' === $action && self::is_attachment( self::request_int( 'post' ) ) ) {
				return;
			}
		} elseif ( ! self::is_write_method() && 'edit' === self::request_string( 'action' ) ) {
			// View Only asking to read an item in the editor: not a change, so the refusal says what is true.
			self::refuse( $role, 'read' );
		}
		self::refuse( $role );
	}

	/**
	 * Whether a GET request to an otherwise allowed admin page asks for a change.
	 *
	 * @param string $page Admin file.
	 * @return bool
	 */
	private static function get_changes_something( $page ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only inspection of the request to refuse it.
		foreach ( self::CHANGE_PARAMS as $param ) {
			if ( isset( $_GET[ $param ] ) ) {
				return true;
			}
		}

		$read_actions = array( '', '-1' );
		if ( 'nav-menus.php' === $page ) {
			$read_actions = array( '', '-1', 'edit', 'locations' );
		}
		$has_plugin_page = isset( $_GET['page'] ) && '' !== $_GET['page'];
		foreach ( array( 'action', 'action2' ) as $param ) {
			if ( ! isset( $_GET[ $param ] ) || ! is_string( $_GET[ $param ] ) ) {
				continue;
			}
			$value = sanitize_text_field( wp_unslash( $_GET[ $param ] ) );
			if ( in_array( $value, $read_actions, true ) ) {
				continue;
			}
			// Other plugins' own screens use action=edit and similar for reading; their nonce links are caught below.
			if ( 'admin.php' === $page && $has_plugin_page ) {
				continue;
			}
			return true;
		}

		$nonces = array( '_wpnonce', '_ajax_nonce', 'nonce' );
		if ( $has_plugin_page ) {
			// Another plugin's screen. Its search and filter forms often carry a token too, so the request is
			// not refused here: the token is taken off, the screen still reads, and a handler that checks the
			// token (it is about to change something) gets the plain refusal from refuse_removed_nonce().
			foreach ( $nonces as $param ) {
				if ( isset( $_GET[ $param ] ) ) {
					unset( $_GET[ $param ], $_REQUEST[ $param ] );
					self::$nonce_removed = true;
				}
			}
			return false;
		}

		// A link carrying a security token (nonce) is a link that changes something. The filter forms of
		// WordPress's own list screens also carry one, together with _wp_http_referer, and are reads.
		$list_filter = isset( $_GET['_wp_http_referer'] ) && in_array( $page, self::LIST_SCREENS, true );
		foreach ( $nonces as $param ) {
			if ( isset( $_GET[ $param ] ) && ! $list_filter ) {
				return true;
			}
		}
		// phpcs:enable
		return false;
	}

	/**
	 * Checks an admin-ajax.php call against the allow-list of the role.
	 *
	 * @param string $role Role.
	 */
	private static function guard_ajax( $role ) {
		$action = self::request_string( 'action' );

		if ( 'upload-attachment' === $action ) {
			self::refuse_upload_request( $role );
		}
		if ( 'image-editor' === $action || 'imgedit-preview' === $action ) {
			// Shown by WordPress's image editor script in place of the editor.
			$post_id = self::request_int( 'postid' );
			$back    = $post_id ? '<p><button type="button" class="button" onclick="' . esc_attr( 'imageEdit.close(' . $post_id . ');' ) . '">' . esc_html__( 'Back', 'rolemend' ) . '</button></p>' : '';
			wp_send_json_error(
				array(
					'message' => self::message( $role ),
					'html'    => '<div class="notice notice-error inline rolemend-refused" role="alert"><p>' . esc_html( self::message( $role ) ) . '</p>' . $back . '</div>',
				)
			);
		}

		$allowed = 'view' === $role ? self::VIEW_ONLY_AJAX : self::MEDIA_AJAX;
		if ( ! in_array( $action, $allowed, true ) ) {
			self::refuse_json( $role );
		}

		if ( 'save-attachment' === $action ) {
			// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- WordPress checks the nonce in wp_ajax_save_attachment(); only the field names are read here.
			$changes = isset( $_REQUEST['changes'] ) ? wp_unslash( $_REQUEST['changes'] ) : null;
			// phpcs:enable
			if ( ! is_array( $changes ) || array() === $changes || array_diff( array_keys( $changes ), self::MEDIA_FIELDS ) ) {
				self::refuse_json( $role );
			}
		}
		if ( 'wp-remove-post-lock' === $action && ! self::is_attachment( self::request_int( 'post_ID' ) ) ) {
			self::refuse_json( $role );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- WordPress checks the heartbeat nonce; only keys are removed here.
		if ( 'heartbeat' === $action && isset( $_POST['data'] ) && is_array( $_POST['data'] ) ) {
			// Other plugins can save through heartbeat_received; only WordPress's own sign-in check
			// (and, for the media role, the edit lock of the attachment it is editing) gets through.
			$keep          = 'view' === $role ? array( 'wp-auth-check' ) : array( 'wp-auth-check', 'wp-refresh-post-lock', 'wp-refresh-post-nonces' );
			$_POST['data'] = array_intersect_key( $_POST['data'], array_flip( $keep ) );
		}
		// phpcs:enable
	}

	/**
	 * Refuses async-upload.php and the upload-attachment action in the shape WordPress's uploader expects,
	 * so the message shows in the Media Library's upload panel.
	 *
	 * @param string $role Role.
	 */
	private static function refuse_upload_request( $role ) {
		if ( wp_doing_ajax() ) {
			$name = isset( $_FILES['async-upload']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['async-upload']['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Refusing; nothing is processed.
			wp_send_json_error(
				array(
					'message'  => self::message( $role, 'upload' ),
					'filename' => $name,
				)
			);
		}
		self::refuse( $role, 'upload' );
	}

	/**
	 * REST API: reading only.
	 *
	 * @param mixed           $result  Response to replace the requested version with.
	 * @param WP_REST_Server  $server  Server instance.
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function guard_rest( $result, $server, $request ) {
		$role = self::role_of();
		if ( '' === $role ) {
			return $result;
		}
		$method = strtoupper( $request->get_method() );
		$route  = untrailingslashit( $request->get_route() );
		if ( self::is_preferences_request( $request ) ) {
			// The block editor's own interface preferences (which panels are open, the welcome guide):
			// the user's screen options, kept in their user meta.
			return $result;
		}
		// These GET routes write: the navigation fallback creates a menu, the oEmbed proxy fills a cache.
		$writing_reads = array( '/wp-block-editor/v1/navigation-fallback', '/oembed/1.0/proxy' );
		if ( in_array( $method, array( 'GET', 'HEAD', 'OPTIONS' ), true ) && ! in_array( $route, $writing_reads, true ) ) {
			return $result;
		}
		$kind = ( '/wp/v2/media' === $route && 'POST' === $method ) ? 'upload' : 'change';
		return new WP_Error( 'rolemend_not_allowed', self::message( $role, $kind ), array( 'status' => 403 ) );
	}

	/**
	 * WordPress's own upload handling (wp_handle_upload, wp_handle_sideload, media_sideload_image, media_handle_upload):
	 * refused for both roles, whatever capabilities a role editor has added.
	 *
	 * @param array $file File data.
	 * @return array
	 */
	public static function refuse_upload( $file ) {
		$role = self::role_of();
		if ( '' !== $role ) {
			$file['error'] = self::message( $role, 'upload' );
		}
		return $file;
	}

	/**
	 * Refuses wp_upload_bits(), which takes a non-array return as the error.
	 *
	 * @param array $bits Name, bits and time.
	 * @return array|string
	 */
	public static function refuse_upload_bits( $bits ) {
		$role = self::role_of();
		return '' === $role ? $bits : self::message( $role, 'upload' );
	}

	/**
	 * XML-RPC writes outside the checks above, so the two roles cannot sign in to it.
	 *
	 * @param WP_User|WP_Error|null $user Authenticated user.
	 * @return WP_User|WP_Error|null
	 */
	public static function refuse_xmlrpc( $user ) {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST && $user instanceof WP_User && '' !== self::role_of( $user ) ) {
			return new WP_Error( 'rolemend_xmlrpc', self::message( self::role_of( $user ) ) );
		}
		return $user;
	}

	/**
	 * WordPress asks users who can manage options to confirm the administration email at login,
	 * which saves an option. A View Only user is sent to the Dashboard instead.
	 */
	public static function skip_admin_email_check() {
		if ( 'view' === self::role_of() ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
	}

	/**
	 * Refuses with the plain message on a normal WordPress error page.
	 *
	 * @param string $role Role.
	 * @param string $kind 'change', 'upload' or 'read'.
	 */
	public static function refuse( $role, $kind = 'change' ) {
		if ( ! empty( $_FILES ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Refusing; the files are not read.
			$kind = 'upload';
		}
		if ( wp_doing_ajax() ) {
			self::refuse_json( $role, $kind );
		}
		$title = 'view' === $role ? __( 'View only', 'rolemend' ) : __( 'Not allowed for this account', 'rolemend' );
		wp_die(
			'<h1>' . esc_html( $title ) . '</h1><p>' . esc_html( self::message( $role, $kind ) ) . '</p>',
			esc_html( $title ),
			array(
				'response'  => 403,
				'back_link' => true,
			)
		);
	}

	/**
	 * Refuses an admin-ajax.php call with a JSON error carrying the message.
	 *
	 * @param string $role Role.
	 * @param string $kind 'change' or 'upload'.
	 */
	private static function refuse_json( $role, $kind = 'change' ) {
		if ( ! empty( $_FILES ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Refusing; the files are not read.
			$kind = 'upload';
		}
		wp_send_json_error( array( 'message' => self::message( $role, $kind ) ), 403 );
	}

	/**
	 * The admin file being requested.
	 *
	 * @return string
	 */
	private static function page() {
		global $pagenow;
		return is_string( $pagenow ) ? $pagenow : '';
	}

	/**
	 * Whether the request is addressed to the REST API (checked before WordPress has parsed it).
	 *
	 * @return bool
	 */
	private static function is_rest_url() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Presence only.
		if ( isset( $_GET['rest_route'] ) ) {
			return true;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		return false !== strpos( $uri, '/' . rest_get_url_prefix() . '/' );
	}

	/**
	 * Whether a REST request saves only the current user's block editor preferences
	 * (POST/PUT/PATCH /wp/v2/users/me with nothing but meta.persisted_preferences).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	private static function is_preferences_request( $request ) {
		$route = untrailingslashit( $request->get_route() );
		$own   = array( '/wp/v2/users/me', '/wp/v2/users/' . get_current_user_id() );
		if ( ! in_array( strtoupper( $request->get_method() ), array( 'POST', 'PUT', 'PATCH' ), true ) || ! in_array( $route, $own, true ) ) {
			return false;
		}
		$params = array_merge( (array) $request->get_json_params(), (array) $request->get_body_params() );
		unset( $params['_locale'] );
		return array( 'meta' ) === array_keys( $params ) && is_array( $params['meta'] ) && array( 'persisted_preferences' ) === array_keys( $params['meta'] );
	}

	/**
	 * Whether the URL addresses /wp/v2/users/me (the only REST route where a View Only user may save,
	 * and only their editor preferences; guard_rest() checks the fields).
	 *
	 * @return bool
	 */
	private static function is_own_preferences_route() {
		return in_array( self::rest_route_from_url(), array( '/wp/v2/users/me', '/wp/v2/users/' . get_current_user_id() ), true );
	}

	/**
	 * The REST route addressed by the URL, read before WordPress has parsed the request.
	 *
	 * @return string
	 */
	private static function rest_route_from_url() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only inspection.
		$route = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : '';
		if ( '' === $route ) {
			$uri   = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$path  = (string) wp_parse_url( $uri, PHP_URL_PATH );
			$mark  = '/' . rest_get_url_prefix();
			$at    = strpos( $path, $mark );
			$route = false === $at ? '' : substr( $path, $at + strlen( $mark ) );
		}
		return untrailingslashit( $route );
	}

	/**
	 * The request method in capitals.
	 *
	 * @return string
	 */
	private static function method() {
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
	}

	/**
	 * Whether the request uses a method other than GET or HEAD.
	 *
	 * @return bool
	 */
	private static function is_write_method() {
		return ! in_array( self::method(), array( 'GET', 'HEAD' ), true );
	}

	/**
	 * A request value as a string.
	 *
	 * @param string $key Key.
	 * @return string
	 */
	private static function request_string( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only inspection.
		if ( ! isset( $_REQUEST[ $key ] ) || ! is_string( $_REQUEST[ $key ] ) ) {
			return '';
		}
		return sanitize_text_field( wp_unslash( $_REQUEST[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only inspection.
	}

	/**
	 * A request value as an integer.
	 *
	 * @param string $key Key.
	 * @return int
	 */
	private static function request_int( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only inspection.
		return isset( $_REQUEST[ $key ] ) && is_scalar( $_REQUEST[ $key ] ) ? absint( $_REQUEST[ $key ] ) : 0;
	}

	/**
	 * Whether an ID is an attachment.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function is_attachment( $post_id ) {
		return $post_id > 0 && 'attachment' === get_post_type( $post_id );
	}
}
