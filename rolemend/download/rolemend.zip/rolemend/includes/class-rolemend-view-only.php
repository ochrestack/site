<?php
/**
 * View Only role: what its users see on screen, and their own password.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * The marker, the hidden buttons, and the password-only Profile save.
 */
class Rolemend_View_Only {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 1000 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard' ), 1000 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 1000 );
		add_action( 'admin_head', array( __CLASS__, 'styles' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'site_editor_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'profile_notice' ) );
		add_action( 'admin_footer-profile.php', array( __CLASS__, 'profile_fields' ) );
		add_action( 'admin_notices', array( __CLASS__, 'tools_notice' ) );
		add_action( 'admin_footer', array( __CLASS__, 'switch_off_saves' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'widgets_editor' ) );
	}

	/**
	 * Whether the current user holds the View Only role.
	 *
	 * @return bool
	 */
	private static function applies() {
		return Rolemend_Roles::is_view_only( wp_get_current_user() );
	}

	/**
	 * "View only" marker in the toolbar, on every screen; the "New" and "Edit" menus removed.
	 *
	 * @param WP_Admin_Bar $bar Toolbar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! self::applies() ) {
			return;
		}
		$bar->remove_node( 'new-content' );
		$bar->remove_node( 'edit' );
		$bar->remove_node( 'customize' );
		$bar->add_node(
			array(
				'id'     => 'rolemend-view-only',
				'parent' => 'top-secondary',
				'title'  => '<span class="ab-icon dashicons dashicons-visibility" aria-hidden="true"></span><span class="ab-label">' . esc_html__( 'View only', 'rolemend' ) . '</span>',
				'meta'   => array(
					'title' => __( 'This account can look at everything here but cannot change anything.', 'rolemend' ),
				),
			)
		);
	}

	/**
	 * Quick Draft creates a draft each time the Dashboard loads, so it is not shown. The Welcome panel has only
	 * "Add a new page"-type links that lead to refusals, so it is not shown either.
	 */
	public static function dashboard() {
		if ( self::applies() ) {
			remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
			remove_action( 'welcome_panel', 'wp_welcome_panel' );
		}
	}

	/**
	 * Menu items that only lead to "add new" screens.
	 */
	public static function menu() {
		if ( ! self::applies() ) {
			return;
		}
		remove_submenu_page( 'edit.php', 'post-new.php' );
		remove_submenu_page( 'edit.php?post_type=page', 'post-new.php?post_type=page' );
		remove_submenu_page( 'upload.php', 'media-new.php' );
		if ( current_user_can( 'view_site_health_checks' ) ) {
			// Available Tools lists only what this role may not use (Import, Export, other plugins' tools), so it
			// would open empty; Tools then opens on Site Health, the one thing here the role can read.
			remove_submenu_page( 'tools.php', 'tools.php' );
		}
	}

	/**
	 * Tools > Available Tools, opened by address: says why it is empty instead of showing a blank page.
	 */
	public static function tools_notice() {
		global $pagenow;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		if ( 'tools.php' !== $pagenow || ! self::applies() || ! empty( $_GET['page'] ) ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s</p></div>',
			esc_html__( 'This account is view only, so none of the tools on this screen can be used. Tools > Site Health can be read.', 'rolemend' )
		);
	}

	/**
	 * The one sentence a View Only user reads wherever saving is switched off.
	 *
	 * @return string
	 */
	private static function saving_off_notice() {
		return __( 'This account is view only. You can read this screen; saving is switched off.', 'rolemend' );
	}

	/**
	 * Every screen with a Save, Update or Create button (Settings, Menus, other plugins' settings forms): the
	 * buttons are switched off with a tooltip saying why, and one notice on top says the same, as on Profile.
	 * The server refuses the save anyway (Rolemend_Guard); this keeps a person from typing into a form whose
	 * save can only be refused. Profile, which saves the password, and Screen Options keep their buttons.
	 */
	public static function switch_off_saves() {
		global $pagenow;
		if ( ! self::applies() || 'profile.php' === $pagenow ) {
			return;
		}
		$notice = self::saving_off_notice();
		$tip    = __( 'Saving is switched off: this account is view only.', 'rolemend' );
		?>
		<script id="rolemend-view-only-saves">
		( function () {
			var tip = <?php echo wp_json_encode( $tip ); ?>, message = <?php echo wp_json_encode( $notice ); ?>;
			function shown( el ) { return null !== el.offsetParent || 'fixed' === window.getComputedStyle( el ).position; }
			function makeNote() {
				var note = document.createElement( 'div' ), text = document.createElement( 'p' );
				note.className = 'notice notice-info inline rolemend-saves-off';
				text.textContent = message;
				note.appendChild( text );
				return note;
			}
			// Buttons that only read or move around (tabs, toggles, paging, filters) stay on.
			var reads = /^(next|previous|prev|first|last|page\b|filter|search|sort|show|hide|close|dismiss|cancel|back|view|read|details|more|expand|collapse|copy|menu|help|learn|go to|select|\d+$)/i;
			function isReading( b ) {
				var label = ( b.getAttribute( 'aria-label' ) || b.textContent || b.value || '' ).replace( /\s+/g, ' ' ).trim();
				return 'tab' === b.getAttribute( 'role' ) || b.hasAttribute( 'aria-expanded' ) || b.hasAttribute( 'aria-haspopup' ) || b.hasAttribute( 'aria-pressed' ) || b.hasAttribute( 'aria-selected' ) || reads.test( label );
			}
			function switchOff( b ) {
				if ( 'A' === b.tagName ) {
					b.removeAttribute( 'href' );
					b.setAttribute( 'aria-disabled', 'true' );
					b.style.cssText += ';cursor:not-allowed;opacity:.6;pointer-events:auto';
				} else {
					b.disabled = true;
				}
				b.title = tip;
			}
			// Screens WordPress draws with script (Settings > Connectors, Appearance > Fonts): the notice on top of
			// the page and every button but the tabs switched off, as the script draws them.
			var boot = document.querySelector( '.boot-layout-container' );
			if ( boot ) {
				var tidyBoot = function () {
					var stage = boot.querySelector( '.boot-layout__stage > div' );
					if ( ! stage ) { return; }
					if ( ! stage.querySelector( '.rolemend-saves-off' ) ) {
						var bar = makeNote();
						bar.style.cssText = 'display:block !important;margin:12px 24px 0;flex:none';
						stage.insertBefore( bar, stage.firstChild );
					}
					stage.querySelectorAll( 'button' ).forEach( function ( b ) {
						if ( ! b.disabled && ! isReading( b ) ) { switchOff( b ); }
					} );
					stage.querySelectorAll( 'input[type="file"]' ).forEach( function ( i ) { i.disabled = true; } );
				};
				new MutationObserver( tidyBoot ).observe( boot, { childList: true, subtree: true } );
				tidyBoot();
				return;
			}
			var off = 0;
			document.querySelectorAll( '#wpbody-content form' ).forEach( function ( form ) {
				if ( 'adv-settings' === form.id || 'post' !== ( form.getAttribute( 'method' ) || '' ).toLowerCase() ) { return; }
				form.querySelectorAll( 'input[type="submit"], button[type="submit"], button:not([type])' ).forEach( function ( b ) {
					if ( b.disabled || ! shown( b ) ) { return; }
					b.disabled = true;
					b.title = tip;
					off++;
				} );
			} );
			// Settings > General: the buttons that open the media library to choose or remove the Site Icon lead to a crop
			// that can only be refused.
			document.querySelectorAll( '#choose-from-library-button, #js-remove-site-icon' ).forEach( function ( b ) {
				if ( ! b.disabled && shown( b ) ) {
					b.disabled = true;
					b.title = tip;
					off++;
				}
			} );
			// Menus: the delete link, and the boxes that add items to a menu.
			document.querySelectorAll( '.menu-delete' ).forEach( function ( a ) {
				a.removeAttribute( 'href' );
				a.title = tip;
				a.style.cursor = 'not-allowed';
				a.style.opacity = '.6';
				off++;
			} );
			// Another plugin's own screen (a page of the plugin's menu, or its own kind of post): its buttons outside
			// a form are switched off the same way, also when the plugin draws them after the page has loaded.
			var other = /(^|\s)(toplevel_page_|[a-z0-9-]+_page_)/.test( document.body.className ) || /post-type-(?!post\b|page\b|attachment\b)/.test( document.body.className );
			var wrap = document.querySelector( '#wpbody-content' );
			function note() {
				if ( document.querySelector( '.rolemend-saves-off' ) ) { return; }
				var bar = makeNote(), head = document.querySelector( '#wpbody-content .wrap > h1, #wpbody-content .wrap > h2' );
				if ( head ) {
					var after = head.nextElementSibling && head.nextElementSibling.classList.contains( 'wp-header-end' ) ? head.nextElementSibling : head;
					after.parentNode.insertBefore( bar, after.nextSibling );
				} else {
					wrap.prepend( bar );
				}
			}
			function tidyOther() {
				var n = 0;
				wrap.querySelectorAll( 'button, input[type="button"], input[type="submit"], a.button, .row-actions a[href*="_wpnonce"], .row-actions a[href*="action="]' ).forEach( function ( b ) {
					if ( b.disabled || 'true' === b.getAttribute( 'aria-disabled' ) || ! shown( b ) || b.closest( '#screen-meta, #screen-meta-links, .notice, #contextual-help-wrap, .handle-actions, .postbox-header' ) || isReading( b ) ) { return; }
					switchOff( b );
					n++;
				} );
				if ( n ) { note(); }
			}
			if ( other && wrap ) {
				new MutationObserver( tidyOther ).observe( wrap, { childList: true, subtree: true } );
				tidyOther();
			}
			if ( off ) { note(); }
		}() );
		</script>
		<?php
	}

	/**
	 * Appearance > Widgets (the block editor): no welcome tour, a notice that saving is off, and the Update
	 * button switched off with a tooltip, so the screen reads like every other screen of this role.
	 *
	 * @param string $hook_suffix Admin page.
	 */
	public static function widgets_editor( $hook_suffix ) {
		if ( 'widgets.php' !== $hook_suffix || ! self::applies() || ! wp_script_is( 'wp-edit-widgets', 'registered' ) ) {
			return;
		}
		$script = '( wp.domReady || function ( f ) { document.addEventListener( "DOMContentLoaded", f ); } )( function () {'
			. 'wp.data.dispatch( "core/preferences" ).set( "core/edit-widgets", "welcomeGuide", false );'
			. 'wp.data.dispatch( "core/notices" ).createNotice( "info", ' . wp_json_encode( self::saving_off_notice() ) . ', { isDismissible: false, id: "rolemend-view-only" } );'
			. 'var tip = ' . wp_json_encode( __( 'Saving is switched off: this account is view only.', 'rolemend' ) ) . ';'
			. 'new MutationObserver( function () {'
			. 'document.querySelectorAll( ".edit-widgets-header__actions .is-primary, .edit-widgets-header__actions .components-button.is-primary" ).forEach( function ( b ) {'
			. 'if ( ! b.disabled || b.title !== tip ) { b.disabled = true; b.title = tip; }'
			. '} );'
			. '} ).observe( document.body, { childList: true, subtree: true } );'
			. '} );';
		wp_add_inline_script( 'wp-edit-widgets', $script );
	}

	/**
	 * Hides buttons that would only lead to a refusal, and styles the marker.
	 */
	public static function styles() {
		if ( ! self::applies() ) {
			return;
		}
		?>
		<style id="rolemend-view-only">
			.wrap .page-title-action, .tablenav .bulkactions, .theme-actions .activate, .theme-browser .theme.add-new-theme,
			.media-toolbar .select-mode-toggle-button, .theme-actions .delete-theme { display: none !important; }
			#wpadminbar #wp-admin-bar-rolemend-view-only > .ab-item { background: #2271b1; color: #fff; }
			#wpadminbar #wp-admin-bar-rolemend-view-only .ab-icon:before { color: #fff; top: 2px; }
			@media screen and (max-width: 782px) {
				#wpadminbar li#wp-admin-bar-rolemend-view-only { display: block; }
				#wpadminbar #wp-admin-bar-rolemend-view-only > .ab-item { display: flex; align-items: center; padding: 0 10px 0 0; }
				#wpadminbar #wp-admin-bar-rolemend-view-only .ab-icon { width: 36px; font-size: 28px !important; }
				#wpadminbar #wp-admin-bar-rolemend-view-only .ab-icon:before { top: 0; line-height: 46px; font-size: 24px; }
				#wpadminbar #wp-admin-bar-rolemend-view-only .ab-label { position: static; clip-path: none; width: auto; height: auto; margin: 0; overflow: visible; font-size: 13px; line-height: 46px; white-space: nowrap; }
			}
		</style>
		<?php
	}

	/**
	 * Appearance > Editor (Design with a classic theme): its previews of posts, pages and navigation are empty for this role (WordPress lists
	 * those only for people who may edit them), so the editor says so instead of looking broken.
	 *
	 * @param string $hook_suffix Admin page.
	 */
	public static function site_editor_notice( $hook_suffix ) {
		if ( 'site-editor.php' !== $hook_suffix || ! self::applies() ) {
			return;
		}
		$message = __( 'This account is view only, so saving is switched off. Previews of posts, pages and navigation are empty here because WordPress lists those only for people who may edit them; nothing is missing from the site.', 'rolemend' );
		$tip     = __( 'Saving is switched off: this account is view only.', 'rolemend' );
		// The Save button of the editor is switched off for good: it is re-checked whenever the editor redraws it.
		$keep = 'var tip = ' . wp_json_encode( $tip ) . ', sel = ".edit-site-save-hub__button, .editor-entities-saved-states__save-button, .editor-post-publish-button, .editor-post-save-draft";'
			. 'function off() { document.querySelectorAll( sel ).forEach( function ( b ) { if ( ! b.disabled || b.title !== tip ) { b.disabled = true; b.title = tip; } } ); }'
			. 'new MutationObserver( off ).observe( document.body, { childList: true, subtree: true, attributes: true, attributeFilter: [ "disabled", "aria-disabled" ] } ); off();';
		wp_add_inline_script(
			'wp-edit-site',
			'( wp.domReady || function ( f ) { document.addEventListener( "DOMContentLoaded", f ); } )( function () { wp.data.dispatch( "core/notices" ).createNotice( "info", ' . wp_json_encode( $message ) . ', { type: "snackbar", isDismissible: true, explicitDismiss: true, id: "rolemend-view-only" } ); ' . $keep . ' } );'
		);
	}

	/**
	 * Profile: says what can be saved, and what was.
	 */
	public static function profile_notice() {
		global $pagenow;
		if ( 'profile.php' !== $pagenow || ! self::applies() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$result = isset( $_GET['rolemend'] ) ? sanitize_key( wp_unslash( $_GET['rolemend'] ) ) : '';
		$notes  = array(
			'password'  => array( 'success', __( 'Password changed.', 'rolemend' ) ),
			'nothing'   => array( 'info', __( 'Nothing was saved. This account is view only: on this page only the password can be changed.', 'rolemend' ) ),
			'mismatch'  => array( 'error', __( 'Password not changed: the two passwords do not match.', 'rolemend' ) ),
			'backslash' => array( 'error', __( 'Password not changed: passwords may not contain the character "\\".', 'rolemend' ) ),
		);
		if ( isset( $notes[ $result ] ) ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notes[ $result ][0] ), esc_html( $notes[ $result ][1] ) );
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s</p></div>',
			esc_html__( 'This account is view only. You can change your password on this page; nothing else here is saved.', 'rolemend' )
		);
	}

	/**
	 * Profile: greys out every field but the password, so nobody types into a field that will not be saved.
	 */
	public static function profile_fields() {
		if ( ! self::applies() ) {
			return;
		}
		?>
		<script id="rolemend-view-only-profile">
		( function () {
			var keep = [ 'pass1', 'pass2', 'pw_weak' ];
			function tidy() {
				document.querySelectorAll( '#your-profile input, #your-profile select, #your-profile textarea, #your-profile button' ).forEach( function ( el ) {
					var allowed = 'hidden' === el.type || -1 !== keep.indexOf( el.name ) || 'submit' === el.id ||
						el.classList.contains( 'wp-generate-pw' ) || el.classList.contains( 'wp-hide-pw' ) || el.classList.contains( 'wp-cancel-pw' );
					if ( ! allowed && ! el.disabled ) {
						el.disabled = true;
					}
				} );
			}
			tidy();
			// Other plugins draw their own fields and buttons into the profile after the page has loaded (Yoast SEO's AI consent).
			var form = document.getElementById( 'your-profile' );
			if ( form ) {
				new MutationObserver( tidy ).observe( form, { childList: true, subtree: true } );
			}
		}() );
		</script>
		<?php
	}

	/**
	 * Saves a View Only user's Profile form: the new password, nothing else. Called on admin_init for a
	 * POST to profile.php. Always ends the request.
	 */
	public static function save_profile() {
		$user_id = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked on the next line.
		$posted_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		if ( $posted_id !== $user_id ) {
			Rolemend_Guard::refuse( 'view' );
		}
		check_admin_referer( 'update-user_' . $user_id );

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords are used as typed, as WordPress does.
		$pass1 = isset( $_POST['pass1'] ) ? trim( wp_unslash( $_POST['pass1'] ) ) : '';
		$pass2 = isset( $_POST['pass2'] ) ? trim( wp_unslash( $_POST['pass2'] ) ) : '';
		// phpcs:enable

		$result = 'nothing';
		if ( '' !== $pass1 ) {
			if ( false !== strpos( $pass1, '\\' ) ) {
				$result = 'backslash';
			} elseif ( $pass1 !== $pass2 ) {
				$result = 'mismatch';
			} else {
				// Other plugins' profile_update handlers must not find anything else to save.
				$_POST    = array();
				$_REQUEST = array();
				Rolemend_Writes::allow(
					static function () use ( $user_id, $pass1 ) {
						return wp_update_user(
							array(
								'ID'        => $user_id,
								'user_pass' => $pass1,
							)
						);
					}
				);
				$result = 'password';
			}
		}
		wp_safe_redirect( add_query_arg( 'rolemend', $result, admin_url( 'profile.php' ) ) );
		exit;
	}
}
