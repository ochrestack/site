<?php
/**
 * View Only role: what its users see on screen, and their own password.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * The marker, the hidden buttons, and the password-only Profile save.
 */
class Rolemend_View_Only {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 1000 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard' ), 1000 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 1000 );
		add_action( 'admin_head', array( __CLASS__, 'styles' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'site_editor_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'profile_notice' ) );
		add_action( 'admin_footer-profile.php', array( __CLASS__, 'profile_fields' ) );
	}

	/**
	 * Whether the current user holds the View Only role.
	 *
	 * @return bool
	 */
	private static function applies() {
		return Rolemend_Roles::is_view_only( wp_get_current_user() );
	}

	/**
	 * "View only" marker in the toolbar, on every screen; the "New" and "Edit" menus removed.
	 *
	 * @param WP_Admin_Bar $bar Toolbar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! self::applies() ) {
			return;
		}
		$bar->remove_node( 'new-content' );
		$bar->remove_node( 'edit' );
		$bar->remove_node( 'customize' );
		$bar->add_node(
			array(
				'id'     => 'rolemend-view-only',
				'parent' => 'top-secondary',
				'title'  => '<span class="ab-icon dashicons dashicons-visibility" aria-hidden="true"></span><span class="ab-label">' . esc_html__( 'View only', 'rolemend' ) . '</span>',
				'meta'   => array(
					'title' => __( 'This account can look at everything here but cannot change anything.', 'rolemend' ),
				),
			)
		);
	}

	/**
	 * Quick Draft creates a draft each time the Dashboard loads, so it is not shown.
	 */
	public static function dashboard() {
		if ( self::applies() ) {
			remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
		}
	}

	/**
	 * Menu items that only lead to "add new" screens.
	 */
	public static function menu() {
		if ( ! self::applies() ) {
			return;
		}
		remove_submenu_page( 'edit.php', 'post-new.php' );
		remove_submenu_page( 'edit.php?post_type=page', 'post-new.php?post_type=page' );
		remove_submenu_page( 'upload.php', 'media-new.php' );
	}

	/**
	 * Hides buttons that would only lead to a refusal, and styles the marker.
	 */
	public static function styles() {
		if ( ! self::applies() ) {
			return;
		}
		?>
		<style id="rolemend-view-only">
			.wrap .page-title-action, .tablenav .bulkactions, .theme-actions .activate, .theme-browser .theme.add-new-theme,
			.media-toolbar .select-mode-toggle-button, .theme-actions .delete-theme { display: none !important; }
			#wpadminbar #wp-admin-bar-rolemend-view-only > .ab-item { background: #2271b1; color: #fff; }
			#wpadminbar #wp-admin-bar-rolemend-view-only .ab-icon:before { color: #fff; top: 2px; }
		</style>
		<?php
	}

	/**
	 * Appearance > Editor: its previews of posts, pages and navigation are empty for this role (WordPress lists
	 * those only for people who may edit them), so the editor says so instead of looking broken.
	 *
	 * @param string $hook_suffix Admin page.
	 */
	public static function site_editor_notice( $hook_suffix ) {
		if ( 'site-editor.php' !== $hook_suffix || ! self::applies() ) {
			return;
		}
		$message = __( 'This account is view only. Previews of posts, pages and navigation are empty here because WordPress lists those only for people who may edit them; nothing is missing from the site.', 'rolemend' );
		wp_add_inline_script(
			'wp-edit-site',
			'( wp.domReady || function ( f ) { document.addEventListener( "DOMContentLoaded", f ); } )( function () { wp.data.dispatch( "core/notices" ).createNotice( "info", ' . wp_json_encode( $message ) . ', { type: "snackbar", isDismissible: true, explicitDismiss: true, id: "rolemend-view-only" } ); } );'
		);
	}

	/**
	 * Profile: says what can be saved, and what was.
	 */
	public static function profile_notice() {
		global $pagenow;
		if ( 'profile.php' !== $pagenow || ! self::applies() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$result = isset( $_GET['rolemend'] ) ? sanitize_key( wp_unslash( $_GET['rolemend'] ) ) : '';
		$notes  = array(
			'password'  => array( 'success', __( 'Password changed.', 'rolemend' ) ),
			'nothing'   => array( 'info', __( 'Nothing was saved. This account is view only: on this page only the password can be changed.', 'rolemend' ) ),
			'mismatch'  => array( 'error', __( 'Password not changed: the two passwords do not match.', 'rolemend' ) ),
			'backslash' => array( 'error', __( 'Password not changed: passwords may not contain the character "\\".', 'rolemend' ) ),
		);
		if ( isset( $notes[ $result ] ) ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notes[ $result ][0] ), esc_html( $notes[ $result ][1] ) );
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s</p></div>',
			esc_html__( 'This account is view only. You can change your password on this page; nothing else here is saved.', 'rolemend' )
		);
	}

	/**
	 * Profile: greys out every field but the password, so nobody types into a field that will not be saved.
	 */
	public static function profile_fields() {
		if ( ! self::applies() ) {
			return;
		}
		?>
		<script id="rolemend-view-only-profile">
		( function () {
			var keep = [ 'pass1', 'pass2', 'pw_weak' ];
			document.querySelectorAll( '#your-profile input, #your-profile select, #your-profile textarea, #your-profile button' ).forEach( function ( el ) {
				var allowed = 'hidden' === el.type || -1 !== keep.indexOf( el.name ) || 'submit' === el.id ||
					el.classList.contains( 'wp-generate-pw' ) || el.classList.contains( 'wp-hide-pw' ) || el.classList.contains( 'wp-cancel-pw' );
				if ( ! allowed ) {
					el.disabled = true;
				}
			} );
		}() );
		</script>
		<?php
	}

	/**
	 * Saves a View Only user's Profile form: the new password, nothing else. Called on admin_init for a
	 * POST to profile.php. Always ends the request.
	 */
	public static function save_profile() {
		$user_id = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked on the next line.
		$posted_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		if ( $posted_id !== $user_id ) {
			Rolemend_Guard::refuse( 'view' );
		}
		check_admin_referer( 'update-user_' . $user_id );

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords are used as typed, as WordPress does.
		$pass1 = isset( $_POST['pass1'] ) ? trim( wp_unslash( $_POST['pass1'] ) ) : '';
		$pass2 = isset( $_POST['pass2'] ) ? trim( wp_unslash( $_POST['pass2'] ) ) : '';
		// phpcs:enable

		$result = 'nothing';
		if ( '' !== $pass1 ) {
			if ( false !== strpos( $pass1, '\\' ) ) {
				$result = 'backslash';
			} elseif ( $pass1 !== $pass2 ) {
				$result = 'mismatch';
			} else {
				// Other plugins' profile_update handlers must not find anything else to save.
				$_POST    = array();
				$_REQUEST = array();
				Rolemend_Writes::allow(
					static function () use ( $user_id, $pass1 ) {
						return wp_update_user(
							array(
								'ID'        => $user_id,
								'user_pass' => $pass1,
							)
						);
					}
				);
				$result = 'password';
			}
		}
		wp_safe_redirect( add_query_arg( 'rolemend', $result, admin_url( 'profile.php' ) ) );
		exit;
	}
}
