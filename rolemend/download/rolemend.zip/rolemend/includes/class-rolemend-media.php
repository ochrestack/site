<?php
/**
 * Media Library (no uploads) role: the library without the upload paths, and the Edit Media save.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Screen changes for the media role and the four-field save of the Edit Media screen.
 */
class Rolemend_Media {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 1000 );
		add_action( 'admin_head', array( __CLASS__, 'styles' ) );
		add_action( 'add_meta_boxes_attachment', array( __CLASS__, 'meta_boxes' ), 1000 );
		add_filter( 'media_row_actions', array( __CLASS__, 'row_actions' ), 1000 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 1000 );
	}

	/**
	 * Whether the current user holds the media role.
	 *
	 * @return bool
	 */
	private static function applies() {
		return Rolemend_Roles::is_media_role( wp_get_current_user() );
	}

	/**
	 * No "Add Media File" in the menu.
	 */
	public static function menu() {
		if ( self::applies() ) {
			remove_submenu_page( 'upload.php', 'media-new.php' );
		}
	}

	/**
	 * No "+ New" menu in the toolbar.
	 *
	 * @param WP_Admin_Bar $bar Toolbar.
	 */
	public static function admin_bar( $bar ) {
		if ( self::applies() ) {
			$bar->remove_node( 'new-content' );
		}
	}

	/**
	 * Hides the buttons that would only lead to a refusal: "Add Media File" (library and Edit Media),
	 * bulk selection, "Attach" and "Detach" under "Uploaded to" (the list's links that open a dialog or send a request that
	 * can only be refused), and "Edit Image" (Edit Media screen and the library's Attachment details).
	 */
	public static function styles() {
		if ( ! self::applies() ) {
			return;
		}
		?>
		<style id="rolemend-media-role">
			.upload-php .wrap .page-title-action, .upload-php .tablenav .bulkactions,
			.upload-php .media-toolbar .select-mode-toggle-button,
			.post-type-attachment .wrap .page-title-action, .post-type-attachment input[id^="imgedit-open-btn"],
			.upload-php .column-parent a.hide-if-no-js,
			.media-modal button.edit-attachment { display: none !important; }
		</style>
		<?php
	}

	/**
	 * Edit Media screen: only the boxes with fields this role may save.
	 */
	public static function meta_boxes() {
		if ( ! self::applies() ) {
			return;
		}
		foreach ( array( 'commentstatusdiv', 'commentsdiv', 'slugdiv', 'authordiv', 'postcustom' ) as $box ) {
			remove_meta_box( $box, 'attachment', 'normal' );
			remove_meta_box( $box, 'attachment', 'advanced' );
			remove_meta_box( $box, 'attachment', 'side' );
		}
	}

	/**
	 * List view: no Attach, Detach or delete links.
	 *
	 * @param string[] $actions Row actions.
	 * @return string[]
	 */
	public static function row_actions( $actions ) {
		if ( self::applies() ) {
			unset( $actions['attach'], $actions['detach'], $actions['delete'], $actions['trash'], $actions['untrash'] );
		}
		return $actions;
	}

	/**
	 * Saves Title, Caption, Description and Alternative Text from the Edit Media screen and nothing else,
	 * then returns to the screen as WordPress does. Called on admin_init for a POST to post.php
	 * with action=editpost for an attachment. Always ends the request.
	 *
	 * @param int $post_id Attachment ID.
	 */
	public static function save_edit_media( $post_id ) {
		check_admin_referer( 'update-post_' . $post_id );
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			Rolemend_Guard::refuse( 'media' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above.
		$data = array( 'ID' => $post_id );
		if ( isset( $_POST['post_title'] ) ) {
			$data['post_title'] = wp_kses_post( wp_unslash( $_POST['post_title'] ) );
		}
		if ( isset( $_POST['excerpt'] ) ) {
			$data['post_excerpt'] = wp_kses_post( wp_unslash( $_POST['excerpt'] ) );
		}
		if ( isset( $_POST['content'] ) ) {
			$data['post_content'] = wp_kses_post( wp_unslash( $_POST['content'] ) );
		}
		$alt = isset( $_POST['_wp_attachment_image_alt'] ) ? wp_strip_all_tags( wp_unslash( $_POST['_wp_attachment_image_alt'] ), true ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by wp_strip_all_tags(), as WordPress does.
		// phpcs:enable

		// Other plugins' save_post handlers must not find anything else to save.
		$_POST    = array();
		$_REQUEST = array();
		Rolemend_Writes::allow(
			static function () use ( $post_id, $data, $alt ) {
				if ( count( $data ) > 1 ) {
					// WordPress applies its own filters for users without unfiltered_html on top.
					wp_update_post( wp_slash( $data ) );
				}
				if ( null !== $alt && get_post_meta( $post_id, '_wp_attachment_image_alt', true ) !== $alt ) {
					update_post_meta( $post_id, '_wp_attachment_image_alt', wp_slash( $alt ) );
				}
			}
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'post'    => $post_id,
					'action'  => 'edit',
					'message' => 1,
				),
				admin_url( 'post.php' )
			)
		);
		exit;
	}
}
