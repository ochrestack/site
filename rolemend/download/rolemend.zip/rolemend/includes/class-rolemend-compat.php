<?php
/**
 * Keeps the two roles from meeting dead ends in other plugins' menus and redirects.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Things that make a restricted account look broken without anything being wrong:
 *
 * - WooCommerce sends everyone without Edit Posts (the media role has none) to the shop's
 *   "My account" page whenever they open wp-admin, so the media role never reaches the library.
 * - View Only is given WordPress's own viewing permissions, which some plugins also use for
 *   their menu entries (Yoast SEO's Academy, WooCommerce's Reviews), while the plugin's own
 *   screens ask for a permission this role does not have. The menu then offers links that only refuse.
 * - Other plugins' Dashboard widgets and admin notices say what the plugin's own screens would, or link to them.
 * - The same links sit in the Plugins list (a plugin's own "Settings" row link), which opens the same refusals.
 * - Without a redirect of its own, WordPress sends an account that cannot edit posts to its Profile after
 *   signing in; the media role signs in to the Media Library instead.
 */
class Rolemend_Compat {

	/**
	 * Top-level menu files of WordPress itself.
	 *
	 * @var string[]
	 */
	const CORE_TOP = array(
		'index.php',
		'edit.php',
		'upload.php',
		'edit.php?post_type=page',
		'edit-comments.php',
		'themes.php',
		'plugins.php',
		'users.php',
		'profile.php',
		'tools.php',
		'options-general.php',
	);

	/**
	 * Post types and taxonomies of WordPress itself, as they appear in menu links.
	 *
	 * @var string[]
	 */
	const CORE_TYPES = array( '', 'post', 'page', 'attachment', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'category', 'post_tag' );

	/**
	 * Top-level toolbar items of WordPress itself (and Rolemend's marker); every other top-level item is
	 * another plugin's.
	 *
	 * @var string[]
	 */
	const CORE_TOOLBAR = array(
		'root',
		'top-secondary',
		'menu-toggle',
		'wp-logo',
		'site-name',
		'my-sites',
		'edit-site',
		'customize',
		'updates',
		'comments',
		'new-content',
		'edit',
		'view',
		'preview',
		'archive',
		'search',
		'my-account',
		'recovery-mode',
		'rolemend-view-only',
	);

	/**
	 * Dashboard widgets of WordPress itself; every other widget is another plugin's.
	 *
	 * @var string[]
	 */
	const CORE_WIDGETS = array(
		'dashboard_site_health',
		'dashboard_right_now',
		'dashboard_activity',
		'dashboard_quick_press',
		'dashboard_primary',
		'dashboard_browser_nag',
		'dashboard_php_nag',
	);

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'prune_dashboard' ), PHP_INT_MAX );
		add_action( 'in_admin_header', array( __CLASS__, 'prune_notices' ), PHP_INT_MAX );
		add_action( 'admin_bar_menu', array( __CLASS__, 'prune_toolbar' ), PHP_INT_MAX );
		add_filter( 'woocommerce_prevent_admin_access', array( __CLASS__, 'allow_admin_access' ), 1000 );
		add_filter( 'woocommerce_disable_admin_bar', array( __CLASS__, 'allow_admin_access' ), 1000 );
		add_action( 'admin_menu', array( __CLASS__, 'prune_menus' ), PHP_INT_MAX );
		add_action( 'load-plugins.php', array( __CLASS__, 'prune_plugin_row_links' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 10, 3 );
	}

	/**
	 * Where the media role lands after signing in at wp-login.php, when the sign-in names no page of its own
	 * (or only wp-admin/, which the sign-in form sends): the Media Library, not WordPress's default of the
	 * Profile screen for accounts that cannot edit posts.
	 *
	 * @param string           $redirect_to           Where WordPress would send the user.
	 * @param string           $requested_redirect_to The page the sign-in asked for, if any.
	 * @param WP_User|WP_Error $user                  The signed-in user, or an error.
	 * @return string
	 */
	public static function login_redirect( $redirect_to, $requested_redirect_to, $user ) {
		// The sign-in form sends WordPress's own default (wp-admin/) as the requested page, so that counts as "none".
		$asked   = untrailingslashit( (string) $requested_redirect_to );
		$default = array( '', 'wp-admin', untrailingslashit( admin_url() ), untrailingslashit( admin_url( 'index.php' ) ) );
		if ( in_array( $asked, $default, true ) && $user instanceof WP_User && Rolemend_Roles::is_media_role( $user ) ) {
			return admin_url( 'upload.php' );
		}
		return $redirect_to;
	}

	/**
	 * Other plugins' Dashboard widgets (Yoast SEO's Posts Overview, WooCommerce's status) show what the plugin's
	 * own screens would, so both roles' Dashboard keeps only WordPress's own widgets.
	 */
	public static function prune_dashboard() {
		global $wp_meta_boxes;
		if ( ! rolemend_is_restricted_user() ) {
			return;
		}
		foreach ( (array) ( $wp_meta_boxes['dashboard'] ?? array() ) as $context => $priorities ) {
			foreach ( (array) $priorities as $boxes ) {
				foreach ( array_keys( (array) $boxes ) as $id ) {
					if ( ! in_array( $id, self::CORE_WIDGETS, true ) ) {
						remove_meta_box( $id, 'dashboard', $context );
					}
				}
			}
		}
	}

	/**
	 * Other plugins' and themes' admin notices (a welcome banner with a button to the plugin's screen, a renewal
	 * reminder) are written for the people who run the site and link to screens these roles cannot open, so
	 * neither role sees them. WordPress's own notices and Rolemend's stay.
	 */
	public static function prune_notices() {
		global $wp_filter;
		if ( ! rolemend_is_restricted_user() ) {
			return;
		}
		foreach ( array( 'admin_notices', 'all_admin_notices', 'user_admin_notices', 'network_admin_notices' ) as $hook ) {
			if ( empty( $wp_filter[ $hook ] ) ) {
				continue;
			}
			foreach ( $wp_filter[ $hook ]->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $callback ) {
					if ( self::is_added_by_other_code( $callback['function'] ) ) {
						remove_action( $hook, $callback['function'], $priority );
					}
				}
			}
		}
	}

	/**
	 * Whether a hooked callback is defined in another plugin or in a theme (not in WordPress, not in Rolemend).
	 *
	 * @param callable $callback Hooked callback.
	 * @return bool
	 */
	private static function is_added_by_other_code( $callback ) {
		try {
			if ( is_string( $callback ) && false !== strpos( $callback, '::' ) ) {
				$callback = explode( '::', $callback, 2 );
			}
			if ( is_array( $callback ) ) {
				$reflection = new ReflectionMethod( $callback[0], $callback[1] );
			} elseif ( is_object( $callback ) && ! $callback instanceof Closure ) {
				$reflection = new ReflectionMethod( $callback, '__invoke' );
			} else {
				$reflection = new ReflectionFunction( $callback );
			}
		} catch ( ReflectionException $e ) {
			return false;
		}
		$file = (string) $reflection->getFileName();
		if ( '' === $file ) {
			return false;
		}
		$file = wp_normalize_path( $file );
		$ours = array( wp_normalize_path( dirname( ROLEMEND_FILE ) ) . '/' );
		if ( defined( 'ROLEMEND_PRO_FILE' ) ) {
			$ours[] = wp_normalize_path( dirname( ROLEMEND_PRO_FILE ) ) . '/';
		}
		foreach ( $ours as $dir ) {
			if ( 0 === strpos( $file, $dir ) ) {
				return false;
			}
		}
		$others = array( wp_normalize_path( WP_PLUGIN_DIR ) . '/', wp_normalize_path( WPMU_PLUGIN_DIR ) . '/', wp_normalize_path( get_theme_root() ) . '/' );
		foreach ( $others as $dir ) {
			if ( 0 === strpos( $file, $dir ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Other plugins' row links on the Plugins screen (a "Settings" link, an upgrade link) lead to the same
	 * refusals as their menu entries, so both roles' Plugins list shows none of them. WordPress's own
	 * Activate, Deactivate and Delete are already not there for these roles.
	 */
	public static function prune_plugin_row_links() {
		global $wp_filter;
		if ( ! rolemend_is_restricted_user() ) {
			return;
		}
		$prefixes = array( 'plugin_action_links', 'network_admin_plugin_action_links' );
		foreach ( array_keys( (array) $wp_filter ) as $hook ) {
			foreach ( $prefixes as $prefix ) {
				if ( 0 === strpos( $hook, $prefix . '_' ) ) {
					add_filter( $hook, '__return_empty_array', PHP_INT_MAX );
				}
			}
		}
		foreach ( $prefixes as $prefix ) {
			add_filter( $prefix, '__return_empty_array', PHP_INT_MAX );
		}
	}

	/**
	 * WooCommerce's "send this person to My account" switches, off for the two roles.
	 *
	 * @param bool $acts Whether WooCommerce would act.
	 * @return bool
	 */
	public static function allow_admin_access( $acts ) {
		return rolemend_is_restricted_user() ? false : $acts;
	}

	/**
	 * Other plugins' toolbar items (Yoast SEO's "SEO" menu, for one) lead to the same refusals as their menu
	 * entries, so both roles' toolbars keep only WordPress's own items and Rolemend's marker.
	 *
	 * @param WP_Admin_Bar $bar Toolbar.
	 */
	public static function prune_toolbar( $bar ) {
		if ( ! rolemend_is_restricted_user() ) {
			return;
		}
		foreach ( $bar->get_nodes() as $id => $node ) {
			$top = empty( $node->parent ) || 'root' === $node->parent || 'top-secondary' === $node->parent;
			if ( $top && ! in_array( $id, self::CORE_TOOLBAR, true ) ) {
				$bar->remove_node( $id );
			}
		}
	}

	/**
	 * Other plugins' menu entries stay only when they use WordPress's own Settings permission
	 * (manage_options); every other entry of theirs is taken out of the menu of both roles.
	 * The pages themselves are not blocked here: each still checks its own permission.
	 */
	public static function prune_menus() {
		global $menu, $submenu;
		if ( ! rolemend_is_restricted_user() ) {
			return;
		}
		foreach ( (array) $menu as $position => $item ) {
			$slug = isset( $item[2] ) ? (string) $item[2] : '';
			if ( '' === $slug || 0 === strpos( $slug, 'separator' ) || in_array( $slug, self::CORE_TOP, true ) ) {
				continue;
			}
			if ( ! self::uses_settings_permission( $item ) ) {
				unset( $menu[ $position ], $submenu[ $slug ] );
			}
		}
		foreach ( (array) $submenu as $parent => $entries ) {
			foreach ( (array) $entries as $key => $entry ) {
				$slug = isset( $entry[2] ) ? (string) $entry[2] : '';
				if ( ! self::is_core_file( $slug ) && ! self::uses_settings_permission( $entry ) ) {
					unset( $submenu[ $parent ][ $key ] );
				}
			}
		}
	}

	/**
	 * Whether a menu entry asks for manage_options.
	 *
	 * @param array $entry Menu or submenu entry (title, permission, slug, ...).
	 * @return bool
	 */
	private static function uses_settings_permission( $entry ) {
		return isset( $entry[1] ) && 'manage_options' === $entry[1];
	}

	/**
	 * Whether a submenu slug is one of WordPress's own screens (a file in wp-admin, not a plugin page).
	 *
	 * @param string $slug Submenu slug.
	 * @return bool
	 */
	private static function is_core_file( $slug ) {
		$parts = explode( '?', $slug, 2 );
		if ( '.php' !== substr( $parts[0], -4 ) || ! file_exists( ABSPATH . 'wp-admin/' . $parts[0] ) ) {
			return false;
		}
		$query = array();
		if ( isset( $parts[1] ) ) {
			wp_parse_str( $parts[1], $query );
		}
		if ( isset( $query['page'] ) ) {
			return false;
		}
		foreach ( array( 'post_type', 'taxonomy' ) as $key ) {
			if ( isset( $query[ $key ] ) && ! in_array( $query[ $key ], self::CORE_TYPES, true ) ) {
				return false;
			}
		}
		return true;
	}
}
