<?php
/**
 * The two roles: definitions, activation, new sites, membership checks.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds the roles and answers "does this user hold one of them".
 *
 * The roles are stored with no capabilities at all. Everything they can see is
 * granted at run time by Rolemend_Caps while the plugin is active, so a
 * deactivated plugin leaves accounts that cannot open wp-admin, and
 * reactivating brings the same access back.
 */
class Rolemend_Roles {

	const VIEW_ONLY = 'rolemend_view_only';
	const MEDIA     = 'rolemend_media_library';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_initialize_site', array( __CLASS__, 'on_new_site' ), 200 );
		add_filter( 'gettext_with_context_default', array( __CLASS__, 'translate_role_name' ), 10, 3 );
	}

	/**
	 * Role keys handled by the plugin.
	 *
	 * @return string[]
	 */
	public static function keys() {
		return array( self::VIEW_ONLY, self::MEDIA );
	}

	/**
	 * Activation: add the roles to this site, or to every site when network-activated.
	 *
	 * @param bool $network_wide Whether the plugin is being network-activated.
	 */
	public static function activate( $network_wide = false ) {
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( $site_id );
				self::add_roles();
				restore_current_blog();
			}
			return;
		}
		self::add_roles();
	}

	/**
	 * Adds both roles to the current site if they are missing. Nothing else is written.
	 */
	public static function add_roles() {
		if ( ! get_role( self::VIEW_ONLY ) ) {
			add_role( self::VIEW_ONLY, 'View Only', array() );
		}
		if ( ! get_role( self::MEDIA ) ) {
			add_role( self::MEDIA, 'Media Library (no uploads)', array() );
		}
	}

	/**
	 * A site created while the plugin is network-active gets the roles too.
	 *
	 * @param WP_Site $site The new site.
	 */
	public static function on_new_site( $site ) {
		if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		if ( ! is_plugin_active_for_network( plugin_basename( ROLEMEND_FILE ) ) ) {
			return;
		}
		switch_to_blog( (int) $site->blog_id );
		self::add_roles();
		restore_current_blog();
	}

	/**
	 * Lets translators translate the two role names, which WordPress shows through translate_user_role().
	 *
	 * @param string $translation Translated text.
	 * @param string $text        Original text.
	 * @param string $context     Context.
	 * @return string
	 */
	public static function translate_role_name( $translation, $text, $context ) {
		// Translations load from init on; WordPress names roles earlier than that on some requests.
		if ( 'User role' !== $context || ! did_action( 'init' ) ) {
			return $translation;
		}
		if ( 'View Only' === $text ) {
			return _x( 'View Only', 'User role', 'rolemend' );
		}
		if ( 'Media Library (no uploads)' === $text ) {
			return _x( 'Media Library (no uploads)', 'User role', 'rolemend' );
		}
		return $translation;
	}

	/**
	 * Whether the user holds the View Only role. Network super admins are never restricted.
	 *
	 * @param WP_User|false|null $user User.
	 * @return bool
	 */
	public static function is_view_only( $user ) {
		return self::holds( $user, self::VIEW_ONLY );
	}

	/**
	 * Whether the user holds the Media Library (no uploads) role and not View Only
	 * (View Only is the stricter of the two and wins when an account holds both).
	 *
	 * @param WP_User|false|null $user User.
	 * @return bool
	 */
	public static function is_media_role( $user ) {
		return self::holds( $user, self::MEDIA ) && ! self::holds( $user, self::VIEW_ONLY );
	}

	/**
	 * Role membership check.
	 *
	 * @param WP_User|false|null $user User.
	 * @param string             $role Role key.
	 * @return bool
	 */
	private static function holds( $user, $role ) {
		if ( ! ( $user instanceof WP_User ) || ! $user->exists() ) {
			return false;
		}
		if ( ! in_array( $role, (array) $user->roles, true ) ) {
			return false;
		}
		// On single sites is_super_admin() asks for a capability, which would loop back here.
		if ( is_multisite() && is_super_admin( $user->ID ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Users holding a role on the current site.
	 *
	 * @param string $role Role key.
	 * @return WP_User[]
	 */
	public static function holders( $role ) {
		return get_users(
			array(
				'role'    => $role,
				'orderby' => 'display_name',
				'order'   => 'ASC',
			)
		);
	}
}
