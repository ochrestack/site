<?php
/**
 * The last line for both roles: no database write on their requests unless Rolemend allows it.
 *
 * @package Rolemend
 */

defined( 'ABSPATH' ) || exit;

/**
 * Database write net.
 *
 * The request checks in Rolemend_Guard refuse every change with a plain message. Other plugins can
 * still run their own code on a request Rolemend lets through (an admin-ajax.php call it allows, the
 * Profile form, a reading screen, a plain link), and that code may save something. So, for the two
 * roles, every write sent through WordPress's database layer ($wpdb) is stopped unless it is one of:
 *
 * - inside an operation Rolemend allows and runs itself (the View Only password, the four media
 *   fields, the media role's own Profile, an add-on's end of access): see allow() and open();
 * - a cache WordPress keeps in the options table (transients);
 * - the user's own settings and session in their user meta (never their role);
 * - for the media role, the edit lock of the attachment it has open.
 *
 * Stopped writes fail as if the database had refused them; the code that tried gets `false`.
 */
class Rolemend_Writes {

	/**
	 * Depth of operations Rolemend allows.
	 *
	 * @var int
	 */
	private static $scope = 0;

	/**
	 * One write announced by WordPress's meta functions just before they run it: table and a text the query contains.
	 *
	 * @var array|null
	 */
	private static $announced = null;

	/**
	 * Set while the current user is being looked up, so the lookup's own queries are not inspected.
	 *
	 * @var bool
	 */
	private static $busy = false;

	/**
	 * The current user's restriction ('view', 'media' or ''), taken when WordPress sets the user, so code
	 * that changes the user object in memory (for example set_role() before it saves) cannot lift it.
	 * Null until a user is set.
	 *
	 * @var string|null
	 */
	private static $role = null;

	/**
	 * Number of writes stopped on this request.
	 *
	 * @var int
	 */
	private static $stopped = 0;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'set_current_user', array( __CLASS__, 'take_role' ), PHP_INT_MIN );
		add_filter( 'query', array( __CLASS__, 'filter_query' ), PHP_INT_MAX );
		add_action( 'add_user_meta', array( __CLASS__, 'announce_user_meta_add' ), PHP_INT_MAX, 2 );
		add_action( 'update_user_meta', array( __CLASS__, 'announce_user_meta' ), PHP_INT_MAX, 3 );
		add_action( 'delete_user_meta', array( __CLASS__, 'announce_user_meta' ), PHP_INT_MAX, 3 );
		add_action( 'add_post_meta', array( __CLASS__, 'announce_post_meta_add' ), PHP_INT_MAX, 2 );
		add_action( 'update_post_meta', array( __CLASS__, 'announce_post_meta' ), PHP_INT_MAX, 3 );
		add_action( 'wp_ajax_save-attachment', array( __CLASS__, 'open_for_save_attachment' ), 0 );
		add_action( 'personal_options_update', array( __CLASS__, 'open_for_own_profile' ), PHP_INT_MIN );
	}

	/**
	 * Runs an operation Rolemend allows, with the net lifted for its duration.
	 *
	 * @param callable $operation Operation.
	 * @return mixed What the operation returns.
	 */
	public static function allow( $operation ) {
		++self::$scope;
		try {
			return call_user_func( $operation );
		} finally {
			--self::$scope;
		}
	}

	/**
	 * Lifts the net for the rest of the request. Used once Rolemend has checked a request and only
	 * WordPress's own handler for it is left to run.
	 */
	public static function open() {
		++self::$scope;
	}

	/**
	 * The current user's restriction as taken when WordPress set the user: 'view', 'media' or ''.
	 *
	 * @return string
	 */
	public static function role() {
		return null === self::$role ? '' : self::$role;
	}

	/**
	 * Whether an operation Rolemend allows is running.
	 *
	 * @return bool
	 */
	public static function is_allowing() {
		return self::$scope > 0;
	}

	/**
	 * How many writes were stopped on this request.
	 *
	 * @return int
	 */
	public static function stopped() {
		return self::$stopped;
	}

	/**
	 * The media role's Attachment details save (admin-ajax.php, action save-attachment). Rolemend_Guard has
	 * checked that only the four fields are sent; the request is cut down to what WordPress's handler reads,
	 * then that handler runs with the net lifted.
	 */
	public static function open_for_save_attachment() {
		if ( 'media' !== self::$role ) {
			return;
		}
		$keep = array_flip( array( 'action', 'id', 'nonce', 'changes', 'post_id' ) );
		// phpcs:disable WordPress.Security.NonceVerification -- WordPress checks the nonce in wp_ajax_save_attachment(); keys are only removed here.
		$_POST    = array_intersect_key( $_POST, $keep );
		$_GET     = array_intersect_key( $_GET, $keep );
		$_REQUEST = array_intersect_key( $_REQUEST, $keep );
		// phpcs:enable
		self::open();
	}

	/**
	 * The media role saving its own Profile (WordPress's edit_user() runs right after this action).
	 * View Only never gets here: Rolemend_View_Only::save_profile() ends that request earlier.
	 *
	 * @param int $user_id User being saved.
	 */
	public static function open_for_own_profile( $user_id ) {
		if ( 'media' === self::$role && get_current_user_id() === (int) $user_id ) {
			self::open();
		}
	}

	/**
	 * Records the restriction of the user WordPress has just set as current.
	 */
	public static function take_role() {
		self::$busy = true;
		self::$role = Rolemend_Guard::role_of();
		self::$busy = false;
	}

	/**
	 * The current user's ID once WordPress has worked it out, without working it out from here.
	 *
	 * @return int|null
	 */
	private static function known_user_id() {
		return null !== self::$role && isset( $GLOBALS['current_user'] ) && $GLOBALS['current_user'] instanceof WP_User ? (int) $GLOBALS['current_user']->ID : null;
	}

	/**
	 * User meta about to be added.
	 *
	 * @param int    $user_id  User.
	 * @param string $meta_key Key.
	 */
	public static function announce_user_meta_add( $user_id, $meta_key ) {
		self::announce_user_meta( 0, $user_id, $meta_key );
	}

	/**
	 * User meta about to be updated or deleted: allowed when it is the current user's own setting or session.
	 *
	 * @param int|int[] $meta_id  Meta ID(s).
	 * @param int       $user_id  User.
	 * @param string    $meta_key Key.
	 */
	public static function announce_user_meta( $meta_id, $user_id, $meta_key ) {
		global $wpdb;
		self::$announced = null;
		if ( self::known_user_id() !== (int) $user_id || ! is_string( $meta_key ) ) {
			return;
		}
		// The role is never the user's own setting.
		if ( preg_match( '/(capabilities|user_level)$/', $meta_key ) ) {
			return;
		}
		self::$announced = array( $wpdb->usermeta, self::needle_for( $meta_id, $meta_key ) );
	}

	/**
	 * Post meta about to be added.
	 *
	 * @param int    $post_id  Post.
	 * @param string $meta_key Key.
	 */
	public static function announce_post_meta_add( $post_id, $meta_key ) {
		self::announce_post_meta( 0, $post_id, $meta_key );
	}

	/**
	 * Post meta about to be updated: the media role may keep the edit lock of an attachment it has open.
	 *
	 * @param int    $meta_id  Meta ID.
	 * @param int    $post_id  Post.
	 * @param string $meta_key Key.
	 */
	public static function announce_post_meta( $meta_id, $post_id, $meta_key ) {
		global $wpdb;
		self::$announced = null;
		if ( '_edit_lock' === $meta_key && 'media' === self::$role && 'attachment' === get_post_type( $post_id ) ) {
			self::$announced = array( $wpdb->postmeta, self::needle_for( $meta_id, $meta_key ) );
		}
	}

	/**
	 * A piece of text the announced query is sure to contain, or null for a delete by row ID (the very
	 * next write to the table is the announced one).
	 *
	 * @param int|int[] $meta_id  Meta ID(s), 0 when adding.
	 * @param string    $meta_key Key.
	 * @return string|null
	 */
	private static function needle_for( $meta_id, $meta_key ) {
		if ( is_array( $meta_id ) ) {
			return null;
		}
		return "'" . esc_sql( $meta_key ) . "'";
	}

	/**
	 * The `query` filter: returns an empty query (which $wpdb does not run) for a write that is not allowed.
	 *
	 * @param string $query SQL.
	 * @return string
	 */
	public static function filter_query( $query ) {
		if ( self::$scope > 0 || self::$busy || ! is_string( $query ) ) {
			return $query;
		}
		if ( ! preg_match( '/^\s*(?:\/\*.*?\*\/\s*)*(INSERT|REPLACE|UPDATE|DELETE|ALTER|CREATE|DROP|TRUNCATE|RENAME)\b/is', $query ) ) {
			return $query;
		}
		// Until WordPress has set the current user, nothing is restricted (looking the user up from here would do it
		// too early, and WordPress itself writes while it signs a user in, for example an application password's last use).
		if ( null === self::$role || '' === self::$role ) {
			self::$announced = null;
			return $query;
		}
		$announced       = self::$announced;
		self::$announced = null;
		if ( self::allowed( $query, $announced ) ) {
			return $query;
		}
		++self::$stopped;
		return '';
	}

	/**
	 * Whether a write is one of the kinds allowed outside Rolemend's own operations.
	 *
	 * @param string     $query     SQL.
	 * @param array|null $announced Table and text of a write announced by the meta functions.
	 * @return bool
	 */
	private static function allowed( $query, $announced ) {
		global $wpdb;
		if ( ! preg_match( '/^\s*(INSERT(?:\s+IGNORE)?\s+INTO|REPLACE\s+INTO|UPDATE|DELETE\s+FROM)\s+`?([A-Za-z0-9_$]+)`?\s/i', $query, $m ) ) {
			return false;
		}
		$verb  = strtoupper( substr( $m[1], 0, 6 ) );
		$table = $m[2];

		if ( null !== $announced && $table === $announced[0] && ( null === $announced[1] || false !== strpos( $query, $announced[1] ) ) ) {
			return true;
		}
		if ( $table === $wpdb->options ) {
			return self::is_cache_key( self::key_in( $query, $verb, 'option_name', false ) );
		}
		if ( is_multisite() && $table === $wpdb->sitemeta ) {
			return self::is_cache_key( self::key_in( $query, $verb, 'meta_key', true ) );
		}
		return false;
	}

	/**
	 * Whether an option name is one of WordPress's caches (transients).
	 *
	 * @param string|null $name Option name.
	 * @return bool
	 */
	private static function is_cache_key( $name ) {
		return is_string( $name ) && ( 0 === strpos( $name, '_transient_' ) || 0 === strpos( $name, '_site_transient_' ) );
	}

	/**
	 * The single option name (or network option key) a core-shaped write addresses, or null.
	 *
	 * Matches what add_option(), update_option(), delete_option() and their network versions send:
	 * INSERT ... VALUES ('name', ...) or VALUES (1, 'name', ...); UPDATE ... WHERE `option_name` = 'name';
	 * DELETE ... WHERE `option_name` = 'name' (network: `meta_key` and `site_id` in either order).
	 *
	 * @param string $query   SQL.
	 * @param string $verb    First six letters of the statement.
	 * @param string $column  Name column.
	 * @param bool   $network Network options table.
	 * @return string|null
	 */
	private static function key_in( $query, $verb, $column, $network ) {
		$quoted = "'((?:[^'\\\\]|\\\\.)*)'";
		if ( 'INSERT' === $verb || 'REPLACE' === $verb ) {
			$pattern = $network ? '/\bVALUES\s*\(\s*\d+\s*,\s*' . $quoted . '/i' : '/\bVALUES\s*\(\s*' . $quoted . '/i';
			return preg_match( $pattern, $query, $m ) ? $m[1] : null;
		}
		if ( ! preg_match( '/\bWHERE\s+(.*)$/is', $query, $w ) ) {
			return null;
		}
		$name = null;
		foreach ( preg_split( '/\s+AND\s+/i', trim( $w[1] ) ) as $condition ) {
			if ( preg_match( '/^`?' . $column . '`?\s*=\s*' . $quoted . '$/', $condition, $c ) ) {
				$name = $c[1];
			} elseif ( ! ( $network && preg_match( '/^`?site_id`?\s*=\s*\d+$/', $condition ) ) ) {
				return null;
			}
		}
		return $name;
	}
}
