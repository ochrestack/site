<?php
/**
 * Deleting the plugin removes both roles. Their users keep their accounts, with no role on the site.
 *
 * @package Rolemend
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Takes the two roles off their users, then removes the roles, on the current site.
 */
$rolemend_uninstall_site = static function () {
	foreach ( array( 'rolemend_view_only', 'rolemend_media_library' ) as $role ) {
		$user_ids = get_users(
			array(
				'role'   => $role,
				'fields' => 'ID',
			)
		);
		foreach ( $user_ids as $user_id ) {
			$user = new WP_User( (int) $user_id );
			$user->remove_role( $role );
		}
		remove_role( $role );
	}
};

if ( is_multisite() ) {
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $rolemend_site_id ) {
		switch_to_blog( $rolemend_site_id );
		$rolemend_uninstall_site();
		restore_current_blog();
	}
} else {
	$rolemend_uninstall_site();
}
