=== Rolemend – View Only and No-Upload Media Roles ===
Contributors: ochrestack
Tags: read-only, user-role, roles, media-library, alt-text
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A View Only role that opens wp-admin and changes nothing, and a Media Library role that edits alt text but cannot upload files.

== Description ==

Want someone to view your WordPress back end but not edit it? Or an SEO person who can fix alt text but not upload files? Rolemend adds both roles, and changes nothing else.

WordPress ties seeing to editing. The Posts list opens only for people who may edit posts, every Settings screen only for people who may save settings, and the Media Library only for people who may upload files. So there is no combination of capabilities in a role editor that gives "look but do not touch", or "edit the alt text but do not upload". Rolemend gives each of those jobs its own role.

= View Only =

Give it to an accountant, auditor, client, board member or new hire who should look round wp-admin and change nothing.

* They see the screens an Administrator sees for WordPress itself: Dashboard, Posts, Pages, Media, Comments, Appearance (Themes, Editor or Menus, Widgets), Plugins, Users, Tools > Site Health and every Settings screen.
* The Posts and Pages lists show every post and page, drafts and private ones included, by title, author, date and status.
* In Appearance > Editor (block themes), Styles, Templates and Patterns open; the Pages list, the Navigation panel and post lists in previews stay empty, because the Site Editor loads those only for people who may edit them.
* Every change is refused with a plain message ("This account is view only, so nothing was changed. Ask an administrator if this change is needed."): saving any Settings screen; creating, editing, publishing, scheduling, trashing or deleting posts, pages and drafts; uploading, editing or deleting media; approving, editing, marking as spam or deleting comments; adding, editing, promoting or deleting users and creating application passwords; installing, activating, deactivating, updating or deleting plugins and themes; menus, widgets and the Customizer; and the same changes through the REST API.
* Other plugins are held back too. Form posts to their save handlers (admin-post.php, admin-ajax.php, the REST API, their own screens) are refused with the same message, and so is a link or button on their screens whose handler checks WordPress's security token. Other plugin code that still runs on a View Only user's request (for example during a background request WordPress itself sends) is stopped silently at the database: it takes no write except caches and the user's own settings and sign-in. What a plugin does outside the database, such as sending an email, is not stopped, so give the role to people you trust not to tamper.
* The only things they can still save are their own password (on their Profile) and their own Screen Options.
* A "View only" marker shows in the toolbar on every screen.
* Tools > Export, Import, the theme and plugin file editors and Network Admin are not available to the role.
* While signed in, they cannot post comments or send other forms on the front end either, and they cannot sign in to XML-RPC.

= Media Library (no uploads) =

Give it to an SEO or accessibility contractor who should fix titles and alternative text without adding files.

* They see Dashboard, Media > Library (grid and list views, with search and filters) and their own Profile.
* They can open any item's Attachment details and Edit Media screen and save its Title, Alternative Text, Caption and Description.
* Refused with a plain message: uploading in any way (there is no "Add Media File", called "Add New Media File" in older WordPress; drag and drop and the upload button in the Media Library, the REST API, and files fetched from a URL through WordPress's own handling are all refused), deleting or trashing, Edit Image (crop, rotate, scale, restore), changing "Uploaded to", and every other change.
* Uploads stay refused for this role even if a role editor later gives it upload rights.
* Other plugins' code that runs on the media role's requests cannot delete media or change anything else in the database: only the four fields, saved through WordPress's own Attachment details and Edit Media, get through.
* While signed in, they cannot post comments or send other forms on the front end.

= Nothing else changes =

* Activation adds the two roles and nothing more: no existing role or user is changed, the front end is untouched, and there is no notice, wizard or redirect.
* Users > Rolemend lists who holds each role, with an "Add a user with this role" link, and says in plain words what each role can do, what it cannot do, and what it does not lock.
* Deactivating stops both roles at once: their users can no longer open wp-admin. Reactivating gives them back the same access.
* Deleting the plugin removes both roles. Their users keep their accounts, with no role on the site. Users > Rolemend says so before you delete.
* On a network (multisite), each site gets the roles separately.

= What it does not lock =

Stated here so nobody finds out later:

* Anything another plugin does outside the WordPress database when a plain link is clicked or a screen is read, such as sending an email, writing a file or calling another service. WordPress's own links, such as Trash or Activate, are refused, and database writes from other plugins' links are stopped. A plugin whose save was stopped may still show its own "Saved" message.
* Code that runs while plugins are still loading, before WordPress knows who is signed in, and plugins that write to the database through their own connection instead of WordPress's ($wpdb).
* What the View Only account can read is readable, including user email addresses and commenter details. Choose who gets the role.
* Drafts are listed by title, author and date, but their text cannot be opened, because WordPress shows a draft only to people who may edit it.
* Tools > Export and the theme and plugin file editors are not available to the View Only role.
* Other plugins' screens appear only when they use WordPress's own Settings permission (manage_options), and some of them may load empty when their reading also goes through a save handler. WooCommerce and other plugins with their own permissions stay hidden.
* New alternative text in the Media Library does not change images already placed in posts and pages: they keep the alt text they were inserted with. Featured images, galleries and shop images that the theme reads from the Media Library do show the new text.

= Rolemend Pro =

Both roles are complete and free here, for any number of users. Rolemend Pro is a separate add-on ($19 once, on ochrestack.com) for people who hand access to outsiders: an "Access ends on" date for either role, and Media > Text Changes, a list of every title, alternative text, caption and description change made by the media role, with undo and CSV download. You do not need it for anything described above.

== External services ==

None. Rolemend does not contact any outside server: no telemetry, no analytics, no licence check, no update check of its own. Rolemend Pro does not either.

== Installation ==

1. In wp-admin go to Plugins > Add Plugin ("Add New Plugin" in older WordPress), search for "Rolemend", then Install Now and Activate. (Or upload rolemend.zip through Plugins > Add Plugin > Upload Plugin.)
2. Go to Users > Add User ("Add New User" in older WordPress), fill in the person's details, and choose "View Only" or "Media Library (no uploads)" under Role. To change an existing user, open their profile and pick the role there.
3. Users > Rolemend shows who has each role and what each role can and cannot do.

== Frequently Asked Questions ==

= Can I add a view-only role, since WordPress doesn't seem to let someone view but not edit the back end? =

Yes. Activate Rolemend, then give the person the "View Only" role in Users > Add User (or on their profile). They can open the Dashboard, Posts, Pages, Media, Comments, Appearance, Plugins, Users, Site Health and every Settings screen, and every change they try is refused with a plain message, drafts included, through the REST API too. Form posts to other plugins' save handlers are refused the same way, and once WordPress knows who is signed in, the database takes no write from other plugin code on their requests (caches and the user's own settings aside). Not stopped: what a plugin does outside the database, such as sending an email, and code that runs while plugins are still loading.

= Will installing it change anything by default? =

No. Activation adds the two roles and nothing else: no existing role or user is changed, the front end is untouched, and there is no notice, wizard or redirect. Nothing happens to anyone until you give someone one of the roles.

= Can my SEO person edit alt text without being able to upload files? =

Yes. Give them the "Media Library (no uploads)" role. They can open Media > Library in grid and list view, search and filter it, and save the Title, Alternative Text, Caption and Description of any item. Uploading is refused in every way WordPress offers (drag and drop, the upload button, the REST API, files fetched from a URL), and so are deleting and Edit Image.

= Can the View Only user read drafts? =

They see every draft in the Posts and Pages lists by title, author, date and status, but they cannot open a draft's text: WordPress shows a draft only to people who may edit it. Published and private posts can be read.

= Will new alt text change images already in my posts? =

No. Images already placed in posts and pages keep the alt text they were inserted with; WordPress copies it into the post at that moment. Featured images, galleries and shop images that your theme reads from the Media Library do show the new text.

= What does it not lock? =

Anything another plugin does outside the database (an email, a file, a call to another service) when a plain link is clicked; code that runs before WordPress knows who is signed in; and anything the account can read, which includes user email addresses and commenter details. Other plugins' screens appear only when they use WordPress's own Settings permission. The full list is under "What it does not lock" above and on Users > Rolemend.

= What happens when I deactivate or delete it? =

Deactivating stops both roles at once: their users can no longer open wp-admin. Reactivating gives them back exactly the same access. Deleting the plugin removes both roles; the users keep their accounts, with no role on the site, so you can give them another role or remove them.

= Can a role editor such as Members or User Role Editor change these roles? =

A role editor can let the roles see more screens (for example another plugin's screens), but it cannot let them change anything: the refusals do not depend on the role's capabilities. Uploads stay refused for the media role even if a role editor adds upload rights.

= Does it work on multisite? =

Yes. Each site gets the two roles separately, and the roles never open Network Admin. Network super admins are never restricted.

= How do I leave a review or get help? =

Reviews: https://wordpress.org/support/plugin/rolemend/reviews/ . Help: the support forum here, or support@ochrestack.com.

== Screenshots ==

1. A View Only user on the Posts screen: drafts, private and scheduled posts are listed, there are no edit links, and the toolbar says "View only".
2. Settings > General saved by a View Only user: the change is refused in plain words and nothing is saved.
3. The Media Library for a Media Library (no uploads) user: Attachment details with the Alternative Text being edited.
4. A file dropped onto the Media Library by the media role, refused in plain words.
5. Users > Rolemend: who has each role, "Add a user with this role", and what each role can do, cannot do and does not lock.

== Changelog ==

= 1.1.0 =
* Other plugins' code can no longer save on these accounts' requests: on View Only and media-role requests the database takes no write except caches and the user's own settings and sign-in. Before, another plugin's save handler could run through the Heartbeat API, other allowed background requests or the Profile form.
* A link or button on another plugin's screen that carries WordPress's security token is refused for both roles (before, some GET forms got through).
* The media role cannot delete, trash or change media through another plugin's tool, and cannot send front-end forms (comments included) while signed in.

= 1.0.0 =
* First release: the View Only and Media Library (no uploads) roles, and Users > Rolemend.

== Upgrade Notice ==

= 1.1.0 =
Closes ways other plugins' save code could still change things on a View Only or media-role request. Recommended for every site.

= 1.0.0 =
First release.
