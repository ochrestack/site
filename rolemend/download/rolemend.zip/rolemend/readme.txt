=== Rolemend – View Only and No-Upload Media Roles ===
Contributors: ochrestack
Tags: read-only, user-roles, roles, media-library, alt-text
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Two roles WordPress lacks: View Only opens wp-admin and saves nothing; Media Library (no uploads) edits alt text but cannot upload.

== Description ==

Want someone to view your WordPress back end but not edit it? Or an SEO person who can fix alt text but not upload files? Rolemend adds both roles, and changes nothing else.

WordPress ties seeing to editing: the Posts list opens only for people who may edit posts, Settings only for people who may save them, and the Media Library only for people who may upload. No combination of capabilities in a role editor gives "look but do not touch" or "edit the alt text but do not upload".

**Both roles are free and complete**, for any number of users: no account, no locked button, no notice or review request in wp-admin. An optional add-on, Rolemend Pro, costs $19 once (below); you do not need it.

**Tested, not promised.** On Rolemend 1.2.0 a View Only user opened 54 wp-admin screens, and 142 of 142 attempts to change something were refused, with a checksum of the site's content, settings and user tables identical after every one. The media role saved alt text on others' photos and all 11 upload routes were refused. Tested on Linux with WordPress 7.1.4 and 6.5.14, PHP 8.3 and 7.4, single site and multisite; Windows and macOS untested.

= View Only =

For an accountant, auditor, client, board member or new hire who should look round and change nothing.

* Sees what an Administrator sees for WordPress itself: Dashboard, Posts, Pages, Media, Comments, Appearance, Plugins, Users, Tools > Site Health and every Settings screen. Lists show every post and page, drafts and private ones included.
* Every change is refused with a plain message ("This account is view only, so nothing was changed. Ask an administrator if this change is needed."): settings, posts, pages and drafts, media, comments, users and application passwords, plugins and themes, menus, widgets, the Customizer, and the same through the REST API.
* Other plugins are held back too: form posts to their save handlers are refused with the same message, and so is a link or button on their screens whose handler checks WordPress's security token. Other plugin code that still runs on the user's request takes no database write, except caches and the user's own settings and sign-in.
* Other plugins' menu and toolbar items (WooCommerce's Products, Yoast SEO) are left out unless the plugin uses WordPress's Settings permission (tested: every menu link opens, with WooCommerce, Yoast SEO and GiveWP active).
* They can change their own password and Screen Options, nothing else.
* A "View only" marker shows in the toolbar on every screen.

= Media Library (no uploads) =

For an SEO or accessibility contractor who should fix titles and alternative text without adding files.

* Sees Dashboard, Media > Library (grid and list, search and filters) and their own Profile. On a WooCommerce shop it signs in to wp-admin like any other account, not to My account.
* Saves Title, Alternative Text, Caption and Description in Attachment details and on the Edit Media screen, on any item.
* Refused with a plain message: uploading in any way (drag and drop, the upload button, the REST API, files fetched from a URL), deleting or trashing, Edit Image, changing "Uploaded to", and every other change. Uploads stay refused even if a role editor later gives the role upload rights.

= Nothing else changes =

* Activation adds the two roles and nothing more: no existing role or user changes, the front end is untouched, no notice, wizard or redirect.
* Users > Rolemend lists who holds each role and what each can and cannot do.
* Deactivating stops both roles at once: their users can no longer open wp-admin. Deleting the plugin removes both roles; their users keep their accounts with no role.

= When you may not need Rolemend =

If you only need WordPress's own screens locked, Readministrator, another free plugin, also blocks core writes, drafts included. Rolemend adds the media role, a plain message on each refusal, the user's own password, and a stop on other plugins' database writes on these users' requests, not only their settings.

= What it does not lock =

* Anything another plugin does outside the WordPress database when a plain link is clicked or a screen is read, such as sending an email or writing a file. WordPress's own links, such as Trash or Activate, are refused, and database writes from other plugins' links are stopped. A plugin whose save was stopped may still show its own "Saved" message. Choose who gets the role as you would for any account that can read your site.
* Code that runs before WordPress knows who is signed in, and plugins that write through their own connection instead of WordPress's ($wpdb).
* What the account can read is readable, including user email addresses and commenter details.
* Drafts are listed by title, author and date, but their text cannot be opened, because WordPress shows a draft only to people who may edit it.
* Tools > Export and the theme and plugin file editors are not available to the role.
* Other plugins' screens appear only when they use WordPress's own Settings permission, and some of them may load empty when their reading also goes through a save handler. Appearance > Editor opens, but its previews of posts, pages and navigation are empty.
* New alt text does not change images already placed in posts and pages: they keep the alt text they were inserted with. Featured images, galleries and shop images that the theme reads from the Media Library show the new text.

= Rolemend Pro =

$19 once, unlimited sites, no renewal, no licence check, on ochrestack.com. For people who hand access to outsiders: an "Access ends on" date for either role, and Media > Text Changes, every title, alt text, caption and description change the media role made, with undo and CSV.

== External services ==

None. Rolemend does not contact any outside server: no telemetry, no analytics, no licence check, no update check of its own. Rolemend Pro does not either.

== Installation ==

1. Plugins > Add Plugin, search for "Rolemend", Install Now, Activate.
2. Users > Add User: choose "View Only" or "Media Library (no uploads)" under Role. For an existing user, pick the role on their profile.

Help: the support forum here, or support@ochrestack.com.

== Frequently Asked Questions ==

= Can I add a view-only role, since WordPress doesn't seem to let someone view but not edit the back end? =

Yes. Give the person the "View Only" role. They open every WordPress screen an Administrator sees, and every change is refused with a plain message, drafts and the REST API included.

= Will installing it change anything by default? =

No. Activation adds two roles and nothing else: existing roles, users and the front end are untouched. Nothing happens until you give someone a role.

= Can my SEO person edit alt text without being able to upload files? =

Yes: the "Media Library (no uploads)" role. They open the Media Library and save Title, Alternative Text, Caption and Description on any item. Uploading, deleting and Edit Image are refused.

= Can the View Only user read drafts? =

They see every draft in the lists by title, author, date and status, but cannot open its text: WordPress shows a draft only to people who may edit it.

= Will new alt text change images already in my posts? =

No. Images already in posts and pages keep the alt text they were inserted with. Featured images, galleries and shop images your theme reads from the Media Library show the new text.

= What does it not lock? =

What another plugin does outside the database, code that runs before WordPress knows who is signed in, and anything the account can read. The full list is above.

= What happens when I deactivate or delete it? =

Deactivating stops both roles; reactivating gives back the same access. Deleting removes both roles; the users keep their accounts with no role.

= Why can't a role editor do this? I only see one option under Media Library. =

That option is the upload permission, and WordPress opens the Media Library only for people who have it. A role editor can let a role see more screens, but not stop it changing them.

= Does it work with WooCommerce, Yoast SEO and GiveWP? =

Tested with WooCommerce 11.2.2, Yoast SEO 28.8 and GiveWP 4.19.2 active. The media role reaches wp-admin on a WooCommerce shop (its My account redirect is off for the role) and edits the alt text of product photos. View Only does not see these plugins' menus or data, which need permissions it lacks. Other plugins that send people without Edit Posts to an account page are not handled.

= Does it work on multisite? =

Yes. Each site gets the roles separately; neither role opens Network Admin.

== Screenshots ==

1. A View Only user on Posts: drafts, private and scheduled posts are listed, and the toolbar says "View only".
2. The same user clicks Save Changes on Settings > General: refused in plain words. Nothing is saved.
3. Plugins for a View Only user: the list is there, Activate, Deactivate and Delete are not.
4. The SEO contractor's Media Library: Alternative Text typed and saved on a photo someone else uploaded.
5. The same contractor drops a photo onto the Media Library: refused, and nothing is added.
6. Users > Rolemend: who has each role, and what each role can do, cannot do and does not lock.

== Changelog ==

= 1.2.0 =
* Fix: on a WooCommerce shop the media role is no longer sent to My account and reaches the Media Library.
* Fix: View Only no longer sees other plugins' menu entries that only lead to a refusal.
* Media role: no Add Media File or Edit Image button on Edit Media or in Attachment details.
* Opening a draft as View Only says the editor does not open, not that nothing was changed.

== Upgrade Notice ==

= 1.2.0 =
The media role works on WooCommerce shops; View Only menus no longer lead to refusals.
