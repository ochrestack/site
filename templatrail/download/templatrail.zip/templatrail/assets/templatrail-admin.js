/* Templatrail admin screen: drives the scan in batches, enables Move to Trash. No network calls except to this site's own REST API. */
( function () {
	'use strict';

	var data = window.templatrailData || {};
	var strings = data.strings || {};

	function $( id ) {
		return document.getElementById( id );
	}

	function post( route, body ) {
		return fetch( data.restUrl + route, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': data.nonce, 'Content-Type': 'application/json' },
			body: JSON.stringify( body || {} )
		} ).then( function ( response ) {
			return response.json().then( function ( json ) {
				if ( ! response.ok ) {
					throw new Error( json && json.message ? json.message : response.statusText );
				}
				return json;
			} );
		} );
	}

	function show( progress ) {
		$( 'templatrail-progress' ).hidden = false;
		$( 'templatrail-bar' ).value = progress.percent;
		$( 'templatrail-progress-text' ).textContent = progress.percent + '% ' + progress.message;
	}

	function setBusy( busy ) {
		// The report under the bar is the old one: dim it and stop clicks on it while the new scan runs.
		var wrap = document.querySelector( '.wrap.templatrail' );
		if ( wrap ) {
			wrap.classList.toggle( 'templatrail-scanning', busy );
		}
		var buttons = document.querySelectorAll( '#templatrail-scan, #templatrail-continue' );
		Array.prototype.forEach.call( buttons, function ( button ) {
			button.disabled = busy;
		} );
		// A link that exports the old report (Templatrail Pro's Export CSV) is greyed with its reason while the new scan runs.
		var links = document.querySelectorAll( '.templatrail-scan-buttons a[data-templatrail-busy-title]' );
		Array.prototype.forEach.call( links, function ( link ) {
			if ( busy ) {
				link.setAttribute( 'data-templatrail-title', link.title );
				link.title = link.getAttribute( 'data-templatrail-busy-title' );
				link.setAttribute( 'aria-disabled', 'true' );
				link.classList.add( 'disabled' );
			} else {
				link.title = link.getAttribute( 'data-templatrail-title' ) || '';
				link.removeAttribute( 'aria-disabled' );
				link.classList.remove( 'disabled' );
			}
		} );
		// While a scan runs the line above must not say "No scan yet".
		var last = document.querySelector( '.templatrail-last' );
		if ( last ) {
			if ( busy && ! last.hasAttribute( 'data-was' ) ) {
				last.setAttribute( 'data-was', last.textContent );
				last.textContent = strings.scanningNote;
			} else if ( ! busy && last.hasAttribute( 'data-was' ) ) {
				last.textContent = last.getAttribute( 'data-was' );
				last.removeAttribute( 'data-was' );
			}
		}
	}

	function loop( progress ) {
		show( progress );
		if ( progress.finished ) {
			$( 'templatrail-progress-text' ).textContent = strings.finished;
			window.location.href = window.location.href.replace( /&(view|paged|template|autoscan)=[^&]*/g, '' );
			return;
		}
		return post( 'scan/step', { job: progress.job } ).then( loop );
	}

	function fail( error ) {
		setBusy( false );
		$( 'templatrail-progress' ).hidden = false;
		$( 'templatrail-progress-text' ).textContent = strings.failed + error.message + ' ' + strings.retry;
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest ? event.target.closest( 'a[data-templatrail-busy-title]' ) : null;
		if ( link && link.getAttribute( 'aria-disabled' ) === 'true' ) {
			event.preventDefault();
		}
	} );

	var scan = $( 'templatrail-scan' );
	if ( scan ) {
		scan.addEventListener( 'click', function () {
			setBusy( true );
			show( { percent: 0, message: strings.starting } );
			post( 'scan/start' ).then( loop ).catch( fail );
		} );
	}

	if ( scan && data.autoscan === '1' ) {
		scan.click();
	}

	var resume = $( 'templatrail-continue' );
	if ( resume && data.job ) {
		resume.addEventListener( 'click', function () {
			setBusy( true );
			show( { percent: 0, message: strings.scanning } );
			loop( { job: data.job, percent: 0, message: strings.scanning, finished: false } ).catch( fail );
		} );
	}

	// Move to Trash: enabled only while at least one template is ticked. The same button sits under a long list.
	var trashes = document.querySelectorAll( '.templatrail-trash-button' );
	var trash = trashes.length ? trashes[0] : null;
	var counts = document.querySelectorAll( '.templatrail-selcount' );
	var all = $( 'templatrail-all' );
	var picks = document.querySelectorAll( '.templatrail-pick' );
	var formEl = $( 'templatrail-form' );
	function refresh() {
		if ( ! trash ) {
			return;
		}
		var ticked = document.querySelectorAll( '.templatrail-pick:checked' ).length;
		var can = trash.getAttribute( 'data-can' ) === '1';
		var text = strings.selectedOf.replace( '%1$d', ticked ).replace( '%2$d', picks.length );
		Array.prototype.forEach.call( trashes, function ( button ) {
			button.disabled = ! can || ticked === 0;
			// With no tick box usable on the page the server wrote the reason into the title, and the count is not drawn.
			if ( can && picks.length ) {
				button.title = ticked === 0 ? strings.selectNone : strings.selectedN;
			}
		} );
		Array.prototype.forEach.call( counts, function ( node ) {
			node.textContent = text;
		} );
	}
	Array.prototype.forEach.call( picks, function ( box ) {
		box.addEventListener( 'change', refresh );
	} );
	if ( all ) {
		all.addEventListener( 'change', function () {
			Array.prototype.forEach.call( picks, function ( box ) {
				box.checked = all.checked;
			} );
			refresh();
		} );
	}
	refresh();

	// A second press while the first is being sent would run the cleanup twice and hide the first result.
	if ( formEl && trash ) {
		formEl.addEventListener( 'submit', function () {
			// Disabled after the browser has read the form, so the button's own value is not lost and a second press sends nothing.
			setTimeout( function () {
				Array.prototype.forEach.call( trashes, function ( button ) {
					button.disabled = true;
				} );
			}, 0 );
		} );
	}
}() );
