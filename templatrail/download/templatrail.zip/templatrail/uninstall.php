<?php
/**
 * Removes Templatrail's own data: its two tables and its options.
 * Templates, pages and posts are never touched.
 *
 * @package Templatrail
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
// The tables are Templatrail's own and are named from $wpdb->prefix and a fixed suffix.
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'templatrail_refs_a' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'templatrail_refs_b' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

foreach ( array( 'templatrail_live', 'templatrail_db_version', 'templatrail_job', 'templatrail_lock', 'templatrail_summary', 'templatrail_scans_done', 'templatrail_review_dismissed', 'templatrail_trashed' ) as $templatrail_option ) {
	delete_option( $templatrail_option );
}
delete_transient( 'templatrail_activated' );
foreach ( get_users(
	array(
		'role'   => 'administrator',
		'fields' => 'ID',
	)
) as $templatrail_user ) {
	delete_transient( 'templatrail_notice_' . $templatrail_user );
}
