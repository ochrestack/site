<?php
/**
 * REST routes that drive the scan from the screen's script.
 *
 * Every route needs a signed-in administrator (manage_options) and a valid
 * REST nonce in the X-WP-Nonce header.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API.
 */
class Templatrail_Rest {

	/**
	 * Hook the routes.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Register the routes.
	 */
	public static function routes() {
		register_rest_route(
			'templatrail/v1',
			'/scan/start',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'start' ),
				'permission_callback' => array( __CLASS__, 'permission' ),
			)
		);
		register_rest_route(
			'templatrail/v1',
			'/scan/step',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'step' ),
				'permission_callback' => array( __CLASS__, 'permission' ),
				'args'                => array(
					'job' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Administrators with a valid nonce only.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public static function permission( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'templatrail_forbidden', __( 'Only administrators can run a scan.', 'templatrail' ), array( 'status' => rest_authorization_required_code() ) );
		}
		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error( 'templatrail_bad_nonce', __( 'Your session has expired or is missing. Reload the page and try again.', 'templatrail' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Start a scan.
	 *
	 * @return WP_REST_Response
	 */
	public static function start() {
		return rest_ensure_response( Templatrail_Scan::start() );
	}

	/**
	 * Run one batch.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function step( $request ) {
		$result = Templatrail_Scan::step( (string) $request->get_param( 'job' ) );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}
}
