<?php
/**
 * The Tools > Templatrail screen, the "Used on" column and the form handlers.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin screens.
 */
class Templatrail_Admin {

	const SCREEN   = 'templatrail';
	const PER_PAGE = 25;

	/**
	 * Result of Move to Trash waiting for the tabs.
	 *
	 * @var array|null
	 */
	private static $held = null;

	/**
	 * Hook everything up.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_templatrail_trash', array( __CLASS__, 'handle_trash' ) );
		add_action( 'admin_post_templatrail_restore', array( __CLASS__, 'handle_restore' ) );
		add_filter( 'manage_elementor_library_posts_columns', array( __CLASS__, 'columns' ), 20 );
		add_action( 'manage_elementor_library_posts_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( TEMPLATRAIL_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'load-plugins.php', array( __CLASS__, 'plugins_screen' ) );
	}

	/**
	 * Whether Elementor is running.
	 *
	 * @return bool
	 */
	public static function elementor_active() {
		return defined( 'ELEMENTOR_VERSION' );
	}

	/**
	 * Address of the screen.
	 *
	 * @param array $args Extra query arguments.
	 * @return string
	 */
	public static function url( array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SCREEN ), $args ), admin_url( 'tools.php' ) );
	}

	/**
	 * Tools > Templatrail.
	 */
	public static function menu() {
		$hook = add_submenu_page(
			'tools.php',
			__( 'Templatrail', 'templatrail' ),
			__( 'Templatrail', 'templatrail' ),
			'manage_options',
			self::SCREEN,
			array( __CLASS__, 'render' )
		);
		if ( $hook ) {
			add_action( 'load-' . $hook, array( __CLASS__, 'enqueue' ) );
		}
	}

	/**
	 * Scripts and styles, on this screen only.
	 */
	public static function enqueue() {
		wp_enqueue_style( 'templatrail-admin', TEMPLATRAIL_URL . 'assets/templatrail-admin.css', array(), TEMPLATRAIL_VERSION );
		wp_enqueue_script( 'templatrail-admin', TEMPLATRAIL_URL . 'assets/templatrail-admin.js', array(), TEMPLATRAIL_VERSION, true );
		$job = Templatrail_Scan::job();
		wp_localize_script(
			'templatrail-admin',
			'templatrailData',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'templatrail/v1/' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'job'      => $job ? $job['id'] : '',
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only decides whether the page presses Scan itself; the scan runs with a REST nonce.
				'autoscan' => isset( $_GET['autoscan'] ) ? '1' : '',
				'strings'  => array(
					'starting'     => __( 'Starting the scan…', 'templatrail' ),
					'failed'       => __( 'The scan stopped: ', 'templatrail' ),
					'retry'        => __( 'Press the button to start again.', 'templatrail' ),
					'finished'     => __( 'Scan finished. Showing the report…', 'templatrail' ),
					'scanning'     => __( 'Scanning…', 'templatrail' ),
					'scanningNote' => __( 'Scanning the site. Keep this page open until the report appears.', 'templatrail' ),
					'selectNone'   => __( 'Select templates with no use found first.', 'templatrail' ),
					'selectedN'    => __( 'Move the selected templates to the Trash', 'templatrail' ),
				),
			)
		);
	}

	/**
	 * Link on the Plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open Templatrail', 'templatrail' ) . '</a>' );
		return $links;
	}

	/**
	 * One plain line after activation, in place of WordPress's own "Plugin activated.".
	 */
	public static function plugins_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only reads WordPress's own redirect flag.
		if ( ! isset( $_GET['activate'] ) || ! get_transient( 'templatrail_activated' ) ) {
			return;
		}
		delete_transient( 'templatrail_activated' );
		unset( $_GET['activate'], $_GET['activate-multi'] );
		add_action(
			'admin_notices',
			static function () {
				printf(
					'<div class="notice notice-success is-dismissible"><p>%s <a href="%s">%s</a></p></div>',
					esc_html__( 'Templatrail is active. It lives under Tools > Templatrail: press Scan site there.', 'templatrail' ),
					esc_url( Templatrail_Admin::url() ),
					esc_html__( 'Open Templatrail', 'templatrail' )
				);
			}
		);
	}

	/**
	 * Add the Used on column to Elementor's Saved Templates list.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function columns( $columns ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			// The column links to Tools > Templatrail, which is for administrators; Editors who open Saved Templates would only meet a refusal.
			return $columns;
		}
		$summary = Templatrail_Scan::summary();
		$title   = $summary
			? sprintf(
				/* translators: %s: date and time of the last scan. */
				__( 'Counts from the scan of %s', 'templatrail' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $summary['at'] )
			)
			: __( 'No scan yet', 'templatrail' );
		$label  = '<span title="' . esc_attr( $title ) . '">' . esc_html__( 'Used on', 'templatrail' ) . '</span>';
		$out    = array();
		$placed = false;
		foreach ( $columns as $key => $value ) {
			if ( 'date' === $key ) {
				$out['templatrail_used_on'] = $label;
				$placed                     = true;
			}
			$out[ $key ] = $value;
		}
		if ( ! $placed ) {
			$out['templatrail_used_on'] = $label;
		}
		return $out;
	}

	/**
	 * Content of the Used on column.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 */
	public static function column_content( $column, $post_id ) {
		if ( 'templatrail_used_on' !== $column ) {
			return;
		}
		if ( 'trash' === get_post_status( $post_id ) ) {
			echo '<span aria-hidden="true">&mdash;</span><span class="screen-reader-text">' . esc_html__( 'In the Trash', 'templatrail' ) . '</span>';
			return;
		}
		$summary = Templatrail_Scan::summary();
		if ( null === $summary || ! isset( $summary['templates'][ $post_id ] ) ) {
			echo '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Not scanned', 'templatrail' ) . '</a>';
			return;
		}
		$item  = $summary['templates'][ $post_id ];
		$count = sprintf(
			/* translators: %d: number of places that use the template. */
			_n( '%d place', '%d places', (int) $item['n'], 'templatrail' ),
			(int) $item['n']
		);
		echo '<a href="' . esc_url( self::url( array( 'template' => $post_id ) ) ) . '">' . esc_html( $count ) . '</a>';
		$changes = (array) get_option( 'templatrail_changed', array() );
		if ( 'none' === $item['s'] && isset( $changes[ $post_id ] ) ) {
			echo '<br><span class="description">' . esc_html__( 'Changed since the scan', 'templatrail' ) . '</span>';
		} elseif ( 'none' === $item['s'] ) {
			echo '<br><span class="description">' . esc_html( Templatrail_Report::use_label( 'none' ) ) . '</span>';
		} elseif ( 'check' === $item['s'] ) {
			echo '<br><span class="description">' . esc_html( Templatrail_Report::use_label( 'check' ) ) . '</span>';
		}
	}

	/**
	 * Keep a message for the next load of the screen.
	 *
	 * @param array $notice Notice data.
	 */
	private static function flash( array $notice ) {
		set_transient( 'templatrail_notice_' . get_current_user_id(), $notice, 300 );
	}

	/**
	 * Back to the screen.
	 *
	 * @param array $args Query arguments.
	 */
	private static function back( array $args = array() ) {
		wp_safe_redirect( self::url( $args ) );
		exit;
	}

	/**
	 * Move selected templates to the Trash, after a re-check.
	 */
	public static function handle_trash() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'templatrail' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'templatrail_trash' );
		$ids = isset( $_POST['templates'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['templates'] ) ) : array();
		if ( ! $ids ) {
			self::flash(
				array(
					'type' => 'warning',
					'text' => __( 'Nothing was selected, so nothing was moved.', 'templatrail' ),
				)
			);
			self::back( self::posted_view() );
		}
		$result = Templatrail_Cleanup::trash( $ids );
		self::flash(
			array(
				'type'    => 'trash',
				'moved'   => $result['moved'],
				'skipped' => $result['skipped'],
			)
		);
		self::back( self::posted_view() );
	}

	/**
	 * The tab the person was on when they pressed Move to Trash, so the screen comes back to it.
	 *
	 * @return array Query arguments.
	 */
	private static function posted_view() {
		// The caller checked the nonce.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$view = isset( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : '';
		return in_array( $view, array( 'used', 'none', 'check' ), true ) ? array( 'view' => $view ) : array();
	}

	/**
	 * Restore a template from the Trash.
	 */
	public static function handle_restore() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'templatrail' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'templatrail_restore' );
		$id = isset( $_GET['template'] ) ? absint( $_GET['template'] ) : 0;
		if ( $id && Templatrail_Cleanup::restore( $id ) ) {
			self::flash(
				array(
					'type' => 'success',
					'text' => sprintf(
						/* translators: %s: template title. */
						__( '“%s” was restored from the Trash. Scan again to refresh the list of missing references.', 'templatrail' ),
						Templatrail_Report::raw_title( $id )
					),
				)
			);
		} else {
			self::flash(
				array(
					'type' => 'warning',
					'text' => __( 'That template is not in the Trash, so there was nothing to restore.', 'templatrail' ),
				)
			);
		}
		self::back( array( 'view' => 'missing' ) );
	}

	/**
	 * Show the notice left by the last action, once.
	 */
	private static function show_flash( $hold_result = false ) {
		$key    = 'templatrail_notice_' . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! is_array( $notice ) ) {
			return;
		}
		delete_transient( $key );
		if ( 'trash' !== $notice['type'] ) {
			printf( '<div class="notice notice-%s inline"><p>%s</p></div>', esc_attr( $notice['type'] ), esc_html( $notice['text'] ) );
			return;
		}
		if ( $hold_result ) {
			self::$held = $notice;
			return;
		}
		self::print_result( $notice );
	}

	/**
	 * The result of Move to Trash, held until the tabs are drawn so it sits between the tabs and the rows it is about.
	 */
	private static function show_held() {
		if ( null !== self::$held ) {
			$notice     = self::$held;
			self::$held = null;
			self::print_result( $notice );
		}
	}

	/**
	 * The result of Move to Trash.
	 *
	 * @param array $notice Notice data.
	 */
	private static function print_result( array $notice ) {
		$moved   = $notice['moved'];
		$skipped = $notice['skipped'];
		echo '<div class="notice ' . ( $moved ? 'notice-success' : 'notice-warning' ) . ' inline templatrail-result">';
		if ( $moved ) {
			echo '<p><strong>' . esc_html(
				sprintf(
					/* translators: %d: number of templates. */
					_n( 'Re-checked, then moved %d template to the Trash.', 'Re-checked, then moved %d templates to the Trash.', count( $moved ), 'templatrail' ),
					count( $moved )
				)
			) . '</strong> ' . esc_html(
				implode(
					', ',
					array_map(
						static function ( $title ) {
							return '“' . $title . '”';
						},
						$moved
					)
				)
			) . '. ';
			echo '<a href="' . esc_url( admin_url( 'edit.php?post_status=trash&post_type=elementor_library' ) ) . '">' . esc_html__( 'Open Elementor’s Trash view to restore templates', 'templatrail' ) . '</a>. ' . esc_html(
				sprintf(
					/* translators: %d: number of days. */
					_n( 'WordPress empties its Trash after %d day.', 'WordPress empties its Trash after %d days.', (int) EMPTY_TRASH_DAYS, 'templatrail' ),
					(int) EMPTY_TRASH_DAYS
				)
			) . '</p>';
		} else {
			echo '<p><strong>' . esc_html__( 'Nothing was moved.', 'templatrail' ) . '</strong></p>';
		}
		if ( $skipped ) {
			echo '<p>' . esc_html(
				sprintf(
					/* translators: %d: number of templates. */
					_n( 'Left alone after the re-check: %d template.', 'Left alone after the re-check: %d templates.', count( $skipped ), 'templatrail' ),
					count( $skipped )
				)
			) . '</p><ul class="templatrail-skipped">';
			foreach ( $skipped as $item ) {
				echo '<li>“' . esc_html( $item['title'] ) . '” ' . esc_html( $item['reason'] ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	/**
	 * The screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to open this screen.', 'templatrail' ), '', array( 'response' => 403 ) );
		}
		echo '<div class="wrap templatrail">';
		echo '<h1>' . esc_html__( 'Templatrail', 'templatrail' ) . '</h1>';

		if ( ! self::elementor_active() ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Templatrail needs Elementor, and Elementor is not active on this site. Activate Elementor on the Plugins screen, then come back here.', 'templatrail' ) . ' <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'Open Plugins', 'templatrail' ) . '</a></p></div></div>';
			return;
		}

		Templatrail_Store::maybe_install();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display filters only.
		$template_id = isset( $_GET['template'] ) ? absint( $_GET['template'] ) : 0;
		$view        = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'all';
		$paged       = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		self::show_flash( ! $template_id );

		if ( $template_id ) {
			self::render_detail( $template_id );
			echo '</div>';
			return;
		}
		self::render_overview( $view, $paged );
		echo '</div>';
	}

	/**
	 * Scan button, progress, last scan line.
	 *
	 * @param array|null $summary Stored summary.
	 */
	private static function render_scan_panel( $summary ) {
		$job = Templatrail_Scan::job();
		echo '<div class="templatrail-scan">';
		if ( $summary ) {
			$templates = count( $summary['templates'] );
			printf(
				'<p class="templatrail-last">%s</p>',
				esc_html(
					sprintf(
						/* translators: 1: date and time, 2: number of posts read, 3: number of templates listed. */
						__( 'Last scan: %1$s. It read %2$d posts. Listed below: %3$d saved templates and Components.', 'templatrail' ),
						wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $summary['at'] ),
						(int) $summary['posts'],
						$templates
					)
				)
			);
		} else {
			echo '<p class="templatrail-last">' . esc_html__( 'No scan yet. Press Scan site to read every page, post, template and widget for references to saved templates.', 'templatrail' ) . '</p>';
		}
		$label = $summary ? __( 'Scan again', 'templatrail' ) : __( 'Scan site', 'templatrail' );
		echo '<p class="templatrail-scan-buttons">';
		echo '<button type="button" class="button button-primary" id="templatrail-scan">' . esc_html( $label ) . '</button>';
		if ( $job ) {
			echo ' <button type="button" class="button" id="templatrail-continue">' . esc_html__( 'Continue the scan that was started', 'templatrail' ) . '</button>';
		}
		do_action( 'templatrail_toolbar' );
		echo '</p>';
		echo '<div class="templatrail-progress" id="templatrail-progress" hidden><progress max="100" value="0" id="templatrail-bar"></progress> <span id="templatrail-progress-text" role="status" aria-live="polite"></span></div>';
		echo '</div>';
	}

	/**
	 * Overview: the report.
	 *
	 * @param string $view  Filter.
	 * @param int    $paged Page number.
	 */
	private static function render_overview( $view, $paged ) {
		$summary = Templatrail_Scan::summary();
		self::render_scan_panel( $summary );

		echo '<details class="templatrail-copy-note"><summary>' . esc_html__( 'What counts as a use', 'templatrail' ) . '</summary><p>' . esc_html__( 'A template inserted into a page as a copy is not a use: the copy no longer points at the template, so it does not appear here. A use is a place that points at the template: a shortcode, a Template or Loop Grid widget, a global widget, a popup link, a Component, an Elementor Template block, an add-on’s saved-template option, or Maintenance Mode.', 'templatrail' ) . '</p></details>';

		if ( null === $summary ) {
			self::show_held();
			self::render_pro_line();
			return;
		}

		if ( empty( $summary['v'] ) || TEMPLATRAIL_VERSION !== $summary['v'] ) {
			echo '<div class="notice notice-warning inline templatrail-old-scan"><p>' . esc_html__( 'This report was made by an earlier version of Templatrail, which read fewer places. Press Scan again to update it before you rely on No use found.', 'templatrail' ) . '</p></div>';
		}

		$report    = new Templatrail_Report();
		$templates = $report->templates();
		$counts    = array(
			'all'   => 0,
			'used'  => 0,
			'none'  => 0,
			'check' => 0,
		);
		foreach ( $summary['templates'] as $id => $item ) {
			if ( ! isset( $templates[ $id ] ) ) {
				continue;
			}
			++$counts['all'];
			++$counts[ $item['s'] ];
		}
		$missing           = $report->missing();
		$counts['missing'] = count( array_unique( wp_list_pluck( $missing, 'target' ) ) );

		if ( ! in_array( $view, array( 'all', 'used', 'none', 'check', 'missing' ), true ) ) {
			$view = 'all';
		}

		$tabs = array(
			'all'     => __( 'All', 'templatrail' ),
			'used'    => __( 'In use', 'templatrail' ),
			'none'    => __( 'No use found', 'templatrail' ),
			'check'   => __( 'Check by hand', 'templatrail' ),
			'missing' => __( 'Missing templates', 'templatrail' ),
		);
		// The separators between tabs are drawn by the stylesheet, so a tab never wraps away from its own separator.
		echo '<ul class="subsubsub templatrail-tabs">';
		foreach ( $tabs as $key => $label ) {
			$text = esc_html( $label ) . ' <span class="count">(' . (int) $counts[ $key ] . ')</span>';
			echo '<li>';
			if ( $view === $key ) {
				echo '<span class="current" aria-current="page"><strong>' . $text . '</strong></span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from esc_html() and an integer.
			} else {
				echo '<a href="' . esc_url( self::url( array( 'view' => $key ) ) ) . '">' . $text . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from esc_html() and an integer.
			}
			echo "</li>\n";
		}
		echo '</ul><br class="clear">';

		self::show_held();
		self::render_loops( $summary, $templates );

		if ( 'missing' === $view ) {
			self::render_missing( $missing );
			self::render_pro_line();
			return;
		}

		$rows = array();
		foreach ( $templates as $id => $template ) {
			if ( ! isset( $summary['templates'][ $id ] ) ) {
				continue;
			}
			if ( 'all' !== $view && $summary['templates'][ $id ]['s'] !== $view ) {
				continue;
			}
			$rows[ $id ] = $template;
		}
		$total = count( $rows );
		if ( 0 === $total ) {
			echo '<p class="templatrail-empty">' . esc_html( self::empty_text( $view, $counts ) ) . '</p>';
			self::render_pro_line();
			return;
		}
		$pages = (int) ceil( $total / self::PER_PAGE );
		$paged = min( $paged, $pages );
		$rows  = array_slice( $rows, ( $paged - 1 ) * self::PER_PAGE, self::PER_PAGE, true );

		// Ticking and Move to Trash belong to the tabs that can hold a template with no use found.
		$can_pick  = in_array( $view, array( 'all', 'none' ), true );
		$can_trash = Templatrail_Cleanup::trash_available();
		$any_none  = $counts['none'] > 0;
		if ( $can_pick ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="templatrail-form">';
			echo '<input type="hidden" name="action" value="templatrail_trash"><input type="hidden" name="view" value="' . esc_attr( $view ) . '">';
			wp_nonce_field( 'templatrail_trash' );

			if ( ! $can_trash ) {
				$trash_tip = __( 'WordPress’s Trash is switched off on this site, so Move to Trash would delete templates for good. Templatrail won’t do that. Ask whoever manages the site to turn the Trash back on.', 'templatrail' ) . ' ' . __( '(The setting is EMPTY_TRASH_DAYS in wp-config.php.)', 'templatrail' );
			} elseif ( ! $any_none ) {
				$trash_tip = __( 'No template has “No use found” in the last scan, so there is nothing to select.', 'templatrail' );
			} else {
				$trash_tip = __( 'Select templates with no use found first.', 'templatrail' );
			}
			if ( $can_trash && $any_none ) {
				echo '<p class="description templatrail-not-read">' . esc_html__( 'Not read: templates placed from PHP theme files, menus or other plugins’ own tables. They show as No use found because Templatrail cannot see them, so leave them out of your selection.', 'templatrail' ) . '</p>';
			}
			echo '<p class="templatrail-bulk"><button type="submit" class="button" id="templatrail-trash" aria-describedby="templatrail-bulk-note" disabled title="' . esc_attr( $trash_tip ) . '" data-can="' . ( $can_trash && $any_none ? '1' : '0' ) . '">' . esc_html__( 'Move selected to Trash', 'templatrail' ) . '</button></p>';
			echo '<p class="description templatrail-bulk-note" id="templatrail-bulk-note">';
			if ( ! $can_trash ) {
				esc_html_e( 'WordPress’s Trash is switched off on this site, so Move to Trash would delete templates for good. Templatrail won’t do that. Ask whoever manages the site to turn the Trash back on.', 'templatrail' );
			} else {
				esc_html_e( 'Templatrail re-reads the site for the selected templates first, skips any that gained a use, and moves the rest to WordPress’s Trash. Templatrail deletes nothing for good.', 'templatrail' );
			}
			echo '</p>';
		}

		echo '<table class="widefat striped templatrail-table templatrail-report-table' . ( $can_pick ? '' : ' templatrail-no-pick' ) . '"><thead><tr>';
		if ( $can_pick ) {
			$pickable = 0;
			foreach ( $rows as $row_id => $row_template ) {
				if ( 'none' === $summary['templates'][ $row_id ]['s'] && ! $row_template['is_component'] ) {
					++$pickable;
				}
			}
			$all_tip = $pickable && $can_trash ? __( 'Select every template with no use found on this page', 'templatrail' ) : __( 'No template on this page has “No use found”, so there is nothing to select.', 'templatrail' );
			echo '<td class="check-column"><input type="checkbox" id="templatrail-all" title="' . esc_attr( $all_tip ) . '" aria-label="' . esc_attr( $all_tip ) . '"' . ( $pickable && $can_trash ? '' : ' disabled' ) . '><label for="templatrail-all" class="templatrail-selectall-label">' . esc_html__( 'Select all with no use found', 'templatrail' ) . '</label></td>';
		}
		echo '<th>' . esc_html__( 'Template', 'templatrail' ) . '</th><th>' . esc_html__( 'Type', 'templatrail' ) . '</th><th>' . esc_html__( 'Status', 'templatrail' ) . '</th><th>' . esc_html__( 'Use', 'templatrail' ) . '</th><th>' . esc_html__( 'Places', 'templatrail' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $rows as $id => $template ) {
			self::render_row( $report, $template, $summary['templates'][ $id ]['s'], $can_trash, $can_pick );
		}
		echo '</tbody></table>';
		if ( $can_pick ) {
			echo '</form>';
		}

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post(
				paginate_links(
					array(
						'base'      => add_query_arg( 'paged', '%#%', self::url( array( 'view' => $view ) ) ),
						'format'    => '',
						'current'   => $paged,
						'total'     => $pages,
						'prev_text' => '‹',
						'next_text' => '›',
					)
				)
			);
			echo '</div></div>';
		}
		self::render_pro_line();
	}

	/**
	 * Words for an empty filter.
	 *
	 * @param string $view   Filter.
	 * @param array  $counts Counts.
	 * @return string
	 */
	private static function empty_text( $view, array $counts ) {
		if ( 0 === $counts['all'] ) {
			return __( 'The scan found no saved templates or Components on this site.', 'templatrail' );
		}
		$texts = array(
			'used'  => __( 'No template is in use according to the last scan.', 'templatrail' ),
			'none'  => __( 'Every template has a use found, or needs a check by hand. Nothing to clean up.', 'templatrail' ),
			'check' => __( 'No template needs a check by hand.', 'templatrail' ),
		);
		return isset( $texts[ $view ] ) ? $texts[ $view ] : __( 'Nothing to show.', 'templatrail' );
	}

	/**
	 * One template row.
	 *
	 * @param Templatrail_Report $report    Report.
	 * @param array              $template  Template info.
	 * @param string             $status    used, none or check.
	 * @param bool               $can_trash Whether the Trash is on.
	 * @param bool               $can_pick  Whether this tab has tick boxes.
	 */
	private static function render_row( Templatrail_Report $report, array $template, $status, $can_trash, $can_pick ) {
		$id     = $template['id'];
		$places = $report->places( $id );
		$assess = $report->assess( $id, $places );

		// A re-check after the scan found a use or a doubt for a template the scan listed as No use found.
		$changes = (array) get_option( 'templatrail_changed', array() );
		$changed = 'none' === $assess['status'] && isset( $changes[ $id ] ) ? (string) $changes[ $id ] : '';

		echo '<tr data-status="' . esc_attr( '' !== $changed ? 'check' : $assess['status'] ) . '">';
		$selectable = 'none' === $assess['status'] && '' === $changed && ! $template['is_component'] && $can_trash;
		if ( $can_pick ) {
			echo '<th scope="row" class="check-column">';
		}
		if ( ! $can_pick ) {
			$selectable = false;
		} elseif ( $selectable ) {
			echo '<input type="checkbox" name="templates[]" value="' . esc_attr( (string) $id ) . '" class="templatrail-pick" id="templatrail-pick-' . esc_attr( (string) $id ) . '">';
		} else {
			if ( $template['is_component'] ) {
				$why = __( 'Components are reported but not moved to the Trash: Elementor reserves deleting Components to Elementor Pro.', 'templatrail' );
			} elseif ( ! $can_trash ) {
				$why = __( 'The Trash is switched off on this site, so Templatrail cannot move templates there.', 'templatrail' );
			} elseif ( '' !== $changed ) {
				$why = __( 'The last re-check found a use or a doubt for this template after the scan. Scan again to refresh the list.', 'templatrail' );
			} elseif ( 'used' === $assess['status'] ) {
				$why = __( 'This template is in use. Its places are listed here.', 'templatrail' );
			} else {
				$why = __( 'Check this template by hand. The reason is listed under its use.', 'templatrail' );
			}
			echo '<input type="checkbox" disabled title="' . esc_attr( $why ) . '" aria-label="' . esc_attr( $why ) . '">';
		}
		if ( $can_pick ) {
			echo '</th>';
		}

		// The name opens the screen that answers "where is it used"; the editor is linked from that screen.
		echo '<td class="templatrail-c-name" data-label="' . esc_attr__( 'Template', 'templatrail' ) . '"><strong><a href="' . esc_url( self::url( array( 'template' => $id ) ) ) . '">' . esc_html( $template['title'] ) . '</a></strong> <span class="templatrail-id">#' . esc_html( (string) $id ) . '</span></td>';
		echo '<td class="templatrail-c-type" data-label="' . esc_attr__( 'Type', 'templatrail' ) . '">' . esc_html( $template['type_label'] ) . '</td>';
		echo '<td class="templatrail-c-status" data-label="' . esc_attr__( 'Status', 'templatrail' ) . '">' . esc_html( Templatrail_Report::status_label( $template['status'] ) ) . '</td>';
		if ( '' !== $changed ) {
			echo '<td class="templatrail-c-use templatrail-has-note" data-label="' . esc_attr__( 'Use', 'templatrail' ) . '"><span class="templatrail-badge templatrail-changed">' . esc_html__( 'Changed since the scan', 'templatrail' ) . '</span>';
			self::render_changed_note( $changed );
		} else {
			echo '<td class="templatrail-c-use' . ( $assess['reasons'] ? ' templatrail-has-note' : '' ) . '" data-label="' . esc_attr__( 'Use', 'templatrail' ) . '"><span class="templatrail-badge templatrail-' . esc_attr( $assess['status'] ) . '">' . esc_html( Templatrail_Report::use_label( $assess['status'] ) ) . '</span>';
			foreach ( $assess['reasons'] as $reason ) {
				echo '<span class="description templatrail-note">' . esc_html( $reason ) . '</span>';
			}
		}
		echo '</td>';
		echo '<td class="templatrail-c-places" data-label="' . esc_attr__( 'Places', 'templatrail' ) . '">';
		if ( $places ) {
			echo '<details class="templatrail-details"><summary>' . esc_html(
				sprintf(
					/* translators: %d: number of places. */
					_n( '%d place', '%d places', count( $places ), 'templatrail' ),
					count( $places )
				)
			) . '</summary>';
			self::render_places( $places );
			echo '</details>';
		} else {
			echo '<span>' . esc_html(
				sprintf(
					/* translators: %d: number of places. */
					_n( '%d place', '%d places', 0, 'templatrail' ),
					0
				)
			) . '</span>';
		}
		echo '</td></tr>';
	}

	/**
	 * The words for how a place uses a template. A use through another template says when that template has no use found itself.
	 *
	 * @param array $place_use A use from Templatrail_Report::places().
	 * @return string
	 */
	public static function how_text( array $place_use ) {
		if ( empty( $place_use['via'] ) || ! Templatrail_Report::holder_unused( (int) $place_use['via'] ) ) {
			return $place_use['how'];
		}
		/* translators: %s: the words "inside template X". */
		return sprintf( __( '%s (which has no use found)', 'templatrail' ), $place_use['how'] );
	}

	/**
	 * One phrase for how a place uses a template. A use through another template says when that template has no use found itself.
	 *
	 * @param array $place_use A use from Templatrail_Report::places().
	 * @param array $place     The place it belongs to.
	 * @return string
	 */
	public static function use_text( array $place_use, array $place ) {
		$text = Templatrail_Report::use_phrase( $place_use['detail'] );
		if ( ! empty( $place_use['via'] ) && Templatrail_Report::holder_unused( (int) $place_use['via'] ) ) {
			$text .= ' ' . ( (int) $place_use['via'] === (int) $place['id'] ? __( '(this template has no use found)', 'templatrail' ) : __( '(that template has no use found)', 'templatrail' ) );
		}
		return $text;
	}

	/**
	 * The note that a re-check found a use or a doubt after the scan, with the way to refresh.
	 *
	 * @param string $changed What the re-check found, such as "gained a use: “Back to school” (shortcode in content)."
	 */
	private static function render_changed_note( $changed ) {
		/* translators: %s: what the re-check found, such as "gained a use: “Back to school” (shortcode in content)". */
		echo '<span class="description templatrail-note">' . esc_html( sprintf( __( 'Since the scan, it %s', 'templatrail' ), $changed ) ) . ' <a href="' . esc_url( self::url( array( 'autoscan' => 1 ) ) ) . '">' . esc_html__( 'Scan again', 'templatrail' ) . '</a></span>';
	}

	/**
	 * A list of places.
	 *
	 * @param array $places Places.
	 */
	private static function render_places( array $places ) {
		echo '<ul class="templatrail-places">';
		foreach ( $places as $place ) {
			echo '<li><span class="templatrail-place-name">' . esc_html( $place['title'] ) . '</span> <span class="templatrail-place-meta">' . esc_html( $place['type_label'] ) . ', ' . esc_html( $place['status_label'] ) . '</span>';
			foreach ( $place['uses'] as $use ) {
				echo '<br><span class="templatrail-how">' . esc_html( self::use_text( $use, $place ) ) . '</span>';
			}
			if ( $place['edit_url'] ) {
				echo '<br><a class="templatrail-edit" href="' . esc_url( $place['edit_url'] ) . '">' . esc_html( $place['edit_label'] ) . '</a>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}

	/**
	 * Loops of templates that point at each other.
	 *
	 * @param array $summary   Stored summary.
	 * @param array $templates Existing templates.
	 */
	private static function render_loops( array $summary, array $templates ) {
		if ( empty( $summary['loops'] ) ) {
			return;
		}
		echo '<div class="notice notice-warning inline templatrail-loops"><p><strong>' . esc_html__( 'Templates that point at themselves or at each other', 'templatrail' ) . '</strong></p><ul>';
		foreach ( $summary['loops'] as $loop ) {
			$names = array();
			foreach ( $loop as $id ) {
				$names[] = '“' . ( isset( $templates[ $id ] ) ? $templates[ $id ]['title'] : '#' . $id ) . '”';
			}
			if ( 1 === count( $loop ) ) {
				/* translators: %s: template title. */
				$text = sprintf( __( '%s refers to itself. That is not counted as a use, and Templatrail did not follow it further.', 'templatrail' ), $names[0] );
			} else {
				/* translators: %s: template titles joined by arrows. */
				$text = sprintf( __( 'Loop: %s. Templatrail stopped following it where it came back to the start.', 'templatrail' ), implode( ' → ', array_merge( $names, array( $names[0] ) ) ) );
			}
			echo '<li>' . esc_html( $text ) . '</li>';
		}
		echo '</ul></div>';
	}

	/**
	 * The missing-templates list.
	 *
	 * @param array $missing Rows from Templatrail_Report::missing().
	 */
	private static function render_missing( array $missing ) {
		$targets = count( array_unique( wp_list_pluck( $missing, 'target' ) ) );
		echo '<p class="description templatrail-missing-intro">' . esc_html__( 'These pages, posts and templates still point at a template that is gone: deleted, or in the Trash. Elementor can fail to open or render a page whose loop template is gone.', 'templatrail' );
		if ( $missing ) {
			echo ' ' . esc_html(
				sprintf(
					/* translators: 1: "3 places", 2: number of templates that are gone. */
					_n( 'Found %1$s pointing at %2$d template that is gone.', 'Found %1$s pointing at %2$d templates that are gone.', $targets, 'templatrail' ),
					sprintf(
						/* translators: %d: number of places. */
						_n( '%d place', '%d places', count( $missing ), 'templatrail' ),
						count( $missing )
					),
					$targets
				)
			);
		}
		echo '</p>';
		if ( ! $missing ) {
			echo '<p class="templatrail-empty">' . esc_html__( 'No page points at a deleted template or at one in the Trash.', 'templatrail' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped templatrail-table templatrail-missing"><thead><tr><th>' . esc_html__( 'Page, post or template', 'templatrail' ) . '</th><th>' . esc_html__( 'Points at', 'templatrail' ) . '</th><th>' . esc_html__( 'Where the reference sits', 'templatrail' ) . '</th><th>' . esc_html__( 'Fix', 'templatrail' ) . '</th></tr></thead><tbody>';
		foreach ( $missing as $row ) {
			$place = $row['place'];
			echo '<tr><td data-label="' . esc_attr__( 'Page, post or template', 'templatrail' ) . '"><strong>' . esc_html( $place['title'] ) . '</strong> <span class="templatrail-place-meta">' . esc_html( $place['type_label'] . ', ' . $place['status_label'] ) . '</span></td>';
			echo '<td data-label="' . esc_attr__( 'Points at', 'templatrail' ) . '">';
			if ( 'trash' === $row['state'] ) {
				echo esc_html(
					sprintf(
						/* translators: 1: template ID, 2: template title. */
						__( '#%1$d “%2$s”, which is in the Trash', 'templatrail' ),
						$row['target'],
						$row['target_title']
					)
				);
			} else {
				echo esc_html(
					sprintf(
						/* translators: %d: template ID. */
						__( '#%d, which no longer exists', 'templatrail' ),
						$row['target']
					)
				);
			}
			echo '</td><td data-label="' . esc_attr__( 'Where the reference sits', 'templatrail' ) . '">' . esc_html( Templatrail_Report::use_phrase( $row['detail'] ) ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Fix', 'templatrail' ) . '">';
			if ( $place['edit_url'] ) {
				echo '<a class="button button-small" href="' . esc_url( $place['edit_url'] ) . '">' . esc_html( $place['edit_label'] ) . '</a> ';
			}
			if ( 'trash' === $row['state'] ) {
				$url = wp_nonce_url(
					add_query_arg(
						array(
							'action'   => 'templatrail_restore',
							'template' => $row['target'],
						),
						admin_url( 'admin-post.php' )
					),
					'templatrail_restore'
				);
				echo '<a class="button button-small" href="' . esc_url( $url ) . '">' . esc_html__( 'Restore the template', 'templatrail' ) . '</a>';
			} else {
				echo '<span class="description">' . esc_html__( 'Nothing to restore. Open the page and choose another template, or remove this one.', 'templatrail' ) . '</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Detail of one template.
	 *
	 * @param int $id Template ID.
	 */
	private static function render_detail( $id ) {
		$report    = new Templatrail_Report();
		$templates = $report->templates();
		echo '<p><a href="' . esc_url( self::url() ) . '">&larr; ' . esc_html__( 'All templates', 'templatrail' ) . '</a></p>';
		if ( ! isset( $templates[ $id ] ) ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'That template is not in the list: it may be in the Trash or deleted. Open All templates, or scan again.', 'templatrail' ) . '</p></div>';
			return;
		}
		$template = $templates[ $id ];
		$summary  = Templatrail_Scan::summary();
		if ( null === $summary ) {
			echo '<p>' . esc_html__( 'No scan yet. Press Scan site on the main screen first.', 'templatrail' ) . '</p>';
			return;
		}
		$places  = $report->places( $id );
		$assess  = $report->assess( $id, $places );
		$edit    = Templatrail_Report::edit_link( $id, $template['post_type'] );
		$changes = (array) get_option( 'templatrail_changed', array() );
		$changed = 'none' === $assess['status'] && isset( $changes[ $id ] ) ? (string) $changes[ $id ] : '';
		echo '<h2>' . esc_html(
			sprintf(
				/* translators: %s: template title. */
				__( 'Where “%s” is used', 'templatrail' ),
				$template['title']
			)
		) . '</h2>';
		echo '<p>' . esc_html( $template['type_label'] . ', ' . Templatrail_Report::status_label( $template['status'] ) ) . ' · <span class="templatrail-badge templatrail-' . ( '' !== $changed ? 'changed' : esc_attr( $assess['status'] ) ) . '">' . esc_html( '' !== $changed ? __( 'Changed since the scan', 'templatrail' ) : Templatrail_Report::use_label( $assess['status'] ) ) . '</span> · ' . esc_html(
			sprintf(
				/* translators: %d: number of places. */
				_n( '%d place', '%d places', $assess['places'], 'templatrail' ),
				$assess['places']
			)
		);
		if ( $edit['url'] ) {
			echo ' · <a class="templatrail-nowrap" href="' . esc_url( $edit['url'] ) . '">' . esc_html( $edit['label'] ) . '</a>';
		}
		echo '</p>';
		if ( '' !== $changed ) {
			echo '<p>';
			self::render_changed_note( $changed );
			echo '</p>';
		}
		foreach ( $assess['reasons'] as $reason ) {
			echo '<p class="description">' . esc_html( $reason ) . '</p>';
		}
		do_action( 'templatrail_template_actions', $template );
		if ( ! $places && '' !== $changed ) {
			return;
		}
		if ( ! $places ) {
			echo '<p class="templatrail-empty">' . esc_html__( 'No place uses this template, as far as the last scan could tell.', 'templatrail' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped templatrail-table templatrail-place-table"><thead><tr><th>' . esc_html__( 'Place', 'templatrail' ) . '</th><th>' . esc_html__( 'Type', 'templatrail' ) . '</th><th>' . esc_html__( 'Status', 'templatrail' ) . '</th><th>' . esc_html__( 'How it is used', 'templatrail' ) . '</th><th>' . esc_html__( 'Open', 'templatrail' ) . '</th></tr></thead><tbody>';
		foreach ( $places as $place ) {
			echo '<tr><td data-label="' . esc_attr__( 'Place', 'templatrail' ) . '"><strong>' . esc_html( $place['title'] ) . '</strong></td>';
			echo '<td data-label="' . esc_attr__( 'Type', 'templatrail' ) . '">' . esc_html( $place['type_label'] ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Status', 'templatrail' ) . '">' . esc_html( $place['status_label'] ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'How it is used', 'templatrail' ) . '">';
			foreach ( $place['uses'] as $use ) {
				echo '<span class="templatrail-how">' . esc_html( self::use_text( $use, $place ) ) . '</span><br>';
			}
			echo '</td><td data-label="' . esc_attr__( 'Open', 'templatrail' ) . '">';
			if ( $place['edit_url'] ) {
				echo '<a class="templatrail-edit" href="' . esc_url( $place['edit_url'] ) . '">' . esc_html( $place['edit_label'] ) . '</a>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * The one sentence about Pro.
	 */
	private static function render_pro_line() {
		if ( defined( 'TEMPLATRAIL_PRO_VERSION' ) ) {
			return;
		}
		echo '<p class="templatrail-pro description">' . esc_html__( 'Templatrail Pro, a separate add-on from ochrestack.com, adds Replace everywhere and CSV export. The report and the cleanup above are free.', 'templatrail' ) . '</p>';
	}
}
