<?php
/**
 * Reads the stored references and answers the report's questions: which
 * places use a template, what status it has, which references are missing.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Table names come from Templatrail_Store (prefix plus a fixed suffix); values are prepared.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

/**
 * Report queries.
 */
class Templatrail_Report {

	const POST_TYPES = array( 'elementor_library', 'elementor_component' );

	/**
	 * Table to read.
	 *
	 * @var string
	 */
	private $table;

	/**
	 * Cache of post rows by ID (false when the post does not exist).
	 *
	 * @var array
	 */
	private $posts = array();

	/**
	 * Cache of saved templates.
	 *
	 * @var array|null
	 */
	private $templates = null;

	/**
	 * Loops found while computing places.
	 *
	 * @var array
	 */
	private $loops = array();

	/**
	 * Constructor.
	 *
	 * @param string|null $table Table to read; the live one by default.
	 */
	public function __construct( $table = null ) {
		$this->table = $table ? $table : Templatrail_Store::live_table();
	}

	/**
	 * Names of the template types, in Elementor's own words.
	 *
	 * @param string $type Type slug from _elementor_template_type.
	 * @return string
	 */
	public static function type_label( $type ) {
		$labels = array(
			'section'         => __( 'Section', 'templatrail' ),
			'container'       => __( 'Container', 'templatrail' ),
			'page'            => __( 'Page', 'templatrail' ),
			'widget'          => __( 'Global widget', 'templatrail' ),
			'popup'           => __( 'Popup', 'templatrail' ),
			'loop-item'       => __( 'Loop item', 'templatrail' ),
			'header'          => __( 'Header', 'templatrail' ),
			'footer'          => __( 'Footer', 'templatrail' ),
			'single-post'     => __( 'Single post', 'templatrail' ),
			'single-page'     => __( 'Single page', 'templatrail' ),
			'single'          => __( 'Single', 'templatrail' ),
			'archive'         => __( 'Archive', 'templatrail' ),
			'search-results'  => __( 'Search results', 'templatrail' ),
			'error-404'       => __( '404 page', 'templatrail' ),
			'product'         => __( 'Single product', 'templatrail' ),
			'product-archive' => __( 'Product archive', 'templatrail' ),
			'loop-grid'       => __( 'Loop grid', 'templatrail' ),
			'component'       => __( 'Component', 'templatrail' ),
		);
		if ( isset( $labels[ $type ] ) ) {
			return $labels[ $type ];
		}
		return '' === $type ? __( 'Template', 'templatrail' ) : ucfirst( str_replace( array( '-', '_' ), ' ', $type ) );
	}

	/**
	 * Words for a post status.
	 *
	 * @param string $status Post status.
	 * @return string
	 */
	public static function status_label( $status ) {
		$labels = array(
			'publish' => __( 'Published', 'templatrail' ),
			'draft'   => __( 'Draft', 'templatrail' ),
			'private' => __( 'Private', 'templatrail' ),
			'pending' => __( 'Pending', 'templatrail' ),
			'future'  => __( 'Scheduled', 'templatrail' ),
			'trash'   => __( 'In the Trash', 'templatrail' ),
		);
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}

	/**
	 * Words for the three statuses.
	 *
	 * @param string $status used, none or check.
	 * @return string
	 */
	public static function use_label( $status ) {
		if ( 'used' === $status ) {
			return __( 'In use', 'templatrail' );
		}
		if ( 'check' === $status ) {
			return __( 'Check by hand', 'templatrail' );
		}
		return __( 'No use found', 'templatrail' );
	}

	/**
	 * Words for how a reference is made.
	 *
	 * @param string $kind Reference kind.
	 * @return string
	 */
	public static function how_label( $kind ) {
		$labels = array(
			'setting'     => __( 'template widget setting', 'templatrail' ),
			'shortcode'   => __( 'shortcode in content', 'templatrail' ),
			'block'       => __( 'template block', 'templatrail' ),
			'title'       => __( 'template chosen by its title', 'templatrail' ),
			'global'      => __( 'global widget', 'templatrail' ),
			'popup'       => __( 'popup link', 'templatrail' ),
			'component'   => __( 'Component instance', 'templatrail' ),
			'maintenance' => __( 'Maintenance Mode', 'templatrail' ),
		);
		return isset( $labels[ $kind ] ) ? $labels[ $kind ] : $kind;
	}

	/**
	 * One phrase for where a use sits, from the stored detail ("the [elementor-template] shortcode in the content"
	 * becomes "[elementor-template] shortcode in the content"). The kind label is not added in front: the detail already says it.
	 *
	 * @param string $detail Stored detail.
	 * @return string
	 */
	public static function use_phrase( $detail ) {
		$text = trim( (string) $detail );
		$text = (string) preg_replace( '/^the (?=\[|"|“)/i', '', $text );
		if ( '' === $text ) {
			return $text;
		}
		// The last two words stay together, so a phrase never ends a line with one word.
		$text = (string) preg_replace( '/ (\S+)$/u', "\u{00A0}$1", $text );
		return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 ) : ucfirst( $text );
	}

	/**
	 * A post's title exactly as saved (get_the_title() runs WordPress's typographic filter and adds "Private:").
	 *
	 * @param int $id Post ID.
	 * @return string
	 */
	public static function raw_title( $id ) {
		$post = get_post( (int) $id );
		return $post ? (string) $post->post_title : '';
	}

	/**
	 * Every saved template and Component that is not in the Trash, by ID.
	 *
	 * @return array id => array( id, title, type, type_label, status, post_type, is_component ).
	 */
	public function templates() {
		global $wpdb;
		if ( null !== $this->templates ) {
			return $this->templates;
		}
		$rows = $wpdb->get_results(
			"SELECT ID, post_title, post_status, post_type FROM {$wpdb->posts} WHERE post_type IN ('elementor_library', 'elementor_component') AND post_status NOT IN ('trash', 'auto-draft', 'inherit') ORDER BY post_title ASC, ID ASC"
		);
		$ids  = wp_list_pluck( (array) $rows, 'ID' );
		if ( $ids ) {
			update_meta_cache( 'post', $ids );
		}
		$this->templates = array();
		foreach ( (array) $rows as $row ) {
			$id   = (int) $row->ID;
			$type = 'elementor_component' === $row->post_type ? 'component' : (string) get_post_meta( $id, '_elementor_template_type', true );
			if ( 'kit' === $type ) {
				continue;
			}
			$this->templates[ $id ] = array(
				'id'           => $id,
				'title'        => '' !== trim( $row->post_title ) ? $row->post_title : __( '(no title)', 'templatrail' ),
				'type'         => $type,
				'type_label'   => self::type_label( $type ),
				'status'       => $row->post_status,
				'post_type'    => $row->post_type,
				'is_component' => 'elementor_component' === $row->post_type,
			);
		}
		return $this->templates;
	}

	/**
	 * Titles of the saved templates and Components that are not in the Trash, lower case, with the IDs that carry each.
	 * Some add-ons store a template's title instead of its ID.
	 *
	 * @return array title => int[]
	 */
	public static function title_map() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type IN ('elementor_library', 'elementor_component') AND post_status NOT IN ('trash', 'auto-draft', 'inherit') AND post_title <> ''" );
		$map  = array();
		foreach ( (array) $rows as $row ) {
			$raw = trim( $row->post_title );
			foreach ( array( $raw, trim( html_entity_decode( $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) as $title ) {
				$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title, 'UTF-8' ) : strtolower( $title );
				if ( '' !== $key && ( ! isset( $map[ $key ] ) || ! in_array( (int) $row->ID, $map[ $key ], true ) ) ) {
					$map[ $key ][] = (int) $row->ID;
				}
			}
		}
		return $map;
	}

	/**
	 * Post rows for a list of IDs, cached.
	 *
	 * @param int[] $ids Post IDs.
	 */
	private function load_posts( array $ids ) {
		global $wpdb;
		$need = array();
		foreach ( $ids as $id ) {
			if ( ! array_key_exists( (int) $id, $this->posts ) ) {
				$need[ (int) $id ] = (int) $id;
			}
		}
		foreach ( array_chunk( array_values( $need ), 500 ) as $chunk ) {
			$rows = $wpdb->get_results( "SELECT ID, post_title, post_status, post_type FROM {$wpdb->posts} WHERE ID IN (" . implode( ',', array_map( 'intval', $chunk ) ) . ')' );
			foreach ( (array) $rows as $row ) {
				$this->posts[ (int) $row->ID ] = $row;
			}
			foreach ( $chunk as $id ) {
				if ( ! isset( $this->posts[ $id ] ) ) {
					$this->posts[ $id ] = false;
				}
			}
		}
	}

	/**
	 * One post row (or null when the post does not exist).
	 *
	 * @param int $id Post ID.
	 * @return object|null
	 */
	public function post( $id ) {
		$this->load_posts( array( $id ) );
		return $this->posts[ (int) $id ] ? $this->posts[ (int) $id ] : null;
	}

	/**
	 * Stored rows that point at a template.
	 *
	 * @param int  $target   Template ID.
	 * @param bool $mentions True for the unrecognized mentions, false for recognized references.
	 * @return array
	 */
	public function rows_for( $target, $mentions = false ) {
		global $wpdb;
		$operator = $mentions ? '=' : '<>';
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT source_type, source_id, source_key, kind, detail FROM {$this->table} WHERE target_id = %d AND kind {$operator} 'mention' ORDER BY id ASC", $target )
		);
	}

	/**
	 * A place that holds references: post or option, with its words and links.
	 *
	 * @param object $row A stored row.
	 * @return array|null Null when the source is gone or in the Trash.
	 */
	private function place_from_row( $row ) {
		if ( 'option' === $row->source_type ) {
			return $this->option_place( $row->source_key );
		}
		$post = $this->post( (int) $row->source_id );
		if ( ! $post || 'trash' === $post->post_status ) {
			return null;
		}
		$is_template = in_array( $post->post_type, self::POST_TYPES, true );
		$type_label  = $this->post_type_label( $post );
		$edit        = self::edit_link( (int) $post->ID, $post->post_type );
		return array(
			'key'          => 'p:' . $post->ID,
			'id'           => (int) $post->ID,
			'title'        => '' !== trim( $post->post_title ) ? $post->post_title : __( '(no title)', 'templatrail' ),
			'type_label'   => $type_label,
			'status'       => $post->post_status,
			'status_label' => self::status_label( $post->post_status ),
			'is_template'  => $is_template,
			'edit_url'     => $edit['url'],
			'edit_label'   => $edit['label'],
			'uses'         => array(),
		);
	}

	/**
	 * Label for a source post's type.
	 *
	 * @param object $post Post row.
	 * @return string
	 */
	private function post_type_label( $post ) {
		if ( 'elementor_component' === $post->post_type ) {
			return __( 'Component', 'templatrail' );
		}
		if ( 'elementor_library' === $post->post_type ) {
			/* translators: %s: template type such as Section or Popup. */
			return sprintf( __( 'Template (%s)', 'templatrail' ), strtolower( self::type_label( (string) get_post_meta( $post->ID, '_elementor_template_type', true ) ) ) );
		}
		$object = get_post_type_object( $post->post_type );
		return $object && ! empty( $object->labels->singular_name ) ? $object->labels->singular_name : $post->post_type;
	}

	/**
	 * The edit link of a post: Edit with Elementor when it is built with Elementor.
	 *
	 * @param int    $post_id   Post ID.
	 * @param string $post_type Post type.
	 * @return array url and label.
	 */
	public static function edit_link( $post_id, $post_type ) {
		$builder = in_array( $post_type, self::POST_TYPES, true ) || 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true );
		if ( $builder ) {
			return array(
				'url'   => add_query_arg(
					array(
						'post'   => $post_id,
						'action' => 'elementor',
					),
					admin_url( 'post.php' )
				),
				'label' => __( 'Edit with Elementor', 'templatrail' ),
			);
		}
		$url = get_edit_post_link( $post_id, 'raw' );
		return array(
			'url'   => $url ? $url : '',
			'label' => __( 'Edit', 'templatrail' ),
		);
	}

	/**
	 * Point a place's edit link at the editor where its reference can be changed: Elementor when the reference is in
	 * Elementor's data (or the place is a template), the ordinary editor when it is in the post's content, excerpt or a custom field.
	 * A place read from an older scan has no field recorded and keeps the link edit_link() chose.
	 *
	 * @param array $place A place with an optional 'fields' list.
	 * @return array The place without 'fields'.
	 */
	private static function edit_where_it_sits( array $place ) {
		$fields = isset( $place['fields'] ) ? $place['fields'] : array();
		unset( $place['fields'] );
		if ( ! $fields || ! empty( $place['is_template'] ) || empty( $place['id'] ) || isset( $fields['elementor'] ) ) {
			return $place;
		}
		$url = get_edit_post_link( (int) $place['id'], 'raw' );
		if ( $url ) {
			$place['edit_url']   = $url;
			$place['edit_label'] = __( 'Edit', 'templatrail' );
		}
		return $place;
	}

	/**
	 * A place made from a site option (a widget, Maintenance Mode).
	 *
	 * @param string $source_key maintenance, widget_text:3, widget_block:5, opt:name.
	 * @return array|null
	 */
	private function option_place( $source_key ) {
		if ( 'maintenance' === $source_key ) {
			return array(
				'key'          => 'o:maintenance',
				'id'           => 0,
				'title'        => __( 'Maintenance Mode', 'templatrail' ),
				'type_label'   => __( 'Elementor setting', 'templatrail' ),
				'status'       => 'option',
				'status_label' => __( 'Setting', 'templatrail' ),
				'is_template'  => false,
				'edit_url'     => admin_url( 'admin.php?page=elementor-tools#tab-maintenance_mode' ),
				'edit_label'   => __( 'Open the setting', 'templatrail' ),
				'uses'         => array(),
			);
		}
		if ( 0 === strpos( $source_key, 'opt:' ) ) {
			return array(
				'key'          => 'o:' . $source_key,
				'id'           => 0,
				'title'        => substr( $source_key, 4 ),
				'type_label'   => __( 'Site setting', 'templatrail' ),
				'status'       => 'option',
				'status_label' => __( 'Setting', 'templatrail' ),
				'is_template'  => false,
				'edit_url'     => '',
				'edit_label'   => '',
				'uses'         => array(),
			);
		}
		$parts = explode( ':', $source_key );
		if ( 2 !== count( $parts ) ) {
			return null;
		}
		$number    = (int) $parts[1];
		$instances = get_option( $parts[0] );
		if ( ! is_array( $instances ) || ! isset( $instances[ $number ] ) ) {
			return null;
		}
		$instance = $instances[ $number ];
		$base     = str_replace( 'widget_', '', $parts[0] );
		$kinds    = array(
			'text'        => __( 'Text widget', 'templatrail' ),
			'custom_html' => __( 'Custom HTML widget', 'templatrail' ),
			'block'       => __( 'Block widget', 'templatrail' ),
		);
		$title    = isset( $instance['title'] ) && '' !== $instance['title'] ? $instance['title'] : $kinds[ $base ] . ' ' . $number;
		$sidebar  = $this->widget_sidebar( $base . '-' . $number );
		$screen   = self::widgets_screen_url();
		if ( '' === $screen ) {
			$sidebar = __( 'The active theme has no widget areas', 'templatrail' );
		}
		return array(
			'key'          => 'o:' . $source_key,
			'id'           => 0,
			'title'        => $title,
			'type_label'   => isset( $kinds[ $base ] ) ? $kinds[ $base ] : $base,
			'status'       => 'widget',
			'status_label' => '' !== $sidebar ? $sidebar : __( 'Not in a widget area', 'templatrail' ),
			'is_template'  => false,
			'edit_url'     => $screen,
			'edit_label'   => '' !== $screen ? __( 'Edit', 'templatrail' ) : '',
			'uses'         => array(),
		);
	}

	/**
	 * Address of the Widgets screen, or an empty string when the active theme has no widget areas
	 * (WordPress then answers that screen with an error, so no link is offered).
	 *
	 * @return string
	 */
	public static function widgets_screen_url() {
		global $wp_registered_sidebars;
		return empty( $wp_registered_sidebars ) ? '' : admin_url( 'widgets.php' );
	}

	/**
	 * Name of the widget area a widget sits in, or an empty string.
	 *
	 * @param string $widget_id Such as text-3.
	 * @return string
	 */
	private function widget_sidebar( $widget_id ) {
		global $wp_registered_sidebars;
		$sidebars = get_option( 'sidebars_widgets' );
		if ( ! is_array( $sidebars ) ) {
			return '';
		}
		foreach ( $sidebars as $sidebar => $widgets ) {
			if ( is_array( $widgets ) && in_array( $widget_id, $widgets, true ) && 'wp_inactive_widgets' !== $sidebar && 'array_version' !== $sidebar ) {
				return isset( $wp_registered_sidebars[ $sidebar ]['name'] ) ? $wp_registered_sidebars[ $sidebar ]['name'] : $sidebar;
			}
		}
		return '';
	}

	/**
	 * Every place that uses a template, with how.
	 *
	 * A template inside another template is reported as "inside template X",
	 * and the pages that show X are reported too. A loop is stopped and recorded.
	 *
	 * @param int $target Template ID.
	 * @return array places keyed by place key.
	 */
	public function places( $target ) {
		$places = array();
		$this->collect( (int) $target, (int) $target, array( (int) $target ), 0, $places );
		foreach ( $places as $key => $place ) {
			$places[ $key ] = self::edit_where_it_sits( $place );
		}
		return $places;
	}

	/**
	 * Recursive part of places().
	 *
	 * @param int   $origin Template whose places are wanted.
	 * @param int   $current Template whose direct references are read now.
	 * @param array $chain  Templates already passed on this route.
	 * @param int   $via    First template that holds the origin (0 at the top).
	 * @param array $places Collected places.
	 */
	private function collect( $origin, $current, array $chain, $via, array &$places ) {
		if ( count( $chain ) > 25 ) {
			return;
		}
		$rows = $this->rows_for( $current );
		$ids  = array();
		foreach ( $rows as $row ) {
			if ( 'post' === $row->source_type ) {
				$ids[] = (int) $row->source_id;
			}
		}
		$this->load_posts( $ids );
		foreach ( $rows as $row ) {
			$source_id = 'post' === $row->source_type ? (int) $row->source_id : 0;
			if ( $source_id && $source_id === $current ) {
				$this->add_loop( array( $current, $current ) );
				continue;
			}
			if ( $source_id && in_array( $source_id, $chain, true ) ) {
				$this->add_loop( array_merge( array_slice( $chain, array_search( $source_id, $chain, true ) ), array( $source_id ) ) );
				continue;
			}
			$place = $this->place_from_row( $row );
			if ( null === $place ) {
				continue;
			}
			$holder = $via;
			if ( $place['is_template'] ) {
				if ( 0 === $holder ) {
					$holder = $source_id;
				}
			}
			if ( ! isset( $places[ $place['key'] ] ) ) {
				$places[ $place['key'] ] = $place;
			}
			if ( $holder ) {
				$use = array(
					'how'    => sprintf(
						/* translators: %s: title of the template that holds this one. */
						__( 'inside template %s', 'templatrail' ),
						$this->title_of( $holder )
					),
					'via'    => $holder,
					'detail' => $source_id === $holder ? $row->detail : sprintf(
						/* translators: %s: title of the template that holds this one. */
						__( 'shows the template “%s”, which holds this one', 'templatrail' ),
						$this->title_of( $holder )
					),
				);
			} else {
				$use = array(
					'how'    => self::how_label( $row->kind ),
					'via'    => 0,
					'detail' => $row->detail,
				);
			}
			$use['kind'] = $row->kind;
			$places[ $place['key'] ]['uses'][ $use['how'] . '|' . $use['detail'] ] = $use;
			if ( 'post' === $row->source_type && '' !== (string) $row->source_key ) {
				$places[ $place['key'] ]['fields'][ (string) $row->source_key ] = true;
			}

			if ( $place['is_template'] ) {
				$this->collect( $origin, $source_id, array_merge( $chain, array( $source_id ) ), $holder, $places );
			}
		}
	}

	/**
	 * Title of a template for messages.
	 *
	 * @param int $id Post ID.
	 * @return string
	 */
	private function title_of( $id ) {
		$post = $this->post( $id );
		return $post && '' !== trim( $post->post_title ) ? $post->post_title : '#' . $id;
	}

	/**
	 * Remember a loop of templates.
	 *
	 * @param int[] $chain Template IDs, first equal to last.
	 */
	private function add_loop( array $chain ) {
		$body                                 = array_slice( $chain, 0, -1 );
		$min                                  = min( $body );
		$pos                                  = array_search( $min, $body, true );
		$body                                 = array_merge( array_slice( $body, $pos ), array_slice( $body, 0, $pos ) );
		$this->loops[ implode( '>', $body ) ] = $body;
	}

	/**
	 * Loops seen so far.
	 *
	 * @return array
	 */
	public function loops() {
		return array_values( $this->loops );
	}

	/**
	 * Whether a template has Elementor Pro display conditions.
	 *
	 * @param int $id Template ID.
	 * @return string[] The conditions, empty when none.
	 */
	public function conditions( $id ) {
		$conditions = get_post_meta( $id, '_elementor_conditions', true );
		if ( is_array( $conditions ) ) {
			return array_values( array_filter( array_map( 'strval', $conditions ) ) );
		}
		return is_string( $conditions ) && '' !== $conditions ? array( $conditions ) : array();
	}

	/**
	 * Whether a template had "No use found" in the stored scan. Only the live report is judged this way.
	 *
	 * @param int $id Template ID.
	 * @return bool
	 */
	public static function holder_unused( $id ) {
		$summary = Templatrail_Scan::summary();
		return null !== $summary && isset( $summary['templates'][ $id ] ) && 'none' === $summary['templates'][ $id ]['s'];
	}

	/**
	 * Titles of the templates that hold this one when every use of it is inside a template with no use found.
	 *
	 * @param array $places Places of the template.
	 * @return string[] Empty when some use is direct or inside a template that has a use.
	 */
	private function only_inside_unused( array $places ) {
		if ( Templatrail_Store::live_table() !== $this->table ) {
			return array();
		}
		$holders = array();
		foreach ( $places as $place ) {
			foreach ( $place['uses'] as $use ) {
				if ( empty( $use['via'] ) || ! self::holder_unused( (int) $use['via'] ) ) {
					return array();
				}
				$holders[ (int) $use['via'] ] = $this->title_of( (int) $use['via'] );
			}
		}
		return array_values( $holders );
	}

	/**
	 * Titles of the posts in the Trash that point at a template (the scan reads them for this line only).
	 *
	 * @param int $id Template ID.
	 * @return string[]
	 */
	private function trashed_holders( $id ) {
		$rows = $this->rows_for( $id );
		$ids  = array();
		foreach ( $rows as $row ) {
			if ( 'post' === $row->source_type && (int) $row->source_id !== (int) $id ) {
				$ids[] = (int) $row->source_id;
			}
		}
		$this->load_posts( $ids );
		$titles = array();
		foreach ( $ids as $source ) {
			$post = $this->post( $source );
			if ( $post && 'trash' === $post->post_status ) {
				$titles[ $source ] = '' !== trim( $post->post_title ) ? $post->post_title : '#' . $source;
			}
		}
		return array_values( $titles );
	}

	/**
	 * Status and reasons for one template.
	 *
	 * @param int        $id     Template ID.
	 * @param array|null $places Places if already known.
	 * @return array status (used, none, check), places (count), reasons (words), by_hand (list of where mentions sit).
	 */
	public function assess( $id, $places = null ) {
		if ( null === $places ) {
			$places = $this->places( $id );
		}
		$reasons = array();
		$check   = false;

		$conditions = $this->conditions( $id );
		if ( $conditions ) {
			$check     = true;
			$reasons[] = sprintf(
				/* translators: %s: list of Elementor Pro display conditions. */
				__( 'It has Elementor Pro display conditions (%s), which Templatrail does not judge.', 'templatrail' ),
				implode( ', ', $conditions )
			);
		}

		$is_maintenance = false;
		foreach ( $places as $place ) {
			foreach ( $place['uses'] as $use ) {
				if ( 'maintenance' === $use['kind'] ) {
					$is_maintenance = true;
				}
			}
		}
		if ( $is_maintenance ) {
			$check     = true;
			$reasons[] = __( 'It is the Maintenance Mode template.', 'templatrail' );
		}

		$mentions = array();
		foreach ( $this->rows_for( $id, true ) as $row ) {
			if ( 'post' === $row->source_type ) {
				$post = $this->post( (int) $row->source_id );
				if ( ! $post || 'trash' === $post->post_status || (int) $post->ID === (int) $id ) {
					continue;
				}
				$holder = trim( $post->post_title );
				if ( '' === $holder ) {
					$holder = '#' . $post->ID;
				}
				$where = sprintf(
					/* translators: 1: where the ID appears, 2: title of the post that holds it. */
					__( '%1$s, in “%2$s”', 'templatrail' ),
					$row->detail,
					$holder
				);
			} else {
				$where = $row->detail;
			}
			$mentions[ $where ] = $where;
		}
		if ( $mentions ) {
			$check     = true;
			$reasons[] = __( 'Its ID also appears in a form Templatrail does not recognize:', 'templatrail' ) . ' ' . implode( '; ', array_slice( array_values( $mentions ), 0, 5 ) ) . ( count( $mentions ) > 5 ? '…' : '' );
		}

		$count = count( $places );
		if ( ! $check && $count > 0 ) {
			$holders = $this->only_inside_unused( $places );
			if ( $holders ) {
				$quoted    = array_map(
					static function ( $title ) {
						return '“' . $title . '”';
					},
					array_slice( $holders, 0, 5 )
				);
				$reasons[] = sprintf(
					/* translators: %s: titles of the templates that hold this one. */
					__( 'It is only used inside templates that have no use found themselves: %s.', 'templatrail' ),
					implode( ', ', $quoted ) . ( count( $holders ) > 5 ? '…' : '' )
				);
			}
		}
		if ( ! $check && 0 === $count ) {
			$trashed = $this->trashed_holders( $id );
			if ( $trashed ) {
				$quoted    = array_map(
					static function ( $title ) {
						return '“' . $title . '”';
					},
					array_slice( $trashed, 0, 5 )
				);
				$reasons[] = sprintf(
					/* translators: %s: titles of the pages in the Trash that point at this template. */
					__( 'Only used by %s, which is in the Trash. Restoring it would bring the use back.', 'templatrail' ),
					implode( ', ', $quoted ) . ( count( $trashed ) > 5 ? '…' : '' )
				);
			}
		}
		if ( $check ) {
			$status = 'check';
		} elseif ( $count > 0 ) {
			$status = 'used';
		} else {
			$status = 'none';
		}
		return array(
			'status'  => $status,
			'places'  => $count,
			'reasons' => $reasons,
			'by_hand' => array_values( $mentions ),
		);
	}

	/**
	 * Summary of every template: status and number of places. Also collects loops.
	 *
	 * @param int[]|null $only Limit to these IDs.
	 * @return array id => array( s, n )
	 */
	public function summarise( $only = null ) {
		$out = array();
		foreach ( $this->templates() as $id => $template ) {
			if ( null !== $only && ! in_array( $id, $only, true ) ) {
				continue;
			}
			$places     = $this->places( $id );
			$assess     = $this->assess( $id, $places );
			$out[ $id ] = array(
				's' => $assess['status'],
				'n' => $assess['places'],
			);
		}
		return $out;
	}

	/**
	 * References that point at a template that does not exist or is in the Trash.
	 *
	 * @return array Each: place, target (id), state (deleted|trash), target_title, detail, kind.
	 */
	public function missing() {
		global $wpdb;
		$targets = $wpdb->get_col( "SELECT DISTINCT target_id FROM {$this->table} WHERE kind <> 'mention'" );
		$this->load_posts( array_map( 'intval', (array) $targets ) );
		$bad = array();
		foreach ( (array) $targets as $target ) {
			$target = (int) $target;
			$post   = $this->post( $target );
			if ( ! $post ) {
				$bad[ $target ] = 'deleted';
			} elseif ( in_array( $post->post_type, self::POST_TYPES, true ) && 'trash' === $post->post_status ) {
				$bad[ $target ] = 'trash';
			}
		}
		$out = array();
		foreach ( $bad as $target => $state ) {
			foreach ( $this->rows_for( $target ) as $row ) {
				if ( 'post' === $row->source_type && (int) $row->source_id === $target ) {
					continue;
				}
				if ( 'post' === $row->source_type ) {
					$this->load_posts( array( (int) $row->source_id ) );
				}
				$place = $this->place_from_row( $row );
				if ( null === $place ) {
					continue;
				}
				if ( 'post' === $row->source_type && '' !== (string) $row->source_key ) {
					$place['fields'] = array( (string) $row->source_key => true );
				}
				$place = self::edit_where_it_sits( $place );
				$post  = $this->post( $target );
				$out[] = array(
					'place'        => $place,
					'target'       => $target,
					'state'        => $state,
					'target_title' => $post ? $post->post_title : '',
					'detail'       => $row->detail,
					'kind'         => $row->kind,
				);
			}
		}
		return $out;
	}
}
