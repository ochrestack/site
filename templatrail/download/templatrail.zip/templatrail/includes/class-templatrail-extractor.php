<?php
/**
 * Finds references to saved templates and Components inside one post, one
 * option or one block of text.
 *
 * Nothing here writes anything. A reference is an array:
 *   kind   setting | shortcode | block | title | global | popup | component | maintenance | mention
 *   target template ID the reference points at
 *   detail where it sits, in words
 *   field  'content' (post content), 'excerpt' (post excerpt), 'meta' (a custom field), 'elementor' (_elementor_data) or 'option'
 *   path   for 'elementor': the keys that lead to the value inside the decoded data
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reference finder.
 */
class Templatrail_Extractor {

	/**
	 * Shortcode tags that place a saved template by id.
	 *
	 * @var string[]
	 */
	const SHORTCODES = array( 'elementor-template', 'AETS_Template', 'UltraAddons_Template', 'UA_Template', 'ULTRAADDONS_TEMPLATE' );

	/**
	 * Attribute names that hold sizes, counts and positions, never a template.
	 *
	 * @var string
	 */
	const IGNORED_NAMES = '/^(?:id|_id|(?:.*[_-])?(?:size|sizes|width|height|top|right|bottom|left|columns|count|order|index|offset|delay|speed|duration|opacity|gap|radius|spacing|rows|limit|zindex|z_index|number))(?:_(?:tablet|mobile|widescreen|laptop|tablet_extra|mobile_extra))?$/i';

	/**
	 * IDs of existing saved templates and Components (id => true). Only these can be "mentioned".
	 *
	 * @var array
	 */
	private $known;

	/**
	 * Titles of saved templates, lower case: title => template IDs. Some add-ons (Premium Addons) store the title, not the ID.
	 *
	 * @var array
	 */
	private $titles;

	/**
	 * Post meta keys that never hold a template reference (and can be very large).
	 *
	 * @var string
	 */
	const SKIPPED_META = '/^(?:_edit_lock|_edit_last|_wp_|_thumbnail_id|_oembed|_menu_item|_elementor_)/';

	/**
	 * Setting names that hold visible text, where a value equal to a template's title is only text.
	 *
	 * @var string
	 */
	const TEXT_NAMES = '/(?:^|_)(?:title|editor|text|description|caption|heading|subtitle|label|alt|placeholder|name|html|content)$/i';

	/**
	 * Constructor.
	 *
	 * @param array $known  Existing template and Component IDs as keys.
	 * @param array $titles Lower-case title => IDs (see Templatrail_Report::title_map()).
	 */
	public function __construct( array $known = array(), array $titles = array() ) {
		$this->known  = $known;
		$this->titles = $titles;
	}

	/**
	 * Every reference in one post.
	 *
	 * @param int    $post_id      Post ID.
	 * @param string $post_content The post's content.
	 * @param string $post_excerpt The post's excerpt (WooCommerce shows a product's short description from it).
	 * @return array
	 */
	public function extract_post( $post_id, $post_content, $post_excerpt = '' ) {
		$refs = array();

		$this->scan_text( (string) $post_content, 'content', array(), 'the content', $refs, $post_id );
		$this->scan_text( (string) $post_excerpt, 'excerpt', array(), 'the excerpt', $refs, $post_id );
		$this->scan_meta( $post_id, $refs );

		$raw = get_post_meta( $post_id, '_elementor_data', true );
		if ( is_string( $raw ) && '' !== $raw ) {
			$data = json_decode( $raw, true );
			if ( is_array( $data ) ) {
				$this->walk_elements( $data, array(), $refs, $post_id );
			} else {
				$this->scan_text( $raw, 'elementor', array(), 'Elementor data', $refs, $post_id );
			}
		} elseif ( is_array( $raw ) ) {
			$this->walk_elements( $raw, array(), $refs, $post_id );
		}

		return $this->mark_render_copies( $this->unique( $refs ) );
	}

	/**
	 * A page built with Elementor keeps a rendered copy of its content in post_content, so a shortcode in a Shortcode
	 * widget is found twice: in Elementor's data and in the post content. The copy is flagged ('copy' => true) so the scan
	 * stores one use, not two; Pro's Replace still rewrites both.
	 *
	 * @param array $refs References of one post.
	 * @return array
	 */
	private function mark_render_copies( array $refs ) {
		$in_data = array();
		foreach ( $refs as $ref ) {
			if ( 'elementor' === $ref['field'] && isset( $ref['what'] ) ) {
				$in_data[ $ref['kind'] . '|' . $ref['target'] . '|' . $ref['what'] ] = true;
			}
		}
		foreach ( $refs as $index => $ref ) {
			if ( 'content' === $ref['field'] && isset( $ref['what'] ) && isset( $in_data[ $ref['kind'] . '|' . $ref['target'] . '|' . $ref['what'] ] ) ) {
				$refs[ $index ]['copy'] = true;
			}
			unset( $refs[ $index ]['what'] );
		}
		return $refs;
	}

	/**
	 * Custom fields (post meta) other than Elementor's own data: shortcodes and blocks in their text,
	 * and a template ID in a field whose name says "template".
	 *
	 * @param int   $post_id Post ID.
	 * @param array $refs    Collected references.
	 */
	private function scan_meta( $post_id, array &$refs ) {
		$meta = get_post_meta( $post_id );
		if ( ! is_array( $meta ) ) {
			return;
		}
		foreach ( $meta as $key => $values ) {
			if ( preg_match( self::SKIPPED_META, (string) $key ) ) {
				continue;
			}
			foreach ( (array) $values as $value ) {
				if ( ! is_string( $value ) || strlen( $value ) > 500000 ) {
					continue;
				}
				$where = 'the custom field “' . $key . '”';
				$this->scan_text( $value, 'meta', array( (string) $key ), $where, $refs, $post_id );
				if ( ! empty( $this->known ) && false !== stripos( (string) $key, 'template' ) ) {
					$id = $this->numeric( trim( $value ) );
					if ( $id && $id !== (int) $post_id && isset( $this->known[ $id ] ) ) {
						$refs[] = array(
							'kind'   => 'mention',
							'target' => $id,
							'detail' => $where,
							'field'  => 'meta',
							'path'   => array( (string) $key ),
						);
					}
				}
			}
		}
	}

	/**
	 * Every string inside an option value (arrays, objects and JSON text are opened).
	 *
	 * @param mixed $value Value.
	 * @param int   $depth Depth.
	 * @return string[]
	 */
	private function strings_in( $value, $depth = 0 ) {
		if ( $depth > 8 ) {
			return array();
		}
		if ( is_object( $value ) ) {
			$value = get_object_vars( $value );
		}
		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $child ) {
				$out = array_merge( $out, $this->strings_in( $child, $depth + 1 ) );
			}
			return $out;
		}
		if ( ! is_string( $value ) || strlen( $value ) < 4 || strlen( $value ) > 500000 ) {
			return array();
		}
		if ( '{' === $value[0] || '[' === $value[0] ) {
			$decoded = json_decode( $value, true );
			if ( is_array( $decoded ) ) {
				return array_merge( array( $value ), $this->strings_in( $decoded, $depth + 1 ) );
			}
		}
		return array( $value );
	}

	/**
	 * References held in site options: widgets, Maintenance Mode, Elementor's own options, any option that holds a template shortcode.
	 *
	 * @return array Each with source_key.
	 */
	public function extract_options() {
		global $wpdb;
		$out = array();

		$maintenance = get_option( 'elementor_maintenance_mode_template_id' );
		$id          = $this->numeric( $maintenance );
		if ( $id ) {
			$mode   = get_option( 'elementor_maintenance_mode_mode' );
			$detail = 'maintenance' === $mode ? 'Maintenance mode is on' : ( 'coming_soon' === $mode ? 'Coming Soon mode is on' : 'the mode is switched off, the template is still chosen' );
			$out[]  = array(
				'kind'       => 'maintenance',
				'target'     => $id,
				'detail'     => $detail,
				'field'      => 'option',
				'path'       => array(),
				'source_key' => 'maintenance',
			);
		}

		$widget_options = array(
			'widget_text'        => 'text',
			'widget_custom_html' => 'content',
			'widget_block'       => 'content',
		);
		foreach ( $widget_options as $option => $field ) {
			$instances = get_option( $option );
			if ( ! is_array( $instances ) ) {
				continue;
			}
			foreach ( $instances as $number => $instance ) {
				if ( ! is_int( $number ) || ! is_array( $instance ) || ! isset( $instance[ $field ] ) || ! is_string( $instance[ $field ] ) ) {
					continue;
				}
				$refs = array();
				$this->scan_text( $instance[ $field ], 'option', array(), 'a widget in Appearance > Widgets', $refs, 0 );
				foreach ( $this->unique( $refs ) as $ref ) {
					$ref['source_key'] = $option . ':' . $number;
					$out[]             = $ref;
				}
			}
		}

		// Any other option that holds a template shortcode or template block (a theme or plugin setting).
		$needles = array_merge( self::SHORTCODES, array( 'wp:elementor/template' ) );
		$likes   = array();
		foreach ( $needles as $needle ) {
			$likes[] = $wpdb->prepare( 'option_value LIKE %s', '%' . $wpdb->esc_like( $needle ) . '%' );
		}
		$holders = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE (" . implode( ' OR ', $likes ) . ") AND option_name NOT LIKE '\\_transient%' AND option_name NOT LIKE '\\_site\\_transient%' AND option_name NOT LIKE 'templatrail\\_%' AND option_name NOT IN ('widget_text', 'widget_custom_html', 'widget_block') ORDER BY option_name ASC LIMIT 300" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- every LIKE term above went through prepare()
		foreach ( (array) $holders as $name ) {
			$refs = array();
			foreach ( $this->strings_in( get_option( $name ) ) as $text ) {
				$this->scan_text( $text, 'option', array(), 'the setting “' . $name . '”', $refs, 0 );
			}
			foreach ( $this->unique( $refs ) as $ref ) {
				$ref['source_key'] = 'opt:' . $name;
				$out[]             = $ref;
			}
		}

		if ( ! empty( $this->known ) ) {
			$names = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'elementor\\_%' AND option_name NOT LIKE '%transient%' LIMIT 500" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			foreach ( (array) $names as $name ) {
				if ( preg_match( '/^elementor_(?:maintenance_mode_template_id|active_kit|pro_theme_builder_conditions|log|pro_license|connect|remote|install|events|version|.*(?:viewport|container_width|space_between|stretched|breakpoint|css|font|color|time|count|checked|history|license|token|_at$))/i', $name ) ) {
					continue;
				}
				$value = get_option( $name );
				if ( is_string( $value ) ) {
					$value = maybe_unserialize( $value );
				}
				$found = array();
				$this->find_numbers( $value, $name, $found );
				foreach ( $found as $target ) {
					$out[] = array(
						'kind'       => 'mention',
						'target'     => $target,
						'detail'     => 'the option "' . $name . '"',
						'field'      => 'option',
						'path'       => array(),
						'source_key' => 'opt:' . $name,
					);
				}
			}
		}

		return $out;
	}

	/**
	 * Numbers in an option value that equal a known template ID.
	 *
	 * @param mixed  $value Option value.
	 * @param string $name  Name of the nearest key.
	 * @param array  $found Collected IDs.
	 * @param int    $depth Recursion depth.
	 */
	private function find_numbers( $value, $name, array &$found, $depth = 0 ) {
		if ( $depth > 8 ) {
			return;
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $child ) {
				$this->find_numbers( $child, is_string( $key ) ? $key : $name, $found, $depth + 1 );
			}
			return;
		}
		$id = $this->numeric( $value );
		if ( $id && isset( $this->known[ $id ] ) && ! preg_match( self::IGNORED_NAMES, $name ) ) {
			$found[ $id ] = $id;
		}
	}

	/**
	 * Walk a list of Elementor elements.
	 *
	 * @param array $elements Elements.
	 * @param array $path     Keys leading to this list.
	 * @param array $refs     Collected references.
	 * @param int   $post_id  Post being read (a template never "mentions" itself).
	 * @param int   $depth    Recursion depth.
	 */
	private function walk_elements( array $elements, array $path, array &$refs, $post_id, $depth = 0 ) {
		if ( $depth > 60 ) {
			return;
		}
		foreach ( $elements as $index => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			$here   = array_merge( $path, array( $index ) );
			$widget = isset( $element['widgetType'] ) && is_string( $element['widgetType'] ) ? $element['widgetType'] : '';
			$label  = $this->widget_label( $widget, isset( $element['elType'] ) && is_string( $element['elType'] ) ? $element['elType'] : '' );

			if ( isset( $element['templateID'] ) ) {
				$id = $this->numeric( $element['templateID'] );
				if ( $id ) {
					$refs[] = array(
						'kind'   => 'global',
						'target' => $id,
						'detail' => 'Global widget',
						'field'  => 'elementor',
						'path'   => array_merge( $here, array( 'templateID' ) ),
					);
				}
			}

			if ( isset( $element['settings'] ) && is_array( $element['settings'] ) ) {
				foreach ( $element['settings'] as $key => $value ) {
					$this->walk_value( $key, $value, '', $label, array_merge( $here, array( 'settings', $key ) ), $refs, $post_id, 0 );
				}
			}

			if ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$this->walk_elements( $element['elements'], array_merge( $here, array( 'elements' ) ), $refs, $post_id, $depth + 1 );
			}
		}
	}

	/**
	 * Walk one setting value.
	 *
	 * @param int|string $key       Key of this value.
	 * @param mixed      $value     The value.
	 * @param string     $inherited Name of a "template" setting this value sits under.
	 * @param string     $label     Widget label for messages.
	 * @param array      $path      Keys leading to this value.
	 * @param array      $refs      Collected references.
	 * @param int        $post_id   Post being read.
	 * @param int        $depth     Recursion depth.
	 */
	private function walk_value( $key, $value, $inherited, $label, array $path, array &$refs, $post_id, $depth ) {
		if ( $depth > 40 ) {
			return;
		}

		// Elementor's typed values: { "$$type": "number", "value": 12 }.
		if ( is_array( $value ) && isset( $value['$$type'] ) && array_key_exists( 'value', $value ) ) {
			$this->walk_value( $key, $value['value'], $inherited, $label, array_merge( $path, array( 'value' ) ), $refs, $post_id, $depth + 1 );
			return;
		}

		$name = is_string( $key ) ? $key : $inherited;

		if ( is_array( $value ) ) {
			$next_inherited = ( is_string( $key ) && false !== stripos( $key, 'template' ) ) ? $key : $inherited;
			foreach ( $value as $child_key => $child ) {
				$this->walk_value( $child_key, $child, $next_inherited, $label, array_merge( $path, array( $child_key ) ), $refs, $post_id, $depth + 1 );
			}
			return;
		}

		$id = $this->numeric( $value );
		if ( $id ) {
			if ( is_string( $key ) && 'component_id' === strtolower( $key ) ) {
				$refs[] = array(
					'kind'   => 'component',
					'target' => $id,
					'detail' => 'Component instance',
					'field'  => 'elementor',
					'path'   => $path,
				);
				return;
			}
			$template_name = '';
			if ( is_string( $key ) && false !== stripos( $key, 'template' ) ) {
				$template_name = $key;
			} elseif ( '' !== $inherited && ( ! is_string( $key ) || in_array( strtolower( $key ), array( 'id', 'value' ), true ) ) ) {
				$template_name = $inherited;
			}
			if ( '' !== $template_name ) {
				$refs[] = array(
					'kind'   => 'setting',
					'target' => $id,
					'detail' => $this->setting_words( $label, $template_name ),
					'field'  => 'elementor',
					'path'   => $path,
				);
				return;
			}
			if ( $id !== (int) $post_id && isset( $this->known[ $id ] ) && ! preg_match( self::IGNORED_NAMES, (string) $name ) ) {
				$refs[] = array(
					'kind'   => 'mention',
					'target' => $id,
					'detail' => $label . ', setting "' . $name . '"',
					'field'  => 'elementor',
					'path'   => $path,
				);
			}
			return;
		}

		if ( is_string( $value ) && '' !== $value ) {
			$this->scan_text( $value, 'elementor', $path, $label, $refs, $post_id );
			$this->check_title( $name, $value, $label, $path, $refs, $post_id );
		}
	}

	/**
	 * Recognize shortcodes and popup tags in a piece of text, and mentions in forms we do not recognize.
	 *
	 * @param string $text    Text.
	 * @param string $field   'content', 'elementor' or 'option'.
	 * @param array  $path    Path of the string inside Elementor data.
	 * @param string $where   Words for where the text sits.
	 * @param array  $refs    Collected references.
	 * @param int    $post_id Post being read.
	 */
	private function scan_text( $text, $field, array $path, $where, array &$refs, $post_id ) {
		if ( strlen( $text ) < 4 ) {
			return;
		}
		if ( false !== strpos( $text, '\\"' ) ) {
			$text = str_replace( '\\"', '"', $text ); // Text kept inside JSON: [tag id=\"12\"].
		}
		$has_bracket = false !== strpos( $text, '[' );

		$this->scan_popup_actions( $text, $field, $path, $where, $refs );

		// Blocks: <!-- wp:elementor/template {"selectedTemplate":12} /--> and any block whose settings hold a template ID.
		if ( false !== strpos( $text, '<!--' ) && preg_match_all( '/<!--\s+wp:([a-z][a-z0-9_-]*(?:\/[a-z][a-z0-9_-]*)?)\s+(\{.*?\})\s+\/?-->/s', $text, $blocks, PREG_SET_ORDER ) ) {
			foreach ( $blocks as $block ) {
				$attrs = json_decode( $block[2], true );
				if ( is_array( $attrs ) ) {
					$this->walk_block( $block[1], '', $attrs, $field, $path, $where, $refs, $post_id, 0 );
				}
			}
		}

		if ( $has_bracket ) {
			$normal = $this->normalise_quotes( $text );

			// Template shortcodes.
			if ( preg_match( '/' . $this->tag_alternation() . '/', $normal ) ) {
				$regex = '/' . get_shortcode_regex( self::SHORTCODES ) . '/';
				if ( preg_match_all( $regex, $normal, $matches, PREG_SET_ORDER ) ) {
					foreach ( $matches as $m ) {
						if ( '[' === $m[1] && ']' === $m[6] ) {
							continue; // Escaped: [[tag]] prints the tag, it does not run it.
						}
						$atts = shortcode_parse_atts( $m[3] );
						if ( is_array( $atts ) && isset( $atts['id'] ) ) {
							$id = $this->numeric( trim( (string) $atts['id'] ) );
							if ( $id ) {
								$refs[] = array(
									'kind'   => 'shortcode',
									'target' => $id,
									'detail' => 'the [' . $m[2] . '] shortcode in ' . $where,
									'field'  => $field,
									'path'   => $path,
									'what'   => '[' . strtolower( $m[2] ) . ']',
								);
							}
						}
					}
				}
			}

			// Popup links: [elementor-tag id="…" name="popup" settings="%7B%22popup%22%3A%2212345%22%7D"].
			if ( false !== strpos( $normal, 'elementor-tag' ) && preg_match_all( '/\[elementor-tag\b([^\]]*)\]/', $normal, $tags, PREG_SET_ORDER ) ) {
				foreach ( $tags as $tag ) {
					$atts = shortcode_parse_atts( $tag[1] );
					if ( ! is_array( $atts ) || ! isset( $atts['name'], $atts['settings'] ) || 'popup' !== $atts['name'] ) {
						continue;
					}
					$settings = json_decode( rawurldecode( $atts['settings'] ), true );
					$id       = is_array( $settings ) && isset( $settings['popup'] ) ? $this->numeric( $settings['popup'] ) : 0;
					if ( $id ) {
						$refs[] = array(
							'kind'   => 'popup',
							'target' => $id,
							'detail' => 'a link that opens a popup, in ' . $where,
							'field'  => $field,
							'path'   => $path,
							'what'   => 'popup',
						);
					}
				}
			}

			// Other shortcodes that carry a known template ID in an attribute.
			if ( ! empty( $this->known ) && preg_match_all( '/\[([A-Za-z_][\w-]*)\s([^\]]*)\]/', $normal, $others, PREG_SET_ORDER ) ) {
				foreach ( $others as $m ) {
					if ( 'elementor-tag' === $m[1] ) {
						continue;
					}
					$atts = shortcode_parse_atts( $m[2] );
					if ( ! is_array( $atts ) ) {
						continue;
					}
					foreach ( $atts as $attr => $value ) {
						// An "id" attribute counts here: another add-on's embed shortcode (Dynific Addons' [INSERT_ELEMENTOR id="123"]) names the template that way.
						if ( ! is_string( $attr ) || ! is_string( $value ) || ( 'id' !== $attr && preg_match( self::IGNORED_NAMES, $attr ) ) ) {
							continue;
						}
						if ( in_array( $m[1], self::SHORTCODES, true ) && 'id' === $attr ) {
							continue;
						}
						foreach ( explode( ',', $value ) as $piece ) {
							$id = $this->numeric( trim( $piece ) );
							if ( $id && $id !== (int) $post_id && isset( $this->known[ $id ] ) ) {
								$refs[] = array(
									'kind'   => 'mention',
									'target' => $id,
									'detail' => 'the "' . $attr . '" of a [' . $m[1] . '] shortcode in ' . $where,
									'field'  => $field,
									'path'   => $path,
								);
							}
						}
					}
				}
			}
		}

		// Addresses such as ?p=123 or post=123.
		if ( ! empty( $this->known ) && preg_match_all( '/[?&;](?:p|post|post_id|page_id|template_id|elementor_library)=(\d{1,12})(?!\d)/i', $text, $urls ) ) {
			foreach ( $urls[1] as $digits ) {
				$id = (int) $digits;
				if ( $id && $id !== (int) $post_id && isset( $this->known[ $id ] ) ) {
					$refs[] = array(
						'kind'   => 'mention',
						'target' => $id,
						'detail' => 'a link address in ' . $where,
						'field'  => $field,
						'path'   => $path,
					);
				}
			}
		}
	}

	/**
	 * Popup links written as Elementor's own popup action address, as people paste it into a link field:
	 * #elementor-action:action=popup:open&settings=<base64 of {"id":"123"}>, raw, URL-encoded or HTML-escaped.
	 *
	 * @param string $text  Text.
	 * @param string $field Field the text came from.
	 * @param array  $path  Path of the text.
	 * @param string $where Words for where the text sits.
	 * @param array  $refs  Collected references.
	 */
	private function scan_popup_actions( $text, $field, array $path, $where, array &$refs ) {
		if ( false === stripos( $text, 'elementor-action' ) ) {
			return;
		}
		$plain = false !== strpos( $text, '&' ) ? html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : $text;
		$plain = rawurldecode( $plain );
		if ( false !== strpos( $plain, '%' ) ) {
			$plain = rawurldecode( $plain ); // A doubly encoded paste.
		}
		if ( ! preg_match_all( '/elementor-action:action=popup:[a-z]+&settings=([A-Za-z0-9+\/_=-]+)/i', $plain, $found ) ) {
			return;
		}
		foreach ( $found[1] as $encoded ) {
			$json     = base64_decode( strtr( $encoded, '-_', '+/' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Elementor's own popup address carries its settings as base64 JSON; the value is only parsed.
			$settings = false === $json ? null : json_decode( $json, true );
			$id       = is_array( $settings ) && isset( $settings['id'] ) ? $this->numeric( $settings['id'] ) : 0;
			if ( $id ) {
				$refs[] = array(
					'kind'   => 'popup',
					'target' => $id,
					'detail' => 'a link that opens a popup, in ' . $where,
					'field'  => $field,
					'path'   => $path,
					'what'   => 'popup',
				);
			}
		}
	}

	/**
	 * Settings of one block: a template ID under a name that says "template" is a use; any other
	 * number equal to a template ID is a mention.
	 *
	 * @param string $block    Block name, such as elementor/template.
	 * @param string $name     Name of the nearest setting.
	 * @param mixed  $value    Value.
	 * @param string $field    Field the text came from.
	 * @param array  $path     Path of the text.
	 * @param string $where    Words for where the text sits.
	 * @param array  $refs     Collected references.
	 * @param int    $post_id  Post being read.
	 * @param int    $depth    Depth.
	 */
	private function walk_block( $block, $name, $value, $field, array $path, $where, array &$refs, $post_id, $depth ) {
		if ( $depth > 12 ) {
			return;
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $child ) {
				$this->walk_block( $block, is_string( $key ) ? $key : $name, $child, $field, $path, $where, $refs, $post_id, $depth + 1 );
			}
			return;
		}
		$id = $this->numeric( $value );
		// The Elementor Template block always names a saved template, so a deleted one is reported as missing.
		$certain = 'elementor/template' === $block && 'selectedtemplate' === strtolower( $name );
		if ( ! $id || $id === (int) $post_id || ( ! $certain && ! isset( $this->known[ $id ] ) ) ) {
			return;
		}
		$is_use = $certain || false !== stripos( $name, 'template' );
		if ( ! $is_use && preg_match( self::IGNORED_NAMES, $name ) ) {
			return;
		}
		$words  = 'elementor/template' === $block ? 'the Elementor Template block' : 'the “' . $name . '” setting of a “' . $block . '” block';
		$refs[] = array(
			'kind'   => $is_use ? 'block' : 'mention',
			'target' => $id,
			'detail' => $words . ' in ' . $where,
			'field'  => $field,
			'path'   => $path,
		);
	}

	/**
	 * Some add-ons (Premium Addons) store the template's title, not its ID. A text equal to the title of a
	 * saved template, under a setting whose name says "temp", is a use; under another name that is not
	 * plain text it is a mention.
	 *
	 * @param string     $name    Setting name (the nearest name when the value sits in a list).
	 * @param string     $value   The text.
	 * @param string     $label   Widget label.
	 * @param array      $path    Path of the value.
	 * @param array      $refs    Collected references.
	 * @param int        $post_id Post being read.
	 */
	private function check_title( $name, $value, $label, array $path, array &$refs, $post_id ) {
		if ( ! $this->titles || strlen( $value ) > 200 || ! is_string( $name ) || '' === $name ) {
			return;
		}
		$lookup = '';
		foreach ( array( trim( $value ), trim( html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) as $candidate ) {
			$candidate = function_exists( 'mb_strtolower' ) ? mb_strtolower( $candidate, 'UTF-8' ) : strtolower( $candidate );
			if ( isset( $this->titles[ $candidate ] ) ) {
				$lookup = $candidate;
				break;
			}
		}
		if ( '' === $lookup ) {
			return;
		}
		$is_use = false !== stripos( $name, 'temp' );
		if ( ! $is_use && preg_match( self::TEXT_NAMES, $name ) ) {
			return;
		}
		foreach ( $this->titles[ $lookup ] as $id ) {
			if ( ! isset( $this->known[ $id ] ) || (int) $id === (int) $post_id ) {
				continue;
			}
			$refs[] = array(
				'kind'   => $is_use ? 'title' : 'mention',
				'target' => (int) $id,
				'detail' => $is_use ? $label . ' (the template is chosen by its title)' : $label . ', setting "' . $name . '" holds the title of a template',
				'field'  => 'elementor',
				'path'   => $path,
			);
		}
	}

	/**
	 * Alternation of the template shortcode tags for a quick pre-check.
	 *
	 * @return string
	 */
	private function tag_alternation() {
		return '(?:' . implode( '|', array_map( 'preg_quote', self::SHORTCODES ) ) . ')';
	}

	/**
	 * Straight quotes for the quote characters an editor may have saved.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public function normalise_quotes( $text ) {
		if ( false !== strpos( $text, '&' ) ) {
			$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
		return str_replace(
			array( "\u{201C}", "\u{201D}", "\u{201E}", "\u{201F}", "\u{2033}", "\u{2036}", "\u{2018}", "\u{2019}", "\u{201A}", "\u{201B}", "\u{2032}" ),
			array( '"', '"', '"', '"', '"', '"', "'", "'", "'", "'", "'" ),
			$text
		);
	}

	/**
	 * A positive whole number from an int or a string of digits, else 0.
	 *
	 * @param mixed $value Value.
	 * @return int
	 */
	public function numeric( $value ) {
		if ( is_int( $value ) ) {
			return $value > 0 ? $value : 0;
		}
		if ( is_string( $value ) && '' !== $value && strlen( $value ) <= 12 && ctype_digit( $value ) ) {
			return (int) $value;
		}
		return 0;
	}

	/**
	 * Words for where a template setting sits: the widget's own name where it is known, the setting name otherwise.
	 *
	 * @param string $label Widget label.
	 * @param string $name  Setting name.
	 * @return string
	 */
	private function setting_words( $label, $name ) {
		$known = array(
			'Template widget|template_id'  => 'Template widget',
			'Loop Grid widget|template_id' => 'Loop Grid widget (loop item)',
			'Essential Addons Advanced Tabs widget|eael_primary_templates' => 'Essential Addons Advanced Tabs widget (tab content)',
			'Essential Addons Advanced Accordion widget|eael_primary_templates' => 'Essential Addons Advanced Accordion widget (panel content)',
		);
		$key   = $label . '|' . $name;
		if ( isset( $known[ $key ] ) ) {
			return $known[ $key ];
		}
		// Any other add-on setting that names a saved template: say what it is, not the setting's code name.
		if ( preg_match( '/_templates?$/i', $name ) ) {
			return $label . ' (a saved template chosen in the widget)';
		}
		return $label . ', setting "' . $name . '"';
	}

	/**
	 * Human name of a widget, for messages.
	 *
	 * @param string $widget Widget type.
	 * @param string $el_type Element type.
	 * @return string
	 */
	private function widget_label( $widget, $el_type ) {
		$names = array(
			'text-editor'        => 'Text Editor widget',
			'shortcode'          => 'Shortcode widget',
			'html'               => 'HTML widget',
			'template'           => 'Template widget',
			'loop-grid'          => 'Loop Grid widget',
			'global'             => 'Global widget',
			'e-component'        => 'Component instance',
			'eael-adv-tabs'      => 'Essential Addons Advanced Tabs widget',
			'eael-adv-accordion' => 'Essential Addons Advanced Accordion widget',
			'eael-flip-box'      => 'Essential Addons Flip Box widget',
			'eael-info-box'      => 'Essential Addons Info Box widget',
			'eael-cta-box'       => 'Essential Addons Call to Action widget',
			'eael-countdown'     => 'Essential Addons Countdown widget',
		);
		if ( '' !== $widget ) {
			return isset( $names[ $widget ] ) ? $names[ $widget ] : ucfirst( str_replace( array( '-', '_' ), ' ', $widget ) ) . ' widget';
		}
		return '' !== $el_type ? ucfirst( $el_type ) . ' settings' : 'an element';
	}

	/**
	 * Drop references that repeat exactly.
	 *
	 * @param array $refs References.
	 * @return array
	 */
	private function unique( array $refs ) {
		$seen = array();
		$out  = array();
		foreach ( $refs as $ref ) {
			$key = $ref['kind'] . '|' . $ref['target'] . '|' . $ref['detail'] . '|' . wp_json_encode( $ref['path'] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = $ref;
		}
		return $out;
	}
}
