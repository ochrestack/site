<?php
/**
 * Storage for scan results: two tables of references, used in turn.
 *
 * A scan writes into the table that is not live; when it finishes the live
 * pointer flips, so the old report stays on screen until the new one is
 * complete and no row is ever deleted one by one.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Table names are built from $wpdb->prefix and a fixed suffix; they cannot be passed to prepare().
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter

/**
 * Reference tables.
 */
class Templatrail_Store {

	const DB_VERSION = '1';

	/**
	 * Table name for one of the two tables.
	 *
	 * @param string $which 'a' or 'b'.
	 * @return string
	 */
	public static function table( $which ) {
		global $wpdb;
		return $wpdb->prefix . 'templatrail_refs_' . ( 'b' === $which ? 'b' : 'a' );
	}

	/**
	 * Which table holds the finished scan.
	 *
	 * @return string 'a' or 'b'.
	 */
	public static function live_key() {
		return 'b' === get_option( 'templatrail_live', 'a' ) ? 'b' : 'a';
	}

	/**
	 * The table of the finished scan.
	 *
	 * @return string
	 */
	public static function live_table() {
		return self::table( self::live_key() );
	}

	/**
	 * The table a running scan writes into.
	 *
	 * @return string
	 */
	public static function building_table() {
		return self::table( 'a' === self::live_key() ? 'b' : 'a' );
	}

	/**
	 * Create the tables.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		foreach ( array( 'a', 'b' ) as $which ) {
			$name = self::table( $which );
			dbDelta(
				"CREATE TABLE {$name} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	source_type varchar(10) NOT NULL DEFAULT 'post',
	source_id bigint(20) unsigned NOT NULL DEFAULT 0,
	source_key varchar(64) NOT NULL DEFAULT '',
	target_id bigint(20) unsigned NOT NULL DEFAULT 0,
	kind varchar(20) NOT NULL DEFAULT '',
	detail varchar(255) NOT NULL DEFAULT '',
	PRIMARY KEY  (id),
	KEY target_id (target_id),
	KEY source_id (source_id)
) {$charset};"
			);
		}
		update_option( 'templatrail_db_version', self::DB_VERSION, true );
	}

	/**
	 * Create the tables when they are missing (plugin files copied in without activation).
	 */
	public static function maybe_install() {
		if ( get_option( 'templatrail_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	/**
	 * Empty the table a new scan will write into.
	 */
	public static function reset_building() {
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . self::building_table() );
	}

	/**
	 * Make the table that was being written the live one.
	 */
	public static function flip() {
		update_option( 'templatrail_live', 'a' === self::live_key() ? 'b' : 'a', true );
	}

	/**
	 * Insert references.
	 *
	 * @param string $table Table name.
	 * @param array  $rows  Rows with source_type, source_id, source_key, target_id, kind, detail.
	 */
	public static function insert( $table, array $rows ) {
		global $wpdb;
		foreach ( array_chunk( $rows, 100 ) as $chunk ) {
			$values = array();
			foreach ( $chunk as $row ) {
				$values[] = $wpdb->prepare(
					'(%s, %d, %s, %d, %s, %s)',
					$row['source_type'],
					$row['source_id'],
					$row['source_key'],
					$row['target_id'],
					$row['kind'],
					function_exists( 'mb_substr' ) ? mb_substr( $row['detail'], 0, 250 ) : substr( $row['detail'], 0, 250 )
				);
			}
			$wpdb->query( "INSERT INTO {$table} (source_type, source_id, source_key, target_id, kind, detail) VALUES " . implode( ', ', $values ) );
		}
	}
}
