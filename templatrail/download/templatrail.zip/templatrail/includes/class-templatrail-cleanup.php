<?php
/**
 * Cleanup that checks first: re-reads the site for the chosen templates and
 * moves to WordPress's Trash only those that still have no use found.
 * Nothing here deletes anything permanently.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Table names come from core's $wpdb properties; every value is prepared or cast.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

/**
 * Move to Trash and Restore.
 */
class Templatrail_Cleanup {

	/**
	 * Set while Restore runs, so the template returns with the status it had.
	 *
	 * @var bool
	 */
	private static $force_previous_status = false;

	const RECHECK_BATCH   = 100;
	const RECHECK_SECONDS = 25;

	/**
	 * Whether WordPress's Trash is on. With EMPTY_TRASH_DAYS at 0, wp_trash_post() deletes for good.
	 *
	 * @return bool
	 */
	public static function trash_available() {
		return ! defined( 'EMPTY_TRASH_DAYS' ) || (int) EMPTY_TRASH_DAYS > 0;
	}

	/**
	 * Fresh look at the site for these templates only.
	 *
	 * @param int[] $ids Template IDs (checked to be saved templates).
	 * @return array id => array( 'ok' => bool, 'reason' => string )
	 */
	public static function recheck( array $ids ) {
		global $wpdb;
		$ids     = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		$summary = Templatrail_Scan::summary();
		$report  = new Templatrail_Report();
		$out     = array();
		$valid   = array();

		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || 'elementor_library' !== $post->post_type ) {
				$out[ $id ] = array(
					'ok'     => false,
					'reason' => __( 'is not a saved template, or no longer exists.', 'templatrail' ),
				);
				continue;
			}
			if ( 'trash' === $post->post_status ) {
				$out[ $id ] = array(
					'ok'     => false,
					'reason' => __( 'is already in the Trash.', 'templatrail' ),
				);
				continue;
			}
			if ( null === $summary || ! isset( $summary['templates'][ $id ] ) || 'none' !== $summary['templates'][ $id ]['s'] ) {
				$out[ $id ] = array(
					'ok'     => false,
					'reason' => __( 'was not listed as “No use found” in the last scan. Scan again first.', 'templatrail' ),
				);
				continue;
			}
			$valid[ $id ] = true;
			$out[ $id ]   = array(
				'ok'     => true,
				'reason' => '',
			);
		}
		if ( ! $valid ) {
			return $out;
		}

		// Display conditions are read fresh.
		foreach ( array_keys( $valid ) as $id ) {
			$conditions = $report->conditions( $id );
			if ( $conditions ) {
				$out[ $id ] = array(
					'ok'     => false,
					'reason' => sprintf(
						/* translators: %s: Elementor Pro display conditions. */
						__( 'now has Elementor Pro display conditions (%s), which Templatrail does not judge.', 'templatrail' ),
						implode( ', ', $conditions )
					),
				);
			}
		}

		// The same reader as the scan, over every post the scan reads (not a search for the IDs: a search can only find
		// what its author thought of, and the scan reads more than that). Posts come in batches by ID.
		$known     = array_fill_keys( array_keys( $valid ), true );
		$extractor = new Templatrail_Extractor( $known, Templatrail_Report::title_map() );
		$deadline  = microtime( true ) + (float) apply_filters( 'templatrail_recheck_seconds', self::RECHECK_SECONDS );
		$last_id   = 0;
		do {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE ID > %d AND " . Templatrail_Scan::post_filter() . ' ORDER BY ID ASC LIMIT %d',
					$last_id,
					self::RECHECK_BATCH
				)
			);
			foreach ( (array) $rows as $row ) {
				$last_id = (int) $row->ID;
				foreach ( $extractor->extract_post( $last_id, $row->post_content, $row->post_excerpt ) as $ref ) {
					self::judge( $out, $valid, $ref, $last_id, $row->post_title );
				}
			}
			wp_cache_flush_runtime();
			$more = $rows && count( $rows ) === self::RECHECK_BATCH;
			if ( $more && microtime( true ) > $deadline ) {
				// Not read to the end: nothing may be moved on a check that did not finish.
				foreach ( array_keys( $valid ) as $id ) {
					$out[ $id ] = array(
						'ok'     => false,
						'reason' => __( 'could not be checked: the re-check needs more time than this server gives one request. Nothing was moved.', 'templatrail' ),
					);
				}
				return $out;
			}
		} while ( $more );
		foreach ( $extractor->extract_options() as $ref ) {
			self::judge( $out, $valid, $ref, 0, '' );
		}
		return $out;
	}

	/**
	 * Apply one found reference to the verdicts.
	 *
	 * @param array  $out    Verdicts, by reference.
	 * @param array  $valid  Templates being checked.
	 * @param array  $ref    Reference found.
	 * @param int    $source Source post ID (0 for an option).
	 * @param string $title  Source post title.
	 */
	private static function judge( array &$out, array $valid, array $ref, $source, $title ) {
		$target = (int) $ref['target'];
		if ( ! isset( $valid[ $target ] ) || $source === $target || ! $out[ $target ]['ok'] ) {
			return;
		}
		$name = '' !== $title ? $title : ( 'maintenance' === $ref['kind'] ? __( 'Maintenance Mode', 'templatrail' ) : __( 'a widget or setting', 'templatrail' ) );
		if ( 'mention' === $ref['kind'] ) {
			$out[ $target ] = array(
				'ok'     => false,
				'reason' => sprintf(
					/* translators: 1: where the ID appears, 2: title of the post that holds it. */
					__( 'now appears in a form Templatrail does not recognize (%1$s, in “%2$s”). Check by hand.', 'templatrail' ),
					$ref['detail'],
					$name
				),
			);
			return;
		}
		if ( 'maintenance' === $ref['kind'] ) {
			$out[ $target ] = array(
				'ok'     => false,
				'reason' => __( 'is now the Maintenance Mode template.', 'templatrail' ),
			);
			return;
		}
		$out[ $target ] = array(
			'ok'     => false,
			'reason' => sprintf(
				/* translators: 1: title of the place that uses it, 2: how, such as "shortcode in content". */
				__( 'gained a use: “%1$s” (%2$s).', 'templatrail' ),
				$name,
				Templatrail_Report::how_label( $ref['kind'] )
			),
		);
	}

	/**
	 * Posts that may hold a reference to any of these templates: their IDs as digits in content, excerpt,
	 * custom fields or Elementor data, and their titles in Elementor data (some add-ons store the title).
	 * The caller reads each post with the same Templatrail_Extractor the scan uses.
	 *
	 * @param int[] $ids Template IDs.
	 * @return array Post rows (ID, post_title, post_content, post_excerpt).
	 */
	public static function candidate_posts( array $ids ) {
		global $wpdb;
		$found = array();
		foreach ( array_chunk( $ids, 100 ) as $chunk ) {
			$digits = array();
			$titles = array();
			foreach ( $chunk as $id ) {
				$digits[] = '%' . $wpdb->esc_like( (string) $id ) . '%';
				$title    = (string) get_post_field( 'post_title', $id );
				if ( '' !== trim( $title ) ) {
					foreach ( array_unique( array( $title, html_entity_decode( $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) as $variant ) {
						$titles[] = '%' . $wpdb->esc_like( trim( $variant ) ) . '%';
						$encoded  = substr( (string) wp_json_encode( trim( $variant ) ), 1, -1 );
						if ( trim( $variant ) !== $encoded ) {
							$titles[] = '%' . $wpdb->esc_like( $encoded ) . '%';
						}
					}
				}
			}
			$content = array();
			$meta    = array();
			foreach ( $digits as $like ) {
				$content[] = $wpdb->prepare( '(post_content LIKE %s OR post_excerpt LIKE %s)', $like, $like );
				$meta[]    = $wpdb->prepare( 'meta_value LIKE %s', $like );
			}
			$elementor = $meta;
			foreach ( array_unique( $titles ) as $like ) {
				$elementor[] = $wpdb->prepare( 'meta_value LIKE %s', $like );
			}
			$from_content = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE " . implode( ' OR ', $content ) );
			$from_data    = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_elementor_data' AND (" . implode( ' OR ', $elementor ) . ')' );
			$from_meta    = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key <> '_elementor_data' AND meta_key NOT LIKE '\\_elementor\\_%' AND (" . implode( ' OR ', $meta ) . ')' );
			foreach ( array_merge( (array) $from_content, (array) $from_data, (array) $from_meta ) as $post_id ) {
				$found[ (int) $post_id ] = true;
			}
		}
		if ( ! $found ) {
			return array();
		}
		$rows  = array();
		$types = "'" . implode( "','", array_map( 'esc_sql', Templatrail_Scan::SKIP_TYPES ) ) . "'";
		foreach ( array_chunk( array_keys( $found ), 200 ) as $chunk ) {
			$part = $wpdb->get_results(
				"SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts} WHERE ID IN (" . implode( ',', array_map( 'intval', $chunk ) ) . ") AND post_status NOT IN ('trash', 'auto-draft', 'inherit') AND post_type NOT IN ({$types})"
			);
			$rows = array_merge( $rows, (array) $part );
		}
		return $rows;
	}

	/**
	 * Re-check the chosen templates, then move the clean ones to the Trash.
	 *
	 * @param int[] $ids Template IDs chosen on the screen.
	 * @return array moved (id => title), skipped (id => array( title, reason )).
	 */
	public static function trash( array $ids ) {
		$result = array(
			'moved'   => array(),
			'skipped' => array(),
		);
		$ids    = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( ! $ids ) {
			return $result;
		}
		if ( ! self::trash_available() ) {
			foreach ( $ids as $id ) {
				$result['skipped'][ $id ] = array(
					'title'  => get_the_title( $id ),
					'reason' => __( 'was left alone: the Trash is switched off on this site (EMPTY_TRASH_DAYS is 0), so moving it would delete it for good.', 'templatrail' ),
				);
			}
			return $result;
		}

		$verdicts = self::recheck( $ids );
		$trashed  = (array) get_option( 'templatrail_trashed', array() );
		foreach ( $ids as $id ) {
			$title = get_the_title( $id );
			if ( '' === $title ) {
				$title = '#' . $id;
			}
			if ( ! $verdicts[ $id ]['ok'] ) {
				$result['skipped'][ $id ] = array(
					'title'  => $title,
					'reason' => $verdicts[ $id ]['reason'],
				);
				continue;
			}
			$previous = get_post_status( $id );
			$moved    = self::without_revisions( 'wp_trash_post', $id );
			if ( ! $moved ) {
				$result['skipped'][ $id ] = array(
					'title'  => $title,
					'reason' => __( 'could not be moved: WordPress refused.', 'templatrail' ),
				);
				continue;
			}
			$trashed[ $id ]         = $previous;
			$result['moved'][ $id ] = $title;
		}
		update_option( 'templatrail_trashed', $trashed, false );
		Templatrail_Scan::refresh_summary();
		return $result;
	}

	/**
	 * Run a core function that changes a post's status without letting WordPress save a revision of it,
	 * so that moving to the Trash adds no rows beyond WordPress's own Trash bookkeeping.
	 *
	 * @param callable $callback Core function to run.
	 * @param int      $id       Post ID.
	 * @return mixed
	 */
	private static function without_revisions( $callback, $id ) {
		$had = has_action( 'post_updated', 'wp_save_post_revision' );
		if ( false !== $had ) {
			remove_action( 'post_updated', 'wp_save_post_revision', $had );
		}
		$result = call_user_func( $callback, $id );
		if ( false !== $had ) {
			add_action( 'post_updated', 'wp_save_post_revision', $had, 1 );
		}
		return $result;
	}

	/**
	 * Restore a template from the Trash with the status it had.
	 *
	 * @param int $id Template or Component ID.
	 * @return bool
	 */
	public static function restore( $id ) {
		$post = get_post( $id );
		if ( ! $post || ! in_array( $post->post_type, Templatrail_Report::POST_TYPES, true ) || 'trash' !== $post->post_status ) {
			return false;
		}
		self::$force_previous_status = true;
		$restored                    = self::without_revisions( 'wp_untrash_post', $id );
		self::$force_previous_status = false;
		if ( ! $restored ) {
			return false;
		}
		self::forget( $id );
		Templatrail_Scan::refresh_summary();
		return true;
	}

	/**
	 * Remove a template from the list of those Templatrail trashed.
	 *
	 * @param int $id Post ID.
	 */
	private static function forget( $id ) {
		$trashed = (array) get_option( 'templatrail_trashed', array() );
		if ( isset( $trashed[ $id ] ) ) {
			unset( $trashed[ $id ] );
			update_option( 'templatrail_trashed', $trashed, false );
		}
	}

	/**
	 * Filter for wp_untrash_post_status: a template Templatrail trashed comes back as it was
	 * (WordPress would otherwise return it as a draft, which Elementor does not show on pages).
	 *
	 * @param string $new_status      Status WordPress picked.
	 * @param int    $post_id         Post ID.
	 * @param string $previous_status Status before the Trash.
	 * @return string
	 */
	public static function untrash_status( $new_status, $post_id, $previous_status ) {
		$trashed = (array) get_option( 'templatrail_trashed', array() );
		if ( ( self::$force_previous_status || isset( $trashed[ $post_id ] ) ) && in_array( $previous_status, array( 'publish', 'private', 'draft', 'pending', 'future' ), true ) ) {
			if ( isset( $trashed[ $post_id ] ) && ! self::$force_previous_status ) {
				unset( $trashed[ $post_id ] );
				update_option( 'templatrail_trashed', $trashed, false );
			}
			return $previous_status;
		}
		return $new_status;
	}
}
