<?php
/**
 * The scan: reads the site in batches and writes references into the table
 * that is not live. When the last batch is done the table becomes live.
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Table names come from Templatrail_Store; every value is prepared or cast.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

/**
 * Batch scanner.
 */
class Templatrail_Scan {

	const BATCH         = 50;
	const BATCHES_STEP  = 4;
	const SUMMARY_BATCH = 25;
	const TIME_BUDGET   = 2.0;
	const LOCK_LIFETIME = 60;

	/**
	 * Post types that never hold a template reference.
	 *
	 * @var string[]
	 */
	const SKIP_TYPES = array( 'revision', 'nav_menu_item', 'attachment', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_global_styles', 'wp_font_family', 'wp_font_face' );

	/**
	 * SQL condition for the posts a scan (and the Move to Trash re-check) reads.
	 *
	 * The scan also reads posts in the Trash, only to say on a template's row that its sole use is a page in the Trash;
	 * a place in the Trash is never listed as a use, and the re-check does not read them.
	 *
	 * @param bool $with_trash Whether posts in the Trash are read too.
	 * @return string
	 */
	public static function post_filter( $with_trash = false ) {
		$types    = "'" . implode( "','", array_map( 'esc_sql', self::SKIP_TYPES ) ) . "'";
		$statuses = $with_trash ? "'auto-draft', 'inherit'" : "'trash', 'auto-draft', 'inherit'";
		return "post_status NOT IN ({$statuses}) AND post_type NOT IN ({$types})";
	}

	/**
	 * The running job, or null.
	 *
	 * @return array|null
	 */
	public static function job() {
		$job = get_option( 'templatrail_job' );
		return is_array( $job ) && isset( $job['id'] ) ? $job : null;
	}

	/**
	 * Start a scan. Whatever was running is abandoned; the finished report stays until this one ends.
	 *
	 * @return array Progress.
	 */
	public static function start() {
		global $wpdb;
		Templatrail_Store::maybe_install();
		Templatrail_Store::reset_building();
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE " . self::post_filter( true ) );
		$job   = array(
			'id'       => wp_generate_uuid4(),
			'phase'    => 'posts',
			'last_id'  => 0,
			'total'    => $total,
			'done'     => 0,
			'started'  => time(),
			'summary'  => array(),
			'loops'    => array(),
			'tpl_done' => 0,
			'tpl_ids'  => array(),
		);
		update_option( 'templatrail_job', $job, false );
		self::release();
		return self::progress( $job, false );
	}

	/**
	 * Take the lock that lets one request at a time write the job.
	 *
	 * @return bool
	 */
	private static function acquire() {
		if ( add_option( 'templatrail_lock', time(), '', false ) ) {
			return true;
		}
		$since = (int) get_option( 'templatrail_lock' );
		if ( time() - $since > self::LOCK_LIFETIME ) {
			update_option( 'templatrail_lock', time(), false );
			return true;
		}
		return false;
	}

	/**
	 * Give the lock back.
	 */
	private static function release() {
		delete_option( 'templatrail_lock' );
	}

	/**
	 * Run one batch.
	 *
	 * @param string $job_id Job the caller thinks is running.
	 * @return array|WP_Error Progress.
	 */
	public static function step( $job_id ) {
		$job = self::job();
		if ( ! $job || $job['id'] !== $job_id ) {
			return new WP_Error( 'templatrail_no_job', __( 'This scan is no longer running. Another scan was started or it already finished.', 'templatrail' ), array( 'status' => 409 ) );
		}
		if ( ! self::acquire() ) {
			return new WP_Error( 'templatrail_busy', __( 'The scan is working on the previous step. Please wait a moment.', 'templatrail' ), array( 'status' => 409 ) );
		}
		$began = microtime( true );
		try {
			$job = self::job();
			if ( 'posts' === $job['phase'] ) {
				$job = self::step_posts( $job, $began );
			} elseif ( 'options' === $job['phase'] ) {
				$job = self::step_options( $job );
			} else {
				$job = self::step_summary( $job, $began );
			}
		} finally {
			self::release();
		}
		return self::progress( $job, 'done' === $job['phase'] );
	}

	/**
	 * Progress numbers for the screen.
	 *
	 * @param array $job      Job.
	 * @param bool  $finished Whether the scan is complete.
	 * @return array
	 */
	public static function progress( array $job, $finished ) {
		// Fixed shares keep the bar moving forward: posts 0-80, settings 80-85, templates 85-99.
		if ( 'posts' === $job['phase'] ) {
			$percent = (int) floor( 80 * (int) $job['done'] / max( 1, (int) $job['total'] ) );
		} elseif ( 'options' === $job['phase'] ) {
			$percent = 80;
		} elseif ( 'summary' === $job['phase'] ) {
			$percent = 85 + (int) floor( 14 * (int) $job['tpl_done'] / max( 1, count( $job['tpl_ids'] ) ) );
		} else {
			$percent = 100;
		}
		$percent    = $finished ? 100 : min( 99, $percent );
		$phase_text = array(
			'posts'   => sprintf(
				/* translators: 1: posts read so far, 2: all posts. */
				__( 'Reading posts: %1$d of %2$d', 'templatrail' ),
				(int) $job['done'],
				(int) $job['total']
			),
			'options' => __( 'Reading widgets and Elementor settings', 'templatrail' ),
			'summary' => sprintf(
				/* translators: 1: templates checked so far, 2: all templates. */
				__( 'Following templates inside templates: %1$d of %2$d', 'templatrail' ),
				(int) $job['tpl_done'],
				count( $job['tpl_ids'] )
			),
			'done'    => __( 'Scan finished.', 'templatrail' ),
		);
		return array(
			'job'      => $job['id'],
			'phase'    => $job['phase'],
			'percent'  => $percent,
			'finished' => (bool) $finished,
			'message'  => $phase_text[ $job['phase'] ],
		);
	}

	/**
	 * IDs of existing templates and Components (as keys).
	 *
	 * @return array
	 */
	private static function known() {
		$report = new Templatrail_Report( Templatrail_Store::building_table() );
		return array_fill_keys( array_keys( $report->templates() ), true );
	}

	/**
	 * A reader for this scan: knows the existing templates and their titles.
	 *
	 * @return Templatrail_Extractor
	 */
	private static function extractor() {
		return new Templatrail_Extractor( self::known(), Templatrail_Report::title_map() );
	}

	/**
	 * One batch of posts.
	 *
	 * @param array $job   Job.
	 * @param float $began Start time of this step.
	 * @return array Job.
	 */
	private static function step_posts( array $job, $began ) {
		global $wpdb;
		$extractor = self::extractor();
		$table     = Templatrail_Store::building_table();
		$batches   = 0;
		do {
			++$batches;
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE ID > %d AND " . self::post_filter( true ) . ' ORDER BY ID ASC LIMIT %d',
					$job['last_id'],
					self::BATCH
				)
			);
			if ( ! $rows ) {
				$job['phase'] = 'options';
				break;
			}
			$batch = array();
			foreach ( $rows as $row ) {
				foreach ( $extractor->extract_post( (int) $row->ID, $row->post_content, $row->post_excerpt ) as $ref ) {
					if ( ! empty( $ref['copy'] ) ) {
						continue; // The rendered copy of a use already stored from Elementor's data.
					}
					$key                            = $ref['kind'] . '|' . $ref['target'] . '|' . $ref['detail'];
					$batch[ $row->ID . '|' . $key ] = array(
						'source_type' => 'post',
						'source_id'   => (int) $row->ID,
						'source_key'  => substr( (string) $ref['field'], 0, 20 ),
						'target_id'   => (int) $ref['target'],
						'kind'        => $ref['kind'],
						'detail'      => $ref['detail'],
					);
				}
				$job['last_id'] = (int) $row->ID;
				++$job['done'];
			}
			if ( $batch ) {
				Templatrail_Store::insert( $table, array_values( $batch ) );
			}
			wp_cache_flush_runtime();
		} while ( $batches < self::BATCHES_STEP && ( microtime( true ) - $began ) < self::TIME_BUDGET );
		update_option( 'templatrail_job', $job, false );
		return $job;
	}

	/**
	 * Widgets, Maintenance Mode and Elementor's own options.
	 *
	 * @param array $job Job.
	 * @return array Job.
	 */
	private static function step_options( array $job ) {
		$extractor = self::extractor();
		$batch     = array();
		foreach ( $extractor->extract_options() as $ref ) {
			$batch[] = array(
				'source_type' => 'option',
				'source_id'   => 0,
				'source_key'  => $ref['source_key'],
				'target_id'   => (int) $ref['target'],
				'kind'        => $ref['kind'],
				'detail'      => $ref['detail'],
			);
		}
		if ( $batch ) {
			Templatrail_Store::insert( Templatrail_Store::building_table(), $batch );
		}
		$report         = new Templatrail_Report( Templatrail_Store::building_table() );
		$job['tpl_ids'] = array_keys( $report->templates() );
		$job['phase']   = 'summary';
		update_option( 'templatrail_job', $job, false );
		return $job;
	}

	/**
	 * Work out the status of each template, in chunks, then publish the scan.
	 *
	 * @param array $job   Job.
	 * @param float $began Start time of this step.
	 * @return array Job.
	 */
	private static function step_summary( array $job, $began ) {
		$report = new Templatrail_Report( Templatrail_Store::building_table() );
		do {
			$chunk = array_slice( $job['tpl_ids'], $job['tpl_done'], self::SUMMARY_BATCH );
			if ( ! $chunk ) {
				break;
			}
			foreach ( $report->summarise( $chunk ) as $id => $summary ) {
				$job['summary'][ $id ] = $summary;
			}
			$job['tpl_done'] += count( $chunk );
			wp_cache_flush_runtime();
		} while ( ( microtime( true ) - $began ) < self::TIME_BUDGET );

		foreach ( $report->loops() as $loop ) {
			$job['loops'][ implode( '>', $loop ) ] = $loop;
		}

		if ( $job['tpl_done'] >= count( $job['tpl_ids'] ) ) {
			self::publish( $job );
			$job['phase'] = 'done';
			return $job;
		}
		update_option( 'templatrail_job', $job, false );
		return $job;
	}

	/**
	 * Make the finished scan the report.
	 *
	 * @param array $job Job.
	 */
	private static function publish( array $job ) {
		update_option(
			'templatrail_summary',
			array(
				'at'        => time(),
				'v'         => TEMPLATRAIL_VERSION,
				'posts'     => (int) $job['done'],
				'templates' => $job['summary'],
				'loops'     => array_values( $job['loops'] ),
			),
			false
		);
		Templatrail_Store::flip();
		delete_option( 'templatrail_changed' );
		delete_option( 'templatrail_job' );
	}

	/**
	 * The stored summary of the last finished scan, or null.
	 *
	 * @return array|null
	 */
	public static function summary() {
		$summary = get_option( 'templatrail_summary' );
		return is_array( $summary ) && isset( $summary['templates'] ) ? $summary : null;
	}

	/**
	 * Recompute the summary of every template from the live table (after templates were trashed or restored).
	 */
	public static function refresh_summary() {
		$summary = self::summary();
		if ( null === $summary ) {
			return;
		}
		$report               = new Templatrail_Report();
		$summary['templates'] = $report->summarise();
		$summary['loops']     = array();
		foreach ( $report->loops() as $loop ) {
			$summary['loops'][] = $loop;
		}
		update_option( 'templatrail_summary', $summary, false );
	}

	/**
	 * Run a whole scan in this request (tests and WP-CLI-style callers).
	 *
	 * @return array Last progress.
	 */
	public static function run_all() {
		$progress = self::start();
		$guard    = 0;
		while ( ! $progress['finished'] && $guard++ < 100000 ) {
			$progress = self::step( $progress['job'] );
			if ( is_wp_error( $progress ) ) {
				return array( 'error' => $progress->get_error_message() );
			}
		}
		return $progress;
	}
}
