<?php
/**
 * Plugin Name:       Templatrail – Where Elementor Templates Are Used
 * Description:       See which pages use each saved Elementor template. Trash the ones with no use found: re-checked first, restorable from Elementor’s Trash.
 * Version:           1.0.5
 * Requires at least: 6.8
 * Requires PHP:      7.4
 * Requires Plugins:  elementor
 * Author:            Ochrestack
 * Author URI:        https://ochrestack.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       templatrail
 *
 * @package Templatrail
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TEMPLATRAIL_VERSION', '1.0.5' );
define( 'TEMPLATRAIL_FILE', __FILE__ );
define( 'TEMPLATRAIL_DIR', plugin_dir_path( __FILE__ ) );
define( 'TEMPLATRAIL_URL', plugin_dir_url( __FILE__ ) );

require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-store.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-extractor.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-report.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-scan.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-cleanup.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-rest.php';
require_once TEMPLATRAIL_DIR . 'includes/class-templatrail-admin.php';

/**
 * Activation: create the tables and leave one line for the Plugins screen.
 */
function templatrail_activate() {
	Templatrail_Store::install();
	set_transient( 'templatrail_activated', 1, MINUTE_IN_SECONDS );
}
register_activation_hook( __FILE__, 'templatrail_activate' );

/**
 * Start the plugin.
 */
function templatrail_boot() {
	Templatrail_Rest::init();
	add_filter( 'wp_untrash_post_status', array( 'Templatrail_Cleanup', 'untrash_status' ), 10, 3 );
	if ( is_admin() ) {
		Templatrail_Admin::init();
	}
}
add_action( 'plugins_loaded', 'templatrail_boot' );
