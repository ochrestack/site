=== Templatrail – Where Elementor Templates Are Used ===
Contributors: ochrestack
Tags: elementor, elementor-template, elementor-templates, unused, cleanup
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

See which pages use each saved Elementor template. Trash the ones with no use found: re-checked first, restorable from Elementor’s Trash.

== Description ==

“I’m pretty sure I have a load of templates that are no longer used anywhere.” (a user on Elementor’s GitHub issue tracker)

Templatrail shows the pages that use each saved Elementor template, and lists the ones with no use found. Templatrail Pro, a separate add-on, adds Replace everywhere (point one template’s pages at another of the same kind, a revision saved first) and CSV export; the report and the cleanup are free.

After a few years an Elementor site has a library full of saved templates and nobody dares to delete from it. Press Scan site under Tools > Templatrail: it reads the site once, in batches with a progress bar, and tells you where each template is used.

**What you get, free**

* **Tools > Templatrail**: press **Scan site**. For every saved template and Component, the report shows its title, type, status and the number of places that use it, and lists each place by name with how it is used and an Edit link (drafts and private posts included, the Trash left out). A search box finds a template by name.
* A **Used on** column in Elementor’s Saved Templates list, with the same count.
* **Templates inside templates** are followed to the pages that show the outer one.
* **Missing templates**: every page, post or template that points, by ID and in a form Templatrail recognizes, at a template that was deleted or is in the Trash, with an Edit link and, for the Trash, a Restore link.
* **Three statuses**: In use, No use found, and Check by hand (Elementor Pro display conditions, the Maintenance Mode template, or an ID Templatrail finds in a form it does not recognize, shown with where).
* **Cleanup that checks first**: only No use found templates can be selected. Move to Trash reads the site again for them, leaves out any that gained a use and says which and why, and moves the rest to WordPress’s own Trash, where Elementor’s Trash view restores them. Templatrail deletes nothing for good.

Templatrail is independent. It is not affiliated with or endorsed by Elementor, Elementor Blocks for Gutenberg, Essential Addons for Elementor, Premium Addons for Elementor, Show template by shortcode for Elementor or UltraAddons for Elementor.

== Installation ==

1. In WordPress go to Plugins > Add Plugin, press Upload Plugin, choose templatrail.zip and press Install Now.
2. Press Activate Plugin. Elementor has to be active; WordPress asks for it.
3. Open Tools > Templatrail and press Scan site.

== Frequently Asked Questions ==

= Can I delete the templates nothing uses? =

Templatrail moves the templates you select to WordPress’s Trash after a re-check, and you can restore them from Elementor’s Trash view. It deletes nothing for good, but WordPress empties its Trash after 30 days by default, so restore anything you want to keep before then.

= Why does a template I inserted show no uses? =

In free Elementor, inserting a saved template into a page copies it. The copy no longer points at the original, so the page is not a use of it.

= Does it work with Elementor Pro? =

Templatrail reads the formats Elementor Pro writes (Template and Loop Grid widgets, global widgets, popup links made with its Popup tag or popup action address, display conditions). Elementor Pro itself was not part of its tests; those formats were tested as saved data.

= Does it change or delete anything? =

A scan writes only to Templatrail’s own tables and options. Move to Trash moves the templates you selected to WordPress’s Trash, after the re-check, and changes no other post.

= Does it send anything anywhere? =

No. Neither Templatrail nor Templatrail Pro contacts any server. See External services.

= What does Check by hand mean? =

Templatrail could not tell, and shows its reason: Elementor Pro display conditions, the Maintenance Mode template, or an ID (or a title) in a place it reads but in a form it does not recognize.

= What does Templatrail recognize as a use? =

It reads post content and excerpts, custom fields, Elementor’s page data, classic widgets, Elementor’s own settings and site settings that hold a template shortcode. It recognizes:

* the shortcodes that place a saved template by ID: Elementor Pro’s `[elementor-template id="…"]` and the ones of Show template by shortcode for Elementor and UltraAddons for Elementor, in content, excerpts (a WooCommerce product’s short description), custom fields, the Shortcode, Text Editor and HTML widgets, classic text and block widgets, and site settings;
* Elementor settings that hold a saved template’s ID under a name containing “template”, at any depth including repeater rows (the Template and Loop Grid widgets, Essential Addons for Elementor’s Advanced Tabs), and global widgets;
* Elementor Template blocks (Elementor Blocks for Gutenberg), and other blocks with the ID under a name containing “template”;
* a template an add-on chooses by title, in a setting whose name contains “temp” (Premium Addons for Elementor stores the title, not the ID);
* popups opened by a link (the Popup dynamic tag, or Elementor’s popup action address pasted into a link), Component instances, and Elementor’s Maintenance Mode template.

An ID counts only when it belongs to an existing saved template or Component. Anything else is not counted as a use; if the template’s ID, or its exact title in a setting that is not plain text, appears in a place Templatrail reads, the template is Check by hand and the place is shown.

= What does it not see? =

A template inserted into a page as a copy is not a use: the copy no longer points at the template. Templatrail does not read term, user or comment fields, menus, PHP theme files, plugins’ own database tables, other add-ons’ own template post types, translation links (WPML, Polylang), or other sites of a multisite network. A template used only inside a template that has no use found is In use, and the screen names that template. Missing templates lists references by ID, so a template an add-on names by title cannot appear there. “No use found” means no use was found in the places Templatrail reads.

= What do WordPress and Elementor already do? =

Elementor’s Saved Templates screen has Move to Trash and Export. Elementor Pro’s Theme Builder shows where headers, footers and popups apply. Templatrail marks a Theme Builder template that has display conditions Check by hand and does not let you select it; one with no conditions is judged like any other template. A careful admin can search the database for a template’s ID in Elementor’s saved page data and in post content. Templatrail does that search across the whole site, follows templates inside other templates to the pages that show them, and writes the answer in plain words, in the places listed above.

= Where do I get help? =

Write to support@ochrestack.com.

== External services ==

Templatrail and Templatrail Pro do not contact any outside server, send no data to Ochrestack or anyone else, and carry no analytics. Scan results are stored in your site’s own database (two tables named templatrail_refs_a and templatrail_refs_b, and a few options) and are removed when you delete the plugin.

== Screenshots ==

1. Where one template is used: every place, how it is used, and its Edit link. One of the places is a template that holds the first one.
2. The Used on column in Elementor’s Saved Templates list.
3. Templates with No use found, selected for cleanup.
4. The result of Move to Trash: what was moved, and a template that gained a use before the re-check and was left alone.
5. Elementor’s Trash view, where the moved templates can be restored.
6. Missing templates: pages that point at a template that was deleted or is in the Trash, with a Restore link.

== Changelog ==

= 1.0.7 =
* A search box beside the tabs finds templates by name. Names are listed in natural order, so “Section 2” comes before “Section 10”.
* A template that gained a use since the scan is counted beside Move selected to Trash (“0 of 1 selected, 1 changed since the scan”).
* The line about what Templatrail cannot read is a warning notice above Move selected to Trash.

= 1.0.6 =
* A template that needs a check by hand says where its ID turned up in plain words, and the line about Templatrail Pro under the report links to the product page.

= 1.0.5 and earlier =
* Long lists have WordPress’s pager and a Move selected to Trash button under the rows; a large result starts with the count and the Trash link. While a scan runs the old report is dimmed.
* When nothing on a tab can be ticked there is no “0 of 0 selected” counter, and the greyed button says why.
* Missing templates is tidier, and a Check by hand template no longer says that no place uses it.

= Before 1.0.4 =
* Each place has one Edit link, and it opens the editor where the reference sits. A template’s name opens its own screen; Move to Trash comes back to the tab you were on.
* Reads post excerpts, custom fields, Elementor Template blocks, other blocks, site settings and templates an add-on chooses by title; the Move to Trash re-check reads the same places as the scan; a popup opened by Elementor’s popup action address is a use.
* Says what Templatrail cannot see, marks a row the re-check changed, and says when a template is used only by a page in the Trash.

== Upgrade Notice ==

= 1.0.7 =
A name search and natural order in the report, and a clearer count when a template gained a use since the scan.

= 1.0.6 =
Plainer wording for templates that need a check by hand, and a link to Templatrail Pro.
