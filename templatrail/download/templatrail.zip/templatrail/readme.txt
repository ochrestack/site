=== Templatrail – Where Elementor Templates Are Used ===
Contributors: ochrestack
Tags: elementor, templates, usage, cleanup, report
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Shows which pages use each saved Elementor template, lists the ones with no use found, and moves those to the Trash after a re-check.

== Description ==

“I'm pretty sure I have a load of templates that are no longer used anywhere.” (a user on Elementor's GitHub issue tracker) Templatrail shows the pages that use each saved Elementor template, and lists the ones with no use found.

After a few years an Elementor site has a library full of saved templates and nobody dares to delete from it. Press Scan site under Tools > Templatrail: it reads the site once, in batches with a progress bar, and tells you where each template is used.

**What you get, free**

* **Tools > Templatrail**: press **Scan site**. For every saved template (sections, containers, pages, global widgets, popups, loop items, Theme Builder templates) and every Component, the report shows its title, type, status, the number of places that use it, and each place: the page, post, template or setting by name, its type and status (drafts and private posts included, the Trash left out), how it is used, and an Edit with Elementor link.
* A **Used on** column in Elementor's Saved Templates list, with the same count.
* **Templates inside templates** are followed to the pages that show the outer one. A loop of templates that point at each other is stopped and reported.
* **Missing templates**: every page, post or template that points, by ID and in a form Templatrail recognizes, at a template that was deleted or is in the Trash, with an Edit link and, for the Trash, a Restore link.
* **Three statuses**: In use, No use found, and Check by hand (Elementor Pro display conditions, the Maintenance Mode template, or an ID in a place Templatrail reads but in a form it does not recognize, shown with where).
* **Cleanup that checks first**: only No use found templates can be selected. Move to Trash reads the site again for them, leaves out any that gained a use and says which and why, and moves the rest to WordPress's own Trash, where Elementor's Trash view restores them. Templatrail deletes nothing for good.

**What counts as a use**

Templatrail reads post content and excerpts, custom fields, Elementor's page data, classic widgets, Elementor's own settings and any site setting holding a template shortcode. There it recognizes:

* the shortcodes that place a saved template by ID: `[elementor-template id="…"]`, `[AETS_Template id="…"]` (Show template by shortcode for Elementor), `[UltraAddons_Template id="…"]` and `[UA_Template id="…"]` (UltraAddons for Elementor), in content, excerpts (a WooCommerce product's short description), custom fields, the Shortcode, Text Editor and HTML widgets, classic text and block widgets, and site settings;
* Elementor settings that hold a saved template's ID under a name containing "template", at any depth including repeater rows (the Template and Loop Grid widgets, Essential Addons for Elementor's Advanced Tabs), and global widgets;
* Elementor Template blocks (Elementor Blocks for Gutenberg), and other blocks with the ID under a name containing "template";
* a template an add-on chooses by title, in a setting whose name contains "temp" (Premium Addons for Elementor stores the title, not the ID);
* popups opened by a link's popup dynamic tag, Component instances, and Elementor's Maintenance Mode template.

An ID counts only when it belongs to an existing saved template or Component. Anything else is not counted as a use; if the template's ID, or its exact title in a setting that is not plain text, appears in a place Templatrail reads, the template is Check by hand and the place is shown.

**What it does not see**

A template inserted into a page as a copy is not a use: the copy no longer points at the template. Templatrail does not read term, user or comment fields, menus, PHP theme files, plugins' own database tables, other add-ons' own template post types, translation links (WPML, Polylang), or other sites of a multisite network. A template used only inside a template that has no use found is In use, and the screen names that template. Missing templates lists references by ID, so a template an add-on names by title cannot appear there. "No use found" means no use was found in the places Templatrail reads.

**What WordPress and Elementor already do**

Elementor's Saved Templates screen has Move to Trash and Export. Elementor Pro's Theme Builder shows where headers, footers and popups apply; Templatrail lists those templates but never judges them. A careful admin can search the database for a template's ID in Elementor's saved page data and in post content. Templatrail does that search across the whole site, follows templates inside other templates to the pages that show them, and writes the answer in plain words, in the places listed above.

**Templatrail Pro**

A separate add-on, Templatrail Pro, adds Replace everywhere (point the shortcodes and widget settings of one template at another of the same kind, a revision saved first) and CSV export. The report and the cleanup stay free.

Templatrail is independent. It is not affiliated with or endorsed by Elementor, Elementor Blocks for Gutenberg, Essential Addons for Elementor, Premium Addons for Elementor, Show template by shortcode for Elementor or UltraAddons for Elementor.

== Installation ==

1. In WordPress go to Plugins > Add Plugin, search for "Templatrail" and press Install Now. Or press Upload Plugin there, choose templatrail.zip and press Install Now.
2. Press Activate Plugin. Elementor has to be active; WordPress asks for it.
3. Open Tools > Templatrail and press Scan site.

== Frequently Asked Questions ==

= Can I delete the templates nothing uses? =

Templatrail moves the templates you select to WordPress's Trash after a re-check, and you can restore them from Elementor's Trash view. It deletes nothing for good, but WordPress empties its Trash after 30 days by default, so restore anything you want to keep before then. "No use found" means no use was found in the places Templatrail reads, so read the limits above first.

= Why does a template I inserted show no uses? =

In free Elementor, inserting a saved template into a page copies it. The copy no longer points at the original, so the page is not a use of it.

= Does it work with Elementor Pro? =

Templatrail reads the formats Elementor Pro writes (Template and Loop Grid widgets, global widgets, popup links, display conditions). Elementor Pro itself was not part of its tests; those formats were tested as saved data. Templates with display conditions are Check by hand and never offered for cleanup.

= Does it change or delete anything? =

A scan writes only to Templatrail's own tables and options. Move to Trash moves the templates you selected to WordPress's Trash, after the re-check, and changes no other post. Deleting the plugin removes its tables and options and leaves your templates and pages alone.

= Does it send anything anywhere? =

No. Neither Templatrail nor Templatrail Pro contacts any server. See External services.

= What does Check by hand mean? =

Templatrail could not tell, and shows its reason: Elementor Pro display conditions, the Maintenance Mode template, or an ID (or a title) in a place it reads but in a form it does not recognize. Such templates cannot be selected for cleanup.

= Where do I get help? =

Write to support@ochrestack.com.

== External services ==

Templatrail and Templatrail Pro do not contact any outside server, send no data to Ochrestack or anyone else, and carry no analytics. Scan results are stored in your site's own database (two tables named templatrail_refs_a and templatrail_refs_b, and a few options) and are removed when you delete the plugin.

== Screenshots ==

1. Where one template is used: every place, how it is used, and an Edit with Elementor link. One of the places is a template that holds the first one.
2. The Used on column in Elementor's Saved Templates list.
3. Templates with No use found, selected for cleanup.
4. The result of Move to Trash: what was moved, and a template that gained a use before the re-check and was left alone.
5. Elementor's Trash view, where the moved templates can be restored.
6. Missing templates: pages that point at a template that was deleted or is in the Trash, with a Restore link.

== Changelog ==

= 1.0.1 =
* Reads post excerpts, custom fields, Elementor Template blocks, other blocks, site settings with a template shortcode, and templates an add-on chooses by title. Before, a template placed only there was listed as No use found.
* The Move to Trash re-check reads the same places as the scan.
* Editors no longer see the Used on column.
* A template used only inside a template with no use found says so.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.0.1 =
Templates placed in excerpts, blocks, custom fields, site settings or by an add-on's title were listed as No use found. Press Scan again after updating.

= 1.0.0 =
First release.
